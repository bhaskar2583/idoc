﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace IBS.Core.Models
{
    public class AddPolicyBudget
    {
        public int Id { get; set; }
        public int ClientPolicyId { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public int CarrierId { get; set; }
        public string CarrierName { get; set; }
        public int PolicyId { get; set; }
        public string PolicyNumber { get; set; }
        public int CoverageId { get; set; }
        public string Coverage { get; set; }
        public string Division { get; set; }
        public int CarId { get; set; }
        public string CarName { get; set; }

        public int ProductId { get; set; }
        public int CProductId { get; set; }
        public string Product { get; set; }
        public string CFProduct { get; set; }
        [Range(1, int.MaxValue, ErrorMessage = "Please enter year")]
        public int Year { get; set; }
        [Required]
        public decimal JanBudget { get; set; }
        public decimal FebBudget { get; set; }
        public decimal MarchBudget { get; set; }
        public decimal AprilBudget { get; set; }
        public decimal MayBudget { get; set; }
        public decimal JunBudget { get; set; }
        public decimal JulyBudget { get; set; }
        public decimal AugBudget { get; set; }
        public decimal SepBudget { get; set; }
        public decimal OctBudget { get; set; }
        public decimal NovBudget { get; set; }
        public decimal DecBudget { get; set; }
        public decimal TotalBudget { get; set; }
    }
    public class PolicyBudgetsModel
    {
        public int CarId { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string CarrierName { get; set; }
        public int PolicyId { get; set; }
        public int CoverageId { get; set; }
        public string Coverage { get; set; }
        public int ProductId { get; set; }
        public int CFProductId { get; set; }
        public string CFProduct { get; set; }
        public string Division { get; set; }
        public int DivisionId { get; set; }
        public string PolicyNumber { get; set; }
        public int Year { get; set; }
        public decimal JanBudget { get; set; }
        public decimal FebBudget { get; set; }
        public decimal MarchBudget { get; set; }
        public decimal AprilBudget { get; set; }
        public decimal MayBudget { get; set; }
        public decimal JunBudget { get; set; }
        public decimal JulyBudget { get; set; }
        public decimal AugBudget { get; set; }
        public decimal SepBudget { get; set; }
        public decimal OctBudget { get; set; }
        public decimal NovBudget { get; set; }
        public decimal DecBudget { get; set; }
        public decimal TotalBudget { get; set; }
    }
}