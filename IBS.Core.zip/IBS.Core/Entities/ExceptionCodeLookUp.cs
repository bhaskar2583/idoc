﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBS.Core.Entities
{
    public class ExceptionCodeLookUp
    {
        public int Id { get; set; }

        public int ExceptionCode { get; set; }

        public string ExceptionDescription { get; set; }
    }
}
