﻿using IBSSchedular.Core.Data.visitor;
using IBSSchedular.Core.SFDC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.Data.Product
{
    public class ProductDataUpdate : IAccept
    {
        private Product2 _product;
       
        public void Accept(IVisitor visitor)
        {
            visitor.Visit(_product);
        }
        public void AddProduct(Product2 product)
        {
            _product = product;
        }
    }
}
