﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IBS.Service.Repositories;
using IBS.Service.Utils;
using IBSSchedular.Core.SFDC;

namespace IBSSchedular.Core.Data.visitor
{
    public class DataUpdateVisitor : IVisitor
    {
        private readonly IClientRepository _clientRepository;
        public DataUpdateVisitor()
        {
            _clientRepository = new ClientRepository();
        }
        public bool Visit(Account account)
        {
            var isExist = _clientRepository.GetAll().FirstOrDefault(a => a.Name == account.Name);

            if (isExist == null)
                _clientRepository.Add(new IBS.Core.Entities.Client()
                {
                    Name = account.Name,
                    IsActive = true,
                    Division = "",
                    AddUser = "IBS Service",
                    AddDate = DateUtil.GetCurrentDate()
                });

            return true;
        }

        public bool Visit(Product2 product)
        {
            throw new NotImplementedException();
        }
    }
}
