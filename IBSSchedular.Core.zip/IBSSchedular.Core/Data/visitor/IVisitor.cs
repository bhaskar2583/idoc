﻿using IBSSchedular.Core.SFDC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.Data.visitor
{
    public interface IVisitor
    {
        bool Visit(Account accouunt);
        bool Visit(Product2 product);
    }
}
