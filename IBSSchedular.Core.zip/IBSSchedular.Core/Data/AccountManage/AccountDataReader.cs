﻿using IBSSchedular.Core.Data.visitor;
using IBSSchedular.Core.SalesForce;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.Data.AccountManage
{
    public class AccountDataReader : ISfDataReader
    {
        private readonly SfAccountData _accountData;
        private readonly AccountDataUpdate _accountUpdate;
        private IVisitor _visitor;
        public AccountDataReader()
        {
            _accountData = new SfAccountData();
            _accountUpdate = new AccountDataUpdate();
            _visitor = new DataUpdateVisitor();
        }
        public void ReadData()
        {
            var accounts = _accountData.GetAllAccounts();
            accounts.ForEach(a =>
            {
                //_accountUpdate.AddClient(a, _visitor);
            });
            Console.WriteLine("AccountDataReader start");
            
        }
    }
}
