﻿using IBSSchedular.Core.SFDC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.SalesForce
{
    public class SfProduct
    {
        private const string productSfQuery = "select ID,Name,Account__c,IsActive,Annual_Commission__c,Annual_Premium__c,Coverage_Type__c,Division__c,Effective_Date__c,Partner_Record_Keeper__c,ProductCode,Description,Product_Number__c,Product_Status__c,Product_Type__c from Product2";
        public List<Product2> GetAllProducts()
        {

            var accountDetails = new List<Product2>();
            var sfConnection = SfLogin.GetSalesForceInstance();

            if (sfConnection == null)
                return accountDetails;

            QueryResult queryResult = sfConnection.query(productSfQuery);

            if (queryResult.size > 0)
            {

                queryResult.records.ToList().ForEach(a =>
                {
                    Product2 account = (Product2)a;
                    accountDetails.Add(account);
                });

            }

            return accountDetails;

        }
    }
}
