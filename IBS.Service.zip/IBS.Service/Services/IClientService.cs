﻿using IBS.Core.Enums;
using IBS.Core.Models;
using System.Collections.Generic;

namespace IBS.Service.Services
{
    public interface IClientService
    {
        IList<ClientModel> GetAllClients();
        ClientModel GetById(int Id);
        bool AddClient(ClientModel client);
        bool ModifyClient(ClientModel client);
        bool DeleteClient(int clientId);
        IList<ClientModel> ApplyFilterForIndex(string clientName, CarrierStatusEnum searchStatus, IList<ClientModel> source);
        ClientModel GetAllClientPolicies(int clientId);
        bool AddClientPolicy(int clientId, int policyId);
        bool SoftRemoveClientPolicy(int policyId, int clientId);
    }
}