﻿using IBS.Core.Entities;
using System.Linq;

namespace IBS.Service.Repositories
{
    public interface IPolicyRepository
    {
        IQueryable<Policie> GetAll();
        Policie GetById(int id);
        bool Add(Policie policy);
        bool Update(Policie policy);
        bool Delete(int id);
        Policie GetPolicyBudgetById(int id);
        Policie GetPolicyByNoCarriageCoverage(string policy, int carrierId, int coverageId, int product);
    }
}