﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Class2
    {
        public static string EndDate{ get { return "4B-AC-67-DF-F2-EB-B4-90-2C-B1-76-5E-8A-B3-25-F2-12-EF-89-D3-2A-D8-2B-3F-8B-AF-F2-E5-26-D8-09-84"; } }
        public static string Key { get { return "1E-A1-DD-FA-BE-5B-B0-91-44-2B-A8-06-64-7B-C0-71-A8-38-FE-8E-3C-50-CA-31-C8-C4-36-3C-E8-70-A3-64"; } }
        public static string Iv { get { return "7F-CD-DA-56-87-3B-53-20-D7-0A-7C-FD-BE-B3-54-FD"; } }
    }
}
