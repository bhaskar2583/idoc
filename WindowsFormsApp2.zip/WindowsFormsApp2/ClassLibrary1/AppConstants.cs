﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class  AppConstants
    {
        public const string LEVEL1 = "Level1";
        public const string LEVEL2 = "Level2";
    }
}
