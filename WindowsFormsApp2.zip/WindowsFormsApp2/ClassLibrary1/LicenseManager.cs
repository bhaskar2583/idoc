﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class MetaData
    {
        public int Id { get; set; }
        public string DateValue { get; set; }
        public string KeyValue { get; set; }
        public string IvValue { get; set; }
        public string Level { get; set; }
    }
    
    public static class LicenseManager
    { 
        public static void Trigger(bool isTrigger=true)
        {
            
            var watch = new System.Diagnostics.Stopwatch();
            watch.Start();
            var metaData = LicenseManager.GetMetadata();
            ClassLibrary1.Class2.EndDate = metaData.DateValue;
            ClassLibrary1.Class2.Key = metaData.KeyValue;
            ClassLibrary1.Class2.Iv = metaData.IvValue;
            ClassLibrary1.Class2.Level = metaData.Level;
            var endDate = GetEndDate();
            var timeDiffInMS = (endDate - Convert.ToDateTime(ClassLibrary1.Class1.StartDate)).Minutes;
            int milliseconds = timeDiffInMS  * 60 * 1000;
            if (milliseconds <= 0)
            {
                if (!isTrigger)
                {
                    IsLicenseExpired = true;
                    IsLicenseExpiredForLevel1 = true;
                    if (GetLevel() == AppConstants.LEVEL2)
                        IsLicenseExpiredForLevel2 = true;
                }

                if (isTrigger)
                {
                    ClassLibrary1.Class1.StartDate = DateTime.Now.ToString();
                    Trigger(!isTrigger);
                }
            }
                

            var thread = new Thread(() =>
            {
                while (!IsLicenseExpired)
                {
                    if (watch.ElapsedMilliseconds > milliseconds)
                    {
                        IsLicenseExpired = true;
                        IsLicenseExpiredForLevel1 = true;
                        if (GetLevel() == AppConstants.LEVEL2)
                            IsLicenseExpiredForLevel2 = true;
                    }
                        
                }
            });
            thread.Start();
        }
        public static bool IsLicenseExpired { get; set; }
        public static bool IsLicenseExpiredForLevel1 { get; set; }
        public static bool IsLicenseExpiredForLevel2 { get; set; }
        public static DateTime GetEndDate()
        {
            string endDate = string.Empty;
            var endDateAsBits = DecryptKey(ClassLibrary1.Class2.EndDate, "sblw-3hn8-sqoy19");
            String[] arr = endDateAsBits.Split('-');
            byte[] array = new byte[arr.Length];
            for (int i = 0; i < arr.Length; i++) array[i] = Convert.ToByte(arr[i], 16);

            String[] key = DecryptKey(ClassLibrary1.Class2.Key, "sblw-3hn8-sqoy19").Split('-');
            byte[] keyArray = new byte[key.Length];
            for (int i = 0; i < key.Length; i++) keyArray[i] = Convert.ToByte(key[i], 16);

            String[] iv = DecryptKey(ClassLibrary1.Class2.Iv, "sblw-3hn8-sqoy19").Split('-');
            byte[] iVArray = new byte[iv.Length];
            for (int i = 0; i < iv.Length; i++) iVArray[i] = Convert.ToByte(iv[i], 16);


            using (AesManaged myAes = new AesManaged())
            {
                endDate = Decrypt(array, keyArray, iVArray);
            }

            return Convert.ToDateTime(endDate);

        }       
        static string Decrypt(byte[] cipherText, byte[] Key, byte[] IV)
        {
          
            string plaintext = null;
            using (AesManaged aesAlg = new AesManaged())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }

            }

            return plaintext;

        }
        public static string DecryptKey(string input, string key)
        {
            byte[] inputArray = Convert.FromBase64String(input);
            TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
            tripleDES.Key = UTF8Encoding.UTF8.GetBytes(key);
            tripleDES.Mode = CipherMode.ECB;
            tripleDES.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = tripleDES.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
            tripleDES.Clear();
            return UTF8Encoding.UTF8.GetString(resultArray);
        }

        public static MetaData GetMetadata()
        {
            using (var conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["IBSDbContext"].ConnectionString))
            {
                conn.Open();
                var result = conn.Query<MetaData>("select * from Metadata", commandType: CommandType.Text).FirstOrDefault();
                return result;
            }
        }

        public static string GetLevel()
        {
            string endDate = string.Empty;
            var level = DecryptKey(ClassLibrary1.Class2.Level, "sblw-3hn8-sqoy19");
            return level;
        }
    }
}
