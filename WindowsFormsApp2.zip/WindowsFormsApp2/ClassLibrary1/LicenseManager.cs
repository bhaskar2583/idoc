﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public static class LicenseManager
    {
        public static void Trigger()
        {
            var watch = new System.Diagnostics.Stopwatch();
            watch.Start();
            var endDate = GetEndDate();
            var timeDiffInMS = (endDate - Convert.ToDateTime(ClassLibrary1.Class1.StartDate)).Minutes;
            int milliseconds = timeDiffInMS  * 60 * 1000;
            if (milliseconds <= 0)
                IsLicenseExpired = true;

            var thread = new Thread(() =>
            {
                while (!IsLicenseExpired)
                {
                    if (watch.ElapsedMilliseconds > milliseconds)
                        IsLicenseExpired = true;
                }
            });
            thread.Start();
        }
        public static bool IsLicenseExpired { get; set; }
        public static DateTime GetEndDate()
        {
            string endDate = string.Empty;
            var endDateAsBits = ClassLibrary1.Class2.EndDate;
            String[] arr = endDateAsBits.Split('-');
            byte[] array = new byte[arr.Length];
            for (int i = 0; i < arr.Length; i++) array[i] = Convert.ToByte(arr[i], 16);

            String[] key = ClassLibrary1.Class2.Key.Split('-');
            byte[] keyArray = new byte[key.Length];
            for (int i = 0; i < key.Length; i++) keyArray[i] = Convert.ToByte(key[i], 16);

            String[] iv = ClassLibrary1.Class2.Iv.Split('-');
            byte[] iVArray = new byte[iv.Length];
            for (int i = 0; i < iv.Length; i++) iVArray[i] = Convert.ToByte(iv[i], 16);


            using (AesManaged myAes = new AesManaged())
            {
                endDate = Decrypt(array, keyArray, iVArray);
            }

            return Convert.ToDateTime(endDate);

        }       
        static string Decrypt(byte[] cipherText, byte[] Key, byte[] IV)
        {
          
            string plaintext = null;
            using (AesManaged aesAlg = new AesManaged())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }

            }

            return plaintext;

        }
    }
}
