﻿

namespace IBS.Core.Models
{
    public class CarrierDdlModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}