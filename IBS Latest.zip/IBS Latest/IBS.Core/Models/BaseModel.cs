﻿using System;

namespace IBS.Core.Models
{
    public class BaseModel
    {
        public string AddUser { get; set; }
        public DateTime AddDate { get; set; }
        public string RevUser { get; set; }
        public DateTime? RevDate { get; set; }
    }
}
