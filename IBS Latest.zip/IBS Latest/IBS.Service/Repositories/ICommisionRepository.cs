﻿using IBS.Core.Entities;
using IBS.Core.Models;
using IBS.Service.Utils;
using System.Collections.Generic;

namespace IBS.Service.Repositories
{
    public interface ICommisionRepository
    {
        List<Commision> GetSavedCommissions();
        bool Add(Commision commission);
        Commision GetByClientPolicyId(int clientPolicyId);
        bool Update(CommisionModel commission);
        List<Commision> GetSavedCommissionsForCarrier(int carrierId);
        List<Commision> GetByAllClientPolicyId(int clientPolicyId);
        List<Commision> GetVerifiedCommissions();
        List<Commision> GetOpenCommissions();
        bool UpdateCommissionReconciliation(CommisionModel commission);
        List<InvalidCommission> GetExceptionCommissionsForCarrier(int carrierId);
        InvalidCommission GetExceptionCommissionsById(int Id);
        List<int> GetExceptionCommissionsCariers();
        List<SelectListCommon> GetExceptionCarrierStatementDates(int carrierId);
        bool UpdateExceptionCommisions(InvalidCommission commission);
        bool UpdateExceptionCommisionsClient(InvalidCommission commission);
        bool IsValidException(string ClientName, string PolicyNumber, string ProductType, string CoverageType);
        List<ExceptionCodeLookUp> GetExceptionCodeLookUp(int exceptionCode);
        List<InvalidCommission> GetExceptionCommissionsByPolicyNo(string policyNo);
    }
}