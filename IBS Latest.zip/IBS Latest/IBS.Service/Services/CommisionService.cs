﻿using IBS.Core.Entities;
using IBS.Core.Models;
using IBS.Service.Repositories;
using IBS.Service.Utils;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace IBS.Service.Services
{
    public class CommisionService : ICommisionService
    {
        private readonly ICommonRepository _commonRepository;
        private readonly IClientRepository _clientRepository;
        private readonly IPolicyRepository _policyRepository;
        private readonly ICommisionRepository _commissionRepository;
        private readonly ICarrierRepository _carrierRepository;
        public CommisionService(ICommonRepository commonRepository, IClientRepository clientRepository,
            IPolicyRepository policyRepository, ICommisionRepository commissionRepository, ICarrierRepository carrierRepository)
        {
            _commonRepository = commonRepository;
            _clientRepository = clientRepository;
            _policyRepository = policyRepository;
            _commissionRepository = commissionRepository;
            _carrierRepository = carrierRepository;
        }
        private string GetDateFormat(DateTime? date)
        {
            if (date == null)
                return string.Empty;

            DateTime dt = Convert.ToDateTime(date);
            return dt.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        }

        private string GetDateFormatMMYYYY(DateTime? date)
        {
            if (date == null)
                return string.Empty;

            DateTime dt = Convert.ToDateTime(date);
            var dateAsMMDD = dt.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

            string[] dateArray = dateAsMMDD.Split('/');
            dateAsMMDD = dateArray[0] + "/" + dateArray[2];
            return dateAsMMDD;
        }

        public ClientPolicie GetAllClientPoliciesByIndexId(int Id)
        {
            return  _commonRepository.GetAllClientPoliciesByIndexId(Id).FirstOrDefault();
        }
        public List<ClientPolicie> GetAllClientPolicies()
        {
            return _commonRepository.GetAllClientPolicies().ToList();
        }
        public List<Commision> GetSavedCommissions()
        {
            return _commissionRepository.GetSavedCommissions();
        }
        public List<CommisionModel> GetSavedCommissionsByCarrier(int carId, string smd, string pId,int? type)
        {
            var commissionModel = new List<CommisionModel>();
            var commissions = _commissionRepository.GetSavedCommissionsForCarrier(carId);
            if (type == 1) { commissions = commissions.Where(c => c.ReconciliationDate == null).ToList(); }
            if (type == 2) { commissions = commissions.Where(c => c.ReconciliationDate != null).ToList(); }
            if (!string.IsNullOrEmpty(smd) && commissions != null && commissions.Count > 0 && smd != "-- Please select a statement date --")
            {
                var smd1 = Convert.ToDateTime(smd);
                commissions = commissions.Where(c => c.StatementDate == smd1).ToList();
            }
            if (!string.IsNullOrEmpty(pId) && commissions != null && commissions.Count > 0 && pId != "-- Please select a paymentid --")
            {
                commissions = commissions.Where(c => c.PaymentId == pId).ToList();
            }
            commissions.ForEach(dc =>
            {
                //var cpDetails = _commonRepository.GetAllClientPoliciesByIndexId(dc.ClientPolicyId).FirstOrDefault();
                var policyDetails = _policyRepository.GetById(dc.PolicyId);
                //var product = _commonRepository.GetProductById(policyDetails.ProductId);
                var coverage = _commonRepository.GetCoverageById(policyDetails.CoverageId);
                var clientDetails = _clientRepository.GetById(dc.ClientId);
                //var carrier = _carrierRepository.GetById(dc.CarrierId);
                var carrierProduct = _commonRepository.GetAllCorporateXProducts().FirstOrDefault(cp => cp.ProductId == policyDetails.ProductId);
                var cfProduct = _commonRepository.GetAllCorporateProducts().FirstOrDefault(cpp => cpp.Id == carrierProduct.CorporateProductId);

                commissionModel.Add(new CommisionModel()
                {
                    Id = dc.Id,
                    //ReconciliationPaymentDate = dc.ReconciliationDate,
                    ReconciliationPaymentDateAsString = GetDateFormat(dc.ReconciliationDate),
                    ReconciliationStatus = string.IsNullOrEmpty(dc.ReconciliationStatus) ? "Open" : "Verified",
                    //ReconciliationStatusId = string.IsNullOrEmpty(dc.ReconciliationStatus) ? 1 : 2,
                    //ClientId = clientDetails.Id,
                    //CoverageId = coverage.Id,
                    CoverageName = coverage.Name,

                    PolicyId = dc.Id,
                    PolicyNumber = policyDetails.PolicyNumber,

                    //ProductId = product.Id,
                    //ProductName = product.Name,

                    //CfProductId = cfProduct.Id,
                    CfProductName = cfProduct.Name,

                    ClientName = clientDetails.Name,

                    ClientPolicyId = dc.ClientPolicyId,
                    CarrierId = dc.CarrierId,
                    //CarrierName = carrier.Name,
                    CommissionValue = dc.CommissionValue,
                    //StatementDate = dc.StatementDate,
                    StatementDateAsString = GetDateFormat(dc.StatementDate),
                    AppliedDateAsString = GetDateFormatMMYYYY(dc.AppliedDate),
                    //AppliedDateAsFullString = GetDateFormat(dc.AppliedDate),
                    PaymentId = dc.PaymentId
                });
            });

            //commissionModel.ForEach(cm =>
            //{
            //    var carrierProduct = _commonRepository.GetAllCorporateXProducts().FirstOrDefault(cp => cp.ProductId == cm.ProductId);
            //    if (carrierProduct != null)
            //    {
            //        var cp = _commonRepository.GetAllCorporateProducts().FirstOrDefault(cpp => cpp.Id == carrierProduct.CorporateProductId);
            //        if (cp != null)
            //        {
            //            cm.SelectedCorporateProduct = new CorporateProduct()
            //            {
            //                Id = cp.Id,
            //                Name = cp.Name
            //            };
            //        }
            //    }

            //});
            return commissionModel;
        }
        public List<CommisionModel> GetAllSavedCommissionsForCarrier(string startdate, string enddate, string datetype)
        {
            var commissionModel = new List<CommisionModel>();
            var commissions = _commissionRepository.GetSavedCommissions();
            if (datetype == "statementDate")
            {
                commissions = commissions.Where(dd => dd.StatementDate >= Convert.ToDateTime(startdate) && dd.StatementDate <= Convert.ToDateTime(enddate)).ToList();
            }
            if (datetype == "appliedDate")
            {
                commissions = commissions.Where(dd => dd.AppliedDate >= Convert.ToDateTime(startdate) && dd.StatementDate <= Convert.ToDateTime(enddate)).ToList();
            }
            if (datetype == "ReconciliationDate")
            {
                commissions = commissions.Where(dd => dd.ReconciliationDate >= Convert.ToDateTime(startdate) && dd.StatementDate <= Convert.ToDateTime(enddate)).ToList();
            }

            commissions.ForEach(dc =>
            {
                //var cpDetails = _commonRepository.GetAllClientPoliciesByIndexId(dc.ClientPolicyId).FirstOrDefault();
                var policyDetails = _policyRepository.GetById(dc.PolicyId);
                //var product = _commonRepository.GetProductById(policyDetails.ProductId);
                var coverage = _commonRepository.GetCoverageById(policyDetails.CoverageId);
                var clientDetails = _clientRepository.GetById(dc.ClientId);
                var carrier = _carrierRepository.GetById(dc.CarrierId);
                var carrierProduct = _commonRepository.GetAllCorporateXProducts().FirstOrDefault(cp => cp.ProductId == policyDetails.ProductId);
                var cfProduct = _commonRepository.GetAllCorporateProducts().FirstOrDefault(cpp => cpp.Id == carrierProduct.CorporateProductId);

                commissionModel.Add(new CommisionModel()
                {
                    //ReconciliationPaymentDateAsString = GetDateFormat(dc.ReconciliationDate),
                    //CoverageId = coverage.Id,
                    //PolicyId = dc.PolicyId,
                    //PolicyNumber = policyDetails.PolicyNumber,
                    //ClientPolicyId = dc.ClientPolicyId,

                    //CommissionString = dc.CommissionString,

                    Id = dc.Id,
                    ReconciliationPaymentDate = dc.ReconciliationDate,
                    ClientId = clientDetails.Id,

                    CoverageName = coverage.Name,

                    //ProductId = product.Id,

                    CfProductId=cfProduct.Id,
                    CfProductName=cfProduct.Name,

                    ClientName = clientDetails.Name,
                    CarrierId = dc.CarrierId,
                    CarrierName = carrier.Name,
                    CommissionValue = dc.CommissionValue,

                    StatementDate = dc.StatementDate,
                    StatementDateAsString = GetDateFormat(dc.StatementDate),
                    AppliedDate = dc.AppliedDate,
                    AppliedDateAsFullString = GetDateFormat(dc.AppliedDate),
                    DivisionName = string.IsNullOrEmpty(clientDetails.Division) ? "HBS" : "SBS",
                    DivisionId = string.IsNullOrEmpty(clientDetails.Division) ? 1 : 2,
                    Git = policyDetails.IsGroupInsurance

                });
            });

            return commissionModel;
        }
        public List<CommisionModel> GetAllSavedCommissionsForMonthlyReports(int year,int month)
        {
            var commissionModel = new List<CommisionModel>();
            var commissions = _commissionRepository.GetSavedCommissions();
            commissions = commissions.Where(y => Convert.ToDateTime(y.ReconciliationDate).Year == year && Convert.ToDateTime(y.ReconciliationDate).Month <= month).ToList();
            commissions.ForEach(dc =>
            {
                //var cpDetails = _commonRepository.GetAllClientPoliciesByIndexId(dc.ClientPolicyId).FirstOrDefault();
                var policyDetails = _policyRepository.GetById(dc.PolicyId);
                //var product = _commonRepository.GetProductById(policyDetails.ProductId);
                var coverage = _commonRepository.GetCoverageById(policyDetails.CoverageId);
                var clientDetails = _clientRepository.GetById(dc.ClientId);
                var carrier = _carrierRepository.GetById(dc.CarrierId);

                commissionModel.Add(new CommisionModel()
                {
                    Id = dc.Id,
                    ReconciliationPaymentDate = dc.ReconciliationDate,
                    ReconciliationStatus = string.IsNullOrEmpty(dc.ReconciliationStatus) ? "Open" : "Verified",
                    ReconciliationStatusId = string.IsNullOrEmpty(dc.ReconciliationStatus) ? 1 : 2,
                    ClientId = clientDetails.Id,
                    CoverageId = coverage.Id,
                    CoverageName = coverage.Name,

                    PolicyId = dc.PolicyId,
                    PolicyNumber = policyDetails.PolicyNumber,
                    CarrierId = policyDetails.CarId,
                    CarrierName = carrier.Name,
                    CommissionValue = dc.CommissionValue,

                    ClientName = clientDetails.Name,
                    ProductId = policyDetails.ProductId,
                    //ProductName = product.Name,
                    DivisionName = string.IsNullOrEmpty(clientDetails.Division) ? "HBS" : "SBS",
                    DivisionId = string.IsNullOrEmpty(clientDetails.Division) ? 1 : 2,
                    Git = policyDetails.IsGroupInsurance

                });
            });

            commissionModel.ForEach(cm =>
            {
                var carrierProduct = _commonRepository.GetAllCorporateXProducts().FirstOrDefault(cp => cp.ProductId == cm.ProductId);
                if (carrierProduct != null)
                {
                    var cp = _commonRepository.GetAllCorporateProducts().FirstOrDefault(cpp => cpp.Id == carrierProduct.CorporateProductId);
                    if (cp != null)
                    {
                        cm.SelectedCorporateProduct = new CorporateProduct()
                        {
                            Id = cp.Id,
                            Name = cp.Name
                        };
                    }
                }
            });
            return commissionModel;
        }
        public List<CommisionModel> GetAllSavedCommissionsForCarrierEdit(int carrierId,string smd,string pId)
        {
            var commissionModel = new List<CommisionModel>();
            var commissions = _commissionRepository.GetSavedCommissions();
            commissions = commissions.Where(c => c.CarrierId == carrierId).ToList();
            commissions = commissions.Where(c => c.ReconciliationDate == null).ToList();
            if (!string.IsNullOrEmpty(smd) && commissions != null && commissions.Count > 0 && smd != "-- Please select a statement date --")
            {
                var smd1 = Convert.ToDateTime(smd);
                commissions = commissions.Where(c => c.StatementDate == smd1).ToList();
            }
            if (!string.IsNullOrEmpty(pId) && commissions != null && commissions.Count > 0 && pId != "-- Please select a paymentid --")
            {
                commissions = commissions.Where(c => c.PaymentId == pId).ToList();
            }
            commissions.ForEach(dc =>
            {
                var policyDetails = _policyRepository.GetById(dc.PolicyId);
                //var product = _commonRepository.GetProductById(policyDetails.ProductId);
                var coverage = _commonRepository.GetCoverageById(policyDetails.CoverageId);
                var clientDetails = _clientRepository.GetById(dc.ClientId);
                //var carrier = _carrierRepository.GetById(dc.CarrierId);
                var carrierProduct = _commonRepository.GetAllCorporateXProducts().FirstOrDefault(cp => cp.ProductId == policyDetails.ProductId);
                var cfProduct = _commonRepository.GetAllCorporateProducts().FirstOrDefault(cpp => cpp.Id == carrierProduct.CorporateProductId);

                commissionModel.Add(new CommisionModel()
                {
                    Id = dc.Id,
                    ClientId = clientDetails.Id,
                    //CoverageId = coverage.Id,
                    CoverageName = coverage.Name,

                    PolicyId = dc.PolicyId,
                    PolicyNumber = policyDetails.PolicyNumber,
                    CfProductId = cfProduct.Id,
                    CfProductName = cfProduct.Name,
                    //ProductId = product.Id,
                    //ProductName = product.Name,

                    ClientName = clientDetails.Name,

                    ClientPolicyId = dc.ClientPolicyId,
                    CarrierId = dc.CarrierId,
                    //CarrierName = carrier.Name,
                    CommissionValue = dc.CommissionValue,
                    CommissionString = dc.CommissionString,
                    StatementDate = dc.StatementDate,
                    StatementDateAsString = GetDateFormat(dc.StatementDate),
                    AppliedDateAsString = GetDateFormatMMYYYY(dc.AppliedDate),
                    AppliedDateAsFullString = GetDateFormat(dc.AppliedDate),
                    PaymentId = dc.PaymentId,
                });
            });
            
            return commissionModel;
        }
        public List<CommisionModel> GetAllSavedCommissionsForCarrierReports(string startdate, string enddate, string datetype)
        {
            var commissionModel = new List<CommisionModel>();
            var commissions = _commissionRepository.GetSavedCommissions();
            if (datetype == "statementDate")
            {
                commissions = commissions.Where(dd => dd.StatementDate >= Convert.ToDateTime(startdate) && dd.StatementDate <= Convert.ToDateTime(enddate)).ToList();
            }
            if (datetype == "appliedDate")
            {
                commissions = commissions.Where(dd => dd.AppliedDate >= Convert.ToDateTime(startdate) && dd.StatementDate <= Convert.ToDateTime(enddate)).ToList();
            }
            if (datetype == "ReconciliationDate")
            {
                commissions = commissions.Where(dd => dd.ReconciliationDate >= Convert.ToDateTime(startdate) && dd.StatementDate <= Convert.ToDateTime(enddate)).ToList();
            }
            commissions.ForEach(dc =>
            {

                var policyDetails = _policyRepository.GetById(dc.PolicyId);
                var clientDetails = _clientRepository.GetById(dc.ClientId);
                var carrier = _carrierRepository.GetById(dc.CarrierId);
                commissionModel.Add(new CommisionModel()
                {
                    ReconciliationPaymentDateAsString = GetDateFormat(dc.ReconciliationDate),

                    ReconciliationStatus = string.IsNullOrEmpty(dc.ReconciliationStatus) ? "Open" : "Verified",
                    ReconciliationStatusId = string.IsNullOrEmpty(dc.ReconciliationStatus) ? 1 : 2,
                    ClientId = dc.ClientId,
                    ClientName = clientDetails.Name,
                    CarrierId = dc.CarrierId,
                    CarrierName = carrier.Name,
                    
                    CommissionValue = dc.CommissionValue,
                    StatementDateAsString = GetDateFormat(dc.StatementDate),
                    AppliedDateAsFullString = GetDateFormat(dc.AppliedDate),
                    DivisionName = string.IsNullOrEmpty(clientDetails.Division) ? "HBS" : "SBS",
                    DivisionId = string.IsNullOrEmpty(clientDetails.Division) ? 1 : 2,
                    Git = policyDetails.IsGroupInsurance

                });
            });

            return commissionModel;
        }
        public List<CommisionModel> GetAllSavedCommissionsForReports()
        {
            var commissionModel = new List<CommisionModel>();
            var commissions = _commissionRepository.GetSavedCommissions().ToList();

            commissions.ForEach(dc =>
            {

                var policyDetails = _policyRepository.GetById(dc.PolicyId);
                var clientDetails = _clientRepository.GetById(dc.ClientId);
                var carrier = _carrierRepository.GetById(dc.CarrierId);
                var coverage = _commonRepository.GetCoverageById(policyDetails.CoverageId);
                commissionModel.Add(new CommisionModel()
                {
                    PolicyNumber = policyDetails.PolicyNumber,
                    ClientName = clientDetails.Name,
                    CarrierName = carrier.Name,
                    CoverageName = coverage.Name,
                    CommissionValue = dc.CommissionValue,
                    StatementDateAsString = GetDateFormat(dc.StatementDate),
                    
                    DivisionName = string.IsNullOrEmpty(clientDetails.Division) ? "HBS" : "SBS",
                    DivisionId = string.IsNullOrEmpty(clientDetails.Division) ? 1 : 2,
                    Git = policyDetails.IsGroupInsurance

                });
            });

            return commissionModel;
        }
        public List<CommisionModel> GetCommissionsForLastPayment(string date)
        {
            var commissionModel = new List<CommisionModel>();
            var commissions = _commissionRepository.GetSavedCommissions().Where(dd => Convert.ToDateTime(date) >= dd.ReconciliationDate).ToList();
            commissions.ForEach(dc =>
            {

                var policyDetails = _policyRepository.GetById(dc.PolicyId);
                var clientDetails = _clientRepository.GetById(dc.ClientId);
                var carrier = _carrierRepository.GetById(dc.CarrierId);
                commissionModel.Add(new CommisionModel()
                {
                    ReconciliationPaymentDateAsString = GetDateFormat(dc.ReconciliationDate),
                    AppliedDateAsFullString = GetDateFormat(dc.AppliedDate),
                    ClientName = clientDetails.Name,
                    CarrierName = carrier.Name,
                    CommissionValue = dc.CommissionValue,
                    StatementDateAsString = GetDateFormat(dc.StatementDate),

                    Git = policyDetails.IsGroupInsurance
                });
            });
            return commissionModel;
        }
        public List<CommisionModel> GetAllSavedCommissionsForRevenueReport(string startdate, string enddate, string datetype)
        {
            var commissionModel = new List<CommisionModel>();
            var commissions = _commissionRepository.GetSavedCommissions();
            if (datetype == "statementDate")
            {
                commissions = commissions.Where(dd => dd.StatementDate >= Convert.ToDateTime(startdate) && dd.StatementDate <= Convert.ToDateTime(enddate)).ToList();
            }
            if (datetype == "appliedDate")
            {
                commissions = commissions.Where(dd => dd.AppliedDate >= Convert.ToDateTime(startdate) && dd.AppliedDate <= Convert.ToDateTime(enddate)).ToList();
            }
            if (datetype == "ReconciliationDate")
            {
                commissions = commissions.Where(dd => dd.ReconciliationDate >= Convert.ToDateTime(startdate) && dd.ReconciliationDate <= Convert.ToDateTime(enddate)).ToList();
            }
            commissions.ForEach(dc =>
            {
                var policyDetails = _policyRepository.GetById(dc.PolicyId);
                var coverage = _commonRepository.GetCoverageById(policyDetails.CoverageId);
                var clientDetails = _clientRepository.GetById(dc.ClientId);
                var carrier = _carrierRepository.GetById(dc.CarrierId);
                var carrierProduct = _commonRepository.GetAllCorporateXProducts().FirstOrDefault(cp => cp.ProductId == policyDetails.ProductId);
                var cfProduct = _commonRepository.GetAllCorporateProducts().FirstOrDefault(cpp => cpp.Id == carrierProduct.CorporateProductId);

                commissionModel.Add(new CommisionModel()
                {
                    Id = dc.Id,
                    ReconciliationPaymentDate = dc.ReconciliationDate,
                    ReconciliationPaymentDateAsString = GetDateFormat(dc.ReconciliationDate),
                    ReconciliationStatus = string.IsNullOrEmpty(dc.ReconciliationStatus) ? "Open" : "Verified",
                    ReconciliationStatusId = string.IsNullOrEmpty(dc.ReconciliationStatus) ? 1 : 2,

                    CoverageId = coverage.Id,
                    CoverageName = coverage.Name,

                    CfProductName = cfProduct.Name,
                    CfProductId = cfProduct.Id,

                    ClientName = clientDetails.Name,

                    ClientPolicyId = dc.ClientPolicyId,
                    CarrierId = dc.CarrierId,
                    CarrierName = carrier.Name,
                    CommissionValue = dc.CommissionValue,
                    StatementDateAsString = GetDateFormat(dc.StatementDate),
                    AppliedDateAsFullString = GetDateFormat(dc.AppliedDate),
                    DivisionName = string.IsNullOrEmpty(clientDetails.Division) ? "HBS" : "SBS",
                    DivisionId = string.IsNullOrEmpty(clientDetails.Division) ? 1 : 2,
                    Git = policyDetails.IsGroupInsurance

                });
            });            
            return commissionModel;
        }
        public List<CommisionModel> GetCarrierPoliciesById(int carrierId)
        {
            var commisions = new List<CommisionModel>();

            var clientPolicies = _commonRepository.GetAllClientPolicies().Where(cp => cp.IsActive);
            clientPolicies.ToList().ForEach(cp =>
            {

                var policyDetails = _policyRepository.GetById(cp.PolicyId);

                if (policyDetails.CarId == carrierId)
                {
                    var commisionMode = new CommisionModel();
                    var product = _commonRepository.GetProductById(policyDetails.ProductId);
                    var coverage = _commonRepository.GetCoverageById(policyDetails.CoverageId);
                    var clientDetails = _clientRepository.GetById(cp.ClientId);

                    commisionMode.CoverageId = coverage.Id;
                    commisionMode.CoverageName = coverage.Name;

                    commisionMode.PolicyId = policyDetails.Id;
                    commisionMode.PolicyNumber = policyDetails.PolicyNumber;

                    commisionMode.ProductId = product.Id;
                    commisionMode.ProductName = product.Name;

                    commisionMode.ClientId = clientDetails.Id;
                    commisionMode.ClientName = clientDetails.Name;

                    if (!string.IsNullOrEmpty(clientDetails.Division))
                    {
                        if (clientDetails.Division == "HBS")
                        {
                            commisionMode.DivisionId = 1;
                            commisionMode.DivisionName = clientDetails.Division;
                        }
                        if (clientDetails.Division == "SBS")
                        {
                            commisionMode.DivisionId = 2;
                            commisionMode.DivisionName = clientDetails.Division;
                        }
                    }
                    commisionMode.Git = policyDetails.IsGroupInsurance;
                    //commisionMode.DivisionId = Convert.ToInt32(clientDetails.Division);
                    //commisionMode.DivisionName = commisionMode.DivisionId == 1 ? "Division 1" : "Division 2";

                    commisionMode.ClientPolicyId = cp.Id;
                    commisionMode.CarrierId = carrierId;

                    var isExist = commisions.FirstOrDefault(c => c.ClientId == commisionMode.ClientId
                        && c.PolicyNumber == commisionMode.PolicyNumber);
                    if (isExist != null)
                    {
                        isExist.Products.Add(new Product()
                        {
                            Id = commisionMode.ProductId,
                            Name = commisionMode.ProductName
                        });
                    }
                    if (isExist == null)
                    {
                        commisionMode.Products.Add(new Product()
                        {
                            Id = commisionMode.ProductId,
                            Name = commisionMode.ProductName
                        });
                        commisions.Add(commisionMode);
                    }
                }
            });
            //Product management
            commisions.ForEach(c =>
            {
                c.Products.ForEach(cp =>
                {
                    var cpProduct = _commonRepository.GetAllCorporateXProducts().FirstOrDefault(cxp => cxp.ProductId == cp.Id);
                    if (cpProduct != null)
                    {
                        var cProduct = _commonRepository.GetAllCorporateProducts().FirstOrDefault(p => p.Id == cpProduct.CorporateProductId);
                        if (cProduct != null)
                        {
                            var isExit = c.CorporateProducts.FirstOrDefault(cpp => cpp.Id == cProduct.Id);
                            if (isExit == null)
                            {
                                c.CorporateProducts.Add(cProduct);
                            }
                        }
                    }
                });
                //if (c.SelectedCoverage != null && c.SelectedCoverage.Id > 0)
                //{

                //var products = GetProductsOfPolicy(Convert.ToString(c.ClientId), c.PolicyNumber, Convert.ToString(c.CoverageId));
                //    c.Products = products;
                //}

            });
            return commisions;
        }

        public ClientPolicie GetClientPoliciesByPolicyId(int policyId)
        {
            return _commonRepository.GetClientPoliciesByPolicyId(policyId);
        }

        public Policie GetPolicyByNoCarriageCoverage(string policyNo, int carrierId, int coverageId, int product)
        {
            return _policyRepository.GetPolicyByNoCarriageCoverage(policyNo, carrierId, coverageId, product);
        }

        public List<Product> GetProductsOfPolicy(string client, string policyNo, string coverage)
        {
            var products = new List<Product>();
            var clientPolicies = _commonRepository.GetAllClientPolicies().Where(cp => cp.IsActive
            && cp.ClientId == Convert.ToInt32(client)).ToList();

            clientPolicies.ForEach(cp =>
            {
                var policyDetails = _policyRepository.GetById(cp.PolicyId);

                if (policyDetails.PolicyNumber == policyNo && Convert.ToString(policyDetails.CoverageId) == coverage)
                {
                    var isExist = products.FirstOrDefault(pr => pr.Id == policyDetails.ProductId);
                    if (isExist == null)
                    {
                        products.Add(new Product()
                        {
                            Id = policyDetails.ProductId,
                            Name = _commonRepository.GetAllProducts().FirstOrDefault(pro => pro.Id == policyDetails.ProductId).Name
                        });
                    }
                }

            });
            return products;
        }

        public bool SaveCommissions(List<CommisionModel> commissions, bool save)
        {
            commissions.ForEach(c =>
            {
                if (save)
                {
                    var isExist = _commissionRepository.GetByClientPolicyId(c.ClientPolicyId);
                    if (isExist != null)
                    {
                        c.RevUser = LoginUserDetails.GetWindowsLoginUserName();
                        c.RevDate = DateUtil.GetCurrentDate();
                        _commissionRepository.Update(c);
                        return;
                    }
                }

                var commission = new Commision()
                {
                    ClientPolicyId = c.ClientPolicyId,
                    CarrierId = c.CarrierId,
                    ClientId = c.ClientId,
                    PolicyId = c.PolicyId,
                    CommissionValue = c.CommissionValue,
                    CommissionString = c.CommissionString,
                    AppliedDate = c.AppliedDate,
                    StatementDate = c.StatementDate,
                    PaymentId = c.PaymentId,
                    AddUser = LoginUserDetails.GetWindowsLoginUserName(),
                    AddDate = DateUtil.GetCurrentDate(),
                    IsExceptionCommission = c.IsExceptionCommission
                };
                _commissionRepository.Add(commission);
            });
            return true;
        }

        public bool UpdateCommissions(List<CommisionModel> commissions)
        {
            commissions.ForEach(c =>
            {
                var isExist = _commissionRepository.GetByClientPolicyId(c.ClientPolicyId);
                if (isExist != null)
                {
                    c.ReconciliationStatus = "Verified";
                    c.RevUser = LoginUserDetails.GetWindowsLoginUserName();
                    c.RevDate = DateUtil.GetCurrentDate();
                    _commissionRepository.UpdateCommissionReconciliation(c);
                    return;
                }

            });
            return true;
        }

        public List<SelectListCommon> GetCarrierStatementDates(string carrierId)
        {
            var smDates = new List<SelectListCommon>();
            var commissions = _commissionRepository.GetVerifiedCommissions().ToList();
            //var clientPolicies = _commonRepository.GetAllClientPolicies().Where(cp => cp.IsActive);
            commissions.ToList().ForEach(cp =>
            {

                //var policyDetails = _policyRepository.GetById(cp.PolicyId);

                if (cp.CarrierId == Convert.ToInt32(carrierId))
                {
                    var sDate = GetDateFormat(cp.StatementDate);

                    var isExist = smDates.FirstOrDefault(s => s.Name == sDate);
                    if (isExist == null)
                    {
                        smDates.Add(new SelectListCommon()
                        {
                            Id = cp.Id,
                            Name = GetDateFormat(cp.StatementDate)
                        });
                    }
                    //var commisions = _commissionRepository.GetByAllClientPolicyId(cp.Id);
                    //if (commisions != null)
                    //{
                    //    commisions.ForEach(c =>
                    //    {
                    //        var sDate = GetDateFormat(c.StatementDate);

                    //        var isExist = smDates.FirstOrDefault(s => s.Name == sDate);
                    //        if (isExist == null)
                    //        {
                    //            smDates.Add(new SelectListCommon()
                    //            {
                    //                Id = c.Id,
                    //                Name = GetDateFormat(c.StatementDate)
                    //            });
                    //        }
                    //    });

                    //}
                }
            });
            smDates = smDates.OrderByDescending(x => x.Name).ToList();
            return smDates;
        }
        public List<SelectListCommon> GetCarrierStatementDatePayments(string carrierId, string statementDate)
        {
            var payments = new List<SelectListCommon>();
            var commissions = _commissionRepository.GetVerifiedCommissions().ToList();

            if (commissions != null)
            {
                commissions.ForEach(c =>
                {
                    if (c.CarrierId == Convert.ToInt32(carrierId))
                    {
                        var smDate = GetDateFormat(c.StatementDate);
                        if (smDate == statementDate)
                        {
                            var isExist = payments.FirstOrDefault(p => p.Name == c.PaymentId);
                            if (isExist == null)
                            {
                                payments.Add(new SelectListCommon()
                                {
                                    Id = c.Id,
                                    Name = c.PaymentId
                                });
                            }
                        }
                    }
                });
            }
            //var clientPolicies = _commonRepository.GetAllClientPolicies().Where(cp => cp.IsActive);
            //clientPolicies.ToList().ForEach(cp =>
            //{
            //    var policyDetails = _policyRepository.GetById(cp.PolicyId);

            //    if (policyDetails.CarId == Convert.ToInt32(carrierId))
            //    {
            //        var commisions = _commissionRepository.GetByAllClientPolicyId(cp.Id);

            //        if (commisions != null)
            //        {

            //            commisions.ForEach(c =>
            //            {
            //                var smDate = GetDateFormat(c.StatementDate);
            //                if (smDate == statementDate)
            //                {
            //                    var isExist = payments.FirstOrDefault(p => p.Name == c.PaymentId);
            //                    if (isExist == null)
            //                    {
            //                        payments.Add(new SelectListCommon()
            //                        {
            //                            Id = c.Id,
            //                            Name = c.PaymentId
            //                        });
            //                    }
            //                }

            //            });
            //        }
            //    }
            //});

            return payments;
        }

        public List<SelectListCommon> GetCarrierStatementDatesOpen(string carrierId)
        {
            var smDates = new List<SelectListCommon>();
            var commissions = _commissionRepository.GetOpenCommissions().Where(c => c.ReconciliationStatus != "Verified").ToList();

            commissions.ToList().ForEach(cp =>
            {                
                if (cp.CarrierId == Convert.ToInt32(carrierId))
                {
                    var sDate = GetDateFormat(cp.StatementDate);

                    var isExist = smDates.FirstOrDefault(s => s.Name == sDate);
                    if (isExist == null)
                    {
                        smDates.Add(new SelectListCommon()
                        {
                            Id = cp.Id,
                            Name = GetDateFormat(cp.StatementDate)
                        });
                    }
                }
            });
            smDates = smDates.OrderByDescending(x => x.Name).ToList();
            return smDates;
        }
        public List<SelectListCommon> GetCarrierStatementDatePaymentsOpen(string carrierId, string statementDate)
        {
            var payments = new List<SelectListCommon>();
            var commissions = _commissionRepository.GetOpenCommissions().ToList();

            if (commissions != null)
            {
                commissions.ForEach(c =>
                {
                    if (c.CarrierId == Convert.ToInt32(carrierId))
                    {
                        var smDate = GetDateFormat(c.StatementDate);
                        if (smDate == statementDate)
                        {
                            var isExist = payments.FirstOrDefault(p => p.Name == c.PaymentId);
                            if (isExist == null)
                            {
                                payments.Add(new SelectListCommon()
                                {
                                    Id = c.Id,
                                    Name = c.PaymentId
                                });
                            }
                        }
                    }
                });
            }
            return payments;
        }

        public IList<CorporateProduct> GetAllCorporateProducts()
        {
            return _commonRepository.GetAllCorporateProducts();
        }

        public Policie GetPolicyByNoCarriageCoverage(string policyNo, int carrierId, int coverageId)
        {
            return _policyRepository.GetAll().
                Where(pc => pc.PolicyNumber == policyNo && pc.CarId == carrierId && pc.CoverageId == coverageId).FirstOrDefault();
        }

        public List<ExceptionCommissionModel> GetAllExceptionCommissionsForCarrier(int? carrierId)
        {
            if (carrierId == null)
                return new List<ExceptionCommissionModel>();

            var x = new CommisionModel();
            var commissionModel = new List<ExceptionCommissionModel>();
            var commissions = _commissionRepository.GetExceptionCommissionsForCarrier((int)carrierId);
            commissions.ForEach(dc =>
            {
                var clientDetails = _clientRepository.GetById(dc.ClientId);
                var exceptionDesc = string.Empty;
                if (dc.ExceptionCode != null)
                {
                    var exceptionDetails = _commissionRepository.GetExceptionCodeLookUp(Convert.ToInt32(dc.ExceptionCode));
                    if (exceptionDetails != null && exceptionDetails.Count > 0)
                    {
                        exceptionDesc = exceptionDetails.FirstOrDefault().ExceptionDescription;
                    }
                }
                commissionModel.Add(new ExceptionCommissionModel()
                {
                    Id = dc.Id,
                    ClientId = dc.ClientId,
                    ClientName = dc.ClientId == 0 ? "" : clientDetails.Name,
                    PolicyNumber = dc.PolicyNumber,
                    ProductType = dc.ProductType,
                    ClientPolicyId = dc.ClientPolicyId,
                    CarrierId = dc.CarrierId,
                    CommissionValue = dc.CommissionValue,
                    CommissionString = dc.CommissionValue != null ? Convert.ToString(dc.CommissionValue) : null,
                    StatementDateAsString = GetDateFormat(dc.StatementDate),
                    AppliedDate = dc.AppliedDate,
                    AppliedDateAsString = GetDateFormatMMYYYY(dc.AppliedDate),
                    PaymentId = dc.PaymentId,
                    CoverageType = dc.CoverageType,
                    PolicyId = dc.PolicyId,
                    IsValidException = IsValidException(dc.ClientId == 0 ? "" : clientDetails.Name, dc.PolicyNumber, dc.ProductType, dc.CoverageType),
                    ExceptionDesc = exceptionDesc
                });
            });
            return commissionModel;
        }

        private bool IsValidException(string clientName, string PolicyNumber, string ProductType, string CoverageType)
        {
            return _commissionRepository.IsValidException(clientName, PolicyNumber, ProductType, CoverageType);

        }

        public IList<Carrier> GetExceptionCommissionsCariers()
        {
            var carriers = new List<Carrier>();
            var exceptionCarriers = _commissionRepository.GetExceptionCommissionsCariers();
            if (exceptionCarriers == null || exceptionCarriers.Count <= 0)
                return carriers;

            exceptionCarriers.ForEach(c =>
            {
                var carrier = _carrierRepository.GetById(c);
                if (carrier != null)
                    carriers.Add(carrier);
            });
            return carriers;
        }

        public List<SelectListCommon> GetExceptionCarrierStatementDates(int? carrierId)
        {
            if (carrierId == null)
                return new List<SelectListCommon>();

            return _commissionRepository.GetExceptionCarrierStatementDates((int)carrierId);
        }
        public bool UpdateExceptionCommisions(List<ExceptionCommissionModel> commissions)
        {
            var eCommissions = _commissionRepository.GetExceptionCommissionsForCarrier(0).ToList();

            commissions.ForEach(eC =>
            {
                var eCommission = eCommissions.FirstOrDefault(ec => ec.Id == eC.Id);
                if (eCommission != null)
                {
                    _commissionRepository.UpdateExceptionCommisions(eCommission);
                }
            });
            return true;
        }
        public bool UpdateExceptionCommisionsClient(int Id, int clientId, int policyId, string policyNo)
        {
            var clientPolicies = _commonRepository.GetClientPoliciesByPolicyId(policyId);
            var exceptionCommisions = _commissionRepository.GetExceptionCommissionsByPolicyNo(policyNo);

            exceptionCommisions.ForEach(ec =>
            {
                ec.ClientId = clientId;
                ec.ClientPolicyId = clientPolicies.Id;
                ec.ExceptionCode = 0;
                _commissionRepository.UpdateExceptionCommisionsClient(ec);
            });
            return true;
        }
    }
}