﻿namespace Web.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    public class PeriodEventMeasurements
    {
        public List<Period> Periods { get; set; }
        public List<EventMeasurement> EventMeasurements { get; set; }
    }

    public class Period
    {
        public string PeriodId { get; set; }
        public string PeriodText { get; set; }
        public bool IsSelected { get; set; }
    }

    public class EventMeasurement
    {
        public int EventDataId { get; set; }
        public string EventType { get; set; }
        public string MeasureName { get; set; }
        public int OrderBy { get; set; }
        public List<EventMeasure> EventMeasures { get; set; }
    }

    public class EventMeasure
    {
        public string MeasurementsId { get; set; }
        public int HosId { get; set; }
        public int CalId { get; set; }
        public int EmmId { get; set; }
        public string MonthYear { get; set; }
        public decimal Numerator { get; set; }
        public decimal Denominator { get; set; }
        public int Multiplier { get; set; }
        public decimal Measurement { get; set; }
        public int OrderBy { get; set; }
        public string UpdatedBy { get; set; }
    }
}