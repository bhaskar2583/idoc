﻿namespace Web.Models.Measurements
{
    using ClosedXML.Excel;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Text.RegularExpressions;
    using System.Web;
    using System.Web.Mvc;

    public class MeasurementsServiceRepository
    {
        private HttpClient Client { get; set; }
        public MeasurementsServiceRepository()
        {
            Client = new HttpClient
            {
                BaseAddress = new Uri(ConfigurationManager.AppSettings["PFP:PFPAPIuri"].ToString())
            };
        }

        internal List<SelectListItem> GetHospitalsData(int? HOSId, string email)
        {
            HttpResponseMessage response = Client.GetAsync("Measurements/?&email=" + email).Result;
            List<HospitalData> hospitalDatas = response.Content.ReadAsAsync<List<HospitalData>>().Result;

            List<SelectListItem> listHospitals = new List<SelectListItem>();

            foreach (var hospital in hospitalDatas)
                if (hospital.HOSId == (HOSId ?? 0))
                    listHospitals.Add(new SelectListItem { Value = hospital.HOSId.ToString(), Text = hospital.HOSHospitalName.ToString(), Selected = true });
                else
                    listHospitals.Add(new SelectListItem { Value = hospital.HOSId.ToString(), Text = hospital.HOSHospitalName.ToString() });
            return listHospitals;
        }

        internal List<SelectListItem> GetYearsData(int? Year)
        {
            HttpResponseMessage response = Client.GetAsync("Measurements/?&Year=0").Result;
            List<YearData> yearDatas = response.Content.ReadAsAsync<List<YearData>>().Result;

            Year = Year == null || Year <= 0 ? DateTime.Now.Year : Year;
            List<SelectListItem> listYears = new List<SelectListItem>();

            foreach (var yr in yearDatas)
            {
                if (yr.Year == Year)
                    listYears.Add(new SelectListItem { Value = yr.Year.ToString(), Text = yr.Year.ToString(), Selected = true });
                else
                    listYears.Add(new SelectListItem { Value = yr.Year.ToString(), Text = yr.Year.ToString() });
            }
            return listYears;
        }

        internal List<SelectListItem> GetEventTypesData(int? EVMId, string email)
        {
            HttpResponseMessage response = Client.GetAsync("Measurements/?&userId=0&email=" + email).Result;
            List<EventTypeData> eventTypeDatas = response.Content.ReadAsAsync<List<EventTypeData>>().Result;

            List<SelectListItem> listEventTypes = new List<SelectListItem>();
            foreach (var et in eventTypeDatas)
            {
                if (et.EVMId == (EVMId ?? 0))
                    listEventTypes.Add(new SelectListItem { Value = et.EVMId.ToString(), Text = et.EVMEventType.ToString(), Selected = true });
                else
                    listEventTypes.Add(new SelectListItem { Value = et.EVMId.ToString(), Text = et.EVMEventType.ToString() });
            }
            return listEventTypes;
        }

        internal List<EventTypeMeasuresData> GetEventTypeMeasuresData(int? EMMId, int? EVMId)
        {
            EMMId = EMMId ?? 0;
            List<EventTypeMeasuresData> listEventTypeMeasures = new List<EventTypeMeasuresData>();
            if ((EVMId ?? 0) > 0)
            {
                HttpResponseMessage response = Client.GetAsync("Measurements/?&EMMId=" + EMMId + "&EVMId=" + EVMId).Result;
                List<EventTypeMeasuresData> eventTypeMeasuresDatas = response.Content.ReadAsAsync<List<EventTypeMeasuresData>>().Result;

                foreach (var etm in eventTypeMeasuresDatas)
                {
                    if (etm.EMMId == EMMId)
                        listEventTypeMeasures.Add(new EventTypeMeasuresData { EMMId = etm.EMMId, MEMMeasure = etm.MEMMeasure, MEMDisplayName = etm.MEMDisplayName, EMMTimePeriod = etm.EMMTimePeriod, Selected = "active" });
                    else
                        listEventTypeMeasures.Add(new EventTypeMeasuresData { EMMId = etm.EMMId, MEMMeasure = etm.MEMMeasure, MEMDisplayName = etm.MEMDisplayName, EMMTimePeriod = etm.EMMTimePeriod, Selected = "" });
                }
            }
            if (listEventTypeMeasures.Where(etm => etm.Selected == "active").Count() == 0 && listEventTypeMeasures.Count() > 0)
                listEventTypeMeasures.FirstOrDefault().Selected = "active";
            return listEventTypeMeasures.OrderBy(etm => etm.MEMDisplayName).ToList();
        }

        private int? GetTimePeriodId(int? TPId)
        {
            var mo = DateTime.Now.Month;
            return (TPId == null || TPId <= 0) ? ((mo >= 4 && mo <= 6) ? 2 : (mo >= 7 && mo <= 9) ? 3 : (mo >= 10 && mo <= 12) ? 4 : 1) : TPId;
        }

        internal List<SelectListItem> GetTimePeriodsData(int? TPId, int? EMMId)
        {
            List<SelectListItem> listTimePeriods = new List<SelectListItem>();
            if ((EMMId ?? 0) > 0)
            {
                HttpResponseMessage response = Client.GetAsync("Measurements/?&EMMId=" + EMMId).Result;
                List<TimePeriodData> timePeriodDatas = response.Content.ReadAsAsync<List<TimePeriodData>>().Result;
                TPId = GetTimePeriodId(TPId);

                foreach (var tp in timePeriodDatas)
                {
                    if (tp.TPId == TPId)
                        listTimePeriods.Add(new SelectListItem { Value = tp.TPId.ToString(), Text = tp.TimePeriod, Selected = true });
                    else
                        listTimePeriods.Add(new SelectListItem { Value = tp.TPId.ToString(), Text = tp.TimePeriod });
                }
                listTimePeriods = listTimePeriods.OrderBy(tp => tp.Value).ToList();
            }
            if (listTimePeriods.Where(etm => etm.Selected == true).Count() == 0 && listTimePeriods.Count() > 0)
                listTimePeriods.FirstOrDefault().Selected = true;
            return listTimePeriods;
        }

        internal PFPMeasurementData GetPFPMeasurementDatas(int? hOSId, int? year, int? eVMId, int? eMMId, int? tPId)
        {
            PFPMeasurementData pfp = new PFPMeasurementData();
            if (hOSId != null && hOSId > 0 && year != null && year > 0 && eVMId != null && eVMId > 0)
            {
                pfp.HOSId = hOSId;
                pfp.Year = year;
                pfp.EVMId = eVMId;
                pfp.EventTypeMeasuresDatas = GetEventTypeMeasuresData(eMMId, eVMId);
                if (((eMMId != null && eMMId < 0) || pfp.EventTypeMeasuresDatas.Where(etm => etm.EMMId == eMMId).Count() == 0) && (pfp.EventTypeMeasuresDatas != null && pfp.EventTypeMeasuresDatas.Count() > 0))
                    pfp.EMMId = pfp.EventTypeMeasuresDatas.Where(etm => etm.Selected == "active").FirstOrDefault().EMMId;
                else
                    pfp.EMMId = eMMId;

                tPId = GetTimePeriodId(tPId);
                var listTimePeriods = GetTimePeriodsData(tPId, pfp.EMMId);
                if (pfp.EMMId != null && pfp.EMMId > 0 && listTimePeriods.Count() > 0 && listTimePeriods.Where(etm => etm.Value == tPId.ToString()).Count() == 0)
                {
                    if (int.TryParse(listTimePeriods.Where(etm => etm.Selected == true).FirstOrDefault().Value, out int TPId))
                        pfp.TPId = TPId;
                }
                else
                    pfp.TPId = tPId;

                if (pfp.EMMId != null && pfp.EMMId > 0 && pfp.TPId != null && pfp.TPId > 0)
                {
                    HttpResponseMessage response = Client.PostAsJsonAsync("Measurements", pfp).Result;
                    pfp.PFPMeasurements = response.Content.ReadAsAsync<List<PFPMeasurement>>().Result;
                }
            }
            return pfp;
        }

        internal bool SavePFPMeasurementDatas(int hOSId, int cALId, int eMMId, decimal numVal, decimal denVal, string userEmail)
        {
            PFPMeasurement pFP = new PFPMeasurement
            {
                HosId = hOSId,
                CalId = cALId,
                EmmId = eMMId,
                Numerator = numVal,
                Denominator = denVal,
                UpdatedBy = userEmail
            };
            HttpResponseMessage response = Client.PostAsJsonAsync("Measurements/" + hOSId, pFP).Result;
            return response.Content.ReadAsAsync<HttpStatusCode>().Result == HttpStatusCode.OK ? true : false;
        }

        internal dynamic SaveBGMeasures(string id, decimal bgVal, string userEmail)
        {
            PFPMeasurement pFP = new PFPMeasurement
            {
                UpdatedBy = userEmail
            };
            HttpResponseMessage response = Client.PostAsJsonAsync("Measurements/?&bgId=" + id + "&bgVal=" + bgVal, pFP).Result;
            return response.Content.ReadAsAsync<HttpStatusCode>().Result == HttpStatusCode.OK ? true : false;
        }

        internal List<EventTypeMeasuresData> GetReportingPeriods()
        {
            List<EventTypeMeasuresData> eventTypeMeasuresDatas = new List<EventTypeMeasuresData>();
            HttpResponseMessage response = Client.GetAsync("Measurements/?").Result;
            List<EventTypeData> eventTypeDatas = response.Content.ReadAsAsync<List<EventTypeData>>().Result;
            foreach (var et in eventTypeDatas)
            {
                HttpResponseMessage response2 = Client.GetAsync("Measurements/?&EMMId=0&EVMId=" + et.EVMId).Result;
                eventTypeMeasuresDatas.AddRange(response2.Content.ReadAsAsync<List<EventTypeMeasuresData>>().Result);
            }
            return eventTypeMeasuresDatas;
        }

        internal dynamic SaveReportingPeriods(int id, int bPVal, int pPVal, string email)
        {
            EventTypeMeasuresData etm = new EventTypeMeasuresData
            {
                EMMId = id,
                EMMBaselinePeriod = bPVal,
                EMMPerformancePeriod = pPVal
            };

            HttpResponseMessage response = Client.PostAsJsonAsync("Measurements/?&email=" + email, etm).Result;
            return response.Content.ReadAsAsync<HttpStatusCode>().Result == HttpStatusCode.OK ? true : false;
        }

        internal dynamic UploadMeasures(HttpPostedFileBase file, string dirPath, int? hOSId, string email)
        {
            var viewDataMessage = string.Empty;
            var filePath = string.Empty;
            try
            {
                DataTable dt = new DataTable();
                if (file != null)
                {
                    
                    var fileExt = file.FileName != null ? Path.GetExtension(file.FileName).ToLower() : string.Empty;

                    if (file.ContentLength > 0 && (fileExt == ".xlsx" || fileExt == ".xls" || fileExt == ".csv"))
                    {
                        var now = DateTime.Now;
                        var fileName = Path.GetFileNameWithoutExtension(file.FileName) + "_" + now.Year + "" + now.Month + "" + now.Day + "" + now.Hour + "" + now.Minute + "" + now.Second + "" + now.Millisecond + Path.GetExtension(file.FileName);
                        filePath = Path.Combine(dirPath, fileName);
                        file.SaveAs(filePath);

                        int startIndex = -1;
                        var indexMeasure = startIndex;
                        var indexYear = startIndex;
                        var indexMonth = startIndex;
                        var indexNumerator = startIndex;
                        var indexDenominator = startIndex;

                        dt.Columns.Add("UFS_Id", typeof(int));
                        dt.Columns.Add("UFS_HOS_Id", typeof(int));
                        dt.Columns.Add("UFS_Measure", typeof(string));
                        dt.Columns.Add("UFS_Year", typeof(string));
                        dt.Columns.Add("UFS_Month", typeof(string));                        
                        dt.Columns.Add("UFS_Numerator", typeof(decimal));
                        dt.Columns.Add("UFS_Denominator", typeof(decimal));
                        dt.Columns.Add("UFS_SourceType", typeof(string));
                        dt.Columns.Add("UFS_FileName", typeof(string));
                        dt.Columns.Add("UFS_UploadedBy", typeof(string));

                        if (fileExt == ".xlsx" || fileExt == ".xls")
                        {
                            startIndex = 0;
                            using (XLWorkbook workbook = new XLWorkbook(filePath))
                            {
                                IXLWorksheet worksheet = workbook.Worksheet(1);
                                bool FirstRow = true;
                                string readRange = "1:1";
                                foreach (IXLRow row in worksheet.RowsUsed())
                                {
                                    //rowNumber++;
                                    if (FirstRow)
                                    {
                                        var columnNumber = startIndex;
                                        readRange = string.Format("{0}:{1}", 1, row.LastCellUsed().Address.ColumnNumber);
                                        foreach (IXLCell cell in row.Cells(readRange))
                                        {
                                            columnNumber++;
                                            switch (cell.Value.ToString().ToLower())
                                            {
                                                case "measure":
                                                    indexMeasure = columnNumber;
                                                    break;
                                                case "year":
                                                    indexYear = columnNumber;
                                                    break;
                                                case "month":
                                                    indexMonth = columnNumber;
                                                    break;
                                                case "numerator":
                                                    indexNumerator = columnNumber;
                                                    break;
                                                case "denominator":
                                                    indexDenominator = columnNumber;
                                                    break;
                                                default:
                                                    break;
                                            }
                                        }
                                        FirstRow = false;
                                    }
                                    else
                                    {
                                        if (indexMeasure > startIndex || indexYear > startIndex || indexMonth > startIndex || indexNumerator > startIndex || indexDenominator > startIndex)
                                        {
                                            try {
                                                DataRow dr = dt.NewRow();
                                                if (hOSId != null && hOSId > 0)
                                                    dr[1] = hOSId;
                                                if (indexMeasure > startIndex && row.Cell(indexMeasure).Value.ToString().Length > 0)
                                                    dr[2] = row.Cell(indexMeasure).Value.ToString();
                                                if (indexYear > startIndex && int.TryParse(row.Cell(indexYear).Value.ToString(), out int num))
                                                    dr[3] = num;
                                                if (indexMonth > startIndex && int.TryParse(row.Cell(indexMonth).Value.ToString(), out num))
                                                    dr[4] = num;
                                                if (indexNumerator > startIndex && int.TryParse(row.Cell(indexNumerator).Value.ToString(), out num))
                                                    dr[5] = num;
                                                if (indexDenominator > startIndex && int.TryParse(row.Cell(indexDenominator).Value.ToString(), out num))
                                                    dr[6] = num;
                                                dr[7] = "NYSPFP";
                                                dr[8] = fileName;
                                                dr[9] = email;
                                                dt.Rows.Add(dr);
                                            }
                                            catch (Exception ex)
                                            {
                                                Console.WriteLine(ex);
                                            }
                                        }
                                    }
                                }
                                if (FirstRow)
                                {
                                    viewDataMessage = "<span style=\"color: red;\">Error: No record found!</span>";
                                    return viewDataMessage;
                                }
                            }
                        }
                        else if (fileExt == ".csv")
                        {
                            StreamReader sr = new StreamReader(filePath);
                            string[] headers = sr.ReadLine().Split(',');

                            var columnNumber = startIndex;
                            foreach (string header in headers)
                            {
                                columnNumber++;
                                switch (header.ToLower())
                                {
                                    case "measure":
                                        indexMeasure = columnNumber;
                                        break;
                                    case "year":
                                        indexYear = columnNumber;
                                        break;
                                    case "month":
                                        indexMonth = columnNumber;
                                        break;
                                    case "numerator":
                                        indexNumerator = columnNumber;
                                        break;
                                    case "denominator":
                                        indexDenominator = columnNumber;
                                        break;
                                    default:
                                        break;
                                }
                            }

                            if (indexMeasure > startIndex || indexYear > startIndex || indexMonth > startIndex || indexNumerator > startIndex || indexDenominator > startIndex)
                            {
                                while (!sr.EndOfStream)
                                {
                                    string[] row = Regex.Split(sr.ReadLine(), ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");                                    
                                    try
                                    {
                                        DataRow dr = dt.NewRow();
                                        if (hOSId != null && hOSId > 0)
                                            dr[1] = hOSId;
                                        if (indexMeasure > startIndex && row[indexMeasure].ToString().Length > 0)
                                            dr[2] = row[indexMeasure].ToString();
                                        if (indexYear > startIndex && int.TryParse(row[indexYear].ToString(), out int num))
                                            dr[3] = num;
                                        if (indexMonth > startIndex && int.TryParse(row[indexMonth].ToString(), out num))
                                            dr[4] = num;
                                        if (indexNumerator > startIndex && int.TryParse(row[indexNumerator].ToString(), out num))
                                            dr[5] = num;
                                        if (indexDenominator > startIndex && int.TryParse(row[indexDenominator].ToString(), out num))
                                            dr[6] = num;
                                        dr[7] = "NYSPFP";
                                        dr[8] = fileName;
                                        dr[9] = email;
                                        dt.Rows.Add(dr);
                                    }
                                    catch(Exception ex)
                                    {
                                        Console.WriteLine(ex);
                                    }
                                }
                            }
                            else
                            {
                                viewDataMessage = "<span style=\"color: red;\">Error: No record found!</span>";
                                return viewDataMessage;
                            }
                        }

                        if (dt.Rows.Count > 0)
                        {
                            dt = SaveUploadMeasures(dt, email, fileName);

                            if (dt.Rows.Count > 0)
                            {
                                viewDataMessage = "<span style=\"color: red;\">Error: Please check the record(s)!</span>";
                            }
                            else
                            {
                                viewDataMessage = "<span style=\"color: green;\">Success: \"" + Path.GetFileName(file.FileName) + "\" file uploaded!</span>";
                            }
                        }
                        else
                        {
                            viewDataMessage = "<span style=\"color: red;\">Error: Please check the record(s)!</span>";
                             return viewDataMessage;
                        }
                    }
                    else
                    {
                        viewDataMessage = "<span style=\"color: red;\">Error: File upload supports only 3 formats(.xlsx, .xls, .csv). Please verify the file!</span>";
                    }
                }
                else
                {
                    viewDataMessage = "<span style=\"color: red;\">Error: Please upload the file!</span>";
                }
            }
            catch(Exception ex)
            {
                viewDataMessage = "<span style=\"color: red;\">Error: File upload supports only 3 formats(.xlsx, .xls, .csv). Please verify the file!</span>";
                Console.WriteLine(ex);
            }
            finally
            {
                try
                {
                    if (filePath != null && filePath.Length > 0 && System.IO.File.Exists(filePath))
                    {
                        System.IO.File.Delete(filePath);
                    }

                    if (dirPath != null && dirPath.Length > 0 && Directory.Exists(dirPath))
                    {
                        foreach (string f in Directory.GetFiles(dirPath))
                        {
                            if (Path.GetExtension(f).ToLower() != ".txt")
                            {
                                FileInfo fi = new FileInfo(f);
                                if (fi.CreationTime < DateTime.Now.AddDays(-3))
                                    fi.Delete();
                            }
                        }
                    }
                }
                catch (IOException ioExp)
                {
                    Console.WriteLine(ioExp.Message);
                }
            }
            return viewDataMessage;
        }

        private DataTable SaveUploadMeasures(DataTable dt, string email, string fileName)
        {
            HttpResponseMessage response = Client.PostAsJsonAsync("Measurements/?&email=" + email + "&fileName=" + fileName, dt).Result;
            return response.Content.ReadAsAsync<DataTable>().Result;
        }
    }
}
