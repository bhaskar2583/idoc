﻿namespace Web.Models.Measurements
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Mvc;

    public class MeasurementsServiceRepository
    {
        private HttpClient Client { get; set; }
        public MeasurementsServiceRepository()
        {
            Client = new HttpClient
            {
                BaseAddress = new Uri(ConfigurationManager.AppSettings["PFP:PFPAPIuri"].ToString())
            };
        }

        internal List<SelectListItem> GetHospitalsData(int? HOSId, string email)
        {
            HttpResponseMessage response = Client.GetAsync("Measurements/?&email=" + email).Result;
            List<HospitalData> hospitalDatas = response.Content.ReadAsAsync<List<HospitalData>>().Result;

            List<SelectListItem> listHospitals = new List<SelectListItem>();

            foreach (var hospital in hospitalDatas)
                if (hospital.HOSId == (HOSId ?? 0))
                    listHospitals.Add(new SelectListItem { Value = hospital.HOSId.ToString(), Text = hospital.HOSHospitalName.ToString(), Selected = true });
                else
                    listHospitals.Add(new SelectListItem { Value = hospital.HOSId.ToString(), Text = hospital.HOSHospitalName.ToString() });
            return listHospitals;
        }

        internal List<SelectListItem> GetYearsData(int? Year)
        {
            HttpResponseMessage response = Client.GetAsync("Measurements/?&Year=0").Result;
            List<YearData> yearDatas = response.Content.ReadAsAsync<List<YearData>>().Result;

            List<SelectListItem> listYears = new List<SelectListItem>();
            foreach (var yr in yearDatas)
            {
                if (yr.Year == (Year ?? DateTime.Now.Year))
                    listYears.Add(new SelectListItem { Value = yr.Year.ToString(), Text = yr.Year.ToString(), Selected = true });
                else
                    listYears.Add(new SelectListItem { Value = yr.Year.ToString(), Text = yr.Year.ToString() });
            }
            return listYears;
        }

        internal List<SelectListItem> GetYearQuarters()
        {
            var currentQuarter = GetCurrentQuarter();
            List<SelectListItem> listYearQuarters = new List<SelectListItem>()
            {
                new SelectListItem()
                {
                    Value="1",
                    Text="Apr-Jun",
                    Selected=currentQuarter=="1"
                },
                 new SelectListItem()
                {
                    Value="2",
                    Text="July-Sep",
                    Selected=currentQuarter=="2"
                },
                  new SelectListItem()
                {
                    Value="3",
                    Text="Oct-Dec",
                    Selected=currentQuarter=="3"
                },
                   new SelectListItem()
                {
                    Value="4",
                    Text="Jan-Mar",
                    Selected=currentQuarter=="4"
                }
            };

            return listYearQuarters;
        }
        private string GetCurrentQuarter()
        {
            DateTime currentDate = DateTime.Now;
            if (currentDate.Month >= 4 && currentDate.Month <= 6)
                return "1";

            if (currentDate.Month >= 7 && currentDate.Month <= 9)
                return "2";

            if (currentDate.Month >= 10 && currentDate.Month <= 12)
                return "3";

            return "4";
        }

        internal List<SelectListItem> GetEventTypesData(int? EVMId)
        {
            HttpResponseMessage response = Client.GetAsync("Measurements/?").Result;
            List<EventTypeData> eventTypeDatas = response.Content.ReadAsAsync<List<EventTypeData>>().Result;

            List<SelectListItem> listEventTypes = new List<SelectListItem>();
            foreach (var et in eventTypeDatas)
            {
                if (et.EVMId == (EVMId ?? 0))
                    listEventTypes.Add(new SelectListItem { Value = et.EVMId.ToString(), Text = et.EVMEventType.ToString(), Selected = true });
                else
                    listEventTypes.Add(new SelectListItem { Value = et.EVMId.ToString(), Text = et.EVMEventType.ToString() });
            }
            return listEventTypes;
        }

        //internal List<SelectListItem> GetEventTypeMeasuresData(int? EMMId, int? EVMId)
        //{
        //    EMMId = EMMId ?? 0;
        //    List<SelectListItem> listEventTypeMeasures = new List<SelectListItem>();
        //    if ((EVMId ?? 0) > 0)
        //    {
        //        HttpResponseMessage response = Client.GetAsync("Measurements/?&EMMId=" + EMMId + "&EVMId=" + EVMId).Result;
        //        List<EventTypeMeasuresData> eventTypeMeasuresDatas = response.Content.ReadAsAsync<List<EventTypeMeasuresData>>().Result;

        //        foreach (var etm in eventTypeMeasuresDatas)
        //        {
        //            if (etm.EMMId == EMMId)
        //                listEventTypeMeasures.Add(new SelectListItem { Value = etm.EMMId.ToString(), Text = etm.MEMDisplayName, Selected = true });
        //            else
        //                listEventTypeMeasures.Add(new SelectListItem { Value = etm.EMMId.ToString(), Text = etm.MEMDisplayName });
        //        }
        //        listEventTypeMeasures = listEventTypeMeasures.OrderBy(etm => etm.Text).ToList();
        //    }
        //    if (listEventTypeMeasures.Where(etm => etm.Selected == true).Count() == 0 && listEventTypeMeasures.Count() > 0)
        //        listEventTypeMeasures.FirstOrDefault().Selected = true;
        //    return listEventTypeMeasures;
        //}

        internal List<EventTypeMeasuresData> GetEventTypeMeasuresData(int? EMMId, int? EVMId)
        {
            EMMId = EMMId ?? 0;
            List<EventTypeMeasuresData> listEventTypeMeasures = new List<EventTypeMeasuresData>();
            if ((EVMId ?? 0) > 0)
            {
                HttpResponseMessage response = Client.GetAsync("Measurements/?&EMMId=" + EMMId + "&EVMId=" + EVMId).Result;
                List<EventTypeMeasuresData> eventTypeMeasuresDatas = response.Content.ReadAsAsync<List<EventTypeMeasuresData>>().Result;

                foreach (var etm in eventTypeMeasuresDatas)
                {
                    if (etm.EMMId == EMMId)
                        listEventTypeMeasures.Add(new EventTypeMeasuresData { EMMId = etm.EMMId, MEMMeasure = etm.MEMMeasure, MEMDisplayName = etm.MEMDisplayName, EMMTimePeriod = etm.EMMTimePeriod, Selected = "active" });
                    else
                        listEventTypeMeasures.Add(new EventTypeMeasuresData { EMMId = etm.EMMId, MEMMeasure = etm.MEMMeasure, MEMDisplayName = etm.MEMDisplayName, EMMTimePeriod = etm.EMMTimePeriod, Selected = "" });
                }
            }
            if (listEventTypeMeasures.Where(etm => etm.Selected == "active").Count() == 0 && listEventTypeMeasures.Count() > 0)
                listEventTypeMeasures.FirstOrDefault().Selected = "active";
            return listEventTypeMeasures.OrderBy(etm => etm.MEMDisplayName).ToList();
        }

        internal List<SelectListItem> GetTimePeriodsData(int? TPId, int? EMMId)
        {
            List<SelectListItem> listTimePeriods = new List<SelectListItem>();
            if ((EMMId ?? 0) > 0)
            {
                HttpResponseMessage response = Client.GetAsync("Measurements/?&EMMId=" + EMMId).Result;
                List<TimePeriodData> timePeriodDatas = response.Content.ReadAsAsync<List<TimePeriodData>>().Result;

                foreach (var tp in timePeriodDatas)
                {
                    if (tp.TPId == (TPId ?? 0))
                        listTimePeriods.Add(new SelectListItem { Value = tp.TPId.ToString(), Text = tp.TimePeriod, Selected = true });
                    else
                        listTimePeriods.Add(new SelectListItem { Value = tp.TPId.ToString(), Text = tp.TimePeriod });
                }
                listTimePeriods = listTimePeriods.OrderBy(tp => tp.Value).ToList();
            }
            if (listTimePeriods.Where(etm => etm.Selected == true).Count() == 0 && listTimePeriods.Count() > 0)
                listTimePeriods.FirstOrDefault().Selected = true;
            return listTimePeriods;
        }

        internal PFPMeasurementData GetPFPMeasurementDatas(int? hOSId, int? year, int? eVMId, int? eMMId, int? tPId)
        {
            PFPMeasurementData pfp = new PFPMeasurementData();
            if(hOSId != null && hOSId > 0 && year != null && year > 0 && eVMId != null && eVMId > 0)
            {
                pfp.HOSId = hOSId;
                pfp.Year = year;
                pfp.EVMId = eVMId;
                pfp.EventTypeMeasuresDatas = GetEventTypeMeasuresData(eMMId, eVMId);
                if (((eMMId != null && eMMId < 0) || pfp.EventTypeMeasuresDatas.Where(etm => etm.EMMId == eMMId).Count() == 0) && (pfp.EventTypeMeasuresDatas != null && pfp.EventTypeMeasuresDatas.Count() > 0))
                    pfp.EMMId = pfp.EventTypeMeasuresDatas.Where(etm => etm.Selected == "active").FirstOrDefault().EMMId;
                else 
                    pfp.EMMId = eMMId;

                var listTimePeriods = GetTimePeriodsData(tPId, pfp.EMMId);

                var value = Convert.ToInt32(GetCurrentQuarter());

                if ((pfp.EMMId != null && pfp.EMMId > 0 && (tPId == null || (tPId != null && tPId < 0 || listTimePeriods.Where(etm => etm.Value == (tPId ?? 0).ToString()).Count() == 0))) && (listTimePeriods != null && listTimePeriods.Count() > 0))
                {
                    if (int.TryParse(listTimePeriods.Where(etm => etm.Selected == true).FirstOrDefault().Value, out int TPId))
                        pfp.TPId = value;
                }
                else
                    pfp.TPId = tPId;

                if (pfp.EMMId != null && pfp.EMMId > 0 && pfp.TPId != null && pfp.TPId > 0)
                {                    
                    HttpResponseMessage response = Client.PostAsJsonAsync("Measurements", pfp).Result;
                    pfp.PFPMeasurements = response.Content.ReadAsAsync<List<PFPMeasurement>>().Result;
                }                
            }
            return pfp;
        }

        internal bool SavePFPMeasurementDatas(int hOSId, int cALId, int eMMId, decimal numVal, decimal denVal, string userEmail)
        {
            PFPMeasurement pFP = new PFPMeasurement
            {
                HosId = hOSId,
                CalId = cALId,
                EmmId = eMMId,
                Numerator = numVal,
                Denominator = denVal,
                UpdatedBy = userEmail
            };
            HttpResponseMessage response = Client.PostAsJsonAsync("Measurements/"+ hOSId, pFP).Result;
            return response.Content.ReadAsAsync<HttpStatusCode>().Result == HttpStatusCode.OK ? true : false;
        }

        internal dynamic SaveBGMeasures(string id, decimal bgVal, string userEmail)
        {
            PFPMeasurement pFP = new PFPMeasurement
            {
                UpdatedBy = userEmail
            };
            HttpResponseMessage response = Client.PostAsJsonAsync("Measurements/?&bgId=" + id + "&bgVal=" + bgVal, pFP).Result;
            return response.Content.ReadAsAsync<HttpStatusCode>().Result == HttpStatusCode.OK ? true : false;
        }
    }
}
