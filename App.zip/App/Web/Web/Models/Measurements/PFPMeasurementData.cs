﻿namespace Web.Models.Measurements
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Web.Mvc;

    public class PFPMeasurementData
    {
        public PFPMeasurementData()
        {
            //this.HospitalDatas = new List<SelectListItem>();
            //this.YearDatas = new List<SelectListItem>();
            //this.EventTypeDatas = new List<SelectListItem>();
            this.EventTypeMeasuresDatas = new List<EventTypeMeasuresData>();
            //this.TimePeriodDatas = new List<SelectListItem>();
        }

        public int? HOSId { get; set; }
        public int? CALId { get; set; }
        public int? EMMId { get; set; }
        //public decimal Numerator { get; set; }
        //public decimal Denominator { get; set; }
        //public string UpdatedBy { get; set; }

        public int? Year { get; set; }
        public int? EVMId { get; set; }
        public int? TPId { get; set; }

        //public List<SelectListItem> HospitalDatas { get; set; }
        //public List<SelectListItem> YearDatas { get; set; }
        //public List<SelectListItem> EventTypeDatas { get; set; }
        public List<EventTypeMeasuresData> EventTypeMeasuresDatas { get; set; }
        //public List<SelectListItem> TimePeriodDatas { get; set; }
        public List<PFPMeasurement> PFPMeasurements { get; set; }
    }

    public class PFPMeasurement
    {
        public string MeasureId { get; set; }

        [Required]
        public int? HosId { get; set; }
        [Required]
        public int? CalId { get; set; }
        [Required]
        public int? EmmId { get; set; }
        [Display(Name = "Month-Year")]
        public string MonthYear { get; set; }
        [Display(Name = "Numerator")]
        public decimal Numerator { get; set; }
        [Display(Name = "Denominator")]
        public decimal Denominator { get; set; }
        public string UpdatedBy { get; set; }
        public int? OrderBy { get; set; }        
    }
}
