﻿namespace Web.Controllers
{
    using System;
    using System.Web;
    using System.Web.Mvc;
    using Web.Models;
    using Web.Models.Measurements;

    public class BaseController : Controller
    {
        private RolesServiceRepository db = new RolesServiceRepository();
        private MeasurementsServiceRepository msr_db = new MeasurementsServiceRepository();

        public ActionResult IsSuperAdminUser()
        {
            try
            {
                OKTAServiceRepository oktaSR = new OKTAServiceRepository();
                var Okta = oktaSR.GetUserProfile(HttpContext.GetOwinContext().Authentication.User.Claims);
                ViewBag.IsSuperAdminUser = db.IsSuperAdmin(Okta.email) ? true : false;
                return PartialView("admin");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                throw;
            }
        }
        public ActionResult IsHospitalAdmin()
        {           
            try
            {
                OKTAServiceRepository oktaSR = new OKTAServiceRepository();
                var Okta = oktaSR.GetUserProfile(HttpContext.GetOwinContext().Authentication.User.Claims);
                ViewBag.IsSuperAdminUser = db.IsHospitalAdmin(Okta.email) ? true : false;
                return PartialView("admin");
            }
            catch (Exception)
            {
                throw;
            }
        }

        public ActionResult HospitalSelection(int? HOSId)
        {
            try
            {
                OKTAServiceRepository okta = new OKTAServiceRepository();
                var Okta = okta.GetUserProfile(HttpContext.GetOwinContext().Authentication.User.Claims);
                ViewBag.HOSId = msr_db.GetHospitalsData(HOSId, Okta.email);
                return PartialView("HospitalSelection");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                throw;
            }
        }

        public ActionResult YearSelection(int? Year)
        {
            try
            {
                ViewBag.Year = msr_db.GetYearsData(Year);
                return PartialView("YearSelection");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                throw;
            }
        }

        public ActionResult EventTypeSelection(int? EVMId)
        {
            OKTAServiceRepository oktaSR = new OKTAServiceRepository();
            var Okta = oktaSR.GetUserProfile(HttpContext.GetOwinContext().Authentication.User.Claims);
            try
            {                
                ViewBag.EVMId = msr_db.GetEventTypesData(EVMId,Okta.email);
                return PartialView("EventTypeSelection");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                throw;
            }
        }

        public ActionResult TimePeriodSelection(int? TPId, int? EMMId)
        {
            try
            {
                ViewBag.TPId = msr_db.GetTimePeriodsData(TPId, EMMId);
                return PartialView("TimePeriodSelection");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                throw;
            }
        }
    }
}