﻿namespace Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Web;
    using System.Web.Mvc;
    using Web.Models;

    public class MeasurementsController : Controller
    {
        private RolesServiceRepository roleDB = new RolesServiceRepository();
        private MeasuresServiceRepository db = new MeasuresServiceRepository();

        // GET: Measurements
        public ActionResult Index(int HosId = 0, int FromYear = 0, string TP = "")
        {
            return View(db.GetEventTypes());
        }

        // GET: Measurements/Update/?&HosId=0&etid=0&FromYear=2020&TP=
        [HttpGet]
        public ActionResult Update(int HosId = 0, int etid = 0, int FromYear = 0, string TP = "")
        {
            if (HosId < 0)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ViewBag.FromYear = db.GetYears(FromYear);
            //ViewBag.TP = db.GetTimePeriods(TP).ToList();

            var periodEventMeasurements = new PeriodEventMeasurements();
            if (HosId > 0 && FromYear > 0)
                periodEventMeasurements = db.GetMeasurements(HosId, etid, FromYear, TP);

            return View(periodEventMeasurements);
        }

        [HttpPost]
        public ActionResult Update(PeriodEventMeasurements pem, int HosId = 0, int etid = 0, int FromYear = 0, string TP = "")
        {
            if (ModelState.IsValid)
            {
                //if (db.PostMeasuresData(etms))
                return RedirectToAction("Update", new { HosId, etid, FromYear, TP });
            }

            ViewBag.FromYear = db.GetYears(FromYear);
            //ViewBag.TP = db.GetTimePeriods(TP);
            return View(pem);
        }
    }
}