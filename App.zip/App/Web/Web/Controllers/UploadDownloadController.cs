﻿namespace Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using Web.Models;

    [Authorize]
    public class UploadDownloadController : Controller
    {
        private RolesServiceRepository roleDB = new RolesServiceRepository();
        //private MeasuresServiceRepository db = new MeasuresServiceRepository();

        // GET: UploadDownload
        public ActionResult Index(int HosId = 0, int FromYear = 0, string TP = "")
        {
            //ViewBag.FromYear = db.GetYears(FromYear);
            //ViewBag.TP = db.GetTimePeriods(TP);
            ViewBag.Message = "No file selected. ";

            return View();
        }

        [HttpPost]
        public ActionResult ImportExport(HttpPostedFileBase file, int HosId = 0, int FromYear = 0, string TP = "")
        {
            //ViewBag.TP = db.GetTimePeriods(TP);
            ViewBag.Message = string.Empty;

            var DirPath = Server.MapPath("~/App_Data/uploads");
            //ViewBag.Message = db.UploadSpreadsheet(file, DirPath, HosId, FromYear, TP);

            return View();
        }
    }
}