﻿namespace Web.Controllers
{
    using System.Web;
    using System.Web.Mvc;
    using Web.Models;
    using Web.Models.Measurements;

    [Authorize]
    public class UploadMeasuresController : Controller
    {
        private MeasurementsServiceRepository db = new MeasurementsServiceRepository();

        // GET: UploadDownload
        [HttpGet]
        public ActionResult Index(int? HOSId, int? Year, int? EVMId)
        {
            ViewBag.HOSId = HOSId;
            ViewBag.Year = Year;
            ViewBag.EVMId = EVMId;
            ViewBag.Message = "No file selected. ";
            return View();
        }

        [HttpPost]
        public ActionResult Index(HttpPostedFileBase file, int? HOSId, int? Year, int? EVMId)
        {
            ViewBag.HOSId = HOSId;
            ViewBag.Year = Year;
            ViewBag.EVMId = EVMId;
            ViewBag.Message = string.Empty;
            OKTAServiceRepository okta = new OKTAServiceRepository();
            var Okta = okta.GetUserProfile(HttpContext.GetOwinContext().Authentication.User.Claims);

            var DirPath = Server.MapPath("~/App_Data/Uploads");
            ViewBag.Message = db.UploadMeasures(file, DirPath, HOSId, Okta.email);
            return View();
        }
    }
}
