﻿namespace Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Web;
    using System.Web.Mvc;
    using Web.Models;

    [Authorize]
    public class MeasuresController : BaseController
    {
        private RolesServiceRepository roleDB = new RolesServiceRepository();
        private MeasuresServiceRepository db = new MeasuresServiceRepository();

        // GET: Measures
        public ActionResult Index(int HosId = 0, int FromYear = 0, string TP = "")
        {
            ViewBag.FromYear = db.GetYears(FromYear);
            //ViewBag.TP = db.GetTimePeriods(TP);
            return View(db.GetMeasuresEventTypes());
        }

        // GET: Measures/Update/?&HosId=0&FromYear=2020&TP=
        [HttpGet]
        public ActionResult Update(int HosId = 0, int FromYear = 0, string TP = "")
        {
            if (HosId < 0)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ViewBag.FromYear = db.GetYears(FromYear);
            //ViewBag.TP = db.GetTimePeriods(TP);

            var eventMeasureDatas = new List<EventMeasureData>();
            if (HosId > 0 || FromYear > 0)
                eventMeasureDatas = db.GetMeasuresData(HosId, FromYear, TP);

            return View(eventMeasureDatas);
        }

        [HttpPost]
        public ActionResult Update(List<EventMeasureData> etms, int HosId = 0, int FromYear = 0, string TP = "")
        {
            if (ModelState.IsValid)
            {
                if (db.PostMeasuresData(etms))
                    return RedirectToAction("Index", new { HosId, FromYear, TP });
            }

            ViewBag.FromYear = db.GetYears(FromYear);
            //ViewBag.TP = db.GetTimePeriods(TP);
            return View(etms);
        }
    }
}
