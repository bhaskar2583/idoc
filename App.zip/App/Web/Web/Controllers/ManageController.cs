﻿using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using Web.Models.Enums;
using Web.Models;
using Web.Models.Measurements;
using System.Linq;
using System.Collections.Generic;
using PagedList;

namespace Web.Controllers
{
    [Authorize]
    public class ManageController : BaseController
    {
        private RolesServiceRepository db = new RolesServiceRepository();
        private MeasurementsServiceRepository msr_db = new MeasurementsServiceRepository();
        // GET: Manage
        public ActionResult Index()
        {
            IsSuperAdminUser();
            var userType = GetUserType();
            if(userType == UserTypeEnum.HospitalAdmin)
                IsHospitalAdmin();         
            return View();
        }
        private UserTypeEnum GetUserType()
        {
            ServiceRepository serviceObj = new ServiceRepository();
            OKTAServiceRepository okta = new OKTAServiceRepository();
            //HttpResponseMessage response;
            var Okta = okta.GetUserProfile(HttpContext.GetOwinContext().Authentication.User.Claims);
            var IsSuperAdmin = db.IsSuperAdmin(Okta.email);
            if (IsSuperAdmin)
                return UserTypeEnum.Admin;

            //we have to logic here for normal user
            return UserTypeEnum.HospitalAdmin;
        }

        public ActionResult ReportingPeriods(string SortOrder, string CurrentFilter, string SearchString, int? Page, bool SearchEventType = true, bool SearchMeasure = true, bool SearchDescription = true)
        {
            OKTAServiceRepository okta = new OKTAServiceRepository();
            var Okta = okta.GetUserProfile(HttpContext.GetOwinContext().Authentication.User.Claims);

            ViewBag.CurrentSort = SortOrder;
            ViewBag.ETSortParm = (string.IsNullOrEmpty(SortOrder) || SortOrder == "ET") ? "ET_desc" : "ET";
            ViewBag.MSortParm = SortOrder == "M" ? "M_desc" : "M";
            ViewBag.DSortParm = SortOrder == "D" ? "D_desc" : "D";

            if (SearchEventType == false && SearchMeasure == false && SearchDescription == false)
            {
                SearchEventType = true;
                SearchMeasure = true;
                SearchDescription = true;
            }
            if (SearchString != null)
                Page = 1;
            else
                SearchString = CurrentFilter;
            ViewBag.CurrentFilter = SearchString;
            ViewBag.EventTypeFilter = SearchEventType;
            ViewBag.MeasureFilter = SearchMeasure;
            ViewBag.DescriptionFilter = SearchDescription;

            var reportingPeriods = msr_db.GetReportingPeriods();
            if (!string.IsNullOrEmpty(SearchString))
            {
                SearchString = SearchString.Replace(" ", string.Empty).ToLower();
                if (SearchEventType == true && SearchMeasure == true && SearchDescription == true)
                    reportingPeriods = reportingPeriods.Where(k => k.EVMEventType.Replace(" ", string.Empty).ToLower().Contains(SearchString) || k.MEMDisplayName.Replace(" ", string.Empty).ToLower().Contains(SearchString) || k.MEMMeasure.Replace(" ", string.Empty).ToLower().Contains(SearchString)).ToList();
                else if (SearchEventType == true && SearchMeasure == true && SearchDescription == false)
                    reportingPeriods = reportingPeriods.Where(k => k.EVMEventType.Replace(" ", string.Empty).ToLower().Contains(SearchString) || k.MEMDisplayName.Replace(" ", string.Empty).ToLower().Contains(SearchString)).ToList();
                else if (SearchEventType == true && SearchMeasure == false && SearchDescription == true)
                    reportingPeriods = reportingPeriods.Where(k => k.EVMEventType.Replace(" ", string.Empty).ToLower().Contains(SearchString) || k.MEMMeasure.Replace(" ", string.Empty).ToLower().Contains(SearchString)).ToList();
                else if (SearchEventType == false && SearchMeasure == true && SearchDescription == true)
                    reportingPeriods = reportingPeriods.Where(k => k.MEMDisplayName.Replace(" ", string.Empty).ToLower().Contains(SearchString) || k.MEMMeasure.Replace(" ", string.Empty).ToLower().Contains(SearchString)).ToList();
                else if (SearchEventType == true && SearchMeasure == false && SearchDescription == false)
                    reportingPeriods = reportingPeriods.Where(k => k.EVMEventType.Replace(" ", string.Empty).ToLower().Contains(SearchString)).ToList();                
                else if (SearchEventType == false && SearchMeasure == true && SearchDescription == false)
                    reportingPeriods = reportingPeriods.Where(k => k.MEMDisplayName.Replace(" ", string.Empty).ToLower().Contains(SearchString)).ToList();
                else if (SearchEventType == false && SearchMeasure == false && SearchDescription == true)
                    reportingPeriods = reportingPeriods.Where(k => k.MEMMeasure.Replace(" ", string.Empty).ToLower().Contains(SearchString)).ToList();
            }

            switch (SortOrder)
            {
                case "ET":
                    reportingPeriods = reportingPeriods.OrderBy(s => s.EVMEventType).ToList();
                    break;
                case "ET_desc":
                    reportingPeriods = reportingPeriods.OrderByDescending(s => s.EVMEventType).ToList();
                    break;
                case "M":
                    reportingPeriods = reportingPeriods.OrderBy(s => s.MEMDisplayName).ToList();
                    break;
                case "M_desc":
                    reportingPeriods = reportingPeriods.OrderByDescending(s => s.MEMDisplayName).ToList();
                    break;
                case "D":
                    reportingPeriods = reportingPeriods.OrderBy(s => s.MEMMeasure).ToList();
                    break;
                case "D_desc":
                    reportingPeriods = reportingPeriods.OrderByDescending(s => s.MEMMeasure).ToList();
                    break;
                default:
                    reportingPeriods = reportingPeriods.OrderBy(s => s.EVMEventType).ThenBy(s => s.MEMDisplayName).ThenBy(s => s.MEMMeasure).ToList();
                    break;
            }

            if (!db.IsSuperAdmin(Okta.email))
                reportingPeriods = new List<EventTypeMeasuresData>();
            int PageNumber = (Page ?? 1);
            int PageSize = 10;
            return View(reportingPeriods.ToPagedList(PageNumber, PageSize));
        }

        [HttpPost]
        public void SaveReportingPeriods(int id, int BPVal, int PPVal)
        {
            OKTAServiceRepository okta = new OKTAServiceRepository();
            var Okta = okta.GetUserProfile(HttpContext.GetOwinContext().Authentication.User.Claims);
            ViewBag.rptMessage = msr_db.SaveReportingPeriods(id, BPVal, PPVal, Okta.email);
        }
    }
}
