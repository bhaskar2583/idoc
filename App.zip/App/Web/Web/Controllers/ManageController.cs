﻿using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using Web.Core.Models.Enums;
using Web.Models;

namespace Web.Controllers
{
    [Authorize]
    public class ManageController : BaseController
    {
        private RolesServiceRepository db = new RolesServiceRepository();
        // GET: Manage
        public ActionResult Index()
        {
            IsSuperAdminUser();
            var userType = GetUserType();
            if(userType == UserTypeEnum.HospitalAdmin)
                IsHospitalAdmin();         
            return View();
        }
        private UserTypeEnum GetUserType()
        {
            ServiceRepository serviceObj = new ServiceRepository();
            OKTAServiceRepository okta = new OKTAServiceRepository();
            HttpResponseMessage response;
            var Okta = okta.GetUserProfile(HttpContext.GetOwinContext().Authentication.User.Claims);
            var IsSuperAdmin = db.IsSuperAdmin(Okta.email);
            if (IsSuperAdmin)
                return UserTypeEnum.Admin;

            //we have to logic here for normal user
            return UserTypeEnum.HospitalAdmin;
        }
    }
}
