﻿namespace Web.Controllers
{
    using System.Web;
    using System.Web.Mvc;
    using Web.Models;
    using Web.Models.Measurements;

    [Authorize]
    public class PFPMeasuresController : BaseController
    {
        private MeasurementsServiceRepository db = new MeasurementsServiceRepository();

        [HttpGet]
        public ActionResult Index(int? HOSId, int? Year, int? EVMId)
        {
            return View(db.GetPFPMeasurementDatas(HOSId, Year, EVMId, null, null));
        }

        [HttpPost]
        public ActionResult Index(int? HOSId, int? Year, int? EVMId, int? EMMId, int? TPId)
        {
            return View(db.GetPFPMeasurementDatas(HOSId, Year, EVMId, EMMId, TPId));
        }

        [HttpPost]
        public void SaveMeasures(int HOSId, int CALId, int EMMId, decimal NumVal, decimal DenVal)
        {
            OKTAServiceRepository okta = new OKTAServiceRepository();
            var Okta = okta.GetUserProfile(HttpContext.GetOwinContext().Authentication.User.Claims);
            ViewBag.boolasd = db.SavePFPMeasurementDatas(HOSId, CALId, EMMId, NumVal, DenVal, Okta.email);
        }

        [HttpPost]
        public void SaveBGMeasures(string id, decimal bgVal)
        {
            OKTAServiceRepository okta = new OKTAServiceRepository();
            var Okta = okta.GetUserProfile(HttpContext.GetOwinContext().Authentication.User.Claims);
            ViewBag.boolasd = db.SaveBGMeasures(id, bgVal, Okta.email);
        }
    }
}