﻿
function manageNavigationLinks(link){
    $("#lnkAdmin").removeClass("userManagementActive");
    $("#lnkUserManagement").removeClass("userManagementActive");
    $("#lnkRoleManagement").removeClass("userManagementActive");
    $("#lnkUserRoleManagement").removeClass("userManagementActive");

    $("#"+link).addClass("userManagementActive");
};