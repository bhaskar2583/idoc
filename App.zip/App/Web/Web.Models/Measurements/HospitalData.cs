﻿namespace Web.Models.Measurements
{
    public class HospitalData
    {
        public int HOSId { get; set; }
        public string HOSHospitalName { get; set; }
    }
}
