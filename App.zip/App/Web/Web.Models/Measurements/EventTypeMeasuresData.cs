﻿namespace Web.Models.Measurements
{
    using System.ComponentModel.DataAnnotations;

    public class EventTypeMeasuresData
    {
        public int EMMId { get; set; }
        [Display(Name = "Description")]
        public string MEMMeasure { get; set; }
        [Display(Name = "Measure")]
        public string MEMDisplayName { get; set; }
        public string EMMTimePeriod { get; set; }
        public string Selected { get; set; }

        [Display(Name = "Event Type")]
        public string EVMEventType { get; set; }
        [Display(Name = "Baseline Period")]
        public int EMMBaselinePeriod { get; set; }
        [Display(Name = "Performance Period")]
        public int EMMPerformancePeriod { get; set; }
        public int EVMId { get; set; }
    }
}
