﻿CREATE SCHEMA [pfp]
    AUTHORIZATION [dbo];

