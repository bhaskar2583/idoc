﻿-- =============================================
-- Author:		<kamal suriyakumar>
-- Create date: <3/6/2020>
-- Description:	<spUpdateNYSPFPFromUploadedData>
-- =============================================
--	EXEC pfp.spUpdateNYSPFPFromUploadedData 'HANYS Measures Data Upload File Template_20203617045519.xlsx'
CREATE PROCEDURE [pfp].[spUpdateNYSPFPFromUploadedData] 
@FileName varchar(250)
AS 
BEGIN 
    DECLARE @dateTime datetime = getdate();

	If NOT EXISTS(Select Top 1 1 From [pfp].[UploadFileStaging] Where UFS_IsProcessed < 1 And UFS_FileName = @FileName)
	BEGIN
		DECLARE @LoopCounter Int , @MaxTempId Int, @HosId Int, @CalId Int, @EmmId Int, @Numerator decimal, @Denominator decimal, @SourceType varchar(50), @UserId varchar(50)
				
		Select @LoopCounter = min(UFS_Id),@MaxTempId = max(UFS_Id) FROM [pfp].[UploadFileStaging];
		Set @UserId = (Select Top 1 UFS_UpdatedBy From [pfp].[UploadFileStaging] Where UFS_FileName = @FileName);

		WHILE (@LoopCounter IS NOT NULL AND  @LoopCounter <= @MaxTempId)
		BEGIN
		   SELECT @HosId = UFS_HOS_Id, @CalId = UFS_CAL_Id, @EmmId = UFS_EMM_Id, @Numerator = UFS_Numerator, @Denominator = UFS_Denominator, @SourceType = UFS_SourceType
		   FROM [pfp].[UploadFileStaging]  WHERE UFS_Id = @LoopCounter

		   IF(@HosId > 0 And @CalId > 0 And @EmmId > 0)
		   BEGIN
				IF EXISTS(SELECT TOP 1 1 FROM [pfp].[NYSPFPData] WHERE [NPD_HOS_Id] = @HosId AND [NPD_Cal_Id] = @CalId AND [NPD_EMM_Id] = @EmmId)
				BEGIN
					Update [pfp].[NYSPFPData] Set [NPD_Numerator] = ISNULL(@Numerator,0), [NPD_Denominator] = ISNULL(@Denominator,0), [NPD_Measurement] = 0, [NPD_SourceType] = @SourceType, [NPD_UpdatedBy] = @UserId, [NPD_UpdatedOn] = @dateTime, [NPD_IsUploaded] = 1
					WHERE [NPD_HOS_Id] = @HosId AND [NPD_Cal_Id] = @CalId AND [NPD_EMM_Id] = @EmmId;
				END
				ELSE IF(@Numerator is not null OR @Denominator is not null)
				BEGIN
					Insert Into [pfp].[NYSPFPData] ([NPD_HOS_Id],[NPD_Cal_Id],[NPD_EMM_Id],[NPD_Numerator],[NPD_Denominator],[NPD_Measurement],[NPD_SourceType],[NPD_IsUploaded],[NPD_CreatedBy],[NPD_CreatedOn],[NPD_UpdatedBy],[NPD_UpdatedOn])
					Values (@HosId,@CalId,@EmmId,ISNULL(@Numerator,0),ISNULL(@Denominator,0),0,@SourceType,1,@UserId,GETDATE(),@UserId,GETDATE());
				END
		   END
		   
		   SELECT @LoopCounter  = min(UFS_Id) 
		   FROM [pfp].[UploadFileStaging] WHERE UFS_Id > @LoopCounter
		END

		Update [pfp].[UploadFileStaging] Set UFS_IsProcessed = 2, UFS_UpdatedOn = @dateTime  Where UFS_IsProcessed < 2 And UFS_FileName = @FileName;
	END
	ELSE
	BEGIN
		SELECT [UFS_Measure],[UFS_Year],[UFS_Month],[UFS_Numerator],[UFS_Denominator] FROM [PFP].[pfp].[UploadFileStaging] WHERE [UFS_FileName] = @FileName And [UFS_IsProcessed] < 2;
	END	
END
GO
