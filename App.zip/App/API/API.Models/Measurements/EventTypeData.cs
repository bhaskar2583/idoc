﻿namespace API.Models
{
    public class EventTypeData
    {
        public int EVMId { get; set; }
        public string EVMEventType { get; set; }
    }
}