﻿namespace API.Models
{
    public class EventTypeMeasuresData
    {
        public int EMMId { get; set; }        
        public string MEMMeasure { get; set; }
        public string MEMDisplayName { get; set; }
        public string EMMTimePeriod { get; set; }
        public string Selected { get; set; }

        public string EVMEventType { get; set; }
        public int EMMBaselinePeriod { get; set; }
        public int EMMPerformancePeriod { get; set; }
    }
}
