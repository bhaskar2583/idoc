﻿namespace API.Models
{
    public class YearData
    {
        public int Year { get; set; }
    }
}