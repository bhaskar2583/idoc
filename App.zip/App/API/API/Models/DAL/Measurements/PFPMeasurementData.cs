﻿namespace API.Models.DAL.Measurements
{
    using System.Collections.Generic;

    public class PFPMeasurementData
    {
        public PFPMeasurementData()
        {
            this.EventTypeMeasuresDatas = new List<EventTypeMeasuresData>();
        }

        public int? HOSId { get; set; }
        public int? CALId { get; set; }
        public int? EMMId { get; set; }
        public int? Year { get; set; }
        public int? EVMId { get; set; }
        public int? TPId { get; set; }

        public List<EventTypeMeasuresData> EventTypeMeasuresDatas { get; set; }
        public List<PFPMeasurement> PFPMeasurements { get; set; }
    }

    public class PFPMeasurement
    {
        public string MeasureId { get; set; }
        public int? HosId { get; set; }
        public int? CalId { get; set; }
        public int? EmmId { get; set; }
        public string MonthYear { get; set; }
        public decimal Numerator { get; set; }
        public decimal Denominator { get; set; }
        public string UpdatedBy { get; set; }
        public int? OrderBy { get; set; }
    }
}
