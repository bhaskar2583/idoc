﻿namespace API.Models.DAL.Measurements
{
    public class YearData
    {
        public int Year { get; set; }
    }
}