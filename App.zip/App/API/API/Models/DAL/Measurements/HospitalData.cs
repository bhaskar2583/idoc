﻿namespace API.Models.DAL.Measurements
{
    public class HospitalData
    {
        public int HOSId { get; set; }
        public string HOSHospitalName { get; set; }
        //public int HOSPFI { get; set; }
        //public string HOSUniqueId { get; set; }
        //public string HOSParentId { get; set; }
    }
}
