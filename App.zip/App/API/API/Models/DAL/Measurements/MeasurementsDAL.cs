﻿namespace API.Models.DAL.Measurements
{
    using API.Models.EDM;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Entity;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;

    internal class MeasurementsDAL
    {
        private readonly PFPEntities db = new PFPEntities();
        private readonly ManageUserRoles _manageUserRoles = new ManageUserRoles();
        internal List<HospitalData> GetHospitalsData(string email = "")
        {
            var hospitals = new List<Hospital>();
            if (email != null && email.Length > 0)
            {
                var userHosName = db.Users
                    .Where(u => u.USR_Email == email)?.FirstOrDefault()?
                    .USR_OrganizationName?.Replace(" ", "")?.ToLower() ?? string.Empty;
                var Hoss = db.Hospitals.Where(h => h.HOS_Active == true);
                var HosUniqueId = Hoss
                    .Where(h => h.HOS_Active == true && h.HOS_HospitalName.Replace(" ", "").ToLower() == userHosName)?.FirstOrDefault()?
                    .HOS_Unique_Id?.Replace(" ", "")?.ToLower() ?? string.Empty;
                hospitals = Hoss
                    .Where(h => h.HOS_Active == true
                    && (h.HOS_HospitalName.Replace(" ", "").ToLower() == userHosName
                    || h.HOS_Unique_Id.Replace(" ", "").ToLower() == HosUniqueId
                    || h.HOS_Parent_Id.Replace(" ", "").ToLower() == HosUniqueId)).ToList();
                return Komparer(hospitals);
            }
            else
            {
                hospitals = db.Hospitals.Where(h => h.HOS_Active == true).ToList();
                return Komparer(hospitals);
            }
        }

        internal List<HospitalData> Komparer(List<Hospital> hospitals)
        {
            var hoss = hospitals.GroupBy(k => new { k.HOS_HospitalName, k.HOS_Unique_Id }).Select(k => k.FirstOrDefault());
            return hoss.Select(h => new HospitalData() { HOSId = h.HOS_Id, HOSHospitalName = h.HOS_HospitalName }).OrderBy(h => h.HOSHospitalName).ToList();
        }

        internal List<YearData> GetYears(int Year)
        {
            var Years = db.CalendarMasters.Where(c => c.CAL_Active == true).GroupBy(y => new { y.CAL_Year }).Select(c => c.FirstOrDefault());
            if (Year > 0)
                Years = Years.Where(c => c.CAL_Year >= Year);
            return Years.Select(c => new YearData { Year = c.CAL_Year }).OrderByDescending(c => c.Year).ToList();
        }

        internal List<EventTypeData> GetEventTypes()
        {
            var ets = db.EventTypeMasters.Where(e => e.EVM_Active == true).ToList();
            return ets.Select(e => new EventTypeData() { EVMId = e.EVM_Id, EVMEventType = e.EVM_EventType }).OrderBy(e => e.EVMEventType).ToList();
        }

        internal List<EventTypeData> GetEventTypesByUserId(int userId)
        {
            var roles = _manageUserRoles.GetUserAllRoles(userId);
            if (roles == null && roles.Count < 1)
                return null;

            List<int> events = new List<int>();
            roles.ForEach(r =>
            {
                //var str = r.RoleName.Split(null);
                events.Add((int)r.EventId);             
            });
            if (events !=null && events.Count > 0)
            {
                var ets = db.EventTypeMasters.Where(e => e.EVM_Active == true).ToList();
                ets = ets.Where(e => events.Contains(e.EVM_Id)).ToList();
                if(ets.Count==0)
                {
                    return GetEventTypes();
                }
                return ets.Select(e => new EventTypeData() { EVMId = e.EVM_Id, EVMEventType = e.EVM_EventType }).OrderBy(e => e.EVMEventType).ToList();
            }
            return GetEventTypes();
        }
        internal List<EventTypeMeasuresData> GetEventMeasuresByEventId(int eveId)
        {
            var measureIds = db.EventMeasureMasters.Where(x => x.EMM_EVM_Id == eveId && x.EMM_Active == true).ToList();
            if (measureIds == null && measureIds.Count < 1)
                return null;

            List<int> measures = new List<int>();
            measureIds.ForEach(r =>
            {
                var measure = db.MeasureMasters.FirstOrDefault(x => x.MEM_Id == r.EMM_MEM_Id);
                measures.Add(measure.MEM_Id);
            });
            if (measures != null && measures.Count > 0)
            {
                var ets = db.MeasureMasters.Where(e => e.MEM_Active == true).ToList();
                ets = ets.Where(e => measures.Contains(e.MEM_Id)).ToList();
                if (ets.Count == 0)
                {
                    return null;
                }
                return ets.Select(e => new EventTypeMeasuresData() { EMMId = e.MEM_Id, MEMMeasure = e.MEM_Measure, MEMDisplayName = e.MEM_DisplayName }).OrderBy(e => e.MEMDisplayName).ToList();
            }
            return null;
        }
        internal List<EventTypeMeasuresData> GetEventTypeMeasures(int EVMId)
        {
            var ets = db.EventMeasureMasters.Where(e => e.EMM_Active == true && e.EMM_EVM_Id == EVMId).GroupBy(e => new { e.EMM_EVM_Id, e.EMM_MEM_Id }).Select(e => e.FirstOrDefault());
            return ets.Select(e => new EventTypeMeasuresData() { EMMId = e.EMM_Id, MEMDisplayName = e.MeasureMaster.MEM_DisplayName, MEMMeasure = e.MeasureMaster.MEM_Measure, EMMTimePeriod = e.EMM_TimePeriod, EVMEventType = e.EventTypeMaster.EVM_EventType, EMMBaselinePeriod = e.EMM_BaselinePeriod, EMMPerformancePeriod = e.EMM_PerformancePeriod }).OrderBy(k => k.EVMEventType).ThenBy(k => k.MEMDisplayName).ThenBy(k => k.MEMMeasure).ToList();
        }

        internal List<TimePeriodData> GetTimePeriods(int EMMId)
        {
            var emm = db.EventMeasureMasters.Where(e => e.EMM_Id == EMMId).FirstOrDefault();
            var emms = db.EventMeasureMasters.Where(e => e.EMM_EVM_Id == emm.EMM_EVM_Id && e.EMM_MEM_Id == emm.EMM_MEM_Id).GroupBy(e => new { e.EMM_TimePeriod }).Select(e => e.FirstOrDefault()).ToList();
            List<TimePeriodData> timePeriods = new List<TimePeriodData>();
            foreach (var em in emms)
            {
                if (em.EMM_TimePeriod.ToLower().StartsWith("m"))
                {
                    timePeriods.Add(new TimePeriodData() { TPId = 1, TimePeriod = "Monthly (Jan - Mar)" });
                    timePeriods.Add(new TimePeriodData() { TPId = 2, TimePeriod = "Monthly (Apr - Jun)" });
                    timePeriods.Add(new TimePeriodData() { TPId = 3, TimePeriod = "Monthly (Jul - Sep)" });
                    timePeriods.Add(new TimePeriodData() { TPId = 4, TimePeriod = "Monthly (Oct - Dec)" });
                }
                else if (em.EMM_TimePeriod.ToLower().StartsWith("q"))
                    timePeriods.Add(new TimePeriodData() { TPId = 5, TimePeriod = "Quarterly (Q1, Q2, Q3, Q4)" });
            }
            return timePeriods.OrderBy(o => o.TPId).ToList();
        }


        internal List<PFPMeasurement> GetMeasurementsData(PFPMeasurementData m)
        {
            if (m != null && m.HOSId != null && m.Year != null && m.EMMId != null && m.TPId != null)
            {
                var cals = new List<CalendarMaster>();
                if (m.TPId == 5)
                {
                    cals.AddRange(db.CalendarMasters.Where(y => y.CAL_Year == m.Year && (y.CAL_Month == 1 || y.CAL_Month == 4 || y.CAL_Month == 7 || y.CAL_Month == 10)).ToList());
                    foreach (var c in cals)
                        c.CAL_MonthText = c.CAL_Month == 1 ? "Q1" : c.CAL_Month == 4 ? "Q2" : c.CAL_Month == 7 ? "Q3" : c.CAL_Month == 10 ? "Q4" : c.CAL_MonthText;
                }
                else if (m.TPId == 2)
                    cals.AddRange(db.CalendarMasters.Where(y => y.CAL_Year == m.Year && (y.CAL_Month == 4 || y.CAL_Month == 5 || y.CAL_Month == 6)).ToList());
                else if (m.TPId == 3)
                    cals.AddRange(db.CalendarMasters.Where(y => y.CAL_Year == m.Year && (y.CAL_Month == 7 || y.CAL_Month == 8 || y.CAL_Month == 9)).ToList());
                else if (m.TPId == 4)
                    cals.AddRange(db.CalendarMasters.Where(y => y.CAL_Year == m.Year && (y.CAL_Month == 10 || y.CAL_Month == 11 || y.CAL_Month == 12)).ToList());
                else
                    cals.AddRange(db.CalendarMasters.Where(y => y.CAL_Year == m.Year && (y.CAL_Month == 1 || y.CAL_Month == 2 || y.CAL_Month == 3)).ToList());

                try
                {
                    var measure = "hyperglycemiaandhypoglycemia";
                    var SourceTypeNDNQI = "ndnqi";
                    var em = db.EventMeasureMasters.Where(e => e.EMM_Id == m.EMMId && e.MeasureMaster.MEM_DisplayName.Replace(" ", "").ToLower().StartsWith(measure)).FirstOrDefault();

                    List<PFPMeasurement> listPFPMeasurements = new List<PFPMeasurement>();
                    if (em != null)
                    {
                        List<EventMeasureMaster> emms = db.EventMeasureMasters.Where(e => e.EMM_EVM_Id == em.EMM_EVM_Id && e.MeasureMaster.MEM_DisplayName.Replace(" ", "").ToLower().StartsWith(measure)).ToList();
                        if (emms.Count() > 0)
                        {
                            foreach (var emm in emms)
                            {
                                var emmId = emm.EMM_Id;
                                List<NYSPFPData> pfpDatas = new List<NYSPFPData>();
                                foreach (var cal in cals)
                                {
                                    var pfpObj = db.NYSPFPDatas.Where(e => e.NPD_HOS_Id == m.HOSId && e.NPD_Cal_Id == cal.CAL_Id && e.NPD_EMM_Id == emmId).FirstOrDefault();
                                    if (pfpObj != null)
                                        pfpDatas.Add(pfpObj);
                                }

                                var pFPMeasurements = from c1 in cals
                                                      join p1 in pfpDatas on c1.CAL_Id equals p1.NPD_Cal_Id into ll
                                                      from l1 in ll.DefaultIfEmpty()
                                                      select new PFPMeasurement()
                                                      {
                                                          MeasureId = string.Format("{0}_{1}_{2}", m.HOSId, c1.CAL_Id, emmId),
                                                          HosId = m.HOSId,
                                                          CalId = c1.CAL_Id,
                                                          EmmId = emmId,
                                                          MonthYear = string.Format("{0}-{1}", c1?.CAL_MonthText ?? string.Empty, c1?.CAL_Year.ToString() ?? string.Empty),
                                                          Numerator = l1?.NPD_Numerator ?? 0.0m,
                                                          Denominator = l1?.NPD_Denominator ?? 0.0m,
                                                          NumeratorDefinition = emm != null ? emm.MeasureMaster.MEM_NumeratorDefinition : "No Definition",
                                                          DenominatorDefinition = emm != null ? emm.MeasureMaster.MEM_DenominatorDefinition : "No Definition",
                                                          OrderBy = c1?.CAL_OrderBy ?? 1,
                                                          IsReadOnly = (l1?.NPD_SourceType?.Replace(" ", "").ToLower() ?? "NYSPFP") == SourceTypeNDNQI ? true : false
                                                      };
                                if (pFPMeasurements != null)
                                    listPFPMeasurements.AddRange(pFPMeasurements.ToList());
                            }
                        }
                    }
                    else
                    {
                        List<NYSPFPData> pfpDatas = new List<NYSPFPData>();
                        foreach (var cal in cals)
                        {
                            var pfpObj = db.NYSPFPDatas.Where(e => e.NPD_HOS_Id == m.HOSId && e.NPD_Cal_Id == cal.CAL_Id && e.NPD_EMM_Id == m.EMMId).FirstOrDefault();
                            if (pfpObj != null)
                                pfpDatas.Add(pfpObj);
                        }

                        var emm = db.EventMeasureMasters.Where(e => e.EMM_Id == m.EMMId).FirstOrDefault();

                        var pFPMeasurements = from c1 in cals
                                              join p1 in pfpDatas on c1.CAL_Id equals p1.NPD_Cal_Id into ll
                                              from l1 in ll.DefaultIfEmpty()
                                              select new PFPMeasurement()
                                              {
                                                  MeasureId = string.Format("{0}_{1}_{2}", m.HOSId, c1.CAL_Id, m.EMMId),
                                                  HosId = m.HOSId,
                                                  CalId = c1.CAL_Id,
                                                  EmmId = m.EMMId,
                                                  MonthYear = string.Format("{0}-{1}", c1?.CAL_MonthText ?? string.Empty, c1?.CAL_Year.ToString() ?? string.Empty),
                                                  Numerator = l1?.NPD_Numerator ?? 0.0m,
                                                  Denominator = l1?.NPD_Denominator ?? 0.0m,
                                                  NumeratorDefinition = emm != null ? emm.MeasureMaster.MEM_NumeratorDefinition : "No Definition",
                                                  DenominatorDefinition = emm != null ? emm.MeasureMaster.MEM_DenominatorDefinition : "No Definition",
                                                  OrderBy = c1?.CAL_OrderBy ?? 1,
                                                  IsReadOnly = (l1?.NPD_SourceType?.Replace(" ", "").ToLower() ?? "NYSPFP") == SourceTypeNDNQI ? true : false
                                              };
                        if (pFPMeasurements != null)
                            listPFPMeasurements.AddRange(pFPMeasurements.ToList());
                    }

                    return listPFPMeasurements.ToList();
                }
                catch(Exception)
                {
                    return new List<PFPMeasurement>();
                }
            }
            return new List<PFPMeasurement>();
        }

        internal HttpStatusCode SaveBGMeasures(string bgId, decimal bgVal, PFPMeasurement m)
        {
            string[] bgIds = bgId.Split('_');
            m.HosId = int.TryParse(bgIds[0], out int s) ? s : 0;
            m.CalId = int.TryParse(bgIds[1], out int k) ? k : 0;
            m.EmmId = int.TryParse(bgIds[2], out int a) ? a : 0;

            var measure = bgIds[3] == null ? string.Empty : bgIds[3];
            var em = db.EventMeasureMasters.Where(e => e.EMM_Id == m.EmmId).FirstOrDefault();
            if (bgId.ToLower().Contains("denominator"))
            {
                List<int> emmIds = db.EventMeasureMasters.Where(e => e.EMM_EVM_Id == em.EMM_EVM_Id && e.MeasureMaster.MEM_DisplayName.Replace(" ", "").ToLower().StartsWith(measure))?.Select(e => e.EMM_Id).ToList() ?? new List<int>();
                List<PFPMeasurement> pfps = new List<PFPMeasurement>();
                var returnStatus = HttpStatusCode.OK;
                foreach (var emmId in emmIds)
                {
                    PFPMeasurement pfp = new PFPMeasurement()
                    {
                        HosId = m.HosId,
                        CalId = m.CalId,
                        EmmId = emmId,
                        Numerator = db.NYSPFPDatas.Where(l => l.NPD_HOS_Id == m.HosId && l.NPD_Cal_Id == m.CalId && l.NPD_EMM_Id == emmId)?.FirstOrDefault()?.NPD_Numerator ?? 0,
                        Denominator = bgVal,
                        UpdatedBy = m.UpdatedBy
                    };
                    var retStatus = SavePFPMeasurementDatas(pfp);
                    returnStatus = retStatus == HttpStatusCode.OK ? returnStatus : retStatus;
                }
                return returnStatus;
            }
            return HttpStatusCode.NotImplemented;
        }

        internal HttpStatusCode SavePFPMeasurementDatas(PFPMeasurement m)
        {
            try
            {
                if(m != null)
                {
                    var pfp = db.NYSPFPDatas.Where(k => k.NPD_HOS_Id == m.HosId && k.NPD_Cal_Id == m.CalId && k.NPD_EMM_Id == m.EmmId).FirstOrDefault();
                    var multiplier = db.EventMeasureMasters.Where(e => e.EMM_Id == m.EmmId).FirstOrDefault()?.MeasureMaster?.MEM_Multiplier ?? 0;

                    if (pfp != null && pfp.NPD_Id > 0 && (m.Numerator >= 0 || m.Denominator >= 0))
                    {
                        pfp.NPD_Numerator = m.Numerator == -1 ? pfp.NPD_Numerator : m.Numerator;
                        pfp.NPD_Denominator = m.Denominator == -1 ? pfp.NPD_Denominator : m.Denominator;
                        pfp.NPD_Measurement = pfp.NPD_Denominator > 0 ? ((pfp.NPD_Numerator / pfp.NPD_Denominator) * multiplier) : 0;
                        pfp.NPD_SourceType = "NYSPFP";
                        pfp.NPD_CreatedBy = "KSuriyak@HANYS.org";
                        pfp.NPD_UpdatedBy = m.UpdatedBy;
                        pfp.NPD_UpdatedOn = DateTime.Now;

                        db.Entry(pfp).State = EntityState.Modified;
                        db.SaveChanges();
                        return HttpStatusCode.OK;
                    }
                    else if(m.Numerator > 0 || m.Denominator > 0)
                    {
                        pfp = new NYSPFPData
                        {
                            NPD_Id = 0,
                            NPD_HOS_Id = (int)m.HosId,
                            NPD_Cal_Id = (int)m.CalId,
                            NPD_EMM_Id = (int)m.EmmId,
                            NPD_Numerator = m.Numerator == -1 ? 0 : m.Numerator,
                            NPD_Denominator = m.Denominator == -1 ? 0 : m.Denominator,
                            NPD_Measurement = m.Denominator > 0 ? ((m.Numerator == -1 ? 0 : m.Numerator / m.Denominator == -1 ? 0 : m.Denominator) * multiplier) : 0,
                            NPD_SourceType = "NYSPFP",
                            NPD_CreatedBy = "KSuriyak@HANYS.org",
                            NPD_CreatedOn = DateTime.Now,
                            NPD_UpdatedBy = m.UpdatedBy,
                            NPD_UpdatedOn = DateTime.Now
                        };
                        db.NYSPFPDatas.Add(pfp);
                        db.SaveChanges();
                        return HttpStatusCode.OK;
                    }
                }
                return HttpStatusCode.InternalServerError;
            }
            catch (Exception)
            {
                return HttpStatusCode.NotImplemented;
            }
        }

        internal HttpStatusCode SaveReportingPeriods(string email, EventTypeMeasuresData etmd)
        {
            try
            {
                var etms = db.EventMeasureMasters.Where(k => k.EMM_EVM_Id == db.EventMeasureMasters.Where(a => a.EMM_Id == etmd.EMMId).FirstOrDefault().EMM_EVM_Id && k.EMM_MEM_Id == db.EventMeasureMasters.Where(m => m.EMM_Id == etmd.EMMId).FirstOrDefault().EMM_MEM_Id).ToList();
                foreach (var etm in etms)
                {
                    etm.EMM_BaselinePeriod = etmd.EMMBaselinePeriod;
                    etm.EMM_PerformancePeriod = etmd.EMMPerformancePeriod;
                    etm.EMM_UpdatedBy = email;
                    etm.EMM_UpdatedOn = DateTime.Now;

                    db.Entry(etm).State = EntityState.Modified;
                    db.SaveChanges();
                }
                return HttpStatusCode.OK;
            }
            catch(Exception)
            {
                return HttpStatusCode.InternalServerError;
            }
        }

        internal DataTable SaveUploadMeasures(string email, string fileName, DataTable dataTable)
        {
            DataTable dt = new DataTable();
            var connString = System.Configuration.ConfigurationManager.ConnectionStrings["PFPDBConnection"].ConnectionString;

            try
            {
                using (var bulk = new SqlBulkCopy(connString, SqlBulkCopyOptions.FireTriggers))
                {
                    bulk.DestinationTableName = "pfp.UploadFileStaging";
                    bulk.WriteToServer(dataTable);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                try
                {
                    var syn = new PFPEntities().spUpdateNYSPFPFromUploadedData(fileName);

                    SqlConnection conn = new SqlConnection(connString);
                    SqlCommand sqlcmd = new SqlCommand("SELECT [UFS_Measure],[UFS_Year],[UFS_Month],[UFS_Numerator],[UFS_Denominator] FROM [PFP].[pfp].[UploadFileStaging] WHERE [UFS_FileName] = @filename And [UFS_IsProcessed] < 2;", conn);
                    SqlParameter param = new SqlParameter
                    {
                        ParameterName = "@filename",
                        Value = fileName
                    };
                    sqlcmd.Parameters.Add(param);
                    SqlDataAdapter da = new SqlDataAdapter(sqlcmd);
                    conn.Open();
                    da.Fill(dt);
                    conn.Close();
                    da.Dispose();
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return dt;
        }
        public object GetEventTypeById(int eveId)
        {
            return db.EventTypeMasters.Where(x => x.EVM_Id == eveId && x.EVM_Active == true);
        }
    }
}

