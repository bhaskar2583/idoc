﻿namespace API.Models.DAL.Measurements
{
    public class EventTypeData
    {
        public int EVMId { get; set; }
        public string EVMEventType { get; set; }
    }
}