﻿namespace API.Models.DAL.Measurements
{
    public class TimePeriodData
    {
        public int TPId { get; set; }
        public string TimePeriod { get; set; }
    }
}