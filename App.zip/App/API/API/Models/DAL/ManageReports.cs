﻿using API.Models.EDM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models.DAL
{
    public class ManageReports
    {
        private PFPEntities db = new PFPEntities();
        public string GetFromYear(int type)
        {
            var measure = db.EventTypeMasters.FirstOrDefault(x => x.EVM_Id == type);
            var measureType = db.EventMeasureMasters.FirstOrDefault(e => e.EMM_EVM_Id == measure.EVM_Id);
            return measureType.EMM_BaselinePeriod.ToString();
        }
    }
}