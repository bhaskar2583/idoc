﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models
{
    public class ReportsMasterVM
    {
        public string Key { get; set; }
        public List<ReportVM> data { get; set; }
    }
    public class ReportVM
    {
        public int Year { get; set; }
        public int Month { get; set; }
        public string MONTHTEXT { get; set; }
        public decimal NUMERATOR { get; set; }
        public decimal DENOMINATOR { get; set; }
        public decimal PFPRATE { get; set; }
        public decimal HOSPRATE { get; set; }
        public int HOSCOUNT { get; set; }
    }
}