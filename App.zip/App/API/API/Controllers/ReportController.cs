﻿namespace API.Controllers
{
    using API.Models.DAL;
    using System.Collections.Generic;
    using System.Web.Http;

    public class ReportController : ApiController
    {
        private ManageReports reports = new ManageReports();
        // GET: api/Home
        public string GetPFP(int Id, string from, string to, string type,string measure)
        {
            return new SQLHelper().GetDataFromSQL("[pfp].[spPressureInjuryRates]", new List<SQLHelperParams>()
            { new SQLHelperParams() {  Param = "@fromyear", Value = from},
             new SQLHelperParams() {  Param = "@toyear", Value = to},
             new SQLHelperParams() {  Param = "@type", Value = type},
             new SQLHelperParams() {  Param = "@orgid", Value = Id},
             new SQLHelperParams() {  Param = "@Measure", Value = measure}});
        }
        public string GetFromYear(int type)
        {
            var year = reports.GetFromYear(type);
            return year;
        }
    }
}
