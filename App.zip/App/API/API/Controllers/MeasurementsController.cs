﻿namespace API.Controllers
{
    using API.Models.DAL.Measurements;
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Web.Http;
    using System.Web.Http.Description;

    public class MeasurementsController : ApiController
    {
        private MeasurementsDAL dbM = new MeasurementsDAL();

        public List<HospitalData> GetHospitalsData(string email)
        {
            return dbM.GetHospitalsData(email);
        }

        public List<YearData> GetYears(int Year)
        {
            return dbM.GetYears(Year);
        }

        public List<EventTypeData> GetEventTypes()
        {
            return dbM.GetEventTypes();
        }

        public List<EventTypeMeasuresData> GetEventTypeMeasures(int EMMId, int EVMId)
        {
            return dbM.GetEventTypeMeasures(EVMId);
        }

        public List<TimePeriodData> GetTimePeriods(int EMMId)
        {
            return dbM.GetTimePeriods(EMMId);
        }

        [HttpPost]
        public List<PFPMeasurement> GetPFPMeasurementDatas(PFPMeasurementData pFPMeasurementData)
        {
            return dbM.GetMeasurementsData(pFPMeasurementData);
        }

        [HttpPost]
        public HttpStatusCode SavePFPMeasurementDatas(int id, PFPMeasurement pFPMeasurement)
        {
            if (pFPMeasurement.HosId > 0 && pFPMeasurement.CalId > 0 && pFPMeasurement.EmmId > 0)
            {
                return dbM.SavePFPMeasurementDatas(pFPMeasurement);
            }
            return HttpStatusCode.BadRequest;
        }
    }
}
