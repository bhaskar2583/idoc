﻿namespace API.Controllers
{
    using API.Models;
    using API.Models.DAL;
    using API.Models.DAL.Measurements;
    using System.Collections.Generic;
    using System.Data;
    using System.Net;
    using System.Web.Http;

    public class MeasurementsController : ApiController
    {
        private MeasurementsDAL dbM = new MeasurementsDAL();
        private ManageUsers users = new ManageUsers();

        public List<HospitalData> GetHospitalsData(string email)
        {
            return dbM.GetHospitalsData(email);
        }

        public List<YearData> GetYears(int Year)
        {
            return dbM.GetYears(Year);
        }

        public List<EventTypeData> GetEventTypes()
        {
            return dbM.GetEventTypes();
        }
        public List<EventTypeData> GetEventTypes(int userId,string email)
        {
            int user = users.GetUserByEmail(email);
            var list= dbM.GetEventTypesByUserId(user);
            return list;
        }
        public List<EventTypeMeasuresData> GetEventMeasureTypes(int eveId, string email)
        {
            int user = users.GetUserByEmail(email);
            return dbM.GetEventMeasuresByEventId(eveId);
        }
        public List<EventTypeMeasuresData> GetEventTypeMeasures(int EMMId, int EVMId)
        {
            return dbM.GetEventTypeMeasures(EVMId);
        }

        public List<TimePeriodData> GetTimePeriods(int EMMId)
        {
            return dbM.GetTimePeriods(EMMId);
        }

        [HttpPost]
        public List<PFPMeasurement> GetPFPMeasurementDatas(PFPMeasurementData pFPMeasurementData)
        {
            return dbM.GetMeasurementsData(pFPMeasurementData);
        }

        [HttpPost]
        public HttpStatusCode SavePFPMeasurementDatas(int id, PFPMeasurement pFPMeasurement)
        {
            if (pFPMeasurement.HosId > 0 && pFPMeasurement.CalId > 0 && pFPMeasurement.EmmId > 0)
            {
                return dbM.SavePFPMeasurementDatas(pFPMeasurement);
            }
            return HttpStatusCode.BadRequest;
        }

        [HttpPost]
        public HttpStatusCode SaveBGMeasures(string bgId, decimal bgVal, PFPMeasurement pFPMeasurement)
        {
            if (bgId != null && bgId.Length > 0)
            {
                return dbM.SaveBGMeasures(bgId, bgVal, pFPMeasurement);
            }
            return HttpStatusCode.BadRequest;
        }

        [HttpPost]
        public HttpStatusCode SaveReportingPeriods(string email, EventTypeMeasuresData eventTypeMeasuresData)
        {
            if (eventTypeMeasuresData != null && eventTypeMeasuresData.EMMId > 0)
            {
                return dbM.SaveReportingPeriods(email, eventTypeMeasuresData);
            }
            return HttpStatusCode.BadRequest;
        }

        [HttpPost]
        public DataTable SaveUploadMeasures(string email, string fileName, DataTable dt)
        {
            if (email != null && fileName != null && dt.Rows.Count > 0)
            {
                return dbM.SaveUploadMeasures(email, fileName, dt);
            }
            return dt;
        }
    }
}
