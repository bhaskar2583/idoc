﻿using API.Models;
using API.Models.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace API.Validators
{
    public static class RoleValidator
    {
        private static ManageUsers _manageUser = new ManageUsers();
        private static ManageUserRoles _manageUserRoles = new ManageUserRoles();
        public  static async Task<bool> HospitaladminRoleValidator(UserRoleVM userRole)
        {
            var user = await _manageUser.GetUserById(userRole.UserId);
            var roles = _manageUserRoles.GetUserRoles();
           //var users = _manageUser.GetUserMasters();
           // users = users.Where(u => u.USR_OrganizationName == ((UserVM)user).USR_OrganizationName).ToList();
            roles = roles.Where(ur => ur.OrganizationName == ((UserVM)user).USR_OrganizationName).ToList();
            roles = roles.Where(ur => ur.RoleId == 80).ToList();
            return roles.Count() < 2;
        }
        public static async Task<bool> DataFeedRoleValidator(UserRoleVM userRole)
        {
            var user = await _manageUser.GetUserById(userRole.UserId);
            var roles = _manageUserRoles.GetUserRoles();
            //var users = _manageUser.GetUserMasters();
            // users = users.Where(u => u.USR_OrganizationName == ((UserVM)user).USR_OrganizationName).ToList();
            roles = roles.Where(ur => ur.OrganizationName == ((UserVM)user).USR_OrganizationName).ToList();
            roles = roles.Where(ur => ur.RoleId == 76).ToList();
            return roles.Count() < 16;
        }
    }
}