﻿using IBSSchedular.Core.Configurations;
using IBSSchedular.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular
{
    class Program
    {
        static void Main(string[] args)
        {

            SfDataReaderFactory _sfDataReaderFactory = new SfDataReaderFactory();
            _sfDataReaderFactory.CreateDafaultDataReadorFactpory();
            foreach (var dataReader in _sfDataReaderFactory.GetDataReaderFactories())
            {
                dataReader.ReadData();
            }



            SchedularConfigurations.Configure();


        }
    }
}
