﻿using IBSSchedular.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.Builder
{
    public class EmailModelDirector
    {
        public EmailBuilder _builder;
        public EmailModelDirector(EmailBuilder builder)
        {
            _builder = builder;
        }

        public void CreateMailModel(string from,List<string> to)
        {
            _builder.CreateMailMessage();
            _builder.AddFrom(from);
            _builder.AddTo(to);
            _builder.AddSubject("Unable to connect SF account");
            _builder.AddBody("Unable to connect SF account");
        }
        public void CreateMailModelFoServiceStop(string from, List<string> to)
        {
            _builder.CreateMailMessage();
            _builder.AddFrom(from);
            _builder.AddTo(to);
            _builder.AddSubject("IBS schedular stoped");
            _builder.AddBody("IBS schedular stoped");
        }

        public void CreateMailModelForInvalidPolicy(string from, List<string> to,string eFDate,string policyNo)
        {
            _builder.CreateMailMessage();
            _builder.AddFrom(from);
            _builder.AddTo(to);
            if(string.IsNullOrEmpty(eFDate))
            _builder.AddSubject("Invalid policy no:"+ policyNo);
            _builder.AddBody("Invalid effective date for policy no:"+ policyNo);
        }
        public MailMessage GetMailModel()
        {
            return _builder.GetMailMessage();
        }
    }
}
