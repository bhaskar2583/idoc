﻿using IBSSchedular.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.Builder
{
    public abstract class EmailBuilder
    {
        protected EmailModel _mailMessage;

        public void CreateMailMessage()
        {
            _mailMessage = new EmailModel();
        }
        public MailMessage GetMailMessage()
        {
            return _mailMessage;
        }

        public abstract void AddFrom(string fromEmail);
        public abstract void AddTo(List<string> toEmail);
        public abstract void AddCC(List<string> ccEmail);
        public abstract void AddBCC(List<string> bccEmail);
        public abstract void AddSubject(string subject);
        public abstract void AddBody(string body);
    }
}
