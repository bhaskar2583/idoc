﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.Builder
{
    public class ProductEmailModelBuilder : EmailBuilder
    {
        public override void AddBCC(List<string> bccEmail)
        {

        }

        public override void AddBody(string body)
        {
            _mailMessage.Body = body;
        }

        public override void AddCC(List<string> ccEmail)
        {
            throw new NotImplementedException();
        }

        public override void AddFrom(string fromEmail)
        {
            _mailMessage.From = new System.Net.Mail.MailAddress(fromEmail);
        }

        public override void AddSubject(string subject)
        {
            _mailMessage.Subject = subject;
        }

        public override void AddTo(List<string> toEmail)
        {
            toEmail.ForEach(m =>
            {
                _mailMessage.To.Add(m);
            });


        }
    }
}
