﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IBS.Service.Repositories;
using IBS.Service.Utils;
using IBSSchedular.Core.Builder;
using IBSSchedular.Core.Constants;
using IBSSchedular.Core.SFDC;
using IBSSchedular.Core.SMTP;

namespace IBSSchedular.Core.Data.visitor
{
    public class DataUpdateVisitor : IVisitor
    {
        private readonly IClientRepository _clientRepository;
        private readonly ICarrierRepository _carrierRepository;
        private readonly ICommonRepository _commonRepository;
        private readonly ICommisionRepository _commissionRepository;
        private readonly IPolicyRepository _policyRepository;
       
        public DataUpdateVisitor()
        {
            _clientRepository = new ClientRepository();
            _carrierRepository = new CarrierRepository();
            _commonRepository = new CommonRepository();
            _commissionRepository = new CommisionRepository();
            _policyRepository = new PolicyRepository();
        }
        public bool Visit(Account account)
        {
            //

            if (account.Type != "Partner")
            {
                var isExist = _clientRepository.GetAll().FirstOrDefault(a => a.Name == account.Name);

                if (isExist == null)
                {
                    _clientRepository.Add(new IBS.Core.Entities.Client()
                    {
                        Name = account.Name,
                        IsActive = true,
                        Division = account.Division__c,
                        AddUser = "IBS Service",
                        AddDate = DateUtil.GetCurrentDate(),
                        SfiId = account.Id
                    });
                }

                if (isExist != null)
                {
                    isExist.Name = account.Name;
                    isExist.RevDate = DateUtil.GetCurrentDate();
                    isExist.RevUser = "IBS Service";
                    _clientRepository.Update(isExist);
                }


            }
            else
            {
                var isExistCarrier = _carrierRepository.GetAll().FirstOrDefault(a => a.Name == account.Name);

                if (isExistCarrier == null)
                {
                    _carrierRepository.Add(new IBS.Core.Entities.Carrier()
                    {
                        Name = account.Name,
                        SfiId = account.Id,
                        IsActive = true,
                        AddUser = "IBS Service",
                        AddDate = DateUtil.GetCurrentDate()
                    });
                }

                if (isExistCarrier != null)
                {
                    isExistCarrier.Name = account.Name;
                    isExistCarrier.RevDate = DateUtil.GetCurrentDate();
                    isExistCarrier.RevUser = "IBS Service";
                    _carrierRepository.Update(isExistCarrier);
                }

            }

            return true;
        }
      
        public bool Visit(Product2 product)
        {
            SFProductMapper.MapProductType(product);
            var isExistCarrier = _carrierRepository.GetAll().FirstOrDefault(a => a.SfiId == product.Partner_Record_Keeper__c);

            //if (isExistCarrier == null)
            //    _carrierRepository.Add(new IBS.Core.Entities.Carrier()
            //    {
            //        Name = product.Partner_Record_Keeper__c,
            //        IsActive = true,
            //        AddUser = "IBS Service",
            //        AddDate = DateUtil.GetCurrentDate()
            //    });0000
            //isExistCarrier = _carrierRepository.GetAll().FirstOrDefault(a => a.Name == product.Partner_Record_Keeper__c);


            var isExistCoverages = _commonRepository.GetAllCoverages().FirstOrDefault(a => a.Name == product.Coverage_Type__c);

            if (isExistCoverages == null)
            {
                _commonRepository.AddCoverages(new IBS.Core.Entities.Coverage()
                {
                    Name = product.Coverage_Type__c
                });
            }

            if (isExistCoverages != null)
            {
                isExistCoverages.Name = product.Coverage_Type__c;

                _commonRepository.UpdateCoverages(isExistCoverages);
            }
            isExistCoverages = _commonRepository.GetAllCoverages().FirstOrDefault(a => a.Name == product.Coverage_Type__c);

            var isExistProduct = _commonRepository.GetAllProducts().FirstOrDefault(a => a.Name == product.Product_Type__c);
            if (isExistProduct == null)
            {
                _commonRepository.AddProduct(new IBS.Core.Entities.Product()
                {
                    Name = product.Product_Type__c,
                    CoverageId = isExistCoverages.Id
                });
            }
            if (isExistProduct == null)
            {
                isExistProduct.Name = product.Product_Type__c;
                isExistProduct.CoverageId = isExistCoverages.Id;

                _commonRepository.UpdateProduct(isExistProduct);
            }
            isExistProduct = _commonRepository.GetAllProducts().FirstOrDefault(a => a.Name == product.Product_Type__c);

            var isPolicyExist = _policyRepository.GetAll().FirstOrDefault(a => a.PolicyNumber == product.Product_Number__c
            && a.CarId == isExistCarrier.Id);

            if (isPolicyExist == null && isExistCarrier != null && isExistProduct != null && isExistCoverages != null)
            {
                if (product.Effective_Date__c != null)
                {
                    _policyRepository.Add(new IBS.Core.Entities.Policie()
                    {
                        PolicyNumber = product.Product_Number__c,
                        IsActive = true,
                        CarId = isExistCarrier.Id,
                        EffectiveDate = Convert.ToDateTime(product.Effective_Date__c),
                        EndDate = ReturnTypeCaseDate(product.Term_Date__c),//not commin
                        //RevDate = DateUtil.GetCurrentDate(),
                        IsGroupInsurance = true,//not comming
                        CoverageId = isExistCoverages.Id,
                        ProductId = isExistProduct.Id,
                        AddUser = "IBS Service",
                        AddDate = DateUtil.GetCurrentDate()
                    });
                }

                isPolicyExist = _policyRepository.GetAll().FirstOrDefault(a => a.PolicyNumber == product.Product_Number__c
                && a.CarId == isExistCarrier.Id);

                var isClientId = _clientRepository.GetAll().FirstOrDefault(c => c.SfiId == product.Account__c);

                if (isClientId != null && isPolicyExist!=null)
                {

                    var isClientPolicyExist = _commonRepository.AddClientPolocie(new IBS.Core.Entities.ClientPolicie()
                    {
                        ClientId = isClientId.Id,
                        PolicieId = isPolicyExist.Id,
                        IsActive = true,
                        AddUser = "IBS Service",
                        AddDate = DateUtil.GetCurrentDate()
                    });
                }

            }


            if (isPolicyExist != null && isExistCarrier != null && isExistProduct != null && isExistCoverages != null)
            {
                if (product.Effective_Date__c != null)
                {
                    isPolicyExist.PolicyNumber = product.Product_Number__c;
                    isPolicyExist.PolicyNumber = product.Product_Number__c;
                    isPolicyExist.IsActive = true;
                    isPolicyExist.CarId = isExistCarrier.Id;
                    isPolicyExist.EffectiveDate = Convert.ToDateTime(product.Effective_Date__c);
                    isPolicyExist.EndDate = ReturnTypeCaseDate(product.Term_Date__c);//not commin
                    isPolicyExist.IsGroupInsurance = true;//not comming
                    isPolicyExist.CoverageId = isExistCoverages.Id;
                    isPolicyExist.ProductId = isExistProduct.Id;

                    _policyRepository.Update(isPolicyExist);
                }

                if (product.Effective_Date__c == null)
                {
                    isPolicyExist.PolicyNumber = product.Product_Number__c;

                    var emailDirector = new EmailModelDirector(new ProductEmailModelBuilder());
                    emailDirector.CreateMailModelForInvalidPolicy(EmailConfigurations.ProductEmailFrom, EmailConfigurations.ProductEmailTo, null, product.Product_Number__c);
                    var emailCleint = new EmailClient();
                    emailCleint.CreateClient();
                    emailCleint.Send(emailDirector.GetMailModel());
                    _policyRepository.Update(isPolicyExist);
                }

                isPolicyExist = _policyRepository.GetAll().FirstOrDefault(a => a.PolicyNumber == product.Product_Number__c
                && a.CarId == isExistCarrier.Id);

                var isClientId = _clientRepository.GetAll().FirstOrDefault(c => c.SfiId == product.Account__c);

                if (isClientId != null && isPolicyExist != null)
                {

                    var isClientPolicyExist = _commonRepository.AddClientPolocie(new IBS.Core.Entities.ClientPolicie()
                    {
                        ClientId = isClientId.Id,
                        PolicieId = isPolicyExist.Id,
                        IsActive = true,
                        AddUser = "IBS Service",
                        AddDate = DateUtil.GetCurrentDate()
                    });
                }

            }
            //need to check product account_c is equal to account name
            var isExist = _clientRepository.GetAll().FirstOrDefault(a => a.Name == product.Account__c);

           
            if (isExist != null)
            {
                isExist.Division = product.CF_Division__c;
                isExist.RevDate = DateUtil.GetCurrentDate();
                isExist.RevUser = "IBS Service";
                _clientRepository.Update(isExist);
            }

            return true;

        }

        private DateTime? ReturnTypeCaseDate(DateTime? input)
        {
            if (input == null)
                return null;

            return Convert.ToDateTime(input);
        }
    }
}

