﻿using IBS.Service.Repositories;
using IBS.Service.Utils;
using IBSSchedular.Core.Data.visitor;
using IBSSchedular.Core.SFDC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.Data.AccountManage
{
    public class AccountDataUpdate : IAccept
    {
        private Account _account;
        public AccountDataUpdate()
        {
           
        }

        public void Accept(IVisitor visitor)
        {
            visitor.Visit(_account);
        }

        public void AddClient(Account account, IVisitor visitor)
        {
            _account = account;
        }
    }
}
