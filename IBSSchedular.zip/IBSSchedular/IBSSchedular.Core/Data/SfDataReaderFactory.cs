﻿using IBSSchedular.Core.Data.AccountManage;
using IBSSchedular.Core.Data.Product;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.Data
{
    public class SfDataReaderFactory
    {
        public List<ISfDataReader> dataReaderFactory;
        public SfDataReaderFactory()
        {
            dataReaderFactory = new List<ISfDataReader>();
        }

        public void AddFactory(ISfDataReader reader)
        {
            dataReaderFactory.Add(reader);
        }

        public void CreateDafaultDataReadorFactpory()
        {
            dataReaderFactory = new List<ISfDataReader>();
            dataReaderFactory.Add(new ProductDataReader());
            dataReaderFactory.Add(new AccountDataReader());
        }
        public List<ISfDataReader> GetDataReaderFactories()
        {
            return dataReaderFactory;
        }
    }
}
