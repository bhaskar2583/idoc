﻿using IBSSchedular.Core.Data.visitor;
using IBSSchedular.Core.SalesForce;
using IBSSchedular.Core.SFDC;
using IBSSchedular.Core.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.Data.Product
{
    public class ProductDataReader : ISfDataReader
    {
        private readonly SfProduct _productData;
        private readonly IValidator<Product2> _productValidator;
        private visitor.IVisitor _visitor;
        private readonly ProductDataUpdate _productUpdate;
        public ProductDataReader()
        {
            _productData = new SfProduct();
            _productValidator = new ProductValidator();
            _visitor= new DataUpdateVisitor();
            _productUpdate = new ProductDataUpdate();
        }
        public void ReadData()
        {
            var products = _productData.GetAllProducts();

            products.ToList().ForEach(p =>
            {
                if (_productValidator.Validate(p))
                {
                    _productUpdate.AddProduct(p, _visitor);
                }
            });
            Console.WriteLine("ProductReader start");
            
        }
    }
}
