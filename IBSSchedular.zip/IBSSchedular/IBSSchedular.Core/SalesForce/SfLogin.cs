﻿using IBSSchedular.Core.Builder;
using IBSSchedular.Core.Constants;
using IBSSchedular.Core.SFDC;
using IBSSchedular.Core.SMTP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.SalesForce
{
    public class SfLogin
    {
        public static SforceService SfdcBinding = null;

       
        public static SforceService GetSalesForceInstance()
        {
            if (SfdcBinding != null)
                return SfdcBinding;

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            LoginResult CurrentLoginResult = null;
            SfdcBinding = new SforceService();
            try
            {
                CurrentLoginResult = SfdcBinding.login("krish048@salesforce.com1", "Apple@8187bUDsix4yt3ZIKoyQsR8VIc4s");
            }
            catch (System.Web.Services.Protocols.SoapException e)
            {
                // This is likley to be caused by bad username or password

                var emailDirector = new EmailModelDirector(new SalesForceEmailBuilder());
                emailDirector.CreateMailModel(EmailConfigurations.SalesForceEmailFrom, EmailConfigurations.SalesForceEmailTo);
                var emailCleint = new EmailClient();
                emailCleint.CreateClient();
                emailCleint.Send(emailDirector.GetMailModel());

                SfdcBinding = null;
                return null;
            }
            catch (Exception e)
            {
                // This is something else, probably comminication
                var emailDirector = new EmailModelDirector(new SalesForceEmailBuilder());
                emailDirector.CreateMailModel(EmailConfigurations.SalesForceEmailFrom, EmailConfigurations.SalesForceEmailTo);
                var emailCleint = new EmailClient();
                emailCleint.CreateClient();
                emailCleint.Send(emailDirector.GetMailModel());

                SfdcBinding = null;
                return null;
            }

            //Change the binding to the new endpoint
            SfdcBinding.Url = CurrentLoginResult.serverUrl;

            //Create a new session header object and set the session id to that returned by the login
            SfdcBinding.SessionHeaderValue = new SessionHeader();
            SfdcBinding.SessionHeaderValue.sessionId = CurrentLoginResult.sessionId;
            return SfdcBinding;
        }
    }
}
