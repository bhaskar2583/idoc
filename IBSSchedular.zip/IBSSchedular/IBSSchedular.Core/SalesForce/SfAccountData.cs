﻿using IBSSchedular.Core.SFDC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.SalesForce
{
    public class SfAccountData
    {
        private const string accountSfQuery = "select ID,Name from Account";
        public List<Account> GetAllAccounts()
        {
           
            var accountDetails= new List<Account>();
            var sfConnection = SfLogin.GetSalesForceInstance();

            if (sfConnection == null)
                return accountDetails;
            
            QueryResult queryResult = sfConnection.query(accountSfQuery);

            if (queryResult.size > 0)
            {

                queryResult.records.ToList().ForEach(a =>
                {
                    Account account = (Account)a;
                    accountDetails.Add(account);
                });
                
            }

            return accountDetails;

        }
    }
}
