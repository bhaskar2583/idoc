﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.Models
{
    public class EmailHistoryEntity
    {
        public string EmailType { get; set; }
        public string Recipients { get; set; }
        public string CCRecipients { get; set; }
        public string BCCRecipients { get; set; }
        public string EmailSubject { get; set; }
        public string EmailBody { get; set; }
        public DateTime SentDate { get; set; }
        public bool SendStatus { get; set; }
        public string Priority { get; set; }
    }
}
