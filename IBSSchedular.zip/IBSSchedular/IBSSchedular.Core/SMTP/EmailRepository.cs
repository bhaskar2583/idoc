﻿using IBSSchedular.Core.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.SMTP
{
    public class EmailRepository
    {
        private readonly SqlConnection _con;
        private readonly string _connectionString;
        private string _emailInsertQuery = "Insert into EmailHistory (EmailType,Recipients,CCRecipients,BCCRecipients,EmailSubject,EmailBody,SentDate,SendStatus,Priority) values('{0}',{1},{2},{3},'{4}','{5}','{6}','{7}','{8}')";
        public EmailRepository()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["IBSDbContext"].ToString();
            _con = new SqlConnection(_connectionString);
        }
        public void InsertEmail(EmailHistoryEntity entity)
        {
            _con.Open();
            _emailInsertQuery = string.Format(_emailInsertQuery, entity.EmailType, entity.Recipients,entity.CCRecipients, entity.BCCRecipients, entity.EmailSubject, entity.EmailBody, entity.SentDate, entity.SendStatus, entity.Priority);

            var sqlCommand = new SqlCommand(_emailInsertQuery, _con)
            {
                CommandType = CommandType.Text
            };
            sqlCommand.ExecuteNonQuery();
            _con.Close();
        }
    }
}
