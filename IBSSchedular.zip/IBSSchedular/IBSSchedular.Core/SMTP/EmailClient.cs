﻿using IBSSchedular.Core.Constants;
using IBSSchedular.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.SMTP
{
    public class EmailClient
    {
        private EmailRepository _emailRepository;
        public EmailClient()
        {
            
        }
        public void CreateClient()
        {       
            _emailRepository = new EmailRepository();
        }

        public void Send(MailMessage mailMessage)
        {
            var emailEntity = new EmailHistoryEntity()
            {
                EmailType = EmailConfigurations.EmailType,
                Recipients = string.Format("'{0}'", string.Join(",", mailMessage.To)),
                BCCRecipients = string.Format("'{0}'", string.Join(",", mailMessage.Bcc)),
                CCRecipients= string.Format("'{0}'", string.Join(",", mailMessage.CC)),
                EmailSubject = mailMessage.Subject,
                EmailBody = mailMessage.Body,
                SentDate = DateTime.Now,
                SendStatus = false,
                Priority = EmailConfigurations.Priority
            };
            _emailRepository.InsertEmail(emailEntity);
        }
    }
}
