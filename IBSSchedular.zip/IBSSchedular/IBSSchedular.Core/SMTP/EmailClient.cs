﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.SMTP
{
    public class EmailClient
    {
        private readonly string _server;
        private readonly string _userName;
        private readonly string _password;
        private readonly int _port;
        private SmtpClient _client;

        public EmailClient()
        {
            _server = "smtp.gmail.com";
            _port = 587;
            _userName = "";
            _password = "";
        }
        public void CreateClient()
        {
            SmtpClient smtp = new SmtpClient();
            smtp.Host = _server;
            smtp.EnableSsl = true;
            NetworkCredential NetworkCred = new NetworkCredential(_userName, _password);
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = NetworkCred;
            smtp.Port = 587;
            _client = smtp;
        }

        public void Send(MailMessage mailMessage)
        {
             _client.Send(mailMessage);
        }
    }
}
