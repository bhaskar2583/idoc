﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Configuration;
using IBSSchedular.Core.Data;
using IBSSchedular.Core.Builder;
using IBSSchedular.Core.Constants;

namespace IBSSchedular.Core.Job
{
    public class IBSSchedularMigration
    {
        SfDataReaderFactory _sfDataReaderFactory;
        public IBSSchedularMigration()
        {
            _sfDataReaderFactory = new SfDataReaderFactory();
        }
        private static System.Timers.Timer aTimer;
        public void Start()
        {
            Console.WriteLine("Data migration started");

           
            JobTimer();
        }
      
        public void Stop()
        {
            Console.WriteLine("Data migration started");
            var emailDirector = new EmailModelDirector(new IBSServiceFialedBuilder());
            emailDirector.CreateMailModel(EmailConfigurations.FromIBSServiceFialed, EmailConfigurations.IBSServiceFialedTo);
            var emailCleint = new SMTP.EmailClient();
            emailCleint.CreateClient();
            emailCleint.Send(emailDirector.GetMailModel());
        }

        private void JobTimer()
        {
            var interval= ConfigurationManager.AppSettings["TriggerInterval"];
            var intervalInM= TimeSpan.FromHours(Convert.ToInt32(interval)).TotalMilliseconds;
            aTimer = new System.Timers.Timer(intervalInM);
            aTimer.Elapsed += DataMigration;
            aTimer.AutoReset = true;
            aTimer.Enabled = true;
        }

        private void DataMigration(Object source, ElapsedEventArgs e)
        {
            Console.WriteLine("data migration started at {0:HH:mm:ss.fff}",e.SignalTime);
            _sfDataReaderFactory.CreateDafaultDataReadorFactpory();
            foreach (var dataReader in _sfDataReaderFactory.GetDataReaderFactories())
            {
                dataReader.ReadData();
            }
        }
    }
}
