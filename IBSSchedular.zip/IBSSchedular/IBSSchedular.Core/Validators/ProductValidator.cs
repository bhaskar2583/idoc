﻿using IBSSchedular.Core.SFDC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.Validators
{
    public class ProductValidator :IValidator<Product2>
    {
        public bool Validate(Product2 item)
        {
            if ((item.Division__c == "HBS" || item.Division__c == "SBS") && item.Product_Status__c == "Active")
                return true;

            return false;
        }
    }
}
