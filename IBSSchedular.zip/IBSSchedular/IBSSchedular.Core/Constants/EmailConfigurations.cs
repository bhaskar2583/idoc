﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.Constants
{
    public class EmailConfigurations
    {
        public static string FromIBSServiceFialed = "nmdas2019@gmail.com";
        public static List<string> IBSServiceFialedTo = new List<string>()
        {
            "mariyadasu67@gmail.com"
        };
        public static string SalesForceEmailFrom = "nmdas2019@gmail.com";
        public static List<string> SalesForceEmailTo = new List<string>()
        {
            "mariyadasu67@gmail.com"
        };
        public static string ProductEmailFrom = "nmdas2019@gmail.com";
        public static List<string> ProductEmailTo = new List<string>()
        {
            "mariyadasu67@gmail.com"
        };
    }
}
