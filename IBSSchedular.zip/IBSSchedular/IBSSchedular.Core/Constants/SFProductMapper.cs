﻿using IBSSchedular.Core.SFDC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBSSchedular.Core.Constants
{
    public class SFProductMapper
    {
        public static void MapProductType(Product2 product)
        {
            switch (product.Product_Type__c)
            {
                case "Group Life & AD&D":
                    product.Product_Type__c = "Group Life &AD&D";
                    break;
                case "Cobra Service":
                    product.Product_Type__c = "Cobra";
                    break;
                case "LTD":
                    product.Product_Type__c = "Group LTD";
                    break;
                case "Group VSTD":
                    product.Product_Type__c = "Group STD";
                    break;
                case "Group IDI":
                    product.Product_Type__c = "IDI";
                    break;
                case "Gold Cross Legal":
                    product.Product_Type__c = "Legal";
                    break;
                case "RX (Prescription)":
                    product.Product_Type__c = "PBM";
                    break;
            }
        }
    }
}
