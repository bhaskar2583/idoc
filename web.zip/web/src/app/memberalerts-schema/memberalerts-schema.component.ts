import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-memberalerts-schema',
  templateUrl: './memberalerts-schema.component.html',
  styleUrls: ['./memberalerts-schema.component.sass']
})
export class MemberalertsSchemaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
