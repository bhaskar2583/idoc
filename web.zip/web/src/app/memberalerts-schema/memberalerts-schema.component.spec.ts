import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberalertsSchemaComponent } from './memberalerts-schema.component';

describe('MemberalertsSchemaComponent', () => {
  let component: MemberalertsSchemaComponent;
  let fixture: ComponentFixture<MemberalertsSchemaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MemberalertsSchemaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MemberalertsSchemaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
