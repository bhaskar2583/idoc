import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MemberalertsSchemaComponent } from './memberalerts-schema/memberalerts-schema.component';
const routes: Routes = [
  {path:'memberinfo',component:MemberalertsSchemaComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
