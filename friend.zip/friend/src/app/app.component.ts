import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {SharedService} from './services/shared.services';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ICS-Web';
  text: string;
  results: string[];

  constructor(
    private sharedService: SharedService

  ) {

  }


  search(event) {
    this.sharedService.getSearchData(event.query).then(data => {
      this.results = data;
    });
  }
}
