import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable()
export class SharedService {
  constructor(
    private httpClient : HttpClient
  ) { }


  getSearchData(query:any){
    return this.httpClient.get('assets/countries.json')
    .toPromise()
    .then(res => <any[]> res)
    .then(data => { 
      let selectedCountrues:any=[];
      for(let d of data['countries']){
        if(d.title.indexOf(query)!=-1){
          selectedCountrues.push(d.title);
        }
      }
      return selectedCountrues; 
    
    });
  }


}
