import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  eligibleAlert: boolean = false;
  summaryAlert: boolean = false;
  constructor() { }

  ngOnInit() {
  }

  showEligibleAlert() {
    this.eligibleAlert = true;
  }
  showSummaryAlert() {
    this.summaryAlert = true;
  }

}
