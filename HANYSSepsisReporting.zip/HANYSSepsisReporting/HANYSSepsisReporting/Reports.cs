﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Odbc;
using WindowsFormsApplication1;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;

namespace WindowsFormsApplication1
{
    public partial class Reports : Form

    {
        public Reports(SepsisMaster master, string PFI)
        {
            sm = master;
           _PFI = PFI;
            InitializeComponent();
        }
        SepsisMaster sm;
       string _PFI;
        OdbcConnection Conn;
        DataBaseConnection Db = new DataBaseConnection();
        string ConnectionString;
        string DateCreatedFrom { get; set; }
        string DateCreatedTo { get; set; }
        public string Version { get; set; }
        private void Reports_Load(object sender, EventArgs e)
        {

            //DataTable dt = new DataTable();

            //ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;


            //using (Conn = new OdbcConnection(ConnectionString))
            //{


            //    OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("select distinct facility_identifier from sepsis_collab where facility_identifier is not null and version = '" + _Version+"'", Conn);

            //    dbDataAdapter.Fill(dt);



            //}

            //combobox_PFI.DataSource = dt;
        
            // this.reportViewer2.RefreshReport();
            //this.reportViewer_Severity.RefreshReport();
            //this.ReportViewerAdherence1.RefreshReport();
            //this.reportViewer_Adherence.RefreshReport();
            //this.reportViewerAdherenceAdvanced.RefreshReport();
        }

        private DataTable GetData_Master(string _Version, string _FromDate, string _ToDate, string _Excluded, string _RecordComplete, string _Transfer)
        {
            DataTable dt = new DataTable();

            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;


            using (Conn = new OdbcConnection(ConnectionString))
            {
                Conn.Open();
                OdbcCommand cmd = new OdbcCommand("{call Sepsis_SelectExcluded(?,?,?,?,?,?,?)}", Conn);

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = Conn;
                cmd.Parameters.Add(new OdbcParameter("PFI", _PFI));
                cmd.Parameters.Add(new OdbcParameter("Version", _Version));
                cmd.Parameters.Add(new OdbcParameter("DateCreatedFrom", _FromDate));
                cmd.Parameters.Add(new OdbcParameter("DatecreatedTo", _ToDate));
                cmd.Parameters.Add(new OdbcParameter("ExcludedFrom", _Excluded));
                cmd.Parameters.Add(new OdbcParameter("RecordComplete", _RecordComplete));
                cmd.Parameters.Add(new OdbcParameter("Transfer", _Transfer));

                OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter(cmd);

                dbDataAdapter.Fill(dt);





            }
            return dt;
            }



        private DataTable GetData_Severity(string _Version, string _FromDate, string _ToDate, string _Admitted, string _Mechanical)
        {
            DataTable dt = new DataTable();

            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;


            using (Conn = new OdbcConnection(ConnectionString))
            {
                Conn.Open();
                OdbcCommand cmd = new OdbcCommand("{call Sepsis_SeverityCormobidity(?,?,?,?,?,?)}", Conn);

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = Conn;
                cmd.Parameters.Add(new OdbcParameter("PFI", _PFI));
                cmd.Parameters.Add(new OdbcParameter("Version", _Version));
                cmd.Parameters.Add(new OdbcParameter("DateCreatedFrom", _FromDate));
                cmd.Parameters.Add(new OdbcParameter("DatecreatedTo", _ToDate));
                cmd.Parameters.Add(new OdbcParameter("AdmittedICU", _Admitted));
                cmd.Parameters.Add(new OdbcParameter("Mechanical", _Mechanical));

                OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter(cmd);

                dbDataAdapter.Fill(dt);





            }
            return dt;
        }



        private DataTable GetData_Adherence(string _Version, string _FromDate, string _ToDate, string _SevereSepsisPresent, string _SepticShock, string _InitialLactate, string _BloodCulture, string _Antibiotic, string _InitialHypotention)
        {
            DataTable dt = new DataTable();

            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;


            using (Conn = new OdbcConnection(ConnectionString))
            {
                Conn.Open();
                OdbcCommand cmd = new OdbcCommand("{call Sepsis_Adherence(?,?,?,?,?,?,?,?,?,?)}", Conn);

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = Conn;
                cmd.Parameters.Add(new OdbcParameter("PFI", _PFI));
                cmd.Parameters.Add(new OdbcParameter("Version", _Version));
                cmd.Parameters.Add(new OdbcParameter("DateCreatedFrom", _FromDate));
                cmd.Parameters.Add(new OdbcParameter("DatecreatedTo", _ToDate));
                cmd.Parameters.Add(new OdbcParameter("SevereSepsisPresent", _SevereSepsisPresent));
                cmd.Parameters.Add(new OdbcParameter("SepticShock", _SepticShock));
                cmd.Parameters.Add(new OdbcParameter("InitialLactate", _InitialLactate));
                cmd.Parameters.Add(new OdbcParameter("BloodCulture", _BloodCulture));
                cmd.Parameters.Add(new OdbcParameter("Antibiotic", _Antibiotic));
                cmd.Parameters.Add(new OdbcParameter("InitialHypotention", _InitialHypotention));

                OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter(cmd);

                dbDataAdapter.Fill(dt);





            }
            return dt;
        }

        private DataTable GetData_AdherenceAdvanced(string _Version, string _FromDate, string _ToDate, string _LactateLevelBeforeArrival, string _BloodCultureBeforeArrival, string _AntiboticBeforeArrival, string _CryatalloidBeforeArrival)
        {
            DataTable dt = new DataTable();

            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;


            using (Conn = new OdbcConnection(ConnectionString))
            {
                Conn.Open();
                OdbcCommand cmd = new OdbcCommand("{call Sepsis_AdherenceAdvanced(?,?,?,?,?,?,?,?)}", Conn);

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = Conn;
                cmd.Parameters.Add(new OdbcParameter("PFI", _PFI));
                cmd.Parameters.Add(new OdbcParameter("Version", _Version));
                cmd.Parameters.Add(new OdbcParameter("DateCreatedFrom", _FromDate));
                cmd.Parameters.Add(new OdbcParameter("DatecreatedTo", _ToDate));
                cmd.Parameters.Add(new OdbcParameter("LactateLevelBeforeArrival", _LactateLevelBeforeArrival));
                cmd.Parameters.Add(new OdbcParameter("BloodCultureBeforeArrival", _BloodCultureBeforeArrival));
                cmd.Parameters.Add(new OdbcParameter("AntiboticBeforeArrival", _AntiboticBeforeArrival));
                cmd.Parameters.Add(new OdbcParameter("CryatalloidBeforeArrival ", _CryatalloidBeforeArrival));
                OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter(cmd);

                dbDataAdapter.Fill(dt);





            }
            return dt;
        }




        private void button_Search_Click(object sender, EventArgs e)
        {
            if (tabControl_Reports.SelectedTab == tabControl_Reports.TabPages["tabPage_MasterReport"])//your specific tabname
            {
                if (comboBox_Version.Text.ToString().Trim() == "")
                {
                    MessageBox.Show("Please select Version.", "Sepsis Reports Error");
                    comboBox_Version.Focus();
                    return;
                }

                DateCreatedFrom = maskedTextBox_DateFrom.Text.ToString();
                DateCreatedTo = maskedTextBox_DateTo.Text.ToString();


                if (DateCreatedFrom == "  /  /")
                {
                    DateCreatedFrom = "";
                }

                if (DateCreatedTo == "  /  /")
                {
                    DateCreatedTo = "";
                }

                if (comboBox_Version.Text.ToString().Trim() == "6.3")
                    Version = "6.2";
                else
                    Version = comboBox_Version.Text.ToString().Trim();

                reportViewer1.Reset();
                DataTable dt = GetData_Master(Version, DateCreatedFrom, DateCreatedTo, comboBox_ExcludedfromProtocol.Text.ToString(), comboBox_RecordComplete.Text.ToString(), comboBox_Transfer.Text.ToString());
                ReportDataSource rds = new ReportDataSource("DataSet_SelectBasicInfo", dt);
                reportViewer1.LocalReport.DataSources.Add(rds);
                reportViewer1.LocalReport.ReportPath = "ReportExcludedFrom.rdlc";
                //ReportParameter[] rptParams = new ReportParameter[]
                //{
                //    new ReportParameter("Version",comboBox_Version.Text),
                //     new ReportParameter("DischargeDateFrom",DateCreatedFrom),
                //      new ReportParameter("DischargeDateTo",DateCreatedTo),
                //       new ReportParameter("ExcludedFrom",comboBox_ExcludedfromProtocol.Text),
                //       new ReportParameter("RecordComplete",comboBox_RecordComplete.Text),
                //       new ReportParameter("Transfer",comboBox_Transfer.Text)
                //};
                //reportViewer1.LocalReport.SetParameters(rptParams);

                label_TotalCount.Text = "Total Count: " + dt.Rows.Count;
                // your stuff
                reportViewer1.RefreshReport();
            }
            




            //this.reportViewer1.RefreshReport();
            //reportViewer1.LocalReport.Refresh();
        }

        private void button_SeveritySearch_Click(object sender, EventArgs e)
        {
            if (tabControl_Reports.SelectedTab == tabControl_Reports.TabPages["tabpage_SeverityCormobidity"])//your specific tabname

            {

                DateCreatedFrom = maskedTextBox_ServerityDischargeDateFrom.Text.ToString();
                DateCreatedTo = maskedTextBox_ServerityDischargeDateTo.Text.ToString();


                if (DateCreatedFrom == "  /  /")
                {
                    DateCreatedFrom = "";
                }

                if (DateCreatedTo == "  /  /")
                {
                    DateCreatedTo = "";
                }
                

                if (comboBox_ServerityVersion.Text.ToString().Trim() == "6.3")
                    Version = "6.2";
                else
                    Version = comboBox_ServerityVersion.Text.ToString().Trim();

                reportViewer_Severity.Reset();
                DataTable dt = GetData_Severity(Version, DateCreatedFrom, DateCreatedTo, comboBox_AdmittedtoICU.Text.ToString(), comboBox_MechanicalVentilation.Text.ToString());
                ReportDataSource rds = new ReportDataSource("DataSet_Severity", dt);
                reportViewer_Severity.LocalReport.DataSources.Add(rds);
                reportViewer_Severity.LocalReport.ReportPath = "ReportSeverityCormobidity.rdlc";
                //ReportParameter[] rptParams = new ReportParameter[]
                //{
                //    new ReportParameter("Version",comboBox_ServerityVersion.Text),
                //     new ReportParameter("DischargeDateFrom",DateCreatedFrom),
                //      new ReportParameter("DischargeDateTo",DateCreatedTo),
                //       new ReportParameter("AdmittedICU",comboBox_AdmittedtoICU.Text),
                //       new ReportParameter("Mechanical",comboBox_MechanicalVentilation.Text)
                //};
                //reportViewer_Severity.LocalReport.SetParameters(rptParams);

                label_ServerityCount.Text = "Total Count: " + dt.Rows.Count;
                // your stuff
                reportViewer_Severity.RefreshReport();
            }
        }

        private void button_Adherence_Click(object sender, EventArgs e)
        {
            if (tabControl_Reports.SelectedTab == tabControl_Reports.TabPages["tabPage_Adherence"])//your specific tabname

            {
                DateCreatedFrom = maskedTextBox_AdherenceDischargeDateFrom.Text.ToString();
                DateCreatedTo = maskedTextBox_AdherenceDischargeDateTo.Text.ToString();


                if (DateCreatedFrom == "  /  /")
                {
                    DateCreatedFrom = "";
                }

                if (DateCreatedTo == "  /  /")
                {
                    DateCreatedTo = "";
                }
                
                if (comboBox_AdherenceVersion.Text.ToString().Trim() == "6.3")
                    Version = "6.2";
                else
                    Version = comboBox_AdherenceVersion.Text.ToString().Trim();

                reportViewer_Adherence.Reset();
                DataTable dt = GetData_Adherence(Version, DateCreatedFrom, DateCreatedTo, comboBox_AdherenceSevereSepsis.Text.ToString(), comboBox_AdherenceSepticShock.Text.ToString(), comboBox_AdherenceInitialLactateLevel.Text.ToString(), comboBox_AdherenceBloodCultureCollection.Text.ToString(), comboBox_AdherenceAntibioticAdministration.Text.ToString(), comboBox_AdherenceInititalHypotention.Text.ToString());
                ReportDataSource rds = new ReportDataSource("DataSetAdherence", dt);
                reportViewer_Adherence.LocalReport.DataSources.Add(rds);
                reportViewer_Adherence.LocalReport.ReportPath = "ReportAdherence.rdlc";
                //ReportParameter[] rptParams = new ReportParameter[]
                //{
                //    new ReportParameter("Version",comboBox_AdherenceVersion.Text),
                //     new ReportParameter("DischargeDateFrom",DateCreatedFrom),
                //      new ReportParameter("DischargeDateTo",DateCreatedTo),
                //       new ReportParameter("SevereSepsisPresent",comboBox_AdherenceSevereSepsis.Text),
                //       new ReportParameter("SepticShock",comboBox_AdherenceSepticShock.Text),
                //       new ReportParameter("InitialLactate",comboBox_AdherenceInitialLactateLevel.Text),
                //     new ReportParameter("BloodCulture",comboBox_AdherenceBloodCultureCollection.Text),
                //      new ReportParameter("Antibiotic",comboBox_AdherenceAntibioticAdministration.Text),
                //       new ReportParameter("InitialHypotention",comboBox_AdherenceInititalHypotention.Text)
               
                //};
                //reportViewer_Adherence.LocalReport.SetParameters(rptParams);

                lbl_AdherenceCount.Text = "Total Count: " + dt.Rows.Count;
                // your stuff
                reportViewer_Adherence.RefreshReport();
            }
        }

        private void button_AdherenceAdvancedSearch_Click(object sender, EventArgs e)
        {
            if (tabControl_Reports.SelectedTab == tabControl_Reports.TabPages["tabPage_AdherenceAdvanced"])//your specific tabname

            {
                DateCreatedFrom = maskedTextBox_AdvancedDischargedDateFrom.Text.ToString();
                DateCreatedTo = maskedTextBox_AdvancedDischargedDateTo.Text.ToString();


                if (DateCreatedFrom == "  /  /")
                {
                    DateCreatedFrom = "";
                }

                if (DateCreatedTo == "  /  /")
                {
                    DateCreatedTo = "";
                }
                
                if (comboBox_AdvancedVersion.Text.ToString().Trim() == "6.3")
                    Version = "6.2";
                else
                    Version = comboBox_AdvancedVersion.Text.ToString().Trim();

                reportViewerAdherenceAdvanced.Reset();
                DataTable dt = GetData_AdherenceAdvanced(Version, DateCreatedFrom, DateCreatedTo, comboBox_LactateBefore.Text.ToString(), comboBox_BloodCultureBefore.Text.ToString(), comboBox_AntibioticBefore.Text.ToString(), comboBox_CrystalloidFluidBefore.Text.ToString());
                ReportDataSource rds = new ReportDataSource("DataSet_AdherenceAdvanced", dt);
                reportViewerAdherenceAdvanced.LocalReport.DataSources.Add(rds);
                reportViewerAdherenceAdvanced.LocalReport.ReportPath = "ReportAdherenceAdvanced.rdlc";
                //ReportParameter[] rptParams = new ReportParameter[]
                //{
                //     new ReportParameter("Version",comboBox_AdvancedVersion.Text),
                //     new ReportParameter("DischargeDateFrom",DateCreatedFrom),
                //     new ReportParameter("DischargeDateTo",DateCreatedTo),
                //     new ReportParameter("LactateLevelBeforeArrival",comboBox_LactateBefore.Text),
                //     new ReportParameter("BloodCultureBeforeArrival",comboBox_BloodCultureBefore.Text),
                //     new ReportParameter("AntiboticBeforeArrival",comboBox_AntibioticBefore.Text),
                //     new ReportParameter("CryatalloidBeforeArrival",comboBox_CrystalloidFluidBefore.Text)
                //};
                //reportViewerAdherenceAdvanced.LocalReport.SetParameters(rptParams);

                lbl_AdvancedTotalCount.Text = "Total Count: " + dt.Rows.Count;
                // your stuff
                reportViewerAdherenceAdvanced.RefreshReport();
            }
        }

        private void Reports_FormClosing(object sender, FormClosingEventArgs e)
        {
            sm.Show();
        }

     
    }
}
