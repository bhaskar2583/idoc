﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Data;

namespace WindowsFormsApplication1
{
  public partial class ComboBox : System.Windows.Forms.ComboBox
  {
    // Example project demonstrating applying a horizontal scrollbar to a standard combobox
    // Original article and more at http://cyotek.com

    #region  Private Member Declarations  

    private const int CB_SETHORIZONTALEXTENT = 0x015E;
    private const int WS_HSCROLL = 0x100000;

		#endregion  Private Member Declarations  

		#region  Private Class Methods  

    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr hWnd, UInt32 msg, IntPtr wParam, IntPtr lParam);

		#endregion  Private Class Methods  

		#region  Public Methods  

    public void SetHorizontalExtent()
    {
        int maxWith;

        maxWith = 0;


        //for (int i = 0; i <= this.Items.Count - 1; i++)
        //{
        //    Size textSize;

        //    string s= this.item;
        //    textSize = TextRenderer.MeasureText(, this.Font);
        //    if (textSize.Width > maxWith)
        //        maxWith = textSize.Width;

        //}
       // this.SetHorizontalExtent(maxWith);
    //}

        foreach (object item in this.Items)
        {
            Size textSize;

            DataRowView row = item as DataRowView;

            if (row != null)
            {
                textSize = TextRenderer.MeasureText(row[2].ToString(), this.Font);
                if (textSize.Width > maxWith)
                    maxWith = textSize.Width;
            }
         
        }

        this.SetHorizontalExtent(maxWith);
    }

    public void SetHorizontalExtent(int width)
    {
      SendMessage(this.Handle, CB_SETHORIZONTALEXTENT, new IntPtr(width), IntPtr.Zero);
    }

		#endregion  Public Methods  

		#region  Protected Properties  

    protected override CreateParams CreateParams
    {
      get
      {
        CreateParams createParams;

        createParams = base.CreateParams;
        createParams.Style |= WS_HSCROLL;

        return createParams;
      }
    }

		#endregion  Protected Properties  
  }
}
