﻿namespace WindowsFormsApplication1
{
    partial class ExportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExportForm));
            this.folderBrowserDialog_Export = new System.Windows.Forms.FolderBrowserDialog();
            this.label_ExportPath = new System.Windows.Forms.Label();
            this.textBox_Path = new System.Windows.Forms.TextBox();
            this.button_FolderBrowser = new System.Windows.Forms.Button();
            this.button_Export = new System.Windows.Forms.Button();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Label_Contact = new System.Windows.Forms.Label();
            this.Label_ClickHere = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label_ExportPath
            // 
            this.label_ExportPath.AutoSize = true;
            this.label_ExportPath.Location = new System.Drawing.Point(85, 49);
            this.label_ExportPath.Name = "label_ExportPath";
            this.label_ExportPath.Size = new System.Drawing.Size(65, 13);
            this.label_ExportPath.TabIndex = 0;
            this.label_ExportPath.Text = "Export Path:";
            // 
            // textBox_Path
            // 
            this.textBox_Path.Location = new System.Drawing.Point(156, 49);
            this.textBox_Path.Name = "textBox_Path";
            this.textBox_Path.Size = new System.Drawing.Size(668, 20);
            this.textBox_Path.TabIndex = 1;
            // 
            // button_FolderBrowser
            // 
            this.button_FolderBrowser.Location = new System.Drawing.Point(830, 47);
            this.button_FolderBrowser.Name = "button_FolderBrowser";
            this.button_FolderBrowser.Size = new System.Drawing.Size(26, 23);
            this.button_FolderBrowser.TabIndex = 2;
            this.button_FolderBrowser.Text = "...";
            this.button_FolderBrowser.UseVisualStyleBackColor = true;
            this.button_FolderBrowser.Click += new System.EventHandler(this.button_FolderBrowser_Click);
            // 
            // button_Export
            // 
            this.button_Export.Location = new System.Drawing.Point(518, 118);
            this.button_Export.Name = "button_Export";
            this.button_Export.Size = new System.Drawing.Size(108, 33);
            this.button_Export.TabIndex = 4;
            this.button_Export.Text = "Export";
            this.button_Export.UseVisualStyleBackColor = true;
            this.button_Export.Click += new System.EventHandler(this.button_Export_Click);
            // 
            // button_Cancel
            // 
            this.button_Cancel.Location = new System.Drawing.Point(387, 118);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(108, 33);
            this.button_Cancel.TabIndex = 5;
            this.button_Cancel.Text = "Cancel";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(9, 183);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 50);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // Label_Contact
            // 
            this.Label_Contact.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Contact.AutoSize = true;
            this.Label_Contact.Location = new System.Drawing.Point(799, 213);
            this.Label_Contact.Name = "Label_Contact";
            this.Label_Contact.Size = new System.Drawing.Size(122, 13);
            this.Label_Contact.TabIndex = 56;
            this.Label_Contact.Text = "Contact Sepsis support:-";
            // 
            // Label_ClickHere
            // 
            this.Label_ClickHere.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_ClickHere.AutoSize = true;
            this.Label_ClickHere.Location = new System.Drawing.Point(919, 213);
            this.Label_ClickHere.Name = "Label_ClickHere";
            this.Label_ClickHere.Size = new System.Drawing.Size(56, 13);
            this.Label_ClickHere.TabIndex = 55;
            this.Label_ClickHere.TabStop = true;
            this.Label_ClickHere.Text = "Click Here";
            this.Label_ClickHere.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Label_ClickHere_LinkClicked);
            // 
            // ExportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 235);
            this.Controls.Add(this.Label_Contact);
            this.Controls.Add(this.Label_ClickHere);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.button_Export);
            this.Controls.Add(this.button_FolderBrowser);
            this.Controls.Add(this.textBox_Path);
            this.Controls.Add(this.label_ExportPath);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ExportForm";
            this.Text = "ExportForm";
            this.HelpButtonClicked += new System.ComponentModel.CancelEventHandler(this.ExportForm_HelpButtonClicked);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ExportForm_FormClosing);
            this.Load += new System.EventHandler(this.ExportForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog_Export;
        private System.Windows.Forms.Label label_ExportPath;
        private System.Windows.Forms.TextBox textBox_Path;
        private System.Windows.Forms.Button button_FolderBrowser;
        private System.Windows.Forms.Button button_Export;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Label_Contact;
        private System.Windows.Forms.LinkLabel Label_ClickHere;
    }
}