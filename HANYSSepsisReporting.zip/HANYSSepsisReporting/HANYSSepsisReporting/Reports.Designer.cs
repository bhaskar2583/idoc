﻿namespace WindowsFormsApplication1
{
    partial class Reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Reports));
            this.tabControl_Reports = new System.Windows.Forms.TabControl();
            this.tabPage_MasterReport = new System.Windows.Forms.TabPage();
            this.comboBox_Transfer = new System.Windows.Forms.ComboBox();
            this.lbl_transfer = new System.Windows.Forms.Label();
            this.comboBox_RecordComplete = new System.Windows.Forms.ComboBox();
            this.lbl_RecordComplete = new System.Windows.Forms.Label();
            this.comboBox_ExcludedfromProtocol = new System.Windows.Forms.ComboBox();
            this.lbl_ExcludedFromProtocol = new System.Windows.Forms.Label();
            this.label_TotalCount = new System.Windows.Forms.Label();
            this.button_Search = new System.Windows.Forms.Button();
            this.maskedTextBox_DateTo = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox_DateFrom = new System.Windows.Forms.MaskedTextBox();
            this.comboBox_Version = new System.Windows.Forms.ComboBox();
            this.lbl_ToDate = new System.Windows.Forms.Label();
            this.lbl_FromDate = new System.Windows.Forms.Label();
            this.lbl_Version = new System.Windows.Forms.Label();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tabPage_Adherence = new System.Windows.Forms.TabPage();
            this.lbl_AdherenceCount = new System.Windows.Forms.Label();
            this.reportViewer_Adherence = new Microsoft.Reporting.WinForms.ReportViewer();
            this.comboBox_AdherenceInititalHypotention = new System.Windows.Forms.ComboBox();
            this.lbl_AdherenceInititalHypotention = new System.Windows.Forms.Label();
            this.comboBox_AdherenceAntibioticAdministration = new System.Windows.Forms.ComboBox();
            this.lbl_AdherenceAntibioticAdministration = new System.Windows.Forms.Label();
            this.comboBox_AdherenceBloodCultureCollection = new System.Windows.Forms.ComboBox();
            this.lbl_AdherenceBloodCultureCollection = new System.Windows.Forms.Label();
            this.comboBox_AdherenceInitialLactateLevel = new System.Windows.Forms.ComboBox();
            this.lbl_AdherenceInitialLactate = new System.Windows.Forms.Label();
            this.comboBox_AdherenceSepticShock = new System.Windows.Forms.ComboBox();
            this.lbl_AdherenceSepticShock = new System.Windows.Forms.Label();
            this.comboBox_AdherenceSevereSepsis = new System.Windows.Forms.ComboBox();
            this.lbl_AdherenceSevereSepsis = new System.Windows.Forms.Label();
            this.button_Adherence = new System.Windows.Forms.Button();
            this.maskedTextBox_AdherenceDischargeDateTo = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox_AdherenceDischargeDateFrom = new System.Windows.Forms.MaskedTextBox();
            this.comboBox_AdherenceVersion = new System.Windows.Forms.ComboBox();
            this.lbl_AdherenceDischargeDateTo = new System.Windows.Forms.Label();
            this.lbl_AdherenceDischargeDateFrom = new System.Windows.Forms.Label();
            this.lbl_AdherenceVersion = new System.Windows.Forms.Label();
            this.tabPage_AdherenceAdvanced = new System.Windows.Forms.TabPage();
            this.lbl_AdvancedTotalCount = new System.Windows.Forms.Label();
            this.reportViewerAdherenceAdvanced = new Microsoft.Reporting.WinForms.ReportViewer();
            this.comboBox_CrystalloidFluidBefore = new System.Windows.Forms.ComboBox();
            this.lbl_CrystalloidBefore = new System.Windows.Forms.Label();
            this.comboBox_AntibioticBefore = new System.Windows.Forms.ComboBox();
            this.lbl_AntibioticBefore = new System.Windows.Forms.Label();
            this.comboBox_BloodCultureBefore = new System.Windows.Forms.ComboBox();
            this.lbl_BloodCultureBefore = new System.Windows.Forms.Label();
            this.comboBox_LactateBefore = new System.Windows.Forms.ComboBox();
            this.lbl_AdvancedLactateBefore = new System.Windows.Forms.Label();
            this.button_AdherenceAdvancedSearch = new System.Windows.Forms.Button();
            this.maskedTextBox_AdvancedDischargedDateTo = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox_AdvancedDischargedDateFrom = new System.Windows.Forms.MaskedTextBox();
            this.comboBox_AdvancedVersion = new System.Windows.Forms.ComboBox();
            this.lbl_AdvancedDischargedDateTo = new System.Windows.Forms.Label();
            this.lbl_AdvancedDischargedDateFrom = new System.Windows.Forms.Label();
            this.lbl_AdvancedVersion = new System.Windows.Forms.Label();
            this.tabpage_SeverityCormobidity = new System.Windows.Forms.TabPage();
            this.label_ServerityCount = new System.Windows.Forms.Label();
            this.reportViewer_Severity = new Microsoft.Reporting.WinForms.ReportViewer();
            this.comboBox_MechanicalVentilation = new System.Windows.Forms.ComboBox();
            this.lbl_MechanicalVentilation = new System.Windows.Forms.Label();
            this.comboBox_AdmittedtoICU = new System.Windows.Forms.ComboBox();
            this.lbl_AdmittedtoICU = new System.Windows.Forms.Label();
            this.button_SeveritySearch = new System.Windows.Forms.Button();
            this.maskedTextBox_ServerityDischargeDateTo = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox_ServerityDischargeDateFrom = new System.Windows.Forms.MaskedTextBox();
            this.comboBox_ServerityVersion = new System.Windows.Forms.ComboBox();
            this.lbl_ServerityDischargeDateTo = new System.Windows.Forms.Label();
            this.lbl_ServerityDischargeDate = new System.Windows.Forms.Label();
            this.lbl_SeverityVersion = new System.Windows.Forms.Label();
            this.label_Copyright = new System.Windows.Forms.Label();
            this.Label_Contact = new System.Windows.Forms.Label();
            this.Label_ClickHere = new System.Windows.Forms.LinkLabel();
            this.tabControl_Reports.SuspendLayout();
            this.tabPage_MasterReport.SuspendLayout();
            this.tabPage_Adherence.SuspendLayout();
            this.tabPage_AdherenceAdvanced.SuspendLayout();
            this.tabpage_SeverityCormobidity.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl_Reports
            // 
            this.tabControl_Reports.Controls.Add(this.tabPage_MasterReport);
            this.tabControl_Reports.Controls.Add(this.tabPage_Adherence);
            this.tabControl_Reports.Controls.Add(this.tabPage_AdherenceAdvanced);
            this.tabControl_Reports.Controls.Add(this.tabpage_SeverityCormobidity);
            this.tabControl_Reports.Location = new System.Drawing.Point(12, 43);
            this.tabControl_Reports.Name = "tabControl_Reports";
            this.tabControl_Reports.SelectedIndex = 0;
            this.tabControl_Reports.Size = new System.Drawing.Size(1240, 605);
            this.tabControl_Reports.TabIndex = 0;
            // 
            // tabPage_MasterReport
            // 
            this.tabPage_MasterReport.Controls.Add(this.comboBox_Transfer);
            this.tabPage_MasterReport.Controls.Add(this.lbl_transfer);
            this.tabPage_MasterReport.Controls.Add(this.comboBox_RecordComplete);
            this.tabPage_MasterReport.Controls.Add(this.lbl_RecordComplete);
            this.tabPage_MasterReport.Controls.Add(this.comboBox_ExcludedfromProtocol);
            this.tabPage_MasterReport.Controls.Add(this.lbl_ExcludedFromProtocol);
            this.tabPage_MasterReport.Controls.Add(this.label_TotalCount);
            this.tabPage_MasterReport.Controls.Add(this.button_Search);
            this.tabPage_MasterReport.Controls.Add(this.maskedTextBox_DateTo);
            this.tabPage_MasterReport.Controls.Add(this.maskedTextBox_DateFrom);
            this.tabPage_MasterReport.Controls.Add(this.comboBox_Version);
            this.tabPage_MasterReport.Controls.Add(this.lbl_ToDate);
            this.tabPage_MasterReport.Controls.Add(this.lbl_FromDate);
            this.tabPage_MasterReport.Controls.Add(this.lbl_Version);
            this.tabPage_MasterReport.Controls.Add(this.reportViewer1);
            this.tabPage_MasterReport.Location = new System.Drawing.Point(4, 22);
            this.tabPage_MasterReport.Name = "tabPage_MasterReport";
            this.tabPage_MasterReport.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_MasterReport.Size = new System.Drawing.Size(1232, 579);
            this.tabPage_MasterReport.TabIndex = 0;
            this.tabPage_MasterReport.Text = "Master Report";
            this.tabPage_MasterReport.UseVisualStyleBackColor = true;
            // 
            // comboBox_Transfer
            // 
            this.comboBox_Transfer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Transfer.FormattingEnabled = true;
            this.comboBox_Transfer.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_Transfer.Location = new System.Drawing.Point(925, 21);
            this.comboBox_Transfer.Name = "comboBox_Transfer";
            this.comboBox_Transfer.Size = new System.Drawing.Size(40, 21);
            this.comboBox_Transfer.TabIndex = 14;
            // 
            // lbl_transfer
            // 
            this.lbl_transfer.AutoSize = true;
            this.lbl_transfer.Location = new System.Drawing.Point(870, 26);
            this.lbl_transfer.Name = "lbl_transfer";
            this.lbl_transfer.Size = new System.Drawing.Size(52, 13);
            this.lbl_transfer.TabIndex = 13;
            this.lbl_transfer.Text = "Transfer: ";
            // 
            // comboBox_RecordComplete
            // 
            this.comboBox_RecordComplete.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_RecordComplete.FormattingEnabled = true;
            this.comboBox_RecordComplete.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_RecordComplete.Location = new System.Drawing.Point(818, 21);
            this.comboBox_RecordComplete.Name = "comboBox_RecordComplete";
            this.comboBox_RecordComplete.Size = new System.Drawing.Size(40, 21);
            this.comboBox_RecordComplete.TabIndex = 12;
            // 
            // lbl_RecordComplete
            // 
            this.lbl_RecordComplete.AutoSize = true;
            this.lbl_RecordComplete.Location = new System.Drawing.Point(720, 26);
            this.lbl_RecordComplete.Name = "lbl_RecordComplete";
            this.lbl_RecordComplete.Size = new System.Drawing.Size(92, 13);
            this.lbl_RecordComplete.TabIndex = 11;
            this.lbl_RecordComplete.Text = "Record Complete:";
            // 
            // comboBox_ExcludedfromProtocol
            // 
            this.comboBox_ExcludedfromProtocol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ExcludedfromProtocol.FormattingEnabled = true;
            this.comboBox_ExcludedfromProtocol.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_ExcludedfromProtocol.Location = new System.Drawing.Point(658, 22);
            this.comboBox_ExcludedfromProtocol.Name = "comboBox_ExcludedfromProtocol";
            this.comboBox_ExcludedfromProtocol.Size = new System.Drawing.Size(40, 21);
            this.comboBox_ExcludedfromProtocol.TabIndex = 10;
            // 
            // lbl_ExcludedFromProtocol
            // 
            this.lbl_ExcludedFromProtocol.AutoSize = true;
            this.lbl_ExcludedFromProtocol.Location = new System.Drawing.Point(533, 25);
            this.lbl_ExcludedFromProtocol.Name = "lbl_ExcludedFromProtocol";
            this.lbl_ExcludedFromProtocol.Size = new System.Drawing.Size(119, 13);
            this.lbl_ExcludedFromProtocol.TabIndex = 9;
            this.lbl_ExcludedFromProtocol.Text = "Excluded from Protocol:";
            // 
            // label_TotalCount
            // 
            this.label_TotalCount.AutoSize = true;
            this.label_TotalCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TotalCount.Location = new System.Drawing.Point(14, 579);
            this.label_TotalCount.Name = "label_TotalCount";
            this.label_TotalCount.Size = new System.Drawing.Size(81, 13);
            this.label_TotalCount.TabIndex = 8;
            this.label_TotalCount.Text = "Total Count :";
            this.label_TotalCount.Visible = false;
            // 
            // button_Search
            // 
            this.button_Search.Location = new System.Drawing.Point(1006, 16);
            this.button_Search.Name = "button_Search";
            this.button_Search.Size = new System.Drawing.Size(94, 36);
            this.button_Search.TabIndex = 7;
            this.button_Search.Text = "Search";
            this.button_Search.UseVisualStyleBackColor = true;
            this.button_Search.Click += new System.EventHandler(this.button_Search_Click);
            // 
            // maskedTextBox_DateTo
            // 
            this.maskedTextBox_DateTo.Location = new System.Drawing.Point(445, 23);
            this.maskedTextBox_DateTo.Mask = "00/00/0000";
            this.maskedTextBox_DateTo.Name = "maskedTextBox_DateTo";
            this.maskedTextBox_DateTo.Size = new System.Drawing.Size(72, 20);
            this.maskedTextBox_DateTo.TabIndex = 6;
            // 
            // maskedTextBox_DateFrom
            // 
            this.maskedTextBox_DateFrom.Location = new System.Drawing.Point(244, 23);
            this.maskedTextBox_DateFrom.Mask = "00/00/0000";
            this.maskedTextBox_DateFrom.Name = "maskedTextBox_DateFrom";
            this.maskedTextBox_DateFrom.Size = new System.Drawing.Size(72, 20);
            this.maskedTextBox_DateFrom.TabIndex = 5;
            // 
            // comboBox_Version
            // 
            this.comboBox_Version.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Version.FormattingEnabled = true;
            this.comboBox_Version.Items.AddRange(new object[] {
            "6.3",
            "1.1",
            "5.1"});
            this.comboBox_Version.Location = new System.Drawing.Point(70, 25);
            this.comboBox_Version.Name = "comboBox_Version";
            this.comboBox_Version.Size = new System.Drawing.Size(40, 21);
            this.comboBox_Version.TabIndex = 4;
            // 
            // lbl_ToDate
            // 
            this.lbl_ToDate.AutoSize = true;
            this.lbl_ToDate.Location = new System.Drawing.Point(339, 26);
            this.lbl_ToDate.Name = "lbl_ToDate";
            this.lbl_ToDate.Size = new System.Drawing.Size(100, 13);
            this.lbl_ToDate.TabIndex = 3;
            this.lbl_ToDate.Text = "Discharge Date To:";
            // 
            // lbl_FromDate
            // 
            this.lbl_FromDate.AutoSize = true;
            this.lbl_FromDate.Location = new System.Drawing.Point(128, 28);
            this.lbl_FromDate.Name = "lbl_FromDate";
            this.lbl_FromDate.Size = new System.Drawing.Size(110, 13);
            this.lbl_FromDate.TabIndex = 2;
            this.lbl_FromDate.Text = "Discharge Date From:";
            // 
            // lbl_Version
            // 
            this.lbl_Version.AutoSize = true;
            this.lbl_Version.Location = new System.Drawing.Point(18, 28);
            this.lbl_Version.Name = "lbl_Version";
            this.lbl_Version.Size = new System.Drawing.Size(45, 13);
            this.lbl_Version.TabIndex = 1;
            this.lbl_Version.Text = "Version:";
            // 
            // reportViewer1
            // 
            this.reportViewer1.Location = new System.Drawing.Point(17, 79);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ServerReport.BearerToken = null;
            this.reportViewer1.Size = new System.Drawing.Size(1201, 483);
            this.reportViewer1.TabIndex = 0;
            // 
            // tabPage_Adherence
            // 
            this.tabPage_Adherence.Controls.Add(this.lbl_AdherenceCount);
            this.tabPage_Adherence.Controls.Add(this.reportViewer_Adherence);
            this.tabPage_Adherence.Controls.Add(this.comboBox_AdherenceInititalHypotention);
            this.tabPage_Adherence.Controls.Add(this.lbl_AdherenceInititalHypotention);
            this.tabPage_Adherence.Controls.Add(this.comboBox_AdherenceAntibioticAdministration);
            this.tabPage_Adherence.Controls.Add(this.lbl_AdherenceAntibioticAdministration);
            this.tabPage_Adherence.Controls.Add(this.comboBox_AdherenceBloodCultureCollection);
            this.tabPage_Adherence.Controls.Add(this.lbl_AdherenceBloodCultureCollection);
            this.tabPage_Adherence.Controls.Add(this.comboBox_AdherenceInitialLactateLevel);
            this.tabPage_Adherence.Controls.Add(this.lbl_AdherenceInitialLactate);
            this.tabPage_Adherence.Controls.Add(this.comboBox_AdherenceSepticShock);
            this.tabPage_Adherence.Controls.Add(this.lbl_AdherenceSepticShock);
            this.tabPage_Adherence.Controls.Add(this.comboBox_AdherenceSevereSepsis);
            this.tabPage_Adherence.Controls.Add(this.lbl_AdherenceSevereSepsis);
            this.tabPage_Adherence.Controls.Add(this.button_Adherence);
            this.tabPage_Adherence.Controls.Add(this.maskedTextBox_AdherenceDischargeDateTo);
            this.tabPage_Adherence.Controls.Add(this.maskedTextBox_AdherenceDischargeDateFrom);
            this.tabPage_Adherence.Controls.Add(this.comboBox_AdherenceVersion);
            this.tabPage_Adherence.Controls.Add(this.lbl_AdherenceDischargeDateTo);
            this.tabPage_Adherence.Controls.Add(this.lbl_AdherenceDischargeDateFrom);
            this.tabPage_Adherence.Controls.Add(this.lbl_AdherenceVersion);
            this.tabPage_Adherence.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Adherence.Name = "tabPage_Adherence";
            this.tabPage_Adherence.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Adherence.Size = new System.Drawing.Size(1232, 579);
            this.tabPage_Adherence.TabIndex = 3;
            this.tabPage_Adherence.Text = "Adherence";
            this.tabPage_Adherence.UseVisualStyleBackColor = true;
            // 
            // lbl_AdherenceCount
            // 
            this.lbl_AdherenceCount.AutoSize = true;
            this.lbl_AdherenceCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AdherenceCount.Location = new System.Drawing.Point(14, 579);
            this.lbl_AdherenceCount.Name = "lbl_AdherenceCount";
            this.lbl_AdherenceCount.Size = new System.Drawing.Size(81, 13);
            this.lbl_AdherenceCount.TabIndex = 35;
            this.lbl_AdherenceCount.Text = "Total Count :";
            this.lbl_AdherenceCount.Visible = false;
            // 
            // reportViewer_Adherence
            // 
            this.reportViewer_Adherence.LocalReport.ReportEmbeddedResource = "HANYSSepsisReporting.ReportAdherence.rdlc";
            this.reportViewer_Adherence.Location = new System.Drawing.Point(14, 85);
            this.reportViewer_Adherence.Name = "reportViewer_Adherence";
            this.reportViewer_Adherence.ServerReport.BearerToken = null;
            this.reportViewer_Adherence.Size = new System.Drawing.Size(1201, 483);
            this.reportViewer_Adherence.TabIndex = 34;
            // 
            // comboBox_AdherenceInititalHypotention
            // 
            this.comboBox_AdherenceInititalHypotention.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AdherenceInititalHypotention.FormattingEnabled = true;
            this.comboBox_AdherenceInititalHypotention.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_AdherenceInititalHypotention.Location = new System.Drawing.Point(1031, 39);
            this.comboBox_AdherenceInititalHypotention.Name = "comboBox_AdherenceInititalHypotention";
            this.comboBox_AdherenceInititalHypotention.Size = new System.Drawing.Size(40, 21);
            this.comboBox_AdherenceInititalHypotention.TabIndex = 33;
            // 
            // lbl_AdherenceInititalHypotention
            // 
            this.lbl_AdherenceInititalHypotention.AutoSize = true;
            this.lbl_AdherenceInititalHypotention.Location = new System.Drawing.Point(978, 25);
            this.lbl_AdherenceInititalHypotention.Name = "lbl_AdherenceInititalHypotention";
            this.lbl_AdherenceInititalHypotention.Size = new System.Drawing.Size(97, 13);
            this.lbl_AdherenceInititalHypotention.TabIndex = 32;
            this.lbl_AdherenceInititalHypotention.Text = "Initital Hypotention:";
            // 
            // comboBox_AdherenceAntibioticAdministration
            // 
            this.comboBox_AdherenceAntibioticAdministration.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AdherenceAntibioticAdministration.FormattingEnabled = true;
            this.comboBox_AdherenceAntibioticAdministration.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_AdherenceAntibioticAdministration.Location = new System.Drawing.Point(927, 41);
            this.comboBox_AdherenceAntibioticAdministration.Name = "comboBox_AdherenceAntibioticAdministration";
            this.comboBox_AdherenceAntibioticAdministration.Size = new System.Drawing.Size(40, 21);
            this.comboBox_AdherenceAntibioticAdministration.TabIndex = 31;
            // 
            // lbl_AdherenceAntibioticAdministration
            // 
            this.lbl_AdherenceAntibioticAdministration.AutoSize = true;
            this.lbl_AdherenceAntibioticAdministration.Location = new System.Drawing.Point(851, 25);
            this.lbl_AdherenceAntibioticAdministration.Name = "lbl_AdherenceAntibioticAdministration";
            this.lbl_AdherenceAntibioticAdministration.Size = new System.Drawing.Size(121, 13);
            this.lbl_AdherenceAntibioticAdministration.TabIndex = 30;
            this.lbl_AdherenceAntibioticAdministration.Text = "Antibiotic Administration:";
            // 
            // comboBox_AdherenceBloodCultureCollection
            // 
            this.comboBox_AdherenceBloodCultureCollection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AdherenceBloodCultureCollection.FormattingEnabled = true;
            this.comboBox_AdherenceBloodCultureCollection.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_AdherenceBloodCultureCollection.Location = new System.Drawing.Point(802, 41);
            this.comboBox_AdherenceBloodCultureCollection.Name = "comboBox_AdherenceBloodCultureCollection";
            this.comboBox_AdherenceBloodCultureCollection.Size = new System.Drawing.Size(40, 21);
            this.comboBox_AdherenceBloodCultureCollection.TabIndex = 29;
            // 
            // lbl_AdherenceBloodCultureCollection
            // 
            this.lbl_AdherenceBloodCultureCollection.AutoSize = true;
            this.lbl_AdherenceBloodCultureCollection.Location = new System.Drawing.Point(723, 25);
            this.lbl_AdherenceBloodCultureCollection.Name = "lbl_AdherenceBloodCultureCollection";
            this.lbl_AdherenceBloodCultureCollection.Size = new System.Drawing.Size(122, 13);
            this.lbl_AdherenceBloodCultureCollection.TabIndex = 28;
            this.lbl_AdherenceBloodCultureCollection.Text = "Blood Culture Collection:";
            // 
            // comboBox_AdherenceInitialLactateLevel
            // 
            this.comboBox_AdherenceInitialLactateLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AdherenceInitialLactateLevel.FormattingEnabled = true;
            this.comboBox_AdherenceInitialLactateLevel.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_AdherenceInitialLactateLevel.Location = new System.Drawing.Point(673, 41);
            this.comboBox_AdherenceInitialLactateLevel.Name = "comboBox_AdherenceInitialLactateLevel";
            this.comboBox_AdherenceInitialLactateLevel.Size = new System.Drawing.Size(40, 21);
            this.comboBox_AdherenceInitialLactateLevel.TabIndex = 27;
            // 
            // lbl_AdherenceInitialLactate
            // 
            this.lbl_AdherenceInitialLactate.AutoSize = true;
            this.lbl_AdherenceInitialLactate.Location = new System.Drawing.Point(566, 25);
            this.lbl_AdherenceInitialLactate.Name = "lbl_AdherenceInitialLactate";
            this.lbl_AdherenceInitialLactate.Size = new System.Drawing.Size(151, 13);
            this.lbl_AdherenceInitialLactate.TabIndex = 26;
            this.lbl_AdherenceInitialLactate.Text = "Initial Lactate Level Collection:";
            // 
            // comboBox_AdherenceSepticShock
            // 
            this.comboBox_AdherenceSepticShock.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AdherenceSepticShock.FormattingEnabled = true;
            this.comboBox_AdherenceSepticShock.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_AdherenceSepticShock.Location = new System.Drawing.Point(515, 41);
            this.comboBox_AdherenceSepticShock.Name = "comboBox_AdherenceSepticShock";
            this.comboBox_AdherenceSepticShock.Size = new System.Drawing.Size(40, 21);
            this.comboBox_AdherenceSepticShock.TabIndex = 25;
            // 
            // lbl_AdherenceSepticShock
            // 
            this.lbl_AdherenceSepticShock.AutoSize = true;
            this.lbl_AdherenceSepticShock.Location = new System.Drawing.Point(447, 25);
            this.lbl_AdherenceSepticShock.Name = "lbl_AdherenceSepticShock";
            this.lbl_AdherenceSepticShock.Size = new System.Drawing.Size(113, 13);
            this.lbl_AdherenceSepticShock.TabIndex = 24;
            this.lbl_AdherenceSepticShock.Text = "SepticShock Present :";
            // 
            // comboBox_AdherenceSevereSepsis
            // 
            this.comboBox_AdherenceSevereSepsis.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AdherenceSevereSepsis.FormattingEnabled = true;
            this.comboBox_AdherenceSevereSepsis.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_AdherenceSevereSepsis.Location = new System.Drawing.Point(389, 41);
            this.comboBox_AdherenceSevereSepsis.Name = "comboBox_AdherenceSevereSepsis";
            this.comboBox_AdherenceSevereSepsis.Size = new System.Drawing.Size(40, 21);
            this.comboBox_AdherenceSevereSepsis.TabIndex = 23;
            // 
            // lbl_AdherenceSevereSepsis
            // 
            this.lbl_AdherenceSevereSepsis.AutoSize = true;
            this.lbl_AdherenceSevereSepsis.Location = new System.Drawing.Point(317, 25);
            this.lbl_AdherenceSevereSepsis.Name = "lbl_AdherenceSevereSepsis";
            this.lbl_AdherenceSevereSepsis.Size = new System.Drawing.Size(117, 13);
            this.lbl_AdherenceSevereSepsis.TabIndex = 22;
            this.lbl_AdherenceSevereSepsis.Text = "Severe Sepsis Present:";
            // 
            // button_Adherence
            // 
            this.button_Adherence.Location = new System.Drawing.Point(1121, 26);
            this.button_Adherence.Name = "button_Adherence";
            this.button_Adherence.Size = new System.Drawing.Size(94, 36);
            this.button_Adherence.TabIndex = 21;
            this.button_Adherence.Text = "Search";
            this.button_Adherence.UseVisualStyleBackColor = true;
            this.button_Adherence.Click += new System.EventHandler(this.button_Adherence_Click);
            // 
            // maskedTextBox_AdherenceDischargeDateTo
            // 
            this.maskedTextBox_AdherenceDischargeDateTo.Location = new System.Drawing.Point(231, 40);
            this.maskedTextBox_AdherenceDischargeDateTo.Mask = "00/00/0000";
            this.maskedTextBox_AdherenceDischargeDateTo.Name = "maskedTextBox_AdherenceDischargeDateTo";
            this.maskedTextBox_AdherenceDischargeDateTo.Size = new System.Drawing.Size(72, 20);
            this.maskedTextBox_AdherenceDischargeDateTo.TabIndex = 20;
            // 
            // maskedTextBox_AdherenceDischargeDateFrom
            // 
            this.maskedTextBox_AdherenceDischargeDateFrom.Location = new System.Drawing.Point(105, 40);
            this.maskedTextBox_AdherenceDischargeDateFrom.Mask = "00/00/0000";
            this.maskedTextBox_AdherenceDischargeDateFrom.Name = "maskedTextBox_AdherenceDischargeDateFrom";
            this.maskedTextBox_AdherenceDischargeDateFrom.Size = new System.Drawing.Size(72, 20);
            this.maskedTextBox_AdherenceDischargeDateFrom.TabIndex = 19;
            // 
            // comboBox_AdherenceVersion
            // 
            this.comboBox_AdherenceVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AdherenceVersion.FormattingEnabled = true;
            this.comboBox_AdherenceVersion.Items.AddRange(new object[] {
            "6.3",
            "1.1",
            "5.1"});
            this.comboBox_AdherenceVersion.Location = new System.Drawing.Point(14, 39);
            this.comboBox_AdherenceVersion.Name = "comboBox_AdherenceVersion";
            this.comboBox_AdherenceVersion.Size = new System.Drawing.Size(40, 21);
            this.comboBox_AdherenceVersion.TabIndex = 18;
            // 
            // lbl_AdherenceDischargeDateTo
            // 
            this.lbl_AdherenceDischargeDateTo.AutoSize = true;
            this.lbl_AdherenceDischargeDateTo.Location = new System.Drawing.Point(208, 23);
            this.lbl_AdherenceDischargeDateTo.Name = "lbl_AdherenceDischargeDateTo";
            this.lbl_AdherenceDischargeDateTo.Size = new System.Drawing.Size(100, 13);
            this.lbl_AdherenceDischargeDateTo.TabIndex = 17;
            this.lbl_AdherenceDischargeDateTo.Text = "Discharge Date To:";
            // 
            // lbl_AdherenceDischargeDateFrom
            // 
            this.lbl_AdherenceDischargeDateFrom.AutoSize = true;
            this.lbl_AdherenceDischargeDateFrom.Location = new System.Drawing.Point(72, 22);
            this.lbl_AdherenceDischargeDateFrom.Name = "lbl_AdherenceDischargeDateFrom";
            this.lbl_AdherenceDischargeDateFrom.Size = new System.Drawing.Size(110, 13);
            this.lbl_AdherenceDischargeDateFrom.TabIndex = 16;
            this.lbl_AdherenceDischargeDateFrom.Text = "Discharge Date From:";
            // 
            // lbl_AdherenceVersion
            // 
            this.lbl_AdherenceVersion.AutoSize = true;
            this.lbl_AdherenceVersion.Location = new System.Drawing.Point(14, 22);
            this.lbl_AdherenceVersion.Name = "lbl_AdherenceVersion";
            this.lbl_AdherenceVersion.Size = new System.Drawing.Size(45, 13);
            this.lbl_AdherenceVersion.TabIndex = 15;
            this.lbl_AdherenceVersion.Text = "Version:";
            // 
            // tabPage_AdherenceAdvanced
            // 
            this.tabPage_AdherenceAdvanced.Controls.Add(this.lbl_AdvancedTotalCount);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.reportViewerAdherenceAdvanced);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.comboBox_CrystalloidFluidBefore);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.lbl_CrystalloidBefore);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.comboBox_AntibioticBefore);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.lbl_AntibioticBefore);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.comboBox_BloodCultureBefore);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.lbl_BloodCultureBefore);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.comboBox_LactateBefore);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.lbl_AdvancedLactateBefore);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.button_AdherenceAdvancedSearch);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.maskedTextBox_AdvancedDischargedDateTo);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.maskedTextBox_AdvancedDischargedDateFrom);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.comboBox_AdvancedVersion);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.lbl_AdvancedDischargedDateTo);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.lbl_AdvancedDischargedDateFrom);
            this.tabPage_AdherenceAdvanced.Controls.Add(this.lbl_AdvancedVersion);
            this.tabPage_AdherenceAdvanced.Location = new System.Drawing.Point(4, 22);
            this.tabPage_AdherenceAdvanced.Name = "tabPage_AdherenceAdvanced";
            this.tabPage_AdherenceAdvanced.Size = new System.Drawing.Size(1232, 579);
            this.tabPage_AdherenceAdvanced.TabIndex = 4;
            this.tabPage_AdherenceAdvanced.Text = "Adherence Advanced";
            this.tabPage_AdherenceAdvanced.UseVisualStyleBackColor = true;
            // 
            // lbl_AdvancedTotalCount
            // 
            this.lbl_AdvancedTotalCount.AutoSize = true;
            this.lbl_AdvancedTotalCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AdvancedTotalCount.Location = new System.Drawing.Point(10, 583);
            this.lbl_AdvancedTotalCount.Name = "lbl_AdvancedTotalCount";
            this.lbl_AdvancedTotalCount.Size = new System.Drawing.Size(81, 13);
            this.lbl_AdvancedTotalCount.TabIndex = 50;
            this.lbl_AdvancedTotalCount.Text = "Total Count :";
            this.lbl_AdvancedTotalCount.Visible = false;
            // 
            // reportViewerAdherenceAdvanced
            // 
            this.reportViewerAdherenceAdvanced.Location = new System.Drawing.Point(10, 85);
            this.reportViewerAdherenceAdvanced.Name = "reportViewerAdherenceAdvanced";
            this.reportViewerAdherenceAdvanced.ServerReport.BearerToken = null;
            this.reportViewerAdherenceAdvanced.Size = new System.Drawing.Size(1201, 483);
            this.reportViewerAdherenceAdvanced.TabIndex = 49;
            // 
            // comboBox_CrystalloidFluidBefore
            // 
            this.comboBox_CrystalloidFluidBefore.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_CrystalloidFluidBefore.FormattingEnabled = true;
            this.comboBox_CrystalloidFluidBefore.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_CrystalloidFluidBefore.Location = new System.Drawing.Point(1003, 39);
            this.comboBox_CrystalloidFluidBefore.Name = "comboBox_CrystalloidFluidBefore";
            this.comboBox_CrystalloidFluidBefore.Size = new System.Drawing.Size(40, 21);
            this.comboBox_CrystalloidFluidBefore.TabIndex = 48;
            // 
            // lbl_CrystalloidBefore
            // 
            this.lbl_CrystalloidBefore.AutoSize = true;
            this.lbl_CrystalloidBefore.Location = new System.Drawing.Point(896, 10);
            this.lbl_CrystalloidBefore.Name = "lbl_CrystalloidBefore";
            this.lbl_CrystalloidBefore.Size = new System.Drawing.Size(147, 26);
            this.lbl_CrystalloidBefore.TabIndex = 47;
            this.lbl_CrystalloidBefore.Text = "Crystalloid Fluid Administration\r\n Before Arrival Date:";
            // 
            // comboBox_AntibioticBefore
            // 
            this.comboBox_AntibioticBefore.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AntibioticBefore.FormattingEnabled = true;
            this.comboBox_AntibioticBefore.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_AntibioticBefore.Location = new System.Drawing.Point(801, 39);
            this.comboBox_AntibioticBefore.Name = "comboBox_AntibioticBefore";
            this.comboBox_AntibioticBefore.Size = new System.Drawing.Size(40, 21);
            this.comboBox_AntibioticBefore.TabIndex = 46;
            // 
            // lbl_AntibioticBefore
            // 
            this.lbl_AntibioticBefore.AutoSize = true;
            this.lbl_AntibioticBefore.Location = new System.Drawing.Point(729, 10);
            this.lbl_AntibioticBefore.Name = "lbl_AntibioticBefore";
            this.lbl_AntibioticBefore.Size = new System.Drawing.Size(118, 26);
            this.lbl_AntibioticBefore.TabIndex = 45;
            this.lbl_AntibioticBefore.Text = "Antibiotic Administration\r\n Before Arrival Date:";
            // 
            // comboBox_BloodCultureBefore
            // 
            this.comboBox_BloodCultureBefore.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_BloodCultureBefore.FormattingEnabled = true;
            this.comboBox_BloodCultureBefore.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_BloodCultureBefore.Location = new System.Drawing.Point(633, 39);
            this.comboBox_BloodCultureBefore.Name = "comboBox_BloodCultureBefore";
            this.comboBox_BloodCultureBefore.Size = new System.Drawing.Size(40, 21);
            this.comboBox_BloodCultureBefore.TabIndex = 44;
            // 
            // lbl_BloodCultureBefore
            // 
            this.lbl_BloodCultureBefore.AutoSize = true;
            this.lbl_BloodCultureBefore.Location = new System.Drawing.Point(578, 10);
            this.lbl_BloodCultureBefore.Name = "lbl_BloodCultureBefore";
            this.lbl_BloodCultureBefore.Size = new System.Drawing.Size(99, 26);
            this.lbl_BloodCultureBefore.TabIndex = 43;
            this.lbl_BloodCultureBefore.Text = "Blood Culture \r\nBefore Arrival Date:";
            // 
            // comboBox_LactateBefore
            // 
            this.comboBox_LactateBefore.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_LactateBefore.FormattingEnabled = true;
            this.comboBox_LactateBefore.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_LactateBefore.Location = new System.Drawing.Point(475, 39);
            this.comboBox_LactateBefore.Name = "comboBox_LactateBefore";
            this.comboBox_LactateBefore.Size = new System.Drawing.Size(40, 21);
            this.comboBox_LactateBefore.TabIndex = 42;
            // 
            // lbl_AdvancedLactateBefore
            // 
            this.lbl_AdvancedLactateBefore.AutoSize = true;
            this.lbl_AdvancedLactateBefore.Location = new System.Drawing.Point(420, 10);
            this.lbl_AdvancedLactateBefore.Name = "lbl_AdvancedLactateBefore";
            this.lbl_AdvancedLactateBefore.Size = new System.Drawing.Size(99, 26);
            this.lbl_AdvancedLactateBefore.TabIndex = 41;
            this.lbl_AdvancedLactateBefore.Text = "Lactate Level \r\nBefore Arrival Date:";
            // 
            // button_AdherenceAdvancedSearch
            // 
            this.button_AdherenceAdvancedSearch.Location = new System.Drawing.Point(1117, 21);
            this.button_AdherenceAdvancedSearch.Name = "button_AdherenceAdvancedSearch";
            this.button_AdherenceAdvancedSearch.Size = new System.Drawing.Size(94, 36);
            this.button_AdherenceAdvancedSearch.TabIndex = 40;
            this.button_AdherenceAdvancedSearch.Text = "Search";
            this.button_AdherenceAdvancedSearch.UseVisualStyleBackColor = true;
            this.button_AdherenceAdvancedSearch.Click += new System.EventHandler(this.button_AdherenceAdvancedSearch_Click);
            // 
            // maskedTextBox_AdvancedDischargedDateTo
            // 
            this.maskedTextBox_AdvancedDischargedDateTo.Location = new System.Drawing.Point(289, 40);
            this.maskedTextBox_AdvancedDischargedDateTo.Mask = "00/00/0000";
            this.maskedTextBox_AdvancedDischargedDateTo.Name = "maskedTextBox_AdvancedDischargedDateTo";
            this.maskedTextBox_AdvancedDischargedDateTo.Size = new System.Drawing.Size(72, 20);
            this.maskedTextBox_AdvancedDischargedDateTo.TabIndex = 39;
            // 
            // maskedTextBox_AdvancedDischargedDateFrom
            // 
            this.maskedTextBox_AdvancedDischargedDateFrom.Location = new System.Drawing.Point(143, 42);
            this.maskedTextBox_AdvancedDischargedDateFrom.Mask = "00/00/0000";
            this.maskedTextBox_AdvancedDischargedDateFrom.Name = "maskedTextBox_AdvancedDischargedDateFrom";
            this.maskedTextBox_AdvancedDischargedDateFrom.Size = new System.Drawing.Size(72, 20);
            this.maskedTextBox_AdvancedDischargedDateFrom.TabIndex = 38;
            // 
            // comboBox_AdvancedVersion
            // 
            this.comboBox_AdvancedVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AdvancedVersion.FormattingEnabled = true;
            this.comboBox_AdvancedVersion.Items.AddRange(new object[] {
            "6.3",
            "1.1",
            "5.1"});
            this.comboBox_AdvancedVersion.Location = new System.Drawing.Point(10, 42);
            this.comboBox_AdvancedVersion.Name = "comboBox_AdvancedVersion";
            this.comboBox_AdvancedVersion.Size = new System.Drawing.Size(40, 21);
            this.comboBox_AdvancedVersion.TabIndex = 37;
            // 
            // lbl_AdvancedDischargedDateTo
            // 
            this.lbl_AdvancedDischargedDateTo.AutoSize = true;
            this.lbl_AdvancedDischargedDateTo.Location = new System.Drawing.Point(266, 23);
            this.lbl_AdvancedDischargedDateTo.Name = "lbl_AdvancedDischargedDateTo";
            this.lbl_AdvancedDischargedDateTo.Size = new System.Drawing.Size(100, 13);
            this.lbl_AdvancedDischargedDateTo.TabIndex = 36;
            this.lbl_AdvancedDischargedDateTo.Text = "Discharge Date To:";
            // 
            // lbl_AdvancedDischargedDateFrom
            // 
            this.lbl_AdvancedDischargedDateFrom.AutoSize = true;
            this.lbl_AdvancedDischargedDateFrom.Location = new System.Drawing.Point(110, 24);
            this.lbl_AdvancedDischargedDateFrom.Name = "lbl_AdvancedDischargedDateFrom";
            this.lbl_AdvancedDischargedDateFrom.Size = new System.Drawing.Size(110, 13);
            this.lbl_AdvancedDischargedDateFrom.TabIndex = 35;
            this.lbl_AdvancedDischargedDateFrom.Text = "Discharge Date From:";
            // 
            // lbl_AdvancedVersion
            // 
            this.lbl_AdvancedVersion.AutoSize = true;
            this.lbl_AdvancedVersion.Location = new System.Drawing.Point(10, 25);
            this.lbl_AdvancedVersion.Name = "lbl_AdvancedVersion";
            this.lbl_AdvancedVersion.Size = new System.Drawing.Size(45, 13);
            this.lbl_AdvancedVersion.TabIndex = 34;
            this.lbl_AdvancedVersion.Text = "Version:";
            // 
            // tabpage_SeverityCormobidity
            // 
            this.tabpage_SeverityCormobidity.Controls.Add(this.label_ServerityCount);
            this.tabpage_SeverityCormobidity.Controls.Add(this.reportViewer_Severity);
            this.tabpage_SeverityCormobidity.Controls.Add(this.comboBox_MechanicalVentilation);
            this.tabpage_SeverityCormobidity.Controls.Add(this.lbl_MechanicalVentilation);
            this.tabpage_SeverityCormobidity.Controls.Add(this.comboBox_AdmittedtoICU);
            this.tabpage_SeverityCormobidity.Controls.Add(this.lbl_AdmittedtoICU);
            this.tabpage_SeverityCormobidity.Controls.Add(this.button_SeveritySearch);
            this.tabpage_SeverityCormobidity.Controls.Add(this.maskedTextBox_ServerityDischargeDateTo);
            this.tabpage_SeverityCormobidity.Controls.Add(this.maskedTextBox_ServerityDischargeDateFrom);
            this.tabpage_SeverityCormobidity.Controls.Add(this.comboBox_ServerityVersion);
            this.tabpage_SeverityCormobidity.Controls.Add(this.lbl_ServerityDischargeDateTo);
            this.tabpage_SeverityCormobidity.Controls.Add(this.lbl_ServerityDischargeDate);
            this.tabpage_SeverityCormobidity.Controls.Add(this.lbl_SeverityVersion);
            this.tabpage_SeverityCormobidity.Location = new System.Drawing.Point(4, 22);
            this.tabpage_SeverityCormobidity.Name = "tabpage_SeverityCormobidity";
            this.tabpage_SeverityCormobidity.Size = new System.Drawing.Size(1232, 579);
            this.tabpage_SeverityCormobidity.TabIndex = 2;
            this.tabpage_SeverityCormobidity.Text = "Severity/Comorbidity";
            this.tabpage_SeverityCormobidity.UseVisualStyleBackColor = true;
            // 
            // label_ServerityCount
            // 
            this.label_ServerityCount.AutoSize = true;
            this.label_ServerityCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ServerityCount.Location = new System.Drawing.Point(9, 582);
            this.label_ServerityCount.Name = "label_ServerityCount";
            this.label_ServerityCount.Size = new System.Drawing.Size(81, 13);
            this.label_ServerityCount.TabIndex = 27;
            this.label_ServerityCount.Text = "Total Count :";
            this.label_ServerityCount.Visible = false;
            // 
            // reportViewer_Severity
            // 
            this.reportViewer_Severity.Location = new System.Drawing.Point(12, 83);
            this.reportViewer_Severity.Name = "reportViewer_Severity";
            this.reportViewer_Severity.ServerReport.BearerToken = null;
            this.reportViewer_Severity.Size = new System.Drawing.Size(1201, 483);
            this.reportViewer_Severity.TabIndex = 26;
            // 
            // comboBox_MechanicalVentilation
            // 
            this.comboBox_MechanicalVentilation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_MechanicalVentilation.FormattingEnabled = true;
            this.comboBox_MechanicalVentilation.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_MechanicalVentilation.Location = new System.Drawing.Point(804, 20);
            this.comboBox_MechanicalVentilation.Name = "comboBox_MechanicalVentilation";
            this.comboBox_MechanicalVentilation.Size = new System.Drawing.Size(40, 21);
            this.comboBox_MechanicalVentilation.TabIndex = 25;
            // 
            // lbl_MechanicalVentilation
            // 
            this.lbl_MechanicalVentilation.AutoSize = true;
            this.lbl_MechanicalVentilation.Location = new System.Drawing.Point(681, 23);
            this.lbl_MechanicalVentilation.Name = "lbl_MechanicalVentilation";
            this.lbl_MechanicalVentilation.Size = new System.Drawing.Size(117, 13);
            this.lbl_MechanicalVentilation.TabIndex = 24;
            this.lbl_MechanicalVentilation.Text = "Mechanical Ventilation:";
            // 
            // comboBox_AdmittedtoICU
            // 
            this.comboBox_AdmittedtoICU.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AdmittedtoICU.FormattingEnabled = true;
            this.comboBox_AdmittedtoICU.Items.AddRange(new object[] {
            "",
            "Yes",
            "No"});
            this.comboBox_AdmittedtoICU.Location = new System.Drawing.Point(619, 20);
            this.comboBox_AdmittedtoICU.Name = "comboBox_AdmittedtoICU";
            this.comboBox_AdmittedtoICU.Size = new System.Drawing.Size(40, 21);
            this.comboBox_AdmittedtoICU.TabIndex = 23;
            // 
            // lbl_AdmittedtoICU
            // 
            this.lbl_AdmittedtoICU.AutoSize = true;
            this.lbl_AdmittedtoICU.Location = new System.Drawing.Point(517, 25);
            this.lbl_AdmittedtoICU.Name = "lbl_AdmittedtoICU";
            this.lbl_AdmittedtoICU.Size = new System.Drawing.Size(84, 13);
            this.lbl_AdmittedtoICU.TabIndex = 22;
            this.lbl_AdmittedtoICU.Text = "Admitted to ICU:";
            // 
            // button_SeveritySearch
            // 
            this.button_SeveritySearch.Location = new System.Drawing.Point(877, 11);
            this.button_SeveritySearch.Name = "button_SeveritySearch";
            this.button_SeveritySearch.Size = new System.Drawing.Size(94, 36);
            this.button_SeveritySearch.TabIndex = 21;
            this.button_SeveritySearch.Text = "Search";
            this.button_SeveritySearch.UseVisualStyleBackColor = true;
            this.button_SeveritySearch.Click += new System.EventHandler(this.button_SeveritySearch_Click);
            // 
            // maskedTextBox_ServerityDischargeDateTo
            // 
            this.maskedTextBox_ServerityDischargeDateTo.Location = new System.Drawing.Point(426, 22);
            this.maskedTextBox_ServerityDischargeDateTo.Mask = "00/00/0000";
            this.maskedTextBox_ServerityDischargeDateTo.Name = "maskedTextBox_ServerityDischargeDateTo";
            this.maskedTextBox_ServerityDischargeDateTo.Size = new System.Drawing.Size(72, 20);
            this.maskedTextBox_ServerityDischargeDateTo.TabIndex = 20;
            // 
            // maskedTextBox_ServerityDischargeDateFrom
            // 
            this.maskedTextBox_ServerityDischargeDateFrom.Location = new System.Drawing.Point(232, 21);
            this.maskedTextBox_ServerityDischargeDateFrom.Mask = "00/00/0000";
            this.maskedTextBox_ServerityDischargeDateFrom.Name = "maskedTextBox_ServerityDischargeDateFrom";
            this.maskedTextBox_ServerityDischargeDateFrom.Size = new System.Drawing.Size(72, 20);
            this.maskedTextBox_ServerityDischargeDateFrom.TabIndex = 19;
            // 
            // comboBox_ServerityVersion
            // 
            this.comboBox_ServerityVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ServerityVersion.FormattingEnabled = true;
            this.comboBox_ServerityVersion.Items.AddRange(new object[] {
            "6.3",
            "1.1",
            "5.1"});
            this.comboBox_ServerityVersion.Location = new System.Drawing.Point(61, 22);
            this.comboBox_ServerityVersion.Name = "comboBox_ServerityVersion";
            this.comboBox_ServerityVersion.Size = new System.Drawing.Size(40, 21);
            this.comboBox_ServerityVersion.TabIndex = 18;
            // 
            // lbl_ServerityDischargeDateTo
            // 
            this.lbl_ServerityDischargeDateTo.AutoSize = true;
            this.lbl_ServerityDischargeDateTo.Location = new System.Drawing.Point(320, 25);
            this.lbl_ServerityDischargeDateTo.Name = "lbl_ServerityDischargeDateTo";
            this.lbl_ServerityDischargeDateTo.Size = new System.Drawing.Size(100, 13);
            this.lbl_ServerityDischargeDateTo.TabIndex = 17;
            this.lbl_ServerityDischargeDateTo.Text = "Discharge Date To:";
            // 
            // lbl_ServerityDischargeDate
            // 
            this.lbl_ServerityDischargeDate.AutoSize = true;
            this.lbl_ServerityDischargeDate.Location = new System.Drawing.Point(116, 26);
            this.lbl_ServerityDischargeDate.Name = "lbl_ServerityDischargeDate";
            this.lbl_ServerityDischargeDate.Size = new System.Drawing.Size(110, 13);
            this.lbl_ServerityDischargeDate.TabIndex = 16;
            this.lbl_ServerityDischargeDate.Text = "Discharge Date From:";
            // 
            // lbl_SeverityVersion
            // 
            this.lbl_SeverityVersion.AutoSize = true;
            this.lbl_SeverityVersion.Location = new System.Drawing.Point(9, 25);
            this.lbl_SeverityVersion.Name = "lbl_SeverityVersion";
            this.lbl_SeverityVersion.Size = new System.Drawing.Size(45, 13);
            this.lbl_SeverityVersion.TabIndex = 15;
            this.lbl_SeverityVersion.Text = "Version:";
            // 
            // label_Copyright
            // 
            this.label_Copyright.AutoSize = true;
            this.label_Copyright.Location = new System.Drawing.Point(582, 665);
            this.label_Copyright.Name = "label_Copyright";
            this.label_Copyright.Size = new System.Drawing.Size(86, 13);
            this.label_Copyright.TabIndex = 503;
            this.label_Copyright.Text = "© HANYS 2019.";
            // 
            // Label_Contact
            // 
            this.Label_Contact.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Contact.AutoSize = true;
            this.Label_Contact.Location = new System.Drawing.Point(1076, 665);
            this.Label_Contact.Name = "Label_Contact";
            this.Label_Contact.Size = new System.Drawing.Size(122, 13);
            this.Label_Contact.TabIndex = 505;
            this.Label_Contact.Text = "Contact Sepsis support:-";
            // 
            // Label_ClickHere
            // 
            this.Label_ClickHere.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_ClickHere.AutoSize = true;
            this.Label_ClickHere.Location = new System.Drawing.Point(1196, 665);
            this.Label_ClickHere.Name = "Label_ClickHere";
            this.Label_ClickHere.Size = new System.Drawing.Size(56, 13);
            this.Label_ClickHere.TabIndex = 504;
            this.Label_ClickHere.TabStop = true;
            this.Label_ClickHere.Text = "Click Here";
            // 
            // Reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 687);
            this.Controls.Add(this.Label_Contact);
            this.Controls.Add(this.Label_ClickHere);
            this.Controls.Add(this.label_Copyright);
            this.Controls.Add(this.tabControl_Reports);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Reports";
            this.Text = "Reports";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Reports_FormClosing);
            this.Load += new System.EventHandler(this.Reports_Load);
            this.tabControl_Reports.ResumeLayout(false);
            this.tabPage_MasterReport.ResumeLayout(false);
            this.tabPage_MasterReport.PerformLayout();
            this.tabPage_Adherence.ResumeLayout(false);
            this.tabPage_Adherence.PerformLayout();
            this.tabPage_AdherenceAdvanced.ResumeLayout(false);
            this.tabPage_AdherenceAdvanced.PerformLayout();
            this.tabpage_SeverityCormobidity.ResumeLayout(false);
            this.tabpage_SeverityCormobidity.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl_Reports;
        private System.Windows.Forms.TabPage tabPage_MasterReport;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.ComboBox comboBox_Version;
        private System.Windows.Forms.Label lbl_ToDate;
        private System.Windows.Forms.Label lbl_FromDate;
        private System.Windows.Forms.Label lbl_Version;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_DateTo;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_DateFrom;
        private System.Windows.Forms.Button button_Search;
        private System.Windows.Forms.Label label_TotalCount;
        private System.Windows.Forms.ComboBox comboBox_ExcludedfromProtocol;
        private System.Windows.Forms.Label lbl_ExcludedFromProtocol;
        private System.Windows.Forms.ComboBox comboBox_RecordComplete;
        private System.Windows.Forms.Label lbl_RecordComplete;
        private System.Windows.Forms.ComboBox comboBox_Transfer;
        private System.Windows.Forms.Label lbl_transfer;
        private System.Windows.Forms.TabPage tabpage_SeverityCormobidity;
        private System.Windows.Forms.ComboBox comboBox_MechanicalVentilation;
        private System.Windows.Forms.Label lbl_MechanicalVentilation;
        private System.Windows.Forms.ComboBox comboBox_AdmittedtoICU;
        private System.Windows.Forms.Label lbl_AdmittedtoICU;
        private System.Windows.Forms.Button button_SeveritySearch;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_ServerityDischargeDateTo;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_ServerityDischargeDateFrom;
        private System.Windows.Forms.ComboBox comboBox_ServerityVersion;
        private System.Windows.Forms.Label lbl_ServerityDischargeDateTo;
        private System.Windows.Forms.Label lbl_ServerityDischargeDate;
        private System.Windows.Forms.Label lbl_SeverityVersion;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer_Severity;
        private System.Windows.Forms.Label label_ServerityCount;
        private System.Windows.Forms.TabPage tabPage_Adherence;
        private System.Windows.Forms.ComboBox comboBox_AdherenceInitialLactateLevel;
        private System.Windows.Forms.Label lbl_AdherenceInitialLactate;
        private System.Windows.Forms.ComboBox comboBox_AdherenceSepticShock;
        private System.Windows.Forms.Label lbl_AdherenceSepticShock;
        private System.Windows.Forms.ComboBox comboBox_AdherenceSevereSepsis;
        private System.Windows.Forms.Label lbl_AdherenceSevereSepsis;
        private System.Windows.Forms.Button button_Adherence;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_AdherenceDischargeDateTo;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_AdherenceDischargeDateFrom;
        private System.Windows.Forms.ComboBox comboBox_AdherenceVersion;
        private System.Windows.Forms.Label lbl_AdherenceDischargeDateTo;
        private System.Windows.Forms.Label lbl_AdherenceDischargeDateFrom;
        private System.Windows.Forms.Label lbl_AdherenceVersion;
        private System.Windows.Forms.ComboBox comboBox_AdherenceInititalHypotention;
        private System.Windows.Forms.Label lbl_AdherenceInititalHypotention;
        private System.Windows.Forms.ComboBox comboBox_AdherenceAntibioticAdministration;
        private System.Windows.Forms.Label lbl_AdherenceAntibioticAdministration;
        private System.Windows.Forms.ComboBox comboBox_AdherenceBloodCultureCollection;
        private System.Windows.Forms.Label lbl_AdherenceBloodCultureCollection;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer_Adherence;
        private System.Windows.Forms.Label lbl_AdherenceCount;
        private System.Windows.Forms.TabPage tabPage_AdherenceAdvanced;
        private System.Windows.Forms.ComboBox comboBox_CrystalloidFluidBefore;
        private System.Windows.Forms.Label lbl_CrystalloidBefore;
        private System.Windows.Forms.ComboBox comboBox_AntibioticBefore;
        private System.Windows.Forms.Label lbl_AntibioticBefore;
        private System.Windows.Forms.ComboBox comboBox_BloodCultureBefore;
        private System.Windows.Forms.Label lbl_BloodCultureBefore;
        private System.Windows.Forms.ComboBox comboBox_LactateBefore;
        private System.Windows.Forms.Label lbl_AdvancedLactateBefore;
        private System.Windows.Forms.Button button_AdherenceAdvancedSearch;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_AdvancedDischargedDateTo;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_AdvancedDischargedDateFrom;
        private System.Windows.Forms.ComboBox comboBox_AdvancedVersion;
        private System.Windows.Forms.Label lbl_AdvancedDischargedDateTo;
        private System.Windows.Forms.Label lbl_AdvancedDischargedDateFrom;
        private System.Windows.Forms.Label lbl_AdvancedVersion;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerAdherenceAdvanced;
        private System.Windows.Forms.Label lbl_AdvancedTotalCount;
        private System.Windows.Forms.Label label_Copyright;
        private System.Windows.Forms.Label Label_Contact;
        private System.Windows.Forms.LinkLabel Label_ClickHere;
    }
}