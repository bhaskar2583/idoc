﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Odbc;
using System.IO;
using System.Collections;
using System.Globalization;
using System.Diagnostics;


namespace WindowsFormsApplication1
{
    public partial class SepsisCaseDetails : Form
    {

        ArrayList list = new ArrayList();
        string ConnectionString;
        int _uniqueID = 0;
        SepsisMaster sm;
        DataBaseConnection Db = new DataBaseConnection();
        OdbcConnection Conn;
        public SepsisCaseDetails(SepsisMaster master)
        {
            try
            {
            InitializeComponent();
            sm = master;
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;
            // ConnectionString = @"Server=SQLCONC1;Database=Sepsis;User Id=HANYS_SEPSIS_APPLICATION;Password=nonParagamps7!;";
           //ConnectionString = @"Server=JITU-PC\JITU;Database=Sepsis;User Id=sa;Password=jitu123;";
         // ConnectionString = @"Server=HANYS-APPS-DB-D\DEVNETFORUMDB;Database=Sepsis;User Id=sa;Password=password;";
           // ConnectionString = @"Server=CFOSTER-L;Database=Sepsis;User Id=sa;Password=Password1;";
           //ConnectionString = @"Server=KRAUCH-L;Database=Sepsis;User Id=sa;Password=Password1;";
           //ConnectionString = @"Server=MTHERRIAULT-L;Database=Sepsis;User Id=sa;Password=Password1;";
            //ConnectionString = @"Server=TS5-L\SEPSIS;Database=Sepsis;User Id=sa;Password=Password1;";
            LoadCombobox();
            HideDependentFields();
            tempcolor = System.Drawing.ColorTranslator.FromHtml("#E8E8E8");
            result = Color.FromArgb(tempcolor.R, tempcolor.G, tempcolor.B);
            Dropdowncolor();

             }
            catch (Exception ex)
            {

            }
        }
        public SepsisCaseDetails(int uniqueID, SepsisMaster master)
        {
         try
         {
            InitializeComponent();
            sm = master;
            HideDependentFields();
           // ConnectionString = "FIL=Sql server;DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;
            // ConnectionString = @"Server=SQLCONC1;Database=Sepsis;User Id=HANYS_SEPSIS_APPLICATION;Password=nonParagamps7!;";
            //ConnectionString = @"Server=JITU-PC\JITU;Database=Sepsis;User Id=sa;Password=jitu123;";
         // ConnectionString = @"Server=HANYS-APPS-DB-D\DEVNETFORUMDB;Database=Sepsis;User Id=sa;Password=password;";
           //ConnectionString = @"Server=MTHERRIAULT-L;Database=Sepsis;User Id=sa;Password=Password1;";
         // ConnectionString = @"Server=HANYS-APPS-DB-D\DEVNETFORUMDB;Database=Sepsis;User Id=sa;Password=password;";
           //ConnectionString = @"Server=KRAUCH-L;Database=Sepsis;User Id=sa;Password=Password1;";
            //ConnectionString = @"Server=CFOSTER-L;Database=Sepsis;User Id=sa;Password=Password1;";
            //ConnectionString = @"Server=TS5-L\SEPSIS;Database=Sepsis;User Id=sa;Password=Password1;";

            LoadCombobox();
            _uniqueID = uniqueID;
            LoadEditData(_uniqueID);
            tempcolor = System.Drawing.ColorTranslator.FromHtml("#E8E8E8");
            result = Color.FromArgb(tempcolor.R, tempcolor.G, tempcolor.B);
            Dropdowncolor();
            //lbl_ExcludedExplain.Hide();//temporary fix for demo
           }
            catch (Exception ex)
            {

            }

        }

        int positionCount = 0;
        string format1 = "MM/dd/yyyy HH:mm";
        string format2 = "MM/dd/yyyy";
        int lactatelevel = 0;
        string templactatelevel ="";
        string[] ProgramNames;
        int temp = 0;
        int arraycount = 0;
        string query;
        DataSet ds;
        int count = 0;
        DateTime dDateStart = DateTime.Parse("01/01/1910");
        DateTime dDateEnd = DateTime.Parse("01/01/2100");
        int sCount =0;
        char d;
        decimal templactate;
        string allowedchar = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        string Lactateallowedchar = "0123456789.";
        int Decimaloccurance = 0;
        int ExcludedResonChecked = 0;

        Color tempcolor;
        Color result;
     
          private void txtMRN_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
              try
              {
            System.Text.StringBuilder messageBoxCS = new System.Text.StringBuilder();
            
            messageBoxCS.AppendFormat("{0} : {1}", "Medical Record Error", e.RejectionHint);
            messageBoxCS.AppendLine();
            MessageBox.Show(messageBoxCS.ToString(), "Medical Record Number Error");
                 }
            catch (Exception ex)
            {

            }
        }


          public string IsnullString(string inputString)
          {
              if (inputString == "" || inputString == "Select")
              {
                  inputString = null;
                  return inputString;
              }
              return inputString;
          }

          public string BlankComboEdit(string inputString)
          {
              if (inputString == "" || inputString == "Select")
              {
                  inputString = "Select";
                  return inputString;
              }
              return inputString;
          }


          //public string IsnullCombobox(string inputString)
          //{
          //    if (inputString == "Select")
          //    {
          //        inputString = null;
          //        return inputString;
          //    }
          //    return inputString;
          //}


        
         

           


          public bool IsnullDate(string inputString)
          {
            

              if (inputString == "/  /       :" || inputString == "" || inputString == "/  /")
              {
                  return true;
              }
              return false;
            
          }


          private void button_SaveCase_Click(object sender, EventArgs e)
          {

             try
              {


              AllFields A = new AllFields();
              A.UniqueId = _uniqueID;
              if (MandatoryFieldCheck() == false)
              {
                 // A.RecordCompleted = false;
                  A.RecordCompleted = 0;
              }
              else
              {
                 // A.RecordCompleted = true;
                  A.RecordCompleted = 1;
              }



              if (IsnullString(txtId.Text.ToString().Trim()) == null)
              {
                  MessageBox.Show("Please enter unique personal identifier.", "Unique Personal Identifier Error");
                  txtId.Focus();
                  return;
              }
              else
                  A.UniquePersonalIdentifier = txtId.Text.ToString().Trim();


              A.PatientControlNumber = IsnullString(TextBox_PatientCtrlNum.Text.ToString().Trim());

              if (IsnullDate(txtDOB.Text.ToString().Trim()) != true)
                  A.DateofBirth = DateTime.Parse(txtDOB.Text.ToString().Trim());

              A.Gender = IsnullString(Combobox_Gender.SelectedValue.ToString());

              if (checkedListBox_Race.CheckedItems.Count > 0)
              {
                  foreach (object itemChecked in checkedListBox_Race.CheckedItems)
                  {

                      DataRowView castedItem = itemChecked as DataRowView;

                      if (count > 0)
                      {
                          A.Race = A.Race + ":" + castedItem["ComboBox_Key"].ToString();
                      }
                      else
                      {
                          A.Race = castedItem["ComboBox_Key"].ToString();
                      }
                      count++;
                  }

                  count = 0;
              }
              else
              {
                  A.Race = null;
              }
              
              A.Ethnicity = IsnullString(Combobox_Ethnicity.SelectedValue.ToString());
              A.Payor = IsnullString(comboBox_Payor.SelectedValue.ToString());
              A.InsuranceNumber = IsnullString(TextBox_InsuranceNumber.Text.ToString().Trim());
              A.MedicalRecordNumber = IsnullString(txtMRN.Text.ToString().Trim());
              A.FacilityIdentifier = IsnullString(TextBox_FacilityIdentifier.Text.ToString().Trim());

              //if (validateDate(textBox_AdmissionDateTime.Text.ToString().Trim()) == true)
              //{
              if (IsnullDate(textBox_AdmissionDateTime.Text.ToString().Trim()) != true)
                  A.AdmissionDatetime = DateTime.Parse(textBox_AdmissionDateTime.Text.ToString().Trim());
              //}


              A.SourceofAdmission = IsnullString(comboBox_SourceofAdmission.SelectedValue.ToString());

              // if (validateDate(textBox_DischargedDatetime.Text.ToString().Trim()) == true)
              // {
              if (IsnullDate(textBox_DischargedDatetime.Text.ToString().Trim()) != true)
                  A.DischargeDatetime = DateTime.Parse(textBox_DischargedDatetime.Text.ToString().Trim());
              //}

              A.DischargedStatus = IsnullString(comboBox_DischargeStatus.SelectedValue.ToString());
              A.TransferStatus = IsnullString(comboBox_TransferStatus.SelectedValue.ToString());
              A.TransferFacilityIdentifier = IsnullString(textBox_TransferFacilityIdentifier.Text.ToString().Trim());
              A.ProtocolInitiated = IsnullString(comboBox_ProtocolInitiated.SelectedValue.ToString());
              A.ProtocolNotInitiatedReason = IsnullString(comboBox_ProtocolNotInitiatedReason.SelectedValue.ToString());
              A.ProtocolNotInitiatedAdditionalDetail = IsnullString(textBox_ProtocolNIAdditionalDetail.Text.ToString().Trim());
              A.ProtocolInitiatedPlace = IsnullString(comboBox_ProtocolInitiatedPlace.SelectedValue.ToString());
              A.ProtocolType = IsnullString(comboBox_ProtocolType.SelectedValue.ToString());
              A.ExcludedFromProtocol = IsnullString(comboBox_ExcludedFromProtocol.SelectedValue.ToString());



              if (checkedListBox_ExcludedReason.CheckedItems.Count > 0)
              {
                  foreach (object itemChecked in checkedListBox_ExcludedReason.CheckedItems)
                  {

                      DataRowView castedItem = itemChecked as DataRowView;

                      if (count > 0)
                      {
                          A.ExcludedReason = A.ExcludedReason + ":" + castedItem["ComboBox_Key"].ToString();
                      }
                      else
                      {
                          A.ExcludedReason = castedItem["ComboBox_Key"].ToString();
                      }
                      count++;
                  }
                  count = 0;
              }
              else
              {
                  A.ExcludedReason = null;
              }






              if (IsnullDate(textBox_ExcludedDatetime.Text.ToString().Trim()) != true)
                  A.ExcludedDatetime = DateTime.Parse(textBox_ExcludedDatetime.Text.ToString().Trim());




              if (checkedListBox_ExcludedExplain.CheckedItems.Count > 0)
              {
                  foreach (object itemChecked in checkedListBox_ExcludedExplain.CheckedItems)
                  {

                      DataRowView castedItem = itemChecked as DataRowView;

                      if (count > 0)
                      {
                          A.ExcludedExplain = A.ExcludedExplain + ":" + castedItem["ComboBox_Key"].ToString();
                      }
                      else
                      {
                          A.ExcludedExplain = castedItem["ComboBox_Key"].ToString();
                      }
                      count++;
                  }
                  count = 0;
              }
              else
              {
                  A.ExcludedExplain = null;
              }

              if (IsnullDate(textBox_EarliestDatetime.Text.ToString().Trim()) != true)
                  A.EarliestDateTime = DateTime.Parse(textBox_EarliestDatetime.Text.ToString().Trim());
              if (IsnullDate(textbox_TriageDatetime.Text.ToString().Trim()) != true)
                  A.TriageDatetime = DateTime.Parse(textbox_TriageDatetime.Text.ToString().Trim());
              A.SevereSepsisPresent = IsnullString(comboBox_SevereSepsisPresent.SelectedValue.ToString());
              if (IsnullDate(textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim()) != true)
                  A.SevereSepsisPresentationDatetime = DateTime.Parse(textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim());
              A.SepticShockPresent = IsnullString(comboBox_SepticShockPresent.SelectedValue.ToString());
              if (IsnullDate(textBox_septicShockPresentationDatetime.Text.ToString().Trim()) != true)
                  A.SepticShockPresentDatetime = DateTime.Parse(textBox_septicShockPresentationDatetime.Text.ToString().Trim());
              if (IsnullDate(textBox_LeftEDDatetime.Text.ToString().Trim()) != true)
                  A.LeftEDDatetime = DateTime.Parse(textBox_LeftEDDatetime.Text.ToString().Trim());
              A.DestinationAfterED = IsnullString(comboBox_DestinationafterED.SelectedValue.ToString());
              A.InitialLactateLevelCollection = IsnullString(comboBox_InitialLactateLevelCollection.SelectedValue.ToString());
              if (IsnullDate(textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim()) != true)
                  A.InitialLactateLevelCollectionDatetime = DateTime.Parse(textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim());


              A.InitialLactateLevel = IsnullString(textBox_InitialLactateLevel.Text.ToString().Trim());
              //templactatelevel = textBox_InitialLactateLevel.Text.ToString().Trim();

              //if (textBox_InitialLactateLevel.Text.ToString() != "")
              //{
                  
              //    A.InitialLactateLevel =textBox_InitialLactateLevel.Text.ToString().Trim();
              //}
             //lactatelevelindex = textBox_InitialLactateLevel.Text.IndexOf(" ");
                // templactatelevel = templactatelevel.Remove(


                 
              A.InitialLactateLevelUnit = IsnullString(comboBox_InitialLactateLevelUnit.SelectedValue.ToString());
              A.RepeatLactateLevelCollection = IsnullString(comboBox_RepeatLactateLevelCollection.SelectedValue.ToString());
              if (IsnullDate(textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim()) != true)
                  A.RepeatLactateLevelCollectionDatetime = DateTime.Parse(textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim());
              A.BloodCultureCollection = IsnullString(comboBox_BloodCultureCollection.SelectedValue.ToString());
              A.BloodCultureCollectionAcceptableDelay = IsnullString(comboBox_BloodCultureCollectionAcceptableDelay.SelectedValue.ToString());
              if (IsnullDate(textBox_BloodCultureCollectionDatetime.Text.ToString().Trim()) != true)
                  A.BloodCultureCollectionDatetime = DateTime.Parse(textBox_BloodCultureCollectionDatetime.Text.ToString().Trim());
              A.BloodCultureResult = IsnullString(comboBoX_BloodCultureResult.SelectedValue.ToString());
              A.BloodCulturePathogen = IsnullString(comboBox_BloodCulturePathogen.SelectedValue.ToString());
              A.AntibioticAdministration = IsnullString(comboBox_AntibioticAdministration.SelectedValue.ToString());
              A.AntibioticAdministrationSelection = IsnullString(comboBox_AntibioticAdministrationSelection.SelectedValue.ToString());
              if (IsnullDate(textBox_AntibioticAdministrationDatetime.Text.ToString().Trim()) != true)
                  A.AntibioticAdministrationDatetime = DateTime.Parse(textBox_AntibioticAdministrationDatetime.Text.ToString().Trim());
              A.AdultCrystalloidFluidAdministration = IsnullString(comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString());
              A.PediatricCrystalloidFluidAdministration = IsnullString(comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString());
              if (IsnullDate(textBox_CrystalloidFluidAdministrationDatetime.Text.ToString().Trim()) != true)
                  A.CrystalloidFluidAdministrationDatetime = DateTime.Parse(textBox_CrystalloidFluidAdministrationDatetime.Text.ToString().Trim());
              A.InitialHypotension = IsnullString(comboBox_InitialHypotension.SelectedValue.ToString());
              A.PersistentHypotension = IsnullString(comboBox_PersistentHypotension.SelectedValue.ToString());
              A.VasopressorAdministration = IsnullString(comboBox_VasopressorAdministration.SelectedValue.ToString());
              if (IsnullDate(textBox_VasopressorAdministrationDatetime.Text.ToString().Trim()) != true)
                  A.VasopressorAdministrationDatetime = DateTime.Parse(textBox_VasopressorAdministrationDatetime.Text.ToString().Trim());
              A.BesideCardiovascularUltrasound = IsnullString(comboBox_BedsideCardiovascularUltrasound.SelectedValue.ToString());
              if (IsnullDate(textBox_BedsideCardiovascularUltrasoundDatetime.Text.ToString().Trim()) != true)
                  A.BesideCardiovascularUltrasoundDatetime = DateTime.Parse(textBox_BedsideCardiovascularUltrasoundDatetime.Text.ToString().Trim());
              A.CapillaryRefillExamination = IsnullString(comboBox_CapillaryRefillExamination.SelectedValue.ToString());
              if (IsnullDate(textBox_CapillaryRefillExaminationDatetime.Text.ToString().Trim()) != true)
                  A.CapillaryRefillExaminationDatetime = DateTime.Parse(textBox_CapillaryRefillExaminationDatetime.Text.ToString().Trim());
              A.CardiopulmonaryEvaluation = IsnullString(comboBox_CardiopulmonaryEvaluation.SelectedValue.ToString());
              if (IsnullDate(textBox_CardiopulmonaryEvaluationDatetime.Text.ToString().Trim()) != true)
                  A.CardiopulmonaryEvaluationDatetime = DateTime.Parse(textBox_CardiopulmonaryEvaluationDatetime.Text.ToString().Trim());
              A.PassiveLegRaiseExamination = IsnullString(comboBox_PassiveLegRaiseExamination.SelectedValue.ToString());
              if (IsnullDate(textBox_PassiveLegRaiseExaminationDatetime.Text.ToString().Trim()) != true)
                  A.PassiveLegRaiseExaminationDatetime = DateTime.Parse(textBox_PassiveLegRaiseExaminationDatetime.Text.ToString().Trim());
              A.PeripheralPulseEvaluation = IsnullString(comboBox_PeripheralPulseEvaluation.SelectedValue.ToString());
              if (IsnullDate(textBox_PeripheralPulseEvaluationDatetime.Text.ToString().Trim()) != true)
                  A.PeripheralPulseEvaluationDatetime = DateTime.Parse(textBox_PeripheralPulseEvaluationDatetime.Text.ToString().Trim());
              A.SkinExamination = IsnullString(comboBox_SkinExamination.SelectedValue.ToString());
              if (IsnullDate(textBox_SkinExaminationDatetime.Text.ToString().Trim()) != true)
                  A.SkinExaminationDatetime = DateTime.Parse(textBox_SkinExaminationDatetime.Text.ToString().Trim());
              A.CentralVenousOxygenMeasurement = IsnullString(comboBox_CentralVenousOxygenMeasurement.SelectedValue.ToString());
              if (IsnullDate(textBox_CentralVenousOxygenMeasurementDatetime.Text.ToString().Trim()) != true)
                  A.CentralVenousOxygenMeasurementDatetime = DateTime.Parse(textBox_CentralVenousOxygenMeasurementDatetime.Text.ToString().Trim());
              A.CentralVenousPressureMeasurement = IsnullString(comboBox_CentralVenousPressureMeasurement.SelectedValue.ToString());
              if (IsnullDate(textBox_CentralVenousPressureMeasurementDatetime.Text.ToString().Trim()) != true)
                  A.CentralVenousPressureMeasurementDatetime = DateTime.Parse(textBox_CentralVenousPressureMeasurementDatetime.Text.ToString().Trim());
              A.FluidChallengePerformed = IsnullString(comboBox_FluidChallengePerformed.SelectedValue.ToString());
              if (IsnullDate(textBox_FluidChallengePerformedDatetime.Text.ToString().Trim()) != true)
                  A.FluidChallengePerformedDatetime = DateTime.Parse(textBox_FluidChallengePerformedDatetime.Text.ToString().Trim());
              A.VitalSignsReview = IsnullString(comboBox_VitalSignsReview.SelectedValue.ToString());
              if (IsnullDate(textBox_VitalSignsReviewDatetime.Text.ToString().Trim()) != true)
                  A.VitalSignsReviewDatetime = DateTime.Parse(textBox_VitalSignsReviewDatetime.Text.ToString().Trim());
              A.PlateletCount = IsnullString(comboBox_PlateletCount.SelectedValue.ToString());
              A.Bandemia = IsnullString(comboBox_Bandemia.SelectedValue.ToString());
              A.LoweRespiratoryInfection = IsnullString(comboBox_LowerRespiratoryInfection.SelectedValue.ToString());
              A.AlteredMentalStatus = IsnullString(comboBox_AlteredMentalStatus.SelectedValue.ToString());
              A.InfectionEtiology = IsnullString(comboBox_InfectionEtiology.SelectedValue.ToString());
              A.SiteofInfection = IsnullString(comboBox_SiteofInfection.SelectedValue.ToString());
              A.MechanicalVentilation = IsnullString(comboBox_MechanicalVentilation.SelectedValue.ToString());
              if (IsnullDate(textBox_MechanicalVentilationDatetime.Text.ToString().Trim()) != true)
                  A.MechanicalVentilationDatetime = DateTime.Parse(textBox_MechanicalVentilationDatetime.Text.ToString().Trim());
              A.ICU = IsnullString(comboBox_ICU.SelectedValue.ToString());
              if (IsnullDate(textBox_ICUAdmissionDatetime.Text.ToString().Trim()) != true)
                  A.ICUAdmissionDatetime = DateTime.Parse(textBox_ICUAdmissionDatetime.Text.ToString().Trim());
              if (IsnullDate(textBox_ICUDischargeDatetime.Text.ToString().Trim()) != true)
                  A.ICUDischargeDatetime = DateTime.Parse(textBox_ICUDischargeDatetime.Text.ToString().Trim());
              A.ChronicRespiratoryFailure = IsnullString(comboBox_ChronicRespiratoryFailure.SelectedValue.ToString());
              A.AIDS = IsnullString(comboBox_AIDSDisease.SelectedValue.ToString());
              A.MetastaticCancer = IsnullString(comboBox_MetastaticCancer.SelectedValue.ToString());
              A.Lymphoma = IsnullString(comboBox_Lymphoma.SelectedValue.ToString());
              A.ImmuneModifyingMedications = IsnullString(comboBox_ImmuneModifyingMedications.SelectedValue.ToString());
              A.CongestiveHeartFailure = IsnullString(comboBox_CongestiveHeartFailure.SelectedValue.ToString());
              A.ChronicRenalFailure = IsnullString(comboBox_ChronicRenalFailure.SelectedValue.ToString());
              A.ChronicLiverDisease = IsnullString(comboBox_ChronicLiverDisease.SelectedValue.ToString());
              A.Diabetes = IsnullString(comboBox_Diabetes.SelectedValue.ToString());
              A.OrganTransplant = IsnullString(comboBox_OrganTransplant.SelectedValue.ToString());
              A.Year = "2017";
              A.Version = "4.1";
              A.Quarter = "Q1";
              A.DateCreated = DateTime.Now;
             // A.RecordCompleted = false;
              //A.CSVGenerated = false;
              A.CSVGenerated = 0;
              //A.DateCreated = DateTime.Now;
              //A.DateCreated = comboBox_RepeatLactateLevelCollection.SelectedValue.ToString();
              //A.RecordCompleted = comboBox_RepeatLactateLevelCollection.SelectedValue.ToString();
              // A.CSVGenerated

              if (_uniqueID == 0)
              {

                 //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                  using (Conn = new OdbcConnection(ConnectionString))
                  {
                      Conn.Open();

                      //query = "select UniqueId, unique_personal_identifier, patient_control_number, date_of_birth, medical_record_number,Date_Created, Record_Completed, CSVGenerated from sepsis_collab ";
                      //query = query + "where Version = " + comboBox_Version.Text.ToString().Trim();
                      //query = "Sepsis_Insert";
                      query = "{call Sepsis_Insert(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

                      //using (SqlCommand Sqlcmd = new SqlCommand())
                      using (OdbcCommand Sqlcmd = new OdbcCommand())
                      {

                          Sqlcmd.CommandText = query;
                          Sqlcmd.CommandType = CommandType.StoredProcedure;
                          Sqlcmd.Connection = Conn;



                          Sqlcmd.Parameters.Add(new OdbcParameter("UniquePersonalIdentifier", A.UniquePersonalIdentifier));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PatientControlNumber ", A.PatientControlNumber));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DateofBirth", A.DateofBirth));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Gender", A.Gender));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Race", A.Race));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Ethnicity", A.Ethnicity));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Payor", A.Payor));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InsuranceNumber", A.InsuranceNumber));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MedicalRecordNumber", A.MedicalRecordNumber));
                          Sqlcmd.Parameters.Add(new OdbcParameter("FacilityIdentifier", A.FacilityIdentifier));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AdmissionDatetime", A.AdmissionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SourceofAdmission", A.SourceofAdmission));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DischargeDatetime", A.DischargeDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DischargedStatus", A.DischargedStatus));
                          Sqlcmd.Parameters.Add(new OdbcParameter("TransferStatus", A.TransferStatus));
                          Sqlcmd.Parameters.Add(new OdbcParameter("TransferFacilityIdentifier", A.TransferFacilityIdentifier));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolInitiated", A.ProtocolInitiated));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolNotInitiatedReason", A.ProtocolNotInitiatedReason));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolNotInitiatedAdditionalDetail", A.ProtocolNotInitiatedAdditionalDetail));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolInitiatedPlace", A.ProtocolInitiatedPlace));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolType", A.ProtocolType));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedFromProtocol", A.ExcludedFromProtocol));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedReason", A.ExcludedReason));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedDatetime", A.ExcludedDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedExplain", A.ExcludedExplain));
                          Sqlcmd.Parameters.Add(new OdbcParameter("EarliestDateTime", A.EarliestDateTime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("TriageDatetime", A.TriageDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SevereSepsisPresent", A.SevereSepsisPresent));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SevereSepsisPresentationDatetime", A.SevereSepsisPresentationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SepticShockPresent", A.SepticShockPresent));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SepticShockPresentDatetime", A.SepticShockPresentDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("LeftEDDatetime", A.LeftEDDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DestinationAfterED", A.DestinationAfterED));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevelCollection", A.InitialLactateLevelCollection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevelCollectionDatetime", A.InitialLactateLevelCollectionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevel", A.InitialLactateLevel));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevelUnit", A.InitialLactateLevelUnit));
                          Sqlcmd.Parameters.Add(new OdbcParameter("RepeatLactateLevelCollection", A.RepeatLactateLevelCollection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("RepeatLactateLevelCollectionDatetime", A.RepeatLactateLevelCollectionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureCollection", A.BloodCultureCollection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureCollectionAcceptableDelay", A.BloodCultureCollectionAcceptableDelay));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureCollectionDatetime", A.BloodCultureCollectionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureResult", A.BloodCultureResult));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCulturePathogen", A.BloodCulturePathogen));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AntibioticAdministration", A.AntibioticAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AntibioticAdministrationSelection", A.AntibioticAdministrationSelection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AntibioticAdministrationDatetime", A.AntibioticAdministrationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AdultCrystalloidFluidAdministration", A.AdultCrystalloidFluidAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PediatricCrystalloidFluidAdministration", A.PediatricCrystalloidFluidAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CrystalloidFluidAdministrationDatetime", A.CrystalloidFluidAdministrationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialHypotension", A.InitialHypotension));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PersistentHypotension", A.PersistentHypotension));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VasopressorAdministration", A.VasopressorAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VasopressorAdministrationDatetime", A.VasopressorAdministrationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BesideCardiovascularUltrasound", A.BesideCardiovascularUltrasound));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BesideCardiovascularUltrasoundDatetime", A.BesideCardiovascularUltrasoundDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CapillaryRefillExamination", A.CapillaryRefillExamination));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CapillaryRefillExaminationDatetime", A.CapillaryRefillExaminationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CardiopulmonaryEvaluation", A.CardiopulmonaryEvaluation));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CardiopulmonaryEvaluationDatetime", A.CardiopulmonaryEvaluationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PassiveLegRaiseExamination", A.PassiveLegRaiseExamination));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PassiveLegRaiseExaminationDatetime", A.PassiveLegRaiseExaminationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PeripheralPulseEvaluation", A.PeripheralPulseEvaluation));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PeripheralPulseEvaluationDatetime", A.PeripheralPulseEvaluationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SkinExamination", A.SkinExamination));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SkinExaminationDatetime", A.SkinExaminationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousOxygenMeasurement", A.CentralVenousOxygenMeasurement));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousOxygenMeasurementDatetime", A.CentralVenousOxygenMeasurementDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousPressureMeasurement", A.CentralVenousPressureMeasurement));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousPressureMeasurementDatetime", A.CentralVenousPressureMeasurementDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("FluidChallengePerformed", A.FluidChallengePerformed));
                          Sqlcmd.Parameters.Add(new OdbcParameter("FluidChallengePerformedDatetime", A.FluidChallengePerformedDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VitalSignsReview", A.VitalSignsReview));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VitalSignsReviewDatetime", A.VitalSignsReviewDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PlateletCount", A.PlateletCount));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Bandemia", A.Bandemia));
                          Sqlcmd.Parameters.Add(new OdbcParameter("LoweRespiratoryInfection", A.LoweRespiratoryInfection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AlteredMentalStatus", A.AlteredMentalStatus));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InfectionEtiology", A.InfectionEtiology));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SiteofInfection", A.SiteofInfection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MechanicalVentilation", A.MechanicalVentilation));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MechanicalVentilationDatetime", A.MechanicalVentilationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ICU", A.ICU));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ICUAdmissionDatetime", A.ICUAdmissionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ICUDischargeDatetime", A.ICUDischargeDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ChronicRespiratoryFailure", A.ChronicRespiratoryFailure));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AIDS", A.AIDS));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MetastaticCancer", A.MetastaticCancer));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Lymphoma", A.Lymphoma));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ImmuneModifyingMedications", A.ImmuneModifyingMedications));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CongestiveHeartFailure", A.CongestiveHeartFailure));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ChronicRenalFailure", A.ChronicRenalFailure));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ChronicLiverDisease", A.ChronicLiverDisease));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Diabetes", A.Diabetes));
                          Sqlcmd.Parameters.Add(new OdbcParameter("OrganTransplant", A.OrganTransplant));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Version", A.Version));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Year", A.Year));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Quarter", A.Quarter));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DateCreated", A.DateCreated));
                          Sqlcmd.Parameters.Add(new OdbcParameter("RecordCompleted", A.RecordCompleted));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CSVGenerated", A.CSVGenerated));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CSVGeneratedDatetime", A.CSVGeneratedDatetime));


                          //Sqlcmd.Parameters.Add(new SqlParameter("UniquePersonalIdentifier", A.UniquePersonalIdentifier));
                          //Sqlcmd.Parameters.Add(new SqlParameter("PatientControlNumber ", A.PatientControlNumber));
                          //Sqlcmd.Parameters.Add(new SqlParameter("DateofBirth", A.DateofBirth));
                          //Sqlcmd.Parameters.Add(new SqlParameter("Gender", A.Gender));
                          //Sqlcmd.Parameters.Add(new SqlParameter("Race", A.Race));
                          //Sqlcmd.Parameters.Add(new SqlParameter("Ethnicity", A.Ethnicity));
                          //Sqlcmd.Parameters.Add(new SqlParameter("Payor", A.Payor));
                          //Sqlcmd.Parameters.Add(new SqlParameter("InsuranceNumber", A.InsuranceNumber));
                          //Sqlcmd.Parameters.Add(new SqlParameter("MedicalRecordNumber", A.MedicalRecordNumber));
                          //Sqlcmd.Parameters.Add(new SqlParameter("FacilityIdentifier", A.FacilityIdentifier));
                          //Sqlcmd.Parameters.Add(new SqlParameter("AdmissionDatetime", A.AdmissionDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("SourceofAdmission", A.SourceofAdmission));
                          //Sqlcmd.Parameters.Add(new SqlParameter("DischargeDatetime", A.DischargeDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("DischargedStatus", A.DischargedStatus));
                          //Sqlcmd.Parameters.Add(new SqlParameter("TransferStatus", A.TransferStatus));
                          //Sqlcmd.Parameters.Add(new SqlParameter("TransferFacilityIdentifier", A.TransferFacilityIdentifier));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ProtocolInitiated", A.ProtocolInitiated));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ProtocolNotInitiatedReason", A.ProtocolNotInitiatedReason));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ProtocolNotInitiatedAdditionalDetail", A.ProtocolNotInitiatedAdditionalDetail));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ProtocolInitiatedPlace", A.ProtocolInitiatedPlace));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ProtocolType", A.ProtocolType));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ExcludedFromProtocol", A.ExcludedFromProtocol));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ExcludedReason", A.ExcludedReason));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ExcludedDatetime", A.ExcludedDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ExcludedExplain", A.ExcludedExplain));
                          //Sqlcmd.Parameters.Add(new SqlParameter("EarliestDateTime", A.EarliestDateTime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("TriageDatetime", A.TriageDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("SevereSepsisPresent", A.SevereSepsisPresent));
                          //Sqlcmd.Parameters.Add(new SqlParameter("SevereSepsisPresentationDatetime", A.SevereSepsisPresentationDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("SepticShockPresent", A.SepticShockPresent));
                          //Sqlcmd.Parameters.Add(new SqlParameter("SepticShockPresentDatetime", A.SepticShockPresentDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("LeftEDDatetime", A.LeftEDDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("DestinationAfterED", A.DestinationAfterED));
                          //Sqlcmd.Parameters.Add(new SqlParameter("InitialLactateLevelCollection", A.InitialLactateLevelCollection));
                          //Sqlcmd.Parameters.Add(new SqlParameter("InitialLactateLevelCollectionDatetime", A.InitialLactateLevelCollectionDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("InitialLactateLevel", A.InitialLactateLevel));
                          //Sqlcmd.Parameters.Add(new SqlParameter("InitialLactateLevelUnit", A.InitialLactateLevelUnit));
                          //Sqlcmd.Parameters.Add(new SqlParameter("RepeatLactateLevelCollection", A.RepeatLactateLevelCollection));
                          //Sqlcmd.Parameters.Add(new SqlParameter("RepeatLactateLevelCollectionDatetime", A.RepeatLactateLevelCollectionDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("BloodCultureCollection", A.BloodCultureCollection));
                          //Sqlcmd.Parameters.Add(new SqlParameter("BloodCultureCollectionAcceptableDelay", A.BloodCultureCollectionAcceptableDelay));
                          //Sqlcmd.Parameters.Add(new SqlParameter("BloodCultureCollectionDatetime", A.BloodCultureCollectionDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("BloodCultureResult", A.BloodCultureResult));
                          //Sqlcmd.Parameters.Add(new SqlParameter("BloodCulturePathogen", A.BloodCulturePathogen));
                          //Sqlcmd.Parameters.Add(new SqlParameter("AntibioticAdministration", A.AntibioticAdministration));
                          //Sqlcmd.Parameters.Add(new SqlParameter("AntibioticAdministrationSelection", A.AntibioticAdministrationSelection));
                          //Sqlcmd.Parameters.Add(new SqlParameter("AntibioticAdministrationDatetime", A.AntibioticAdministrationDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("AdultCrystalloidFluidAdministration", A.AdultCrystalloidFluidAdministration));
                          //Sqlcmd.Parameters.Add(new SqlParameter("PediatricCrystalloidFluidAdministration", A.PediatricCrystalloidFluidAdministration));
                          //Sqlcmd.Parameters.Add(new SqlParameter("CrystalloidFluidAdministrationDatetime", A.CrystalloidFluidAdministrationDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("InitialHypotension", A.InitialHypotension));
                          //Sqlcmd.Parameters.Add(new SqlParameter("PersistentHypotension", A.PersistentHypotension));
                          //Sqlcmd.Parameters.Add(new SqlParameter("VasopressorAdministration", A.VasopressorAdministration));
                          //Sqlcmd.Parameters.Add(new SqlParameter("VasopressorAdministrationDatetime", A.VasopressorAdministrationDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("BesideCardiovascularUltrasound", A.BesideCardiovascularUltrasound));
                          //Sqlcmd.Parameters.Add(new SqlParameter("BesideCardiovascularUltrasoundDatetime", A.BesideCardiovascularUltrasoundDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("CapillaryRefillExamination", A.CapillaryRefillExamination));
                          //Sqlcmd.Parameters.Add(new SqlParameter("CapillaryRefillExaminationDatetime", A.CapillaryRefillExaminationDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("CardiopulmonaryEvaluation", A.CardiopulmonaryEvaluation));
                          //Sqlcmd.Parameters.Add(new SqlParameter("CardiopulmonaryEvaluationDatetime", A.CardiopulmonaryEvaluationDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("PassiveLegRaiseExamination", A.PassiveLegRaiseExamination));
                          //Sqlcmd.Parameters.Add(new SqlParameter("PassiveLegRaiseExaminationDatetime", A.PassiveLegRaiseExaminationDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("PeripheralPulseEvaluation", A.PeripheralPulseEvaluation));
                          //Sqlcmd.Parameters.Add(new SqlParameter("PeripheralPulseEvaluationDatetime", A.PeripheralPulseEvaluationDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("SkinExamination", A.SkinExamination));
                          //Sqlcmd.Parameters.Add(new SqlParameter("SkinExaminationDatetime", A.SkinExaminationDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("CentralVenousOxygenMeasurement", A.CentralVenousOxygenMeasurement));
                          //Sqlcmd.Parameters.Add(new SqlParameter("CentralVenousOxygenMeasurementDatetime", A.CentralVenousOxygenMeasurementDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("CentralVenousPressureMeasurement", A.CentralVenousPressureMeasurement));
                          //Sqlcmd.Parameters.Add(new SqlParameter("CentralVenousPressureMeasurementDatetime", A.CentralVenousPressureMeasurementDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("FluidChallengePerformed", A.FluidChallengePerformed));
                          //Sqlcmd.Parameters.Add(new SqlParameter("FluidChallengePerformedDatetime", A.FluidChallengePerformedDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("VitalSignsReview", A.VitalSignsReview));
                          //Sqlcmd.Parameters.Add(new SqlParameter("VitalSignsReviewDatetime", A.VitalSignsReviewDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("PlateletCount", A.PlateletCount));
                          //Sqlcmd.Parameters.Add(new SqlParameter("Bandemia", A.Bandemia));
                          //Sqlcmd.Parameters.Add(new SqlParameter("LoweRespiratoryInfection", A.LoweRespiratoryInfection));
                          //Sqlcmd.Parameters.Add(new SqlParameter("AlteredMentalStatus", A.AlteredMentalStatus));
                          //Sqlcmd.Parameters.Add(new SqlParameter("InfectionEtiology", A.InfectionEtiology));
                          //Sqlcmd.Parameters.Add(new SqlParameter("SiteofInfection", A.SiteofInfection));
                          //Sqlcmd.Parameters.Add(new SqlParameter("MechanicalVentilation", A.MechanicalVentilation));
                          //Sqlcmd.Parameters.Add(new SqlParameter("MechanicalVentilationDatetime", A.MechanicalVentilationDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ICU", A.ICU));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ICUAdmissionDatetime", A.ICUAdmissionDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ICUDischargeDatetime", A.ICUDischargeDatetime));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ChronicRespiratoryFailure", A.ChronicRespiratoryFailure));
                          //Sqlcmd.Parameters.Add(new SqlParameter("AIDS", A.AIDS));
                          //Sqlcmd.Parameters.Add(new SqlParameter("MetastaticCancer", A.MetastaticCancer));
                          //Sqlcmd.Parameters.Add(new SqlParameter("Lymphoma", A.Lymphoma));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ImmuneModifyingMedications", A.ImmuneModifyingMedications));
                          //Sqlcmd.Parameters.Add(new SqlParameter("CongestiveHeartFailure", A.CongestiveHeartFailure));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ChronicRenalFailure", A.ChronicRenalFailure));
                          //Sqlcmd.Parameters.Add(new SqlParameter("ChronicLiverDisease", A.ChronicLiverDisease));
                          //Sqlcmd.Parameters.Add(new SqlParameter("Diabetes", A.Diabetes));
                          //Sqlcmd.Parameters.Add(new SqlParameter("OrganTransplant", A.OrganTransplant));
                          //Sqlcmd.Parameters.Add(new SqlParameter("Version", A.Version));
                          //Sqlcmd.Parameters.Add(new SqlParameter("Year", A.Year));
                          //Sqlcmd.Parameters.Add(new SqlParameter("Quarter", A.Quarter));
                          //Sqlcmd.Parameters.Add(new SqlParameter("DateCreated", A.DateCreated));
                          //Sqlcmd.Parameters.Add(new SqlParameter("RecordCompleted", A.RecordCompleted));
                          //Sqlcmd.Parameters.Add(new SqlParameter("CSVGenerated", A.CSVGenerated));
                          //Sqlcmd.Parameters.Add(new SqlParameter("CSVGeneratedDatetime", A.CSVGeneratedDatetime));

                          Sqlcmd.ExecuteNonQuery();

                      }

                      Conn.Close();

                      //if (A.RecordCompleted == false)
                          if (A.RecordCompleted == 0)
                      {
                         
                          MessageBox.Show("Record saved successfully and marked as incomplete because all Mandatory fields are not completed", "Sepsis Data Entry");
                       
                      }
                      else
                      {
                         
                          MessageBox.Show("Record saved successfully and marked as complete.", "Sepsis Data Entry");
                      }

                      sm.LoadGrid();
                      this.Close();
                      sm.Show();


                  }
              }
              else
              {


               
                  //A.CSVGenerated = false;
                  //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                  using (Conn = new OdbcConnection(ConnectionString))
                  {
                      Conn.Open();

                      //query = "select UniqueId, unique_personal_identifier, patient_control_number, date_of_birth, medical_record_number,Date_Created, Record_Completed, CSVGenerated from sepsis_collab ";
                      //query = query + "where Version = " + comboBox_Version.Text.ToString().Trim();
                      //query = "Sepsis_Update";
                      query = "{call Sepsis_Update(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

                      //using (SqlCommand Sqlcmd = new SqlCommand())
                      using (OdbcCommand Sqlcmd = new OdbcCommand())
                      {

                          Sqlcmd.CommandText = query;
                          Sqlcmd.CommandType = CommandType.StoredProcedure;
                          Sqlcmd.Connection = Conn;

                          Sqlcmd.Parameters.Add(new OdbcParameter("id", A.UniqueId));
                          Sqlcmd.Parameters.Add(new OdbcParameter("UniquePersonalIdentifier", A.UniquePersonalIdentifier));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PatientControlNumber ", A.PatientControlNumber));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DateofBirth", A.DateofBirth));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Gender", A.Gender));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Race", A.Race));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Ethnicity", A.Ethnicity));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Payor", A.Payor));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InsuranceNumber", A.InsuranceNumber));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MedicalRecordNumber", A.MedicalRecordNumber));
                          Sqlcmd.Parameters.Add(new OdbcParameter("FacilityIdentifier", A.FacilityIdentifier));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AdmissionDatetime", A.AdmissionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SourceofAdmission", A.SourceofAdmission));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DischargeDatetime", A.DischargeDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DischargedStatus", A.DischargedStatus));
                          Sqlcmd.Parameters.Add(new OdbcParameter("TransferStatus", A.TransferStatus));
                          Sqlcmd.Parameters.Add(new OdbcParameter("TransferFacilityIdentifier", A.TransferFacilityIdentifier));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolInitiated", A.ProtocolInitiated));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolNotInitiatedReason", A.ProtocolNotInitiatedReason));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolNotInitiatedAdditionalDetail", A.ProtocolNotInitiatedAdditionalDetail));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolInitiatedPlace", A.ProtocolInitiatedPlace));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolType", A.ProtocolType));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedFromProtocol", A.ExcludedFromProtocol));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedReason", A.ExcludedReason));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedDatetime", A.ExcludedDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedExplain", A.ExcludedExplain));
                          Sqlcmd.Parameters.Add(new OdbcParameter("EarliestDateTime", A.EarliestDateTime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("TriageDatetime", A.TriageDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SevereSepsisPresent", A.SevereSepsisPresent));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SevereSepsisPresentationDatetime", A.SevereSepsisPresentationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SepticShockPresent", A.SepticShockPresent));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SepticShockPresentDatetime", A.SepticShockPresentDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("LeftEDDatetime", A.LeftEDDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DestinationAfterED", A.DestinationAfterED));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevelCollection", A.InitialLactateLevelCollection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevelCollectionDatetime", A.InitialLactateLevelCollectionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevel", A.InitialLactateLevel));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevelUnit", A.InitialLactateLevelUnit));
                          Sqlcmd.Parameters.Add(new OdbcParameter("RepeatLactateLevelCollection", A.RepeatLactateLevelCollection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("RepeatLactateLevelCollectionDatetime", A.RepeatLactateLevelCollectionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureCollection", A.BloodCultureCollection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureCollectionAcceptableDelay", A.BloodCultureCollectionAcceptableDelay));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureCollectionDatetime", A.BloodCultureCollectionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureResult", A.BloodCultureResult));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCulturePathogen", A.BloodCulturePathogen));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AntibioticAdministration", A.AntibioticAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AntibioticAdministrationSelection", A.AntibioticAdministrationSelection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AntibioticAdministrationDatetime", A.AntibioticAdministrationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AdultCrystalloidFluidAdministration", A.AdultCrystalloidFluidAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PediatricCrystalloidFluidAdministration", A.PediatricCrystalloidFluidAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CrystalloidFluidAdministrationDatetime", A.CrystalloidFluidAdministrationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialHypotension", A.InitialHypotension));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PersistentHypotension", A.PersistentHypotension));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VasopressorAdministration", A.VasopressorAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VasopressorAdministrationDatetime", A.VasopressorAdministrationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BesideCardiovascularUltrasound", A.BesideCardiovascularUltrasound));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BesideCardiovascularUltrasoundDatetime", A.BesideCardiovascularUltrasoundDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CapillaryRefillExamination", A.CapillaryRefillExamination));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CapillaryRefillExaminationDatetime", A.CapillaryRefillExaminationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CardiopulmonaryEvaluation", A.CardiopulmonaryEvaluation));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CardiopulmonaryEvaluationDatetime", A.CardiopulmonaryEvaluationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PassiveLegRaiseExamination", A.PassiveLegRaiseExamination));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PassiveLegRaiseExaminationDatetime", A.PassiveLegRaiseExaminationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PeripheralPulseEvaluation", A.PeripheralPulseEvaluation));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PeripheralPulseEvaluationDatetime", A.PeripheralPulseEvaluationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SkinExamination", A.SkinExamination));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SkinExaminationDatetime", A.SkinExaminationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousOxygenMeasurement", A.CentralVenousOxygenMeasurement));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousOxygenMeasurementDatetime", A.CentralVenousOxygenMeasurementDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousPressureMeasurement", A.CentralVenousPressureMeasurement));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousPressureMeasurementDatetime", A.CentralVenousPressureMeasurementDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("FluidChallengePerformed", A.FluidChallengePerformed));
                          Sqlcmd.Parameters.Add(new OdbcParameter("FluidChallengePerformedDatetime", A.FluidChallengePerformedDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VitalSignsReview", A.VitalSignsReview));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VitalSignsReviewDatetime", A.VitalSignsReviewDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PlateletCount", A.PlateletCount));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Bandemia", A.Bandemia));
                          Sqlcmd.Parameters.Add(new OdbcParameter("LoweRespiratoryInfection", A.LoweRespiratoryInfection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AlteredMentalStatus", A.AlteredMentalStatus));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InfectionEtiology", A.InfectionEtiology));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SiteofInfection", A.SiteofInfection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MechanicalVentilation", A.MechanicalVentilation));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MechanicalVentilationDatetime", A.MechanicalVentilationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ICU", A.ICU));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ICUAdmissionDatetime", A.ICUAdmissionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ICUDischargeDatetime", A.ICUDischargeDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ChronicRespiratoryFailure", A.ChronicRespiratoryFailure));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AIDS", A.AIDS));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MetastaticCancer", A.MetastaticCancer));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Lymphoma", A.Lymphoma));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ImmuneModifyingMedications", A.ImmuneModifyingMedications));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CongestiveHeartFailure", A.CongestiveHeartFailure));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ChronicRenalFailure", A.ChronicRenalFailure));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ChronicLiverDisease", A.ChronicLiverDisease));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Diabetes", A.Diabetes));
                          Sqlcmd.Parameters.Add(new OdbcParameter("OrganTransplant", A.OrganTransplant));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Version", A.Version));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Year", A.Year));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Quarter", A.Quarter));
                          //Sqlcmd.Parameters.Add(new OdbcParameter("DateCreated", A.DateCreated));
                          Sqlcmd.Parameters.Add(new OdbcParameter("RecordCompleted", A.RecordCompleted));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CSVGenerated", A.CSVGenerated));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CSVGeneratedDatetime", A.CSVGeneratedDatetime));

                          Sqlcmd.ExecuteNonQuery();

                          //if (A.RecordCompleted == false)
                              if (A.RecordCompleted == 0)
                          {

                              MessageBox.Show("Record updated successfully and marked as incomplete because all Mandatory fields are not completed.", "Sepsis Data Entry");

                          }
                          else
                          {

                              MessageBox.Show("Record updated successfully and marked as complete.", "Sepsis Data Entry");
                          }

                         // SepsisMaster sm = new SepsisMaster();
                              Conn.Close();
                          sm.LoadGrid();
                          this.Close();
                          sm.Show();


                      }
                  }
              }

          

                  }
            catch (Exception ex)
            {
                int line = 0;

                StackTrace st = new StackTrace(true);
                for (int i = 0; i < st.FrameCount; i++)
                {
                    // Note that high up the call stack, there is only
                    // one stack frame.
                    StackFrame sf = st.GetFrame(i);
                    //Console.WriteLine();
                   // Console.WriteLine("High up the call stack, Method: {0}",
                      var frame =  sf.GetMethod();

                   // Console.WriteLine("High up the call stack, Line Number: {0}",
                      line =  sf.GetFileLineNumber();

                      if (line > 0)
                          break;

                }


                //var st = new StackTrace(ex, true);
                //// Get the top stack frame
                //var frame = st.GetFrame(0);
                //// Get the line number from the stack frame
                //var line = frame.GetFileLineNumber();

                using (Conn = new OdbcConnection(ConnectionString))
                {
                    Conn.Open();

                    query = "{call Sepsis_ErrorLog(?,?,?,?)}";

                    //using (SqlCommand Sqlcmd = new SqlCommand())
                    using (OdbcCommand Sqlcmd = new OdbcCommand())
                    {

                        Sqlcmd.CommandText = query;
                        Sqlcmd.CommandType = CommandType.StoredProcedure;
                        Sqlcmd.Connection = Conn;

                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Line",line));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Desc", ex.Message));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Form", "SepsisCaseDetails.cs"));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Datetime", DateTime.Now));
                 

                        Sqlcmd.ExecuteNonQuery();

        

                      
                        Conn.Close();
                  


                    }
                }



               //MessageBox.Show(ex.Message);
            }
          }


        
          public bool validateDatetime(string inputString)
          
            {
              
              
              DateTime dDate;
          

              if (inputString == "/  /       :")
              {
                  return true;
              }
              if (DateTime.TryParseExact(inputString, format1, CultureInfo.InvariantCulture,
        System.Globalization.DateTimeStyles.None, out dDate))
              //if (DateTime.TryParse(inputString, out dDate))
              {


                  //int result = DateTime.Compare(dDate, dDateStart);

                  //if (result < 0)
                  //    return false;
                  //else
                      return true;

                 // String.Format("{MM/dd/yyyy HH:mm}", dDate);
                  
              }
              else
              {
                  return false;
              }

             
          }



          public bool validateDate(string inputString)
          {


              DateTime dDate;


              if (inputString == "/  /")
              {
                  return true;
              }
              if (DateTime.TryParseExact(inputString, format2, CultureInfo.InvariantCulture,
        System.Globalization.DateTimeStyles.None, out dDate))
          
              {
                  return true;

              }
              else
              {
                  return false;
              }


          }


          public bool validateDatetimeLimit(string inputString1 ,string inputString2)
            {

              DateTime dDate1;
              DateTime dDate2;
             // inputString = inputString.Substring(0, 10);

              if (inputString1 == "/  /       :")
              {
                  return true;
              }

              if (inputString2 == "/  /       :")
              {
                  return true;
              }
              if (DateTime.TryParse(inputString1, out dDate1))
              {
                  if (DateTime.TryParse(inputString2, out dDate2))
                  {


                      int result1 = DateTime.Compare(dDate1, dDate2);
                     //int result2 = DateTime.Compare(dDate, dDateEnd);

                      if (result1 < 0)
                          return false;
                      else
                          return true;
                  }
                  return true;
                  // String.Format("{MM/dd/yyyy HH:mm}", dDate);

              }
              else
              {
                  return false;
              }


          }

          public bool LactateCharcheckCheck(string inputString)
          {

              if (!inputString.All(Lactateallowedchar.Contains))
              {
                  return true;
                  // Not allowed char detected
              }
              else
              {
                  return false;
              }


           
          }




          public Color MandatoryColor(Color c)
          {
              Color light = ControlPaint.Light(c);

              light = ControlPaint.Light(light);
              light = ControlPaint.Light(light);
              //light = ControlPaint.Light(light);
              //light = ControlPaint.Light(light);

              return light;
          }


          public Color ErrorColor(Color c)
          {
              Color light = ControlPaint.Light(c);

             // light = ControlPaint.Light(light);
             // light = ControlPaint.Light(light);
              //light = ControlPaint.Light(light);
             // light = ControlPaint.Light(light);

              return light;
          }



          private void SepsisCaseDetails_Load(object sender, EventArgs e)
          {

           

              this.tabControl.SelectedIndex = 0;
             
         
              //Color lightGray = ControlPaint.Light(Color.Gray);
              //Color lightRed = ControlPaint.Light(Color.Red);


             // textBox_InitialLactateLevel.ValidatingType = typeof(float);
             // textBox_InitialLactateLevel.TypeValidationCompleted += new TypeValidationEventHandler(textBox_InitialLactateLevel_TypeValidationCompleted);
              //textBox_InitialLactateLevel.KeyDown += new KeyEventHandler(textBox_InitialLactateLevel_KeyDown);


              //lightRed = ControlPaint.Light(lightRed);
              //lightRed = ControlPaint.Light(lightRed);
              //lightRed = ControlPaint.Light(lightRed);
              //lightRed = ControlPaint.Light(lightRed);


              //lightGray = ControlPaint.Light(lightGray);
              //lightGray = ControlPaint.Light(lightGray);
              //lightGray = ControlPaint.Light(lightGray);
              //lightGray = ControlPaint.Light(lightGray);
             // txtId.BackColor = MandatoryColor(Color.Gray);




                //TextBox_PatientCtrlNum.BackColor = MandatoryColor(Color.Gray);
                //txtDOB.BackColor = MandatoryColor(Color.Gray);
                //Combobox_Gender.BackColor = MandatoryColor(Color.Gray);
                //checkedListBox_Race.BackColor = MandatoryColor(Color.Gray);
                //Combobox_Ethnicity.BackColor = MandatoryColor(Color.Gray);
                //comboBox_Payor.BackColor = MandatoryColor(Color.Gray);
                //TextBox_InsuranceNumber.BackColor = MandatoryColor(Color.Gray);
                //txtMRN.BackColor = MandatoryColor(Color.Gray);
                //TextBox_FacilityIdentifier.BackColor = MandatoryColor(Color.Gray);
                //textBox_AdmissionDateTime.BackColor = MandatoryColor(Color.Gray);
                //textBox_DischargedDatetime.BackColor = MandatoryColor(Color.Gray);
                //comboBox_SourceofAdmission.BackColor = MandatoryColor(Color.Gray);
                //comboBox_DischargeStatus.BackColor = MandatoryColor(Color.Gray);
                //comboBox_TransferStatus.BackColor = MandatoryColor(Color.Gray);
                //comboBox_ProtocolInitiated.BackColor = MandatoryColor(Color.Gray);
                //comboBox_ProtocolInitiatedPlace.BackColor = MandatoryColor(Color.Gray);
                //comboBox_ProtocolType.BackColor = MandatoryColor(Color.Gray);
                //comboBox_ExcludedFromProtocol.BackColor = MandatoryColor(Color.Gray);
                //textBox_EarliestDatetime.BackColor = MandatoryColor(Color.Gray);
                //comboBox_SevereSepsisPresent.BackColor = MandatoryColor(Color.Gray);
                //textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
                //comboBox_SepticShockPresent.BackColor = MandatoryColor(Color.Gray);
                //comboBox_PlateletCount.BackColor = MandatoryColor(Color.Gray);
                //comboBox_AlteredMentalStatus.BackColor = MandatoryColor(Color.Gray);
                //comboBox_InfectionEtiology.BackColor = MandatoryColor(Color.Gray);
                //comboBox_LowerRespiratoryInfection.BackColor = MandatoryColor(Color.Gray);
                //comboBox_Bandemia.BackColor = MandatoryColor(Color.Gray);
                //comboBox_SiteofInfection.BackColor = MandatoryColor(Color.Gray);
                //comboBox_MechanicalVentilation.BackColor = MandatoryColor(Color.Gray);
                //comboBox_ICU.BackColor = MandatoryColor(Color.Gray);
                //comboBox_ChronicRespiratoryFailure.BackColor = MandatoryColor(Color.Gray);
                //comboBox_AIDSDisease.BackColor = MandatoryColor(Color.Gray);
                //comboBox_MetastaticCancer.BackColor = MandatoryColor(Color.Gray);
                //comboBox_Lymphoma.BackColor = MandatoryColor(Color.Gray);
                //comboBox_ImmuneModifyingMedications.BackColor = MandatoryColor(Color.Gray);
                //comboBox_CongestiveHeartFailure.BackColor = MandatoryColor(Color.Gray);
                //comboBox_ChronicRenalFailure.BackColor = MandatoryColor(Color.Gray);
                //comboBox_ChronicLiverDisease.BackColor = MandatoryColor(Color.Gray);
                //comboBox_Diabetes.BackColor = MandatoryColor(Color.Gray);
                //comboBox_OrganTransplant.BackColor = MandatoryColor(Color.Gray);
              textBox_ProtocolNIAdditionalDetail.BackColor = MandatoryColor(Color.Gray);
              checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.Gray);
              textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.Gray);
              checkedListBox_ExcludedExplain.BackColor = MandatoryColor(Color.Gray);
              textbox_TriageDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_septicShockPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_LeftEDDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_DestinationafterED.BackColor = MandatoryColor(Color.Gray);
              comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
              textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
              comboBox_InitialLactateLevelUnit.BackColor = MandatoryColor(Color.Gray);
              comboBox_RepeatLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
              comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
              comboBox_BloodCultureCollectionAcceptableDelay.BackColor = MandatoryColor(Color.Gray);
              textBox_BloodCultureCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBoX_BloodCultureResult.BackColor = MandatoryColor(Color.Gray);
              comboBox_BloodCulturePathogen.BackColor = MandatoryColor(Color.Gray);
              comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);
              comboBox_AntibioticAdministrationSelection.BackColor = MandatoryColor(Color.Gray);
              textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
              textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray);
              comboBox_PersistentHypotension.BackColor = MandatoryColor(Color.Gray);
              comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
              comboBox_BedsideCardiovascularUltrasound.BackColor = MandatoryColor(Color.Gray);
              textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_VasopressorAdministration.BackColor = MandatoryColor(Color.Gray);
              textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_CardiopulmonaryEvaluation.BackColor = MandatoryColor(Color.Gray);
              textBox_CardiopulmonaryEvaluationDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_CapillaryRefillExamination.BackColor = MandatoryColor(Color.Gray);
              textBox_CapillaryRefillExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_PassiveLegRaiseExamination.BackColor = MandatoryColor(Color.Gray);
              textBox_PassiveLegRaiseExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_PeripheralPulseEvaluation.BackColor = MandatoryColor(Color.Gray);
              textBox_PeripheralPulseEvaluationDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_SkinExamination.BackColor = MandatoryColor(Color.Gray);
              textBox_SkinExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_CentralVenousOxygenMeasurement.BackColor = MandatoryColor(Color.Gray);
              textBox_CentralVenousOxygenMeasurementDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_CentralVenousPressureMeasurement.BackColor = MandatoryColor(Color.Gray);
              textBox_CentralVenousPressureMeasurementDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_FluidChallengePerformed.BackColor = MandatoryColor(Color.Gray);
              textBox_FluidChallengePerformedDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_VitalSignsReview.BackColor = MandatoryColor(Color.Gray);
              textBox_VitalSignsReviewDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_ICUAdmissionDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_ICUDischargeDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_ProtocolNotInitiatedReason.BackColor = MandatoryColor(Color.Gray);
              textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.Gray);

          






              //ConnectionString = @"Server=HANYS-APPS-DB-D\DEVNETFORUMDB;Database=Sepsis;User Id=sa;Password=password;";
             // ConnectionString = @"Server=JITU-PC\JITU;Database=Sepsis;User Id=sa;Password=jitu123;";

              txtId.Focus();



          }

        public void LoadCombobox()
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Codes and Values:");
                 sb.AppendLine("1 = Non-Health Facility Point of Origin-The patient was admitted to this facility from home or from an assisted living facility.");
                 sb.AppendLine("2 = Clinic-The patient was referred to this facility as a transfer from a freestanding or non-freestanding clinic.");
                 sb.AppendLine("4 = Transfer from a Hospital (Different Facility)-The patient was admitted to this facility as a hospital transfer from an acute care facility where he or she was an inpatient or outpatient.");
                 sb.AppendLine("5 = Transfer From a Skilled Nursing Facility (SNF) or Intermediate Care Facility (ICF)-The patient was admitted to this facility as a transfer from a SNF or ICF where he or she was a resident.");
                 sb.AppendLine("6 = Transfer From Another Health Care Facility-The patient was admitted to this facility as a transfer from another type of health care facility not defined elsewhere in this code list.");
                 sb.AppendLine("8 = Court/Law Enforcement- The patient was admitted to this facility upon the direction of a court of law, or upon the request of a law enforcement agency representative.");
                 sb.AppendLine("9 = Information Not Available-The means by which the patient was admitted to this hospital was not known.");
                 sb.AppendLine("A = Transfer from a Rural Primary Care Hospital. The patient was admitted to this facility as a transfer from a Rural Primary Care Hospital (RPCH) where he or she was an inpatient.");
                 sb.AppendLine("D = Transfer from One Distinct Unit of the Hospital to another Distinct Unit of the Same Hospital Resulting in a Separate Claim to the Payer. Inpatient: The patient was admitted to this facility as a transfer from hospital inpatient within this facility resulting in a separate claim to the payer.");
                 sb.AppendLine("E = Transfer from Ambulatory Surgery Center-The patient was admitted to this facility as a transfer from an ambulatory surgery center.");
                 sb.AppendLine("F = Transfer from Hospice and is Under a Hospice Plan of Care or Enrolled in a Hospice Program- The patient was admitted to this facility as a transfer from a hospice.");




 
 
 
 

 



                ToolTip tp = new ToolTip();
                tp.SetToolTip(button_SourceofAdmission, sb.ToString());


               ds = new DataSet();
              //query = "Sepsis_SelectCombo";
               query = "{call Sepsis_SelectCombo}";

              //using (SqlConnection Conn = new SqlConnection(ConnectionString))
              using (Conn = new OdbcConnection(ConnectionString))
              {
                  Conn.Open();


                  //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter(query, Conn))
                  using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter(query, Conn))
                  {

                      dbDataAdapter.Fill(ds);
                 

                  }


                  Conn.Close();
              }

              ds.Tables[0].TableName = "Gender";
              ds.Tables[1].TableName = "Payor";
              ds.Tables[2].TableName = "Race";
              ds.Tables[3].TableName = "Ethnicity";
              ds.Tables[4].TableName = "SourceOfAdmission";
              ds.Tables[5].TableName = "DischargedStatus";
              ds.Tables[6].TableName = "Transfer";
              ds.Tables[7].TableName = "ProtocolInitiated";
              ds.Tables[8].TableName = "ProtocolNotInitiatedReason";
              ds.Tables[9].TableName = "ProtocolInitiatedPlace";
              ds.Tables[10].TableName = "ProtocolType";
              ds.Tables[11].TableName = "ExcludedFromProtocol";
              ds.Tables[12].TableName = "ExcludedReason";
              ds.Tables[13].TableName = "ExcludedExplain";
              ds.Tables[14].TableName = "SevereSepsisPresent";
              ds.Tables[15].TableName = "SepticShockPresent";
              ds.Tables[16].TableName = "DestinationafterED";
              ds.Tables[17].TableName = "InitialLactateLevelCollection";
              ds.Tables[18].TableName = "InitialLactateLevelUnit";
              ds.Tables[19].TableName = "RepeatLactateLevelCollection";
              ds.Tables[20].TableName = "BloodCultureCollection";
              ds.Tables[21].TableName = "BloodCultureCollectionAcceptableDelay";
              ds.Tables[22].TableName = "BloodCultureResult";
              ds.Tables[23].TableName = "BloodCulturePathogen";
              ds.Tables[24].TableName = "AntibioticAdministration";
              ds.Tables[25].TableName = "AntibioticAdministrationSelection";
              ds.Tables[26].TableName = "AdultCrystalloidFluidAdministration";
              ds.Tables[27].TableName = "PediatricCrystalloidFluidAdministration";
              ds.Tables[28].TableName = "InitialHypotension";
              ds.Tables[29].TableName = "PersistentHypotension";
              ds.Tables[30].TableName = "VasopressorAdministration";
              ds.Tables[31].TableName = "BedsideCardiovascularUltrasound";
              ds.Tables[32].TableName = "CapillaryRefillExamination";
              ds.Tables[33].TableName = "CardiopulmonaryEvaluation";
              ds.Tables[34].TableName = "PassiveLegRaiseExamination";
              ds.Tables[35].TableName = "PeripheralPulseEvaluation";
              ds.Tables[36].TableName = "SkinExamination";
              ds.Tables[37].TableName = "CentralVenousOxygenMeasurement";
              ds.Tables[38].TableName = "CentralVenousPressureMeasurement";
              ds.Tables[39].TableName = "FluidChallengePerformed";
              ds.Tables[40].TableName = "VitalSignsReview";
              ds.Tables[41].TableName = "PlateletCount";
              ds.Tables[42].TableName = "LowerRespiratoryInfection";
              ds.Tables[43].TableName = "AlteredMentalStatus";
              ds.Tables[44].TableName = "InfectionEtiology";
              ds.Tables[45].TableName = "SiteofInfection";
              ds.Tables[46].TableName = "MechanicalVentilation";
              ds.Tables[47].TableName = "ICU";
              ds.Tables[48].TableName = "ChronicRespiratoryFailure";
              ds.Tables[49].TableName = "AIDSDisease";
              ds.Tables[50].TableName = "MetastaticCancer";
              ds.Tables[51].TableName = "MultipleMyeloma";
              ds.Tables[52].TableName = "ImmuneModifyingMedications";
              ds.Tables[53].TableName = "CongestiveHeartFailure";
              ds.Tables[54].TableName = "ChronicRenalFailure";
              ds.Tables[55].TableName = "ChronicLiverDisease";
              ds.Tables[56].TableName = "Diabetes";
              ds.Tables[57].TableName = "OrganTransplant";
              ds.Tables[58].TableName = "Bandemia";


              Combobox_Gender.DataSource = ds.Tables["Gender"];
              Combobox_Gender.ValueMember = "ComboBox_Key";
              Combobox_Gender.DisplayMember = "ComboBox_Value";
              Combobox_Gender.SelectedIndex = 0;


              comboBox_Payor.DataSource = ds.Tables["Payor"];
              comboBox_Payor.ValueMember = "ComboBox_Key";
              comboBox_Payor.DisplayMember = "ComboBox_Value";
              comboBox_Payor.SelectedIndex = 0;


              checkedListBox_Race.DataSource = ds.Tables["Race"];
              checkedListBox_Race.ValueMember = "ComboBox_Key";
              checkedListBox_Race.DisplayMember = "ComboBox_Value";
              checkedListBox_Race.SelectedIndex = 0;


              
              Combobox_Ethnicity.DataSource = ds.Tables["Ethnicity"];
              Combobox_Ethnicity.ValueMember = "ComboBox_Key";
              Combobox_Ethnicity.DisplayMember = "ComboBox_Value";
              Combobox_Ethnicity.SelectedIndex = 0;

              comboBox_SourceofAdmission.DataSource = ds.Tables["SourceOfAdmission"];
              comboBox_SourceofAdmission.ValueMember = "ComboBox_Key";
              comboBox_SourceofAdmission.DisplayMember = "ComboBox_Value";
              comboBox_SourceofAdmission.SelectedIndex = 0;


              comboBox_DischargeStatus.DataSource = ds.Tables["DischargedStatus"];
              comboBox_DischargeStatus.ValueMember = "ComboBox_Key";
              comboBox_DischargeStatus.DisplayMember = "ComboBox_Value";
              comboBox_DischargeStatus.SelectedIndex = 0;

             
               comboBox_TransferStatus.DataSource = ds.Tables["Transfer"];
               comboBox_TransferStatus.ValueMember = "ComboBox_Key";
               comboBox_TransferStatus.DisplayMember = "ComboBox_Value";
               comboBox_TransferStatus.SelectedIndex = 0;

             
                 comboBox_ProtocolInitiated.DataSource = ds.Tables["ProtocolInitiated"];
                 comboBox_ProtocolInitiated.ValueMember = "ComboBox_Key";
                 comboBox_ProtocolInitiated.DisplayMember = "ComboBox_Value";
                 comboBox_ProtocolInitiated.SelectedIndex = 0;

              
                 comboBox_ProtocolNotInitiatedReason.DataSource = ds.Tables["ProtocolNotInitiatedReason"];
                 comboBox_ProtocolNotInitiatedReason.ValueMember = "ComboBox_Key";
                 comboBox_ProtocolNotInitiatedReason.DisplayMember = "ComboBox_Value";
                 comboBox_ProtocolNotInitiatedReason.SelectedIndex = 0;

              
                 comboBox_ProtocolInitiatedPlace.DataSource = ds.Tables["ProtocolInitiatedPlace"];
                 comboBox_ProtocolInitiatedPlace.ValueMember = "ComboBox_Key";
                 comboBox_ProtocolInitiatedPlace.DisplayMember = "ComboBox_Value";
                 comboBox_ProtocolInitiatedPlace.SelectedIndex = 0;

              
                 comboBox_ProtocolType.DataSource = ds.Tables["ProtocolType"];
                 comboBox_ProtocolType.ValueMember = "ComboBox_Key";
                 comboBox_ProtocolType.DisplayMember = "ComboBox_Value";
                 comboBox_ProtocolType.SelectedIndex = 0;


              
                 comboBox_ExcludedFromProtocol.DataSource = ds.Tables["ExcludedFromProtocol"];
                 comboBox_ExcludedFromProtocol.ValueMember = "ComboBox_Key";
                 comboBox_ExcludedFromProtocol.DisplayMember = "ComboBox_Value";
                 comboBox_ExcludedFromProtocol.SelectedIndex = 0;

              
                 checkedListBox_ExcludedReason.DataSource = ds.Tables["ExcludedReason"];
                 checkedListBox_ExcludedReason.ValueMember = "ComboBox_Key";
                 checkedListBox_ExcludedReason.DisplayMember = "ComboBox_Value";
                 checkedListBox_ExcludedReason.SelectedIndex = 0;

              
                 checkedListBox_ExcludedExplain.DataSource = ds.Tables["ExcludedExplain"];
                 checkedListBox_ExcludedExplain.ValueMember = "ComboBox_Key";
                 checkedListBox_ExcludedExplain.DisplayMember = "ComboBox_Value";
                 checkedListBox_ExcludedExplain.SelectedIndex = 0;

              
                 comboBox_SevereSepsisPresent.DataSource = ds.Tables["SevereSepsisPresent"];
                 comboBox_SevereSepsisPresent.ValueMember = "ComboBox_Key";
                 comboBox_SevereSepsisPresent.DisplayMember = "ComboBox_Value";
                 comboBox_SevereSepsisPresent.SelectedIndex = 0;

              
                 comboBox_SepticShockPresent.DataSource = ds.Tables["SepticShockPresent"];
                 comboBox_SepticShockPresent.ValueMember = "ComboBox_Key";
                 comboBox_SepticShockPresent.DisplayMember = "ComboBox_Value";
                 comboBox_SepticShockPresent.SelectedIndex = 0;

              
                 comboBox_DestinationafterED.DataSource = ds.Tables["DestinationafterED"];
                 comboBox_DestinationafterED.ValueMember = "ComboBox_Key";
                 comboBox_DestinationafterED.DisplayMember = "ComboBox_Value";
                 comboBox_DestinationafterED.SelectedIndex = 0;

              
                 comboBox_InitialLactateLevelCollection.DataSource = ds.Tables["InitialLactateLevelCollection"];
                 comboBox_InitialLactateLevelCollection.ValueMember = "ComboBox_Key";
                 comboBox_InitialLactateLevelCollection.DisplayMember = "ComboBox_Value";
                 comboBox_InitialLactateLevelCollection.SelectedIndex = 0;

              
                 comboBox_InitialLactateLevelUnit.DataSource = ds.Tables["InitialLactateLevelUnit"];
                 comboBox_InitialLactateLevelUnit.ValueMember = "ComboBox_Key";
                 comboBox_InitialLactateLevelUnit.DisplayMember = "ComboBox_Value";
                 comboBox_InitialLactateLevelUnit.SelectedIndex = 0;

              
                 comboBox_RepeatLactateLevelCollection.DataSource = ds.Tables["RepeatLactateLevelCollection"];
                 comboBox_RepeatLactateLevelCollection.ValueMember = "ComboBox_Key";
                 comboBox_RepeatLactateLevelCollection.DisplayMember = "ComboBox_Value";
                 comboBox_RepeatLactateLevelCollection.SelectedIndex = 0;

              
                 comboBox_BloodCultureCollection.DataSource = ds.Tables["BloodCultureCollection"];
                 comboBox_BloodCultureCollection.ValueMember = "ComboBox_Key";
                 comboBox_BloodCultureCollection.DisplayMember = "ComboBox_Value";
                 comboBox_BloodCultureCollection.SelectedIndex = 0;

              
                 comboBox_BloodCultureCollectionAcceptableDelay.DataSource = ds.Tables["BloodCultureCollectionAcceptableDelay"];
                 comboBox_BloodCultureCollectionAcceptableDelay.ValueMember = "ComboBox_Key";
                 comboBox_BloodCultureCollectionAcceptableDelay.DisplayMember = "ComboBox_Value";
                 comboBox_BloodCultureCollectionAcceptableDelay.SelectedIndex = 0;


                 comboBoX_BloodCultureResult.DataSource = ds.Tables["BloodCultureResult"];
                 comboBoX_BloodCultureResult.ValueMember = "ComboBox_Key";
                 comboBoX_BloodCultureResult.DisplayMember = "ComboBox_Value";
                 comboBoX_BloodCultureResult.SelectedIndex = 0;


              
                 comboBox_BloodCulturePathogen.DataSource = ds.Tables["BloodCulturePathogen"];
                 comboBox_BloodCulturePathogen.ValueMember = "ComboBox_Key";
                 comboBox_BloodCulturePathogen.DisplayMember = "ComboBox_Value";
                 comboBox_BloodCulturePathogen.SelectedIndex = 0;


              
                 comboBox_AntibioticAdministration.DataSource = ds.Tables["AntibioticAdministration"];
                 comboBox_AntibioticAdministration.ValueMember = "ComboBox_Key";
                 comboBox_AntibioticAdministration.DisplayMember = "ComboBox_Value";
                 comboBox_AntibioticAdministration.SelectedIndex = 0;

              
                 comboBox_AntibioticAdministrationSelection.DataSource = ds.Tables["AntibioticAdministrationSelection"];
                 comboBox_AntibioticAdministrationSelection.ValueMember = "ComboBox_Key";
                 comboBox_AntibioticAdministrationSelection.DisplayMember = "ComboBox_Value";
                 comboBox_AntibioticAdministrationSelection.SelectedIndex = 0;

              
                 comboBox_AdultCrystalloidFluidAdministration.DataSource = ds.Tables["AdultCrystalloidFluidAdministration"];
                 comboBox_AdultCrystalloidFluidAdministration.ValueMember = "ComboBox_Key";
                 comboBox_AdultCrystalloidFluidAdministration.DisplayMember = "ComboBox_Value";
                 comboBox_AdultCrystalloidFluidAdministration.SelectedIndex = 0;


              
                 comboBox_PediatricCrystalloidFluidAdministration.DataSource = ds.Tables["PediatricCrystalloidFluidAdministration"];
                 comboBox_PediatricCrystalloidFluidAdministration.ValueMember = "ComboBox_Key";
                 comboBox_PediatricCrystalloidFluidAdministration.DisplayMember = "ComboBox_Value";
                 comboBox_PediatricCrystalloidFluidAdministration.SelectedIndex = 0;

              
                 comboBox_InitialHypotension.DataSource = ds.Tables["InitialHypotension"];
                 comboBox_InitialHypotension.ValueMember = "ComboBox_Key";
                 comboBox_InitialHypotension.DisplayMember = "ComboBox_Value";
                 comboBox_InitialHypotension.SelectedIndex = 0;

              
                 comboBox_PersistentHypotension.DataSource = ds.Tables["PersistentHypotension"];
                 comboBox_PersistentHypotension.ValueMember = "ComboBox_Key";
                 comboBox_PersistentHypotension.DisplayMember = "ComboBox_Value";
                 comboBox_PersistentHypotension.SelectedIndex = 0;

              
                 comboBox_VasopressorAdministration.DataSource = ds.Tables["VasopressorAdministration"];
                 comboBox_VasopressorAdministration.ValueMember = "ComboBox_Key";
                 comboBox_VasopressorAdministration.DisplayMember = "ComboBox_Value";
                 comboBox_VasopressorAdministration.SelectedIndex = 0;

              
                 comboBox_BedsideCardiovascularUltrasound.DataSource = ds.Tables["BedsideCardiovascularUltrasound"];
                 comboBox_BedsideCardiovascularUltrasound.ValueMember = "ComboBox_Key";
                 comboBox_BedsideCardiovascularUltrasound.DisplayMember = "ComboBox_Value";
                 comboBox_BedsideCardiovascularUltrasound.SelectedIndex = 0;

              
                 comboBox_CapillaryRefillExamination.DataSource = ds.Tables["CapillaryRefillExamination"];
                 comboBox_CapillaryRefillExamination.ValueMember = "ComboBox_Key";
                 comboBox_CapillaryRefillExamination.DisplayMember = "ComboBox_Value";
                 comboBox_CapillaryRefillExamination.SelectedIndex = 0;

              
                 comboBox_CardiopulmonaryEvaluation.DataSource = ds.Tables["CardiopulmonaryEvaluation"];
                 comboBox_CardiopulmonaryEvaluation.ValueMember = "ComboBox_Key";
                 comboBox_CardiopulmonaryEvaluation.DisplayMember = "ComboBox_Value";
                 comboBox_CardiopulmonaryEvaluation.SelectedIndex = 0;


              
                 comboBox_PassiveLegRaiseExamination.DataSource = ds.Tables["PassiveLegRaiseExamination"];
                 comboBox_PassiveLegRaiseExamination.ValueMember = "ComboBox_Key";
                 comboBox_PassiveLegRaiseExamination.DisplayMember = "ComboBox_Value";
                 comboBox_PassiveLegRaiseExamination.SelectedIndex = 0;

              
                 comboBox_PeripheralPulseEvaluation.DataSource = ds.Tables["PeripheralPulseEvaluation"];
                 comboBox_PeripheralPulseEvaluation.ValueMember = "ComboBox_Key";
                 comboBox_PeripheralPulseEvaluation.DisplayMember = "ComboBox_Value";
                 comboBox_PeripheralPulseEvaluation.SelectedIndex = 0;


              
                 comboBox_SkinExamination.DataSource = ds.Tables["SkinExamination"];
                 comboBox_SkinExamination.ValueMember = "ComboBox_Key";
                 comboBox_SkinExamination.DisplayMember = "ComboBox_Value";
                 comboBox_SkinExamination.SelectedIndex = 0;

              
                 comboBox_CentralVenousOxygenMeasurement.DataSource = ds.Tables["CentralVenousOxygenMeasurement"];
                 comboBox_CentralVenousOxygenMeasurement.ValueMember = "ComboBox_Key";
                 comboBox_CentralVenousOxygenMeasurement.DisplayMember = "ComboBox_Value";
                 comboBox_CentralVenousOxygenMeasurement.SelectedIndex = 0;

              
                 comboBox_CentralVenousPressureMeasurement.DataSource = ds.Tables["CentralVenousPressureMeasurement"];
                 comboBox_CentralVenousPressureMeasurement.ValueMember = "ComboBox_Key";
                 comboBox_CentralVenousPressureMeasurement.DisplayMember = "ComboBox_Value";
                 comboBox_CentralVenousPressureMeasurement.SelectedIndex = 0;


              
                 comboBox_FluidChallengePerformed.DataSource = ds.Tables["FluidChallengePerformed"];
                 comboBox_FluidChallengePerformed.ValueMember = "ComboBox_Key";
                 comboBox_FluidChallengePerformed.DisplayMember = "ComboBox_Value";
                 comboBox_FluidChallengePerformed.SelectedIndex = 0;


              
                 comboBox_VitalSignsReview.DataSource = ds.Tables["VitalSignsReview"];
                 comboBox_VitalSignsReview.ValueMember = "ComboBox_Key";
                 comboBox_VitalSignsReview.DisplayMember = "ComboBox_Value";
                 comboBox_VitalSignsReview.SelectedIndex = 0;

              
                 comboBox_PlateletCount.DataSource = ds.Tables["PlateletCount"];
                 comboBox_PlateletCount.ValueMember = "ComboBox_Key";
                 comboBox_PlateletCount.DisplayMember = "ComboBox_Value";
                 comboBox_PlateletCount.SelectedIndex = 0;

              
                 comboBox_LowerRespiratoryInfection.DataSource = ds.Tables["LowerRespiratoryInfection"];
                 comboBox_LowerRespiratoryInfection.ValueMember = "ComboBox_Key";
                 comboBox_LowerRespiratoryInfection.DisplayMember = "ComboBox_Value";
                 comboBox_LowerRespiratoryInfection.SelectedIndex = 0;

              
                 comboBox_AlteredMentalStatus.DataSource = ds.Tables["AlteredMentalStatus"];
                 comboBox_AlteredMentalStatus.ValueMember = "ComboBox_Key";
                 comboBox_AlteredMentalStatus.DisplayMember = "ComboBox_Value";
                 comboBox_AlteredMentalStatus.SelectedIndex = 0;

              
                 comboBox_InfectionEtiology.DataSource = ds.Tables["InfectionEtiology"];
                 comboBox_InfectionEtiology.ValueMember = "ComboBox_Key";
                 comboBox_InfectionEtiology.DisplayMember = "ComboBox_Value";
                 comboBox_InfectionEtiology.SelectedIndex = 0;

              
                 comboBox_SiteofInfection.DataSource = ds.Tables["SiteofInfection"];
                 comboBox_SiteofInfection.ValueMember = "ComboBox_Key";
                 comboBox_SiteofInfection.DisplayMember = "ComboBox_Value";
                 comboBox_SiteofInfection.SelectedIndex = 0;


              
                 comboBox_MechanicalVentilation.DataSource = ds.Tables["MechanicalVentilation"];
                 comboBox_MechanicalVentilation.ValueMember = "ComboBox_Key";
                 comboBox_MechanicalVentilation.DisplayMember = "ComboBox_Value";
                 comboBox_MechanicalVentilation.SelectedIndex = 0;


              
                 comboBox_ICU.DataSource = ds.Tables["ICU"];
                 comboBox_ICU.ValueMember = "ComboBox_Key";
                 comboBox_ICU.DisplayMember = "ComboBox_Value";
                 comboBox_ICU.SelectedIndex = 0;

              
                 comboBox_ChronicRespiratoryFailure.DataSource = ds.Tables["ChronicRespiratoryFailure"];
                 comboBox_ChronicRespiratoryFailure.ValueMember = "ComboBox_Key";
                 comboBox_ChronicRespiratoryFailure.DisplayMember = "ComboBox_Value";
                 comboBox_ChronicRespiratoryFailure.SelectedIndex = 0;

              
                 comboBox_AIDSDisease.DataSource = ds.Tables["AIDSDisease"];
                 comboBox_AIDSDisease.ValueMember = "ComboBox_Key";
                 comboBox_AIDSDisease.DisplayMember = "ComboBox_Value";
                 comboBox_AIDSDisease.SelectedIndex = 0;

            
                 comboBox_MetastaticCancer.DataSource = ds.Tables["MetastaticCancer"];
                 comboBox_MetastaticCancer.ValueMember = "ComboBox_Key";
                 comboBox_MetastaticCancer.DisplayMember = "ComboBox_Value";
                 comboBox_MetastaticCancer.SelectedIndex = 0;


             
                 comboBox_Lymphoma.DataSource = ds.Tables["MultipleMyeloma"];
                 comboBox_Lymphoma.ValueMember = "ComboBox_Key";
                 comboBox_Lymphoma.DisplayMember = "ComboBox_Value";
                 comboBox_Lymphoma.SelectedIndex = 0;


              
                 comboBox_ImmuneModifyingMedications.DataSource = ds.Tables["ImmuneModifyingMedications"];
                 comboBox_ImmuneModifyingMedications.ValueMember = "ComboBox_Key";
                 comboBox_ImmuneModifyingMedications.DisplayMember = "ComboBox_Value";
                 comboBox_ImmuneModifyingMedications.SelectedIndex = 0;


              
                 comboBox_CongestiveHeartFailure.DataSource = ds.Tables["CongestiveHeartFailure"];
                 comboBox_CongestiveHeartFailure.ValueMember = "ComboBox_Key";
                 comboBox_CongestiveHeartFailure.DisplayMember = "ComboBox_Value";
                 comboBox_CongestiveHeartFailure.SelectedIndex = 0;


              
                 comboBox_ChronicRenalFailure.DataSource = ds.Tables["ChronicRenalFailure"];
                 comboBox_ChronicRenalFailure.ValueMember = "ComboBox_Key";
                 comboBox_ChronicRenalFailure.DisplayMember = "ComboBox_Value";
                 comboBox_ChronicRenalFailure.SelectedIndex = 0;

              
                 comboBox_ChronicLiverDisease.DataSource = ds.Tables["ChronicLiverDisease"];
                 comboBox_ChronicLiverDisease.ValueMember = "ComboBox_Key";
                 comboBox_ChronicLiverDisease.DisplayMember = "ComboBox_Value";
                 comboBox_ChronicLiverDisease.SelectedIndex = 0;


              
                 comboBox_Diabetes.DataSource = ds.Tables["Diabetes"];
                 comboBox_Diabetes.ValueMember = "ComboBox_Key";
                 comboBox_Diabetes.DisplayMember = "ComboBox_Value";
                 comboBox_Diabetes.SelectedIndex = 0;

              
                 comboBox_OrganTransplant.DataSource = ds.Tables["OrganTransplant"];
                 comboBox_OrganTransplant.ValueMember = "ComboBox_Key";
                 comboBox_OrganTransplant.DisplayMember = "ComboBox_Value";
                 comboBox_OrganTransplant.SelectedIndex = 0;



                 comboBox_Bandemia.DataSource = ds.Tables["Bandemia"];
                 comboBox_Bandemia.ValueMember = "ComboBox_Key";
                 comboBox_Bandemia.DisplayMember = "ComboBox_Value";
                 comboBox_Bandemia.SelectedIndex = 0;
              //ComboBoxValues Cbox = new ComboBoxValues();

              
              //Cbox.Gender.Add(new KeyValuePair<string, string>("0", "Select"));
              //Cbox.Gender.Add(new KeyValuePair<string, string>("M", "Male"));
              //Cbox.Gender.Add(new KeyValuePair<string, string>("F", "Female"));
              //Cbox.Gender.Add(new KeyValuePair<string, string>("U", "Unknown"));

              //Combobox_Gender.DataSource = Cbox.Gender;
              //Combobox_Gender.ValueMember = "Key";
              //Combobox_Gender.DisplayMember = "Value";
              //Combobox_Gender.SelectedIndex = 0;



              //Cbox.Payor.Add(new KeyValuePair<string, string>("0", "Select"));
              //Cbox.Payor.Add(new KeyValuePair<string, string>("A", "Self Pay"));
              //Cbox.Payor.Add(new KeyValuePair<string, string>("B", "Workers Comp"));
              //Cbox.Payor.Add(new KeyValuePair<string, string>("C", "Medicare"));
              //Cbox.Payor.Add(new KeyValuePair<string, string>("D", "Medicaid"));
              //Cbox.Payor.Add(new KeyValuePair<string, string>("E", "Other Federal Program"));
              //Cbox.Payor.Add(new KeyValuePair<string, string>("F", "Commercial Insurance"));
              //Cbox.Payor.Add(new KeyValuePair<string, string>("G", "Blue Cross"));
              //Cbox.Payor.Add(new KeyValuePair<string, string>("H", "CHAMPUS"));
              //Cbox.Payor.Add(new KeyValuePair<string, string>("I", "Other Non-Federal Program"));
           
              //comboBox_Payor.DataSource = Cbox.Payor;
              //comboBox_Payor.ValueMember = "Key";
              //comboBox_Payor.DisplayMember = "Value";
              //comboBox_Payor.SelectedIndex = 0;




              //Cbox.Race.Add(new KeyValuePair<string, string>("0", "Select"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("01", "White"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("02", "African American (Black)"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("03", "Native American (American Indian/Eskimo/Aleut)"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("41", "Asian"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("42", "Chinese"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("43", "Filipino"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("44", "Japanese"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("45", "Korean"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("46", "Vietnamese"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("49", "Other Asian"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("51", "Native Hawaiian"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("52", "Samoan"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("53", "Guamanian or Chamorro"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("59", "Other Pacific Islander"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("88", "Other Race"));
              //Cbox.Race.Add(new KeyValuePair<string, string>("MR", "Multi-racial"));

              
              //checkedListBox_Race.DataSource = Cbox.Race;
              //checkedListBox_Race.ValueMember = "Key";
              //checkedListBox_Race.DisplayMember = "Value";
              //checkedListBox_Race.SelectedIndex = 0;



              //Cbox.Ethnicity.Add(new KeyValuePair<string, string>("0", "Select"));
              //Cbox.Ethnicity.Add(new KeyValuePair<string, string>("1", "Spanish/Hispanic Origin"));
              //Cbox.Ethnicity.Add(new KeyValuePair<string, string>("2", "Not of Spanish/Hispanic Origin"));
              //Cbox.Ethnicity.Add(new KeyValuePair<string, string>("9", "Unknown"));

              //Combobox_Ethnicity.DataSource = Cbox.Ethnicity;
              //Combobox_Ethnicity.ValueMember = "Key";
              //Combobox_Ethnicity.DisplayMember = "Value";
              //Combobox_Ethnicity.SelectedIndex = 0;





              //Cbox.SourceOfAdmission.Add(new KeyValuePair<string, string>("0", "Select"));
              //Cbox.SourceOfAdmission.Add(new KeyValuePair<string, string>("1", "Non-Health Facility Point of Origin-The patient was admitted to this facility from home or from an assisted living facility."));
              //Cbox.SourceOfAdmission.Add(new KeyValuePair<string, string>("2", "Clinic-The patient was referred to this facility as a transfer from a freestanding or non-freestanding clinic."));
              //Cbox.SourceOfAdmission.Add(new KeyValuePair<string, string>("4", "Transfer from a Hospital (Different Facility)-The patient was admitted to this facility as a hospital transfer from an acute care facility where he or she was an inpatient or outpatient."));
              //Cbox.SourceOfAdmission.Add(new KeyValuePair<string, string>("5", "Transfer From a Skilled Nursing Facility (SNF) or Intermediate Care Facility (ICF)-The patient was admitted to this facility as a transfer from a SNF or ICF where he or she was a resident."));
              //Cbox.SourceOfAdmission.Add(new KeyValuePair<string, string>("6", "Transfer From Another Health Care Facility-The patient was admitted to this facility as a transfer from another type of health care facility not defined elsewhere in this code list."));
              //Cbox.SourceOfAdmission.Add(new KeyValuePair<string, string>("8", "Court/Law Enforcement- The patient was admitted to this facility upon the direction of a court of law, or upon the request of a law enforcement agency representative."));
              //Cbox.SourceOfAdmission.Add(new KeyValuePair<string, string>("9", "Information Not Available-The means by which the patient was admitted to this hospital was not known."));
              //Cbox.SourceOfAdmission.Add(new KeyValuePair<string, string>("A", "Transfer from a Rural Primary Care Hospital. The patient was admitted to this facility as a transfer from a Rural Primary Care Hospital (RPCH) where he or she was an inpatient."));
              //Cbox.SourceOfAdmission.Add(new KeyValuePair<string, string>("D", "Transfer from One Distinct Unit of the Hospital to another Distinct Unit of the Same Hospital Resulting in a Separate Claim to the Payer. Inpatient: The patient was admitted to this facility as a transfer from hospital inpatient within this facility resulting in a separate claim to the payer."));
              //Cbox.SourceOfAdmission.Add(new KeyValuePair<string, string>("E", "Transfer from Ambulatory Surgery Center-The patient was admitted to this facility as a transfer from an ambulatory surgery center."));
              //Cbox.SourceOfAdmission.Add(new KeyValuePair<string, string>("F", "Transfer from Hospice and is Under a Hospice Plan of Care or Enrolled in a Hospice Program- The patient was admitted to this facility as a transfer from a hospice."));
        


              //comboBox_SourceofAdmission.DataSource = Cbox.SourceOfAdmission;
              //comboBox_SourceofAdmission.ValueMember = "Key";
              //comboBox_SourceofAdmission.DisplayMember = "Value";
              //comboBox_SourceofAdmission.SelectedIndex = 0;



              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("0", "Select"));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("01", "Discharge to Home or Self Care (Routine Discharge). Includes discharge to home; home on oxygen if DME only; any other DME only; group home, foster care, independent living and other residential care arrangements; outpatient programs, such as partial hospitalization or outpatient chemical dependency programs."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("02", "Discharged/transferred to a Short-Term General Hospital for Inpatient Care."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("03", "Discharged/transferred to Skilled Nursing Facility (SNF) with Medicare Certification in anticipation of Skilled Care. Medicare indicates that the patient is discharged/transferred to a Medicare certified nursing facility. For hospitals with an approved swing bed arrangement, use Code 61 Swing Bed. For reporting other discharges/transfers to nursing facilities see 04 and 64."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("04", "Discharged/transferred to a Facility that Provides Custodial or Supportive Care. This is used to designate patients that are discharged/transferred to a nursing facility with neither Medicare nor Medicaid certification and for discharges/transfers to Assisted Living Facilities."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("05", "Discharged/transferred to a Designated Cancer Center or Children's Hospital."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("06", "Discharged/transferred to Home under Care of Organized Home Health Service Organization in Anticipation of Covered Skilled Care. Report this code when the patient is discharged/transferred to home with a written plan of care (tailored to the patient's medical needs) for home care services. Not used for home health services provided by a DME supplier or from a Home IV provider for home IV services."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("07", "Left against Medical Advice or Discontinued Care."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("09", "Admitted as an Inpatient to this Hospital-Patient admitted to the same short-term medical or specialty hospital where the hospital-based ambulatory surgery service was performed (excluding chronic disease hospitals)."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("20", "Expired."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("21", "Discharged/transferred to Court/Law Enforcement."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("50", "Hospice – Home."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("51", "Hospice – Medical Facility (Certified) Providing Hospice Level of Care."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("61", "Discharged/transferred to Hospital-Based Medicare Approved Swing Bed."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("62", "Discharged/transferred to an Inpatient Rehabilitation Facility (IRF) including Rehabilitation Distinct Part Unit of a Hospital."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("63", "Discharged/transferred to a Medicare Certified Long Term Care Hospital (LTCH)."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("64", "Discharged/transferred to a Nursing Facility Certified under Medicaid but not certified under Medicare."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("65", "Discharged/transferred to a Psychiatric Hospital or Psychiatric Distinct Part Unit of a Hospital."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("66", "Discharged/transferred to a Critical Access Hospital (CAH)."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("69", "Discharged/transferred to a Designated Disaster Alternative Care Site."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("70", "Discharged/transferred to another Type of Health Care Institution not defined Elsewhere in this Code List."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("81", "Discharged to Home or Self Care with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("82", "Discharged/transferred to a Short-Term General Hospital for Inpatient Care with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("83", "Discharged/transferred to Skilled Nursing Facility (SNF) with Medicare Certification with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("54", "Discharged/transferred to a Facility that Provides Custodial or Supportive Care with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("85", "Discharged/transferred to a Designated Cancer Center or Children's Hospital with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("86", "Discharged/transferred to Home under Care of Organized Home Health Service Organization with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("87", "Discharged/transferred to Court/Law Enforcement with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("88", "Discharged/transferred to a Federal Health Care Facility with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("89", "Discharged/transferred to Hospital-Based Medicare Approved Swing Bed with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("90", "Discharged/transferred to an Inpatient Rehabilitation Facility (IRF) including Rehabilitation Distinct Part Units of a Hospital with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("91", "Discharged/transferred to a Medicare Certified Long Term Care Hospital (LTCH) with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("92", "Discharged/transferred to a Nursing Facility Certified under Medicaid but not Certified under Medicare with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("93", "Discharged/transferred to a Psychiatric Hospital or Psychiatric Distinct Part Unit of a Hospital with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("94", "Discharged/transferred to a Critical Access Hospital (CAH) with a Planned Acute Care Hospital Inpatient Readmission."));
              //Cbox.DischargeStatus.Add(new KeyValuePair<string, string>("95", "Discharged/transferred to another Type of Health Care Institution not Defined Elsewhere in this Code List with a Planned Acute Care Hospital Inpatient Readmission."));




              //comboBox_DischargeStatus.DataSource = Cbox.DischargeStatus;
              //comboBox_DischargeStatus.ValueMember = "Key";
              //comboBox_DischargeStatus.DisplayMember = "Value";
              //comboBox_DischargeStatus.SelectedIndex = 0;
                   }
            catch (Exception ex)
            {

            }

        }

          private void textBox_AdmissionDateTime_Leave(object sender, EventArgs e)
                    {
                      try
                      {
                          if (validateDatetime(textBox_AdmissionDateTime.Text.ToString().Trim()) == false)
                          {
                              // textBox_AdmissionDateTime.BackColor = Color.White;
                              textBox_AdmissionDateTime.BackColor = ErrorColor(Color.Red);
                              MessageBox.Show("Admission Datetime should be in format MM/DD/YYYY hh:mm", "Admission Datetime Error");
                              textBox_AdmissionDateTime.Focus();

                          }
                          else if (validateDatetimeLimit(textBox_AdmissionDateTime.Text.ToString().Trim(), txtDOB.Text.ToString().Trim()) == false)
                          {
                              textBox_AdmissionDateTime.BackColor = ErrorColor(Color.Red);
                              MessageBox.Show("Date of Birth cannot have been after Admission Datetime.", "Admission Datetime Error");
                              textBox_AdmissionDateTime.Focus();
                          }
                          else
                          {

                              textBox_AdmissionDateTime.BackColor = MandatoryColor(Color.White);
                          }


                        //if (validateDatetimeLimit(textBox_AdmissionDateTime.Text.ToString().Trim()) == false)
                        //{
                        //    // textBox_AdmissionDateTime.BackColor = Color.White;
                        //    textBox_AdmissionDateTime.BackColor = ErrorColor(Color.Red);
                        //    MessageBox.Show("Admission Datetime should be between 01/01/1900 and 01/01/2100", "Admission Datetime Error");
                        //    textBox_AdmissionDateTime.Focus();

                        //}
                        //else
                        //{
                        //    textBox_AdmissionDateTime.BackColor = ErrorColor(Color.Gray);
                        //}

                     }
            catch (Exception ex)
            {

            }
              
              
          }

          private void textBox_DischargedDatetime_Leave(object sender, EventArgs e)
          {
              try 
              {
              if (validateDatetime(textBox_DischargedDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_DischargedDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Discharge Datetime should be in format MM/DD/YYYY hh:mm", "Discharge Date/Time Error");
                  textBox_DischargedDatetime.Focus();
              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_AdmissionDateTime.Text.ToString().Trim()) == false)
              {
                  textBox_DischargedDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Discharge Datetime should be after Admission Datetime", "Discharge Date/Time Error");
                  textBox_DischargedDatetime.Focus();
              }
              else
              {

                  textBox_DischargedDatetime.BackColor = MandatoryColor(Color.White);
              }
              }
            catch (Exception ex)
            {

            }
          }

          private void textBox_ExcludedDatetime_Leave(object sender, EventArgs e)
          {
              try
              {
              if (validateDatetime(textBox_ExcludedDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ExcludedDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Excluded Datetime should be in format MM/DD/YYYY hh:mm", "Excluded Date/Time Error");
                  textBox_ExcludedDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_ExcludedDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ExcludedDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Excluded Datetime cannot have been after Discharge Datetime.", "Excluded Date/Time Error");
                  textBox_ExcludedDatetime.Focus();
              }
              else
              {

                  if (lbl_ExcludedDatetime.Visible == true)
                      textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.Gray);
                 // textBox_ExcludedDatetime.BackColor = ErrorColor(Color.White);
                  //textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.Gray);
              }



             }
            catch (Exception ex)
            {

            }

          }

          private void textBox_EarliestDatetime_Leave(object sender, EventArgs e)
          {
              try
              {
              
              if (validateDatetime(textBox_EarliestDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_EarliestDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Earliest Datetime should be in format MM/DD/YYYY hh:mm", "Earliest Date/Time Error");
                  textBox_EarliestDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_EarliestDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_EarliestDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Earliest Datetime cannot have been after Discharge Datetime.", "Earliest Date/Time Error");
                  textBox_EarliestDatetime.Focus();
              }
              else
              {
                  textBox_EarliestDatetime.BackColor = MandatoryColor(Color.White);
              }
             }
            catch (Exception ex)
            {

            }
          }

          private void textbox_TriageDatetime_Leave(object sender, EventArgs e)
          {
              try 
              {

              if (validateDatetime(textbox_TriageDatetime.Text.ToString().Trim()) == false)
              {
                  textbox_TriageDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Triage Datetime should be in format MM/DD/YYYY hh:mm", "Triage Date/Time Error");
                  textbox_TriageDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textbox_TriageDatetime.Text.ToString().Trim()) == false)
              {
                  textbox_TriageDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Triage Datetime cannot have been after Discharge Datetime.", "Triage Datetime Error");
                  textbox_TriageDatetime.Focus();
              }
              else
              {
                  textbox_TriageDatetime.BackColor = MandatoryColor(Color.Gray);
              }

              if (textbox_TriageDatetime.Text.ToString().Trim() != "/  /       :")
              {
                  textBox_LeftEDDatetime.Enabled = true;
                  lbl_LeftEDDatetime.Show();
                  textBox_LeftEDDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  textBox_LeftEDDatetime.Enabled = false;
                  textBox_LeftEDDatetime.Text = "";
                  lbl_LeftEDDatetime.Hide();
                  textBox_LeftEDDatetime.BackColor = MandatoryColor(Color.Gray);
              }
                  }
            catch (Exception ex)
            {

            }
            
          }

          private void textBox_SevereSepsisPresentationDatetime_Leave(object sender, EventArgs e)
          {
              try
              {
              if (validateDatetime(textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_SevereSepsisPresentationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Severe Sepsis Presentation Datetime should be in format MM/DD/YYYY hh:mm", "Severe Sepsis Presentation Date/Time Error");
                  textBox_SevereSepsisPresentationDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_SevereSepsisPresentationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Severe Sepsis Presentation Datetime cannot have been after Discharge Datetime.", "Severe Sepsis Presentation Date/Time Error");
                  textBox_SevereSepsisPresentationDatetime.Focus();
              }
              else
              {
                  if (lbl_SevereSepsisPresentationDatetime.Visible == true)
                      textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.Gray);

                  //textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
            }
            catch (Exception ex)
            {

            }
          }

          private void textBox_septicShockPresentationDatetime_Leave(object sender, EventArgs e)
          {
              try
              {
              if (validateDatetime(textBox_septicShockPresentationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_septicShockPresentationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Septic Shock Presentation Datetime should be in format MM/DD/YYYY hh:mm", "Septic Shock Presentation Date/Time Error");
                  textBox_septicShockPresentationDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_septicShockPresentationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_septicShockPresentationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Septic Shock Presentation Datetime cannot have been after Discharge Datetime.", "Septic Shock Presentation Date/Time Error");
                  textBox_septicShockPresentationDatetime.Focus();
              }
              else
              {
                  if (lbl_SepticShockPresentationDatetime.Visible == true)
                      textBox_septicShockPresentationDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_septicShockPresentationDatetime.BackColor = MandatoryColor(Color.Gray);

                  //textBox_septicShockPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
             }
            catch (Exception ex)
            {

            }
          }

          private void textBox_LeftEDDatetime_Leave(object sender, EventArgs e)
          {
             try
             {

              if (validateDatetime(textBox_LeftEDDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_LeftEDDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Left ED Datetime should be in format MM/DD/YYYY hh:mm", "Left ED Datetime Date/Time Error");
                  textBox_LeftEDDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_LeftEDDatetime.Text.ToString().Trim(), textbox_TriageDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_LeftEDDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Left ED Datetime cannot have been before Triage Datetime.", "Left ED Datetime Date/Time Error");
                  textBox_LeftEDDatetime.Focus();
              }
              else
              {
                  if (lbl_LeftEDDatetime.Visible == true)
                      textBox_LeftEDDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_LeftEDDatetime.BackColor = MandatoryColor(Color.Gray);

                 // textBox_LeftEDDatetime.BackColor = MandatoryColor(Color.Gray);
              }

              if (textBox_LeftEDDatetime.Text.ToString().Trim() != "/  /       :")
              {
                  lbl_DestinationafterED.Show();
                  comboBox_DestinationafterED.Enabled = true;
                  comboBox_DestinationafterED.BackColor = result;
              }
              else
              {

                  lbl_DestinationafterED.Hide();
                  comboBox_DestinationafterED.Enabled = false;
                  comboBox_DestinationafterED.SelectedValue = "Select";
                  comboBox_DestinationafterED.BackColor = MandatoryColor(Color.Gray);
              }


           
             }
            catch (Exception ex)
            {

            }

            
          }

          private void textBox_InitialLactateLevelCollectionDatetime_Leave(object sender, EventArgs e)
          {
              try
              {

              //if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "Select" && textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_InitialLactateLevelCollectionDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Initial Lactate Level Collection.", "Initial Lactate Level Collection Date/Time Error");
              //    comboBox_InitialLactateLevelCollection.Focus();
              //}
              //else
              //{
              //    textBox_InitialLactateLevelCollectionDatetime.BackColor = ErrorColor(Color.Gray);
              //}
             

              if (validateDatetime(textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Initial Lactate Level Collection Datetime should be in format MM/DD/YYYY hh:mm", "Initial Lactate Level Collection Date/Time Error");
                  textBox_InitialLactateLevelCollectionDatetime.Focus();

              }
              else
              {
                  if (lbl_InitialLactateLevelCollectionDatetime.Visible == true)
                      textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
                     // textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.Gray);
                 
              }

             }
            catch (Exception ex)
            {

            }
          }

          private void textbox_RepeatLactateLevelCollectionDatetime_Leave(object sender, EventArgs e)
          {

              try
              {

              //if (comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "Select" && textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim() != "")
              //{
              //    textbox_RepeatLactateLevelCollectionDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Repeat Lactate Level Collection.", "Repeat Lactate Level Collection Date/Time Error");
              //    comboBox_RepeatLactateLevelCollection.Focus();

              //}
              //else
              //{
              //    textBox_InitialLactateLevelCollectionDatetime.BackColor = ErrorColor(Color.Gray);
              //}

              if (validateDatetime(textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim()) == false)
              {
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Repeat Lactate Level Collection Datetime should be in format MM/DD/YYYY hh:mm", "Repeat Lactate Level Collection Date/Time Error");
                  textbox_RepeatLactateLevelCollectionDatetime.Focus();

              }
              else
              {
                  if (lbl_RepeatLactateLevelCollectionDatetime.Visible == true)
                      textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
                  
              }
             }
            catch (Exception ex)
            {

            }
          }

          private void textBox_BloodCultureCollectionDatetime_Leave(object sender, EventArgs e)
          {
              try
              {

              //if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "Select" && textBox_BloodCultureCollectionDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_BloodCultureCollectionDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Blood Culture Collection.", "Blood Culture Collection Date/Time Error");
              //    textBox_BloodCultureCollectionDatetime.Focus();

              //}
              //else
              //{
              //    textBox_BloodCultureCollectionDatetime.BackColor = ErrorColor(Color.Gray);
              //}

              if (validateDatetime(textBox_BloodCultureCollectionDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_BloodCultureCollectionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Blood Culture Collection Datetime should be in format MM/DD/YYYY hh:mm", "Blood Culture Collection Date/Time Error");
                  textBox_BloodCultureCollectionDatetime.Focus();

              }
              else
              {
                  if (lbl_BloodCultureCollectionDatetime.Visible == true)
                      textBox_BloodCultureCollectionDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_BloodCultureCollectionDatetime.BackColor = MandatoryColor(Color.Gray);

                  
              }
             }
            catch (Exception ex)
            {

            }
          }

          private void textBox_AntibioticAdministrationDatetime_Leave(object sender, EventArgs e)
          {
              try
              {
             //if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "Select" && textBox_AntibioticAdministrationDatetime.Text.ToString().Trim() != "")
             // {
             //     textBox_AntibioticAdministrationDatetime.BackColor = ErrorColor(Color.Red);
             //     MessageBox.Show("Please select appropriate response from Antibiotic Administration.", "Antibiotic Administration Date/Time Error");
             //     textBox_AntibioticAdministrationDatetime.Focus();

             // }  
             // else
             // {
             //     textBox_AntibioticAdministrationDatetime.BackColor = ErrorColor(Color.Gray);
             // }

              if (validateDatetime(textBox_AntibioticAdministrationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_AntibioticAdministrationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Antibiotic Administration Datetime should be in format MM/DD/YYYY hh:mm", "Antibiotic Administration Date/Time Error");
                  textBox_AntibioticAdministrationDatetime.Focus();

              }
              else
              {
                  if (lbl_AntibioticAdministrationDatetime.Visible == true)
                      textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);

                  //textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              }

                  }
            catch (Exception ex)
            {

            }
          }

          private void textBox_CrystalloidFluidAdministrationDatetime_Leave(object sender, EventArgs e)
          {
              try
              {

              //if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "Select" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "Select") && textBox_CrystalloidFluidAdministrationDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_CrystalloidFluidAdministrationDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response for either Adult or Pediatric Crystalloid Fluid Administration.", "Crystalloid Fluid Administration Date/Time Error");
              //    textBox_CrystalloidFluidAdministrationDatetime.Focus();

              //}
              //else
              //{
              //    textBox_CrystalloidFluidAdministrationDatetime.BackColor = ErrorColor(Color.Gray);
              //}

              if (validateDatetime(textBox_CrystalloidFluidAdministrationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_CrystalloidFluidAdministrationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Crystalloid Fluid Administration Datetime should be in format MM/DD/YYYY hh:mm", "Crystalloid Fluid Administration Date/Time Error");
                  textBox_CrystalloidFluidAdministrationDatetime.Focus();

              }
              else
              {

                  if (lbl_CrystalloidFluidAdministrationDatetime.Visible == true)
                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              }

                  }
            catch (Exception ex)
            {

            }
          }

          private void textBox_BedsideCardiovascularUltrasoundDatetime_Leave(object sender, EventArgs e)
          {

              try
              {
              //if (comboBox_BedsideCardiovascularUltrasound.SelectedValue.ToString() == "Select" && textBox_BedsideCardiovascularUltrasoundDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Bedside Cardiovascular Ultrasound.", "Bedside Cardiovascular Ultrasound Date/Time Error");
              //    textBox_BedsideCardiovascularUltrasoundDatetime.Focus();

              //}
              //else
              //{
              //    textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = ErrorColor(Color.Gray);
              //}

              if (validateDatetime(textBox_BedsideCardiovascularUltrasoundDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Bedside Cardiovascular Ultrasound Datetime should be in format MM/DD/YYYY hh:mm", "Bedside Cardiovascular Ultrasound Date/Time Error");
                  textBox_BedsideCardiovascularUltrasoundDatetime.Focus();

              }
              else
              {
                  if (lbl_BedsideCardioUltrasoundDateTime.Visible == true)
                      textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = MandatoryColor(Color.Gray);
              }
                  }
            catch (Exception ex)
            {

            }
          }

          private void textBox_VasopressorAdministrationDatetime_Leave(object sender, EventArgs e)
          {

              try
              {
              //if (comboBox_VasopressorAdministration.SelectedValue.ToString() == "Select" && textBox_VasopressorAdministrationDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_VasopressorAdministrationDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Vasopressor Administration.", "Vasopressor Administration Date/Time Error");
              //    textBox_VasopressorAdministrationDatetime.Focus();

              //}
              //else
              //{
              //    textBox_VasopressorAdministrationDatetime.BackColor = ErrorColor(Color.Gray);
              //}

                if (validateDatetime(textBox_VasopressorAdministrationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_VasopressorAdministrationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Vasopressor Administration Datetime should be in format MM/DD/YYYY hh:mm", "Vasopressor Administration Date/Time Error");
                  textBox_VasopressorAdministrationDatetime.Focus();

              }
              else
              {

                  if (lbl_VasopressorAdministrationDateTime.Visible == true)
                      textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              }
            catch (Exception ex)
            {

            }
          }

          private void textBox_CardiopulmonaryEvaluationDatetime_Leave(object sender, EventArgs e)
          {
              try
              {

              //if (comboBox_CardiopulmonaryEvaluation.SelectedValue.ToString() == "Select" && textBox_CardiopulmonaryEvaluationDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_CardiopulmonaryEvaluationDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Cardio pulmonary Evaluation.", "Cardiopulmonary Evaluation Date/Time Error");
              //    textBox_CardiopulmonaryEvaluationDatetime.Focus();

              //}
              //else
              //{
              //    textBox_CardiopulmonaryEvaluationDatetime.BackColor = ErrorColor(Color.Gray);
              //}

              if (validateDatetime(textBox_CardiopulmonaryEvaluationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_CardiopulmonaryEvaluationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Cardiopulmonary Evaluation Datetime should be in format MM/DD/YYYY hh:mm", "Cardiopulmonary Evaluation Date/Time Error");
                  textBox_CardiopulmonaryEvaluationDatetime.Focus();

              }
              else
              {
                  if (lbl_CardiopulmonaryEvaluationDatetime.Visible == true)
                      textBox_CardiopulmonaryEvaluationDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_CardiopulmonaryEvaluationDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_CardiopulmonaryEvaluationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
                  }
            catch (Exception ex)
            {

            }
          }

          private void textBox_CapillaryRefillExaminationDatetime_Leave(object sender, EventArgs e)
          {
              try
              {
              //if (comboBox_CapillaryRefillExamination.SelectedValue.ToString() == "Select" && textBox_CapillaryRefillExaminationDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_CapillaryRefillExaminationDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Capillary Refill Examination.", "Capillary Refill Examination Date/Time Error");
              //    textBox_CapillaryRefillExaminationDatetime.Focus();

              //}
              //else
              //{
              //    textBox_CapillaryRefillExaminationDatetime.BackColor = ErrorColor(Color.Gray);
              //}

              if (validateDatetime(textBox_CapillaryRefillExaminationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_CapillaryRefillExaminationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Capillary Refill Examination Datetime should be in format MM/DD/YYYY hh:mm", "Capillary Refill Examination Date/Time Error");
                  textBox_CapillaryRefillExaminationDatetime.Focus();

              }
              else
              {
                  if (lbl_CapillaryRefillExaminationDatetime.Visible == true)
                      textBox_CapillaryRefillExaminationDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_CapillaryRefillExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_CapillaryRefillExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
                  }
            catch (Exception ex)
            {

            }
          }

          private void textBox_PassiveLegRaiseExaminationDatetime_Leave(object sender, EventArgs e)
          {
              try
              {

              //if (comboBox_PassiveLegRaiseExamination.SelectedValue.ToString() == "Select" && textBox_PassiveLegRaiseExaminationDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_PassiveLegRaiseExaminationDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Passive Leg Raise Examination.", "Passive Leg Raise Examination Date/Time Error");
              //    textBox_PassiveLegRaiseExaminationDatetime.Focus();

              //}
              //else
              //{
              //    textBox_PassiveLegRaiseExaminationDatetime.BackColor = ErrorColor(Color.Gray);
              //}

              if (validateDatetime(textBox_PassiveLegRaiseExaminationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_PassiveLegRaiseExaminationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Passive Leg Raise Examination Datetime should be in format MM/DD/YYYY hh:mm", "Passive Leg Raise Examination Date/Time Error");
                  textBox_PassiveLegRaiseExaminationDatetime.Focus();

              }
              else
              {
                  if (lbl_PassiveLegRaiseExaminationDatetime.Visible == true)
                      textBox_PassiveLegRaiseExaminationDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_PassiveLegRaiseExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_PassiveLegRaiseExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
                  }
            catch (Exception ex)
            {

            }

          }

          private void textBox_PeripheralPulseEvaluationDatetime_Leave(object sender, EventArgs e)
          {

              try
              {

                  //if (comboBox_PeripheralPulseEvaluation.SelectedValue.ToString() == "Select" && textBox_PeripheralPulseEvaluationDatetime.Text.ToString().Trim() != "")
                  //{
                  //    textBox_PeripheralPulseEvaluationDatetime.BackColor = ErrorColor(Color.Red);
                  //    MessageBox.Show("Please select appropriate response from Peripheral Pulse Evaluation.", "Peripheral Pulse Evaluation Date/Time Error");
                  //    textBox_PeripheralPulseEvaluationDatetime.Focus();

                  //}
                  //else
                  //{
                  //    textBox_PeripheralPulseEvaluationDatetime.BackColor = ErrorColor(Color.Gray);
                  //}

                  if (validateDatetime(textBox_PeripheralPulseEvaluationDatetime.Text.ToString().Trim()) == false)
                  {
                      textBox_PeripheralPulseEvaluationDatetime.BackColor = ErrorColor(Color.Red);
                      MessageBox.Show("Peripheral Pulse Evaluation Datetime should be in format MM/DD/YYYY hh:mm", "Peripheral Pulse Evaluation Date/Time Error");
                      textBox_PeripheralPulseEvaluationDatetime.Focus();

                  }
                  else
                  {
                      if (lbl_PeripheralPulseEvaluationDatetime.Visible == true)
                          textBox_PeripheralPulseEvaluationDatetime.BackColor = MandatoryColor(Color.White);
                      else
                          textBox_PeripheralPulseEvaluationDatetime.BackColor = MandatoryColor(Color.Gray);
                      //textBox_PeripheralPulseEvaluationDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
              }
              catch (Exception ex)
              {

              }

          
          }

          private void textBox_SkinExaminationDatetime_Leave(object sender, EventArgs e)
          {

              try
              {
              //if (comboBox_SkinExamination.SelectedValue.ToString() == "Select" && textBox_SkinExaminationDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_SkinExaminationDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Skin Examination.", "Skin Examination Date/Time Error");
              //    textBox_SkinExaminationDatetime.Focus();

              //}
              //else
              //{
              //    textBox_SkinExaminationDatetime.BackColor = ErrorColor(Color.Gray);
              //}

              if (validateDatetime(textBox_SkinExaminationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_SkinExaminationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Skin Examination Datetime should be in format MM/DD/YYYY hh:mm", "Skin Examination Date/Time Error");
                  textBox_SkinExaminationDatetime.Focus();

              }
              else
              {

                  if (lbl_SkinExaminationDateTime.Visible == true)
                      textBox_SkinExaminationDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_SkinExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_SkinExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
                     }
              catch (Exception ex)
              {

              }
          }

          private void textBox_CentralVenousOxygenMeasurementDatetime_Leave(object sender, EventArgs e)
          {

              //if (comboBox_CentralVenousOxygenMeasurement.SelectedValue.ToString() == "Select" && textBox_CentralVenousOxygenMeasurementDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_CentralVenousOxygenMeasurementDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Central Venous Oxygen Measurement.", "Central Venous Oxygen Measurement Date/Time Error");
              //    textBox_CentralVenousOxygenMeasurementDatetime.Focus();

              //}
              //else
              //{
              //    textBox_CentralVenousOxygenMeasurementDatetime.BackColor = ErrorColor(Color.Gray);
              //}
              if (validateDatetime(textBox_CentralVenousOxygenMeasurementDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_CentralVenousOxygenMeasurementDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Central Venous Oxygen Measurement Datetime should be in format MM/DD/YYYY hh:mm", "Central Venous Oxygen Measurement Date/Time Error");
                  textBox_CentralVenousOxygenMeasurementDatetime.Focus();

              }
              else
              {
                  if (lbl_CentralVenousOxygenMeasurementDatetime.Visible == true)
                      textBox_CentralVenousOxygenMeasurementDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_CentralVenousOxygenMeasurementDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_CentralVenousOxygenMeasurementDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void textBox_CentralVenousPressureMeasurementDatetime_Leave(object sender, EventArgs e)
          {

              //if (comboBox_CentralVenousPressureMeasurement.SelectedValue.ToString() == "Select" && textBox_CentralVenousPressureMeasurementDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_CentralVenousPressureMeasurementDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Central Venous Pressure Measurement.", "Central Venous Pressure Measurement Date/Time Error");
              //    textBox_CentralVenousPressureMeasurementDatetime.Focus();

              //}
              //else
              //{
              //    textBox_CentralVenousPressureMeasurementDatetime.BackColor = ErrorColor(Color.Gray);
              //}

              if (validateDatetime(textBox_CentralVenousPressureMeasurementDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_CentralVenousPressureMeasurementDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Central Venous Pressure Measurement Datetime should be in format MM/DD/YYYY hh:mm", "Central Venous Pressure Measurement Date/Time Error");
                  textBox_CentralVenousPressureMeasurementDatetime.Focus();

              }
              else
              {
                  if (lbl_CVPressureMeasurementDateTime.Visible == true)
                      textBox_CentralVenousPressureMeasurementDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_CentralVenousPressureMeasurementDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_CentralVenousPressureMeasurementDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void textBox_FluidChallengePerformedDatetime_Leave(object sender, EventArgs e)
          {

              //if (comboBox_FluidChallengePerformed.SelectedValue.ToString() == "Select" && textBox_FluidChallengePerformedDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_FluidChallengePerformedDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Fluid Challenge Performed.", "Admission Date/Time Error");
              //    textBox_FluidChallengePerformedDatetime.Focus();

              //}
              //else
              //{
              //    textBox_FluidChallengePerformedDatetime.BackColor = ErrorColor(Color.Gray);
              //}

              if (validateDatetime(textBox_FluidChallengePerformedDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_FluidChallengePerformedDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Fluid Challenge Performed Datetime should be in format MM/DD/YYYY hh:mm", "Fluid Challenge Performed Date/Time Error");
                  textBox_FluidChallengePerformedDatetime.Focus();

              }
              else
              {
                  if (lbl_FluidChallengePerformedDatetime.Visible == true)
                      textBox_FluidChallengePerformedDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_FluidChallengePerformedDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_FluidChallengePerformedDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void textBox_VitalSignsReviewDatetime_Leave(object sender, EventArgs e)
          {

              //if (comboBox_VitalSignsReview.SelectedValue.ToString() == "Select" && textBox_VitalSignsReviewDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_VitalSignsReviewDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Vital Sign Review.", "Admission Date/Time Error");
              //    textBox_VitalSignsReviewDatetime.Focus();

              //}
              //else
              //{
              //    textBox_VitalSignsReviewDatetime.BackColor = ErrorColor(Color.Gray);
              //}


              if (validateDatetime(textBox_VitalSignsReviewDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_VitalSignsReviewDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Vital Signs Review Datetime should be in format MM/DD/YYYY hh:mm", "Vital Signs Review Date/Time Error");
                  textBox_VitalSignsReviewDatetime.Focus();

              }
              else
              {
                  if (lblVitalSignsReviewDatetime.Visible == true)
                      textBox_VitalSignsReviewDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_VitalSignsReviewDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_VitalSignsReviewDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void textBox_MechanicalVentilationDatetime_Leave(object sender, EventArgs e)
          {

              //if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "Select" && textBox_MechanicalVentilationDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_MechanicalVentilationDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from Mechanical Ventilation.", "Mechanical Ventilation Date/Time Error");
              //    textBox_MechanicalVentilationDatetime.Focus();

              //}
              //else
              //{
              //    textBox_MechanicalVentilationDatetime.BackColor = ErrorColor(Color.Gray);
              //}

              if (validateDatetime(textBox_MechanicalVentilationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_MechanicalVentilationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Mechanical Ventilation Datetime should be in format MM/DD/YYYY hh:mm", "Mechanical Ventilation Date/Time Error");
                  textBox_MechanicalVentilationDatetime.Focus();

              }
              else
              {
                  if (lbl_MechanicalVentilationDatetime.Visible == true)
                      textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void textBox_ICUAdmissionDatetime_Leave(object sender, EventArgs e)
          {

              //if (comboBox_ICU.SelectedValue.ToString() == "Select" && textBox_ICUAdmissionDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_ICUAdmissionDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from ICU.", "ICU Admission Date/Time Error");
              //    textBox_ICUAdmissionDatetime.Focus();

              //}
              //else
              //{
              //    textBox_ICUAdmissionDatetime.BackColor = ErrorColor(Color.Gray);
              //}

              if (validateDatetime(textBox_ICUAdmissionDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ICUAdmissionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("ICU Admission Datetime should be in format MM/DD/YYYY hh:mm", "ICU Admission Date/Time Error");
                  textBox_ICUAdmissionDatetime.Focus();

              }
              else
              {
                  if (lbl_ICUAdmissionDatetime.Visible == true)
                      textBox_ICUAdmissionDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_ICUAdmissionDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_ICUAdmissionDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void textBox_ICUDischargeDatetime_Leave(object sender, EventArgs e)
          {

              //if (comboBox_ICU.SelectedValue.ToString() == "Select" && textBox_ICUDischargeDatetime.Text.ToString().Trim() != "")
              //{
              //    textBox_ICUDischargeDatetime.BackColor = ErrorColor(Color.Red);
              //    MessageBox.Show("Please select appropriate response from ICU.", "ICU Discharge Date/Time Error");
              //    textBox_ICUDischargeDatetime.Focus();

              //}
              //else
              //{
              //    textBox_ICUDischargeDatetime.BackColor = ErrorColor(Color.Gray);
              //}

              if (validateDatetime(textBox_ICUDischargeDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ICUDischargeDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("ICU Discharge Datetime should be in format MM/DD/YYYY hh:mm", "ICU Discharge Date/Time Error");
                  textBox_ICUDischargeDatetime.Focus();

              }
              else
              {
                  if (lbl_ICUDischargeDatetime.Visible == true)
                      textBox_ICUDischargeDatetime.BackColor = MandatoryColor(Color.White);
                  else
                      textBox_ICUDischargeDatetime.BackColor = MandatoryColor(Color.Gray);
                  //textBox_ICUDischargeDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void TextBox_PatientCtrlNum_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
          {
              System.Text.StringBuilder messageBoxCS = new System.Text.StringBuilder();

              messageBoxCS.AppendFormat("{0} : {1}", "Patient Control Number Error", e.RejectionHint);
              messageBoxCS.AppendLine();
              MessageBox.Show(messageBoxCS.ToString(), "Patient Control Number Error");
          }

          private void TextBox_InsuranceNumber_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
          {
              System.Text.StringBuilder messageBoxCS = new System.Text.StringBuilder();

              messageBoxCS.AppendFormat("{0} : {1}", "Insurance Number Error", e.RejectionHint);
              messageBoxCS.AppendLine();
              MessageBox.Show(messageBoxCS.ToString(), "Insurance Number Error");
          }

          private void comboBox_ProtocolInitiated_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_ProtocolInitiated.SelectedValue.ToString() == "0")
              {
                  comboBox_ProtocolInitiatedPlace.SelectedIndex = 4;
                  comboBox_ProtocolType.SelectedIndex = 3;
                  lbl_ProtocolNotInitiatedReason.Show();
                  comboBox_ProtocolNotInitiatedReason.BackColor = result;

              }
              else
              {
                  comboBox_ProtocolInitiatedPlace.SelectedIndex = 0;
                  comboBox_ProtocolType.SelectedIndex = 0;
                  lbl_ProtocolNotInitiatedReason.Hide();
                  comboBox_ProtocolNotInitiatedReason.BackColor = MandatoryColor(Color.Gray);
              }





          }

          private void comboBox_ProtocolInitiatedPlace_SelectedIndexChanged(object sender, EventArgs e)
          {
              //if (comboBox_ProtocolInitiated.SelectedValue.ToString() == "0" && comboBox_ProtocolInitiatedPlace.SelectedIndex != 4)
              //{
              //    MessageBox.Show("If Protocol Initiated is selected as 'Protocol Not Initiated' then Protocol Initiated place should be 'Protocol Not Initiated'", "Protocol Initiated Place Error");
              //    comboBox_ProtocolInitiatedPlace.Focus();
              //}
            

          }

          private void comboBox_ProtocolNotInitiatedReason_SelectedIndexChanged(object sender, EventArgs e)
          {
              //if (comboBox_ProtocolInitiated.SelectedValue.ToString() == "0" && comboBox_ProtocolNotInitiatedReason.SelectedIndex == 0)
              //{
              //    MessageBox.Show("If Protocol Initiated is selected as 'Protocol Not Initiated' then Protocol Not Initiated Reason should be selected.", "Protocol Not Initiated Reason");
              //    comboBox_ProtocolNotInitiatedReason.Focus();
              //}


      
          }

          private void comboBox_ProtocolType_SelectedIndexChanged(object sender, EventArgs e)
          {
              //if (comboBox_ProtocolInitiated.SelectedValue.ToString() == "0" && comboBox_ProtocolType.SelectedIndex != 3)
              //{
              //    MessageBox.Show("If Protocol Initiated is selected as 'Protocol Not Initiated' then Protocol Type should be 'Protocol Not Initiated'.", "Protocol Type");
              //    comboBox_ProtocolType.Focus();
              //}

              if (comboBox_ExcludedFromProtocol.SelectedValue != null)
              {
                  if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" || comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1")
                  {

                      //if (comboBox_ProtocolType.SelectedIndex == 1)
                      //{
                      //    lbl_AdultCrystalloidFluidAdministration.Show();
                      //    comboBox_AdultCrystalloidFluidAdministration.Enabled = true;
                      //    comboBox_AdultCrystalloidFluidAdministration.BackColor = result;

                      //}
                      //else
                      //{
                      //    lbl_AdultCrystalloidFluidAdministration.Hide();
                      //    comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                      //    comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                      //    comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                      //}

                      //if (comboBox_ProtocolType.SelectedIndex == 2)
                      //{
                      //    lbl_PediatricCrystalloidFluidAdministration.Show();
                      //    comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;
                      //    comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;

                      //}
                      //else
                      //{
                      //    lbl_PediatricCrystalloidFluidAdministration.Hide();
                      //    comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                      //    comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";
                      //    comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                      //}



                  //}
                  //else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1")
                  //{

                      if (comboBox_ProtocolType.SelectedIndex == 1)
                      {
                          lbl_AdultCrystalloidFluidAdministration.Show();
                          comboBox_AdultCrystalloidFluidAdministration.Enabled = true;
                          comboBox_AdultCrystalloidFluidAdministration.BackColor = result;

                          lbl_PediatricCrystalloidFluidAdministration.Hide();
                          comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                          comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);


                      }
                      else if (comboBox_ProtocolType.SelectedIndex == 2)
                      {
                          lbl_PediatricCrystalloidFluidAdministration.Show();
                          comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;

                          lbl_AdultCrystalloidFluidAdministration.Hide();
                          comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                          comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                          comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                      }
                      else if (comboBox_ProtocolType.SelectedIndex == 3)
                      {
                          lbl_AdultCrystalloidFluidAdministration.Hide();
                          lbl_PediatricCrystalloidFluidAdministration.Hide();
                          //lbl_AdultCrystalloidFluidAdministration.Show();
                          comboBox_AdultCrystalloidFluidAdministration.Enabled = true;
                          comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                          //lbl_PediatricCrystalloidFluidAdministration.Show();
                          comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                      }
                      else
                      {
                          lbl_PediatricCrystalloidFluidAdministration.Hide();
                          comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                          comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";
                          lbl_AdultCrystalloidFluidAdministration.Hide();
                          comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                          comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                          comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                      }

                  }

                  else
                  {

                  //    if (comboBox_ProtocolType.SelectedIndex == 2)
                  //    {
                  //        lbl_PediatricCrystalloidFluidAdministration.Show();
                  //        comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;

                  //    }
                  //    else
                  //    {
                          lbl_PediatricCrystalloidFluidAdministration.Hide();
                          comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                          comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";
                          lbl_AdultCrystalloidFluidAdministration.Hide();
                          comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                          comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                          comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                  //    }
                  }
              }
           
          }

          //private void TextBox_PatientCtrlNum_Leave(object sender, EventArgs e)
          //{
          //    if (SpecialCharacterCheck(TextBox_PatientCtrlNum.Text.ToString().Trim())== false)
               
          //    {
          //        TextBox_PatientCtrlNum.BackColor = Color.White;
          //        TextBox_PatientCtrlNum.BackColor = ErrorColor(Color.Red);
          //        MessageBox.Show("Patient Control Number should not include special characters.", "Patient Control Number Error");
          //        textBox_AdmissionDateTime.Focus();

          //    }
          //    else
          //    {
          //        TextBox_PatientCtrlNum.BackColor = ErrorColor(Color.Gray);
          //    }
          //}




          public bool MandatoryFieldCheck()
          {


              // Actual Mandatory Fields
              if (txtId.Text.ToString().Trim() == "")
              {
                  return false;
              }



              if (TextBox_PatientCtrlNum.Text.ToString().Trim() == "")
              {
                  return false;
              }


              if (txtDOB.Text.ToString().Trim() == "/  /")
              {
                  return false;
              }


              if (Combobox_Gender.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (checkedListBox_Race.CheckedItems.Count == 0)
              {
                  return false;
              }




              if (Combobox_Ethnicity.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_Payor.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              //if (TextBox_InsuranceNumber.Text.ToString().Trim() == "")
              //{
              //    return false;
              //}




              if (txtMRN.Text.ToString().Trim() == "")
              {
                  return false;
              }


              if (TextBox_FacilityIdentifier.Text.ToString().Trim() == "")
              {
                  return false;
              }




              if (textBox_AdmissionDateTime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }

              if (textBox_DischargedDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }

              if (comboBox_SourceofAdmission.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_DischargeStatus.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_TransferStatus.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_ProtocolInitiated.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_ProtocolInitiatedPlace.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_ProtocolType.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (textBox_EarliestDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }

              if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              //if (textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim() == "/  /       :")
              //{
              //    return false;
              //}


              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_PlateletCount.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_AlteredMentalStatus.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_InfectionEtiology.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_LowerRespiratoryInfection.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_Bandemia.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_SiteofInfection.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (comboBox_ICU.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_ChronicRespiratoryFailure.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (comboBox_AIDSDisease.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_MetastaticCancer.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_Lymphoma.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_ImmuneModifyingMedications.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_CongestiveHeartFailure.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_ChronicRenalFailure.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_ChronicLiverDisease.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_Diabetes.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_OrganTransplant.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

           
              
              // Dependency validations
              if ((comboBox_Payor.SelectedValue.ToString() == "C" || comboBox_Payor.SelectedValue.ToString() == "D" || comboBox_Payor.SelectedValue.ToString() == "F" || comboBox_Payor.SelectedValue.ToString() == "G") && TextBox_InsuranceNumber.Text.ToString().Trim()=="")
              {

                  return false;

              }

              if ((comboBox_TransferStatus.SelectedValue.ToString() == "3" || comboBox_TransferStatus.SelectedValue.ToString() == "4" || comboBox_TransferStatus.SelectedValue.ToString() == "5") && textBox_TransferFacilityIdentifier.Text.Trim() == "")
              {
                  return false;
              }

              if (comboBox_ICU.SelectedValue.ToString() == "1" && textBox_ICUAdmissionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_ICU.SelectedValue.ToString() == "1" && textBox_ICUDischargeDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "1" && textBox_MechanicalVentilationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_VitalSignsReview.SelectedValue.ToString() == "1" && textBox_VitalSignsReviewDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_VitalSignsReview.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_FluidChallengePerformed.SelectedValue.ToString() == "1" && textBox_FluidChallengePerformedDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_FluidChallengePerformed.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (comboBox_CentralVenousPressureMeasurement.SelectedValue.ToString() == "1" && textBox_CentralVenousPressureMeasurementDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_CentralVenousPressureMeasurement.SelectedValue.ToString() == "Select")
              {
                  return false;
              }




              if (comboBox_CentralVenousOxygenMeasurement.SelectedValue.ToString() == "1" && textBox_CentralVenousOxygenMeasurementDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_CentralVenousOxygenMeasurement.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_SkinExamination.SelectedValue.ToString() == "1" && textBox_SkinExaminationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_SkinExamination.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (comboBox_PeripheralPulseEvaluation.SelectedValue.ToString() == "1" && textBox_PeripheralPulseEvaluationDatetime.Text.ToString().Trim() == "")
              {
                  return false;
              }



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_PeripheralPulseEvaluation.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (comboBox_PassiveLegRaiseExamination.SelectedValue.ToString() == "1" && textBox_PassiveLegRaiseExaminationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_PassiveLegRaiseExamination.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (comboBox_CardiopulmonaryEvaluation.SelectedValue.ToString() == "1" && textBox_CardiopulmonaryEvaluationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_CardiopulmonaryEvaluation.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (comboBox_CapillaryRefillExamination.SelectedValue.ToString() == "1" && textBox_CapillaryRefillExaminationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_CapillaryRefillExamination.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (comboBox_BedsideCardiovascularUltrasound.SelectedValue.ToString() == "1" && textBox_BedsideCardiovascularUltrasoundDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_BedsideCardiovascularUltrasound.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_BedsideCardiovascularUltrasound.SelectedValue.ToString() == "1" && textBox_BedsideCardiovascularUltrasoundDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_BedsideCardiovascularUltrasound.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (comboBox_VasopressorAdministration.SelectedValue.ToString() == "1" && textBox_VasopressorAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_AntibioticAdministration.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_InitialHypotension.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_PersistentHypotension.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_VasopressorAdministration.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && textBox_CrystalloidFluidAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }

              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_ProtocolType.SelectedValue.ToString() == "1" && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_ProtocolType.SelectedValue.ToString() == "2" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1" && textBox_AntibioticAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1" && comboBox_AntibioticAdministrationSelection.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && comboBox_BloodCulturePathogen.SelectedValue.ToString() == "Select")
              {
                  return false;
              }
            



              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && comboBoX_BloodCultureResult.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && textBox_BloodCultureCollectionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && comboBox_BloodCultureCollectionAcceptableDelay.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_BloodCultureCollection.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "1" && textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1" && textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1" && comboBox_InitialLactateLevelUnit.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (textBox_LeftEDDatetime.Text.ToString().Trim() != "/  /       :" && comboBox_DestinationafterED.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (textbox_TriageDatetime.Text.ToString().Trim() != "/  /       :" && textBox_LeftEDDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }



              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1" && checkedListBox_ExcludedReason.CheckedItems.Count == 0)
              {
                  return false;
              }



              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1" && textBox_ExcludedDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_ProtocolInitiated.SelectedValue.ToString() == "0" && comboBox_ProtocolNotInitiatedReason.SelectedValue.ToString().Trim() == "Select")
              {
                  return false;
              }


              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && textBox_septicShockPresentationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }

              if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "1" && textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }




              for (int i = 0; i < checkedListBox_ExcludedReason.Items.Count; i++)
              {
                  if (checkedListBox_ExcludedReason.GetItemChecked(i) == true)
                  {
                      DataRowView castedItem = checkedListBox_ExcludedReason.Items[i] as DataRowView;
                      if (castedItem["ComboBox_Key"].ToString() == "1")
                      {
                          ExcludedResonChecked = 1;
                          break;
                      }
                  }

              }


              if (ExcludedResonChecked == 1 && checkedListBox_ExcludedExplain.CheckedItems.Count <= 0)
              {
                  ExcludedResonChecked = 0;
                  return false;

              }
          
            


        

              return true;


          }

          private void comboBox_DestinationafterED_SelectedIndexChanged(object sender, EventArgs e)
          {


              if (textBox_LeftEDDatetime.Text.ToString().Trim() != "/  /       :" && comboBox_DestinationafterED.SelectedValue.ToString() == "Select")
              {
                  MessageBox.Show("Please select appropriate response for DestinationafterED.", "Admission Datetime Error");
                  comboBox_DestinationafterED.Focus();

              }

              //if (textBox_LeftEDDatetime.Text.ToString().Trim() == "/  /       :" && comboBox_DestinationafterED.SelectedValue.ToString() != "Select")
              //{
              //    MessageBox.Show("Please add appropriate datetime to 'Left ED Datetime'.", "Admission Datetime Error");
              //    textBox_BloodCultureCollectionDatetime.Focus();

              //}

          }

      



          public void LoadEditData(int id)
          {
              try
              {
            
              DateTime dt;

              ds = new DataSet();

              //using (SqlConnection Conn = new SqlConnection(ConnectionString))
              using (Conn = new OdbcConnection(ConnectionString))
              {
                  Conn.Open();

                  //query = "select UniqueId, unique_personal_identifier, patient_control_number, date_of_birth, medical_record_number,Date_Created, Record_Completed, CSVGenerated from sepsis_collab ";
                  //query = query + "where Version = " + comboBox_Version.Text.ToString().Trim();
                  //query = "Sepsis_SelectEdit";
                  query = "{call Sepsis_SelectEdit (?)}";

                  //using (SqlCommand Sqlcmd = new SqlCommand())
                  using (OdbcCommand Sqlcmd = new OdbcCommand())
                  {


                      Sqlcmd.CommandText = query;
                      Sqlcmd.CommandType = CommandType.StoredProcedure;

                      Sqlcmd.Connection = Conn;


                      Sqlcmd.Parameters.Add(new OdbcParameter("UniqueId", id));

                      OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter(Sqlcmd);

                      dbDataAdapter.Fill(ds, "Edit");


                      if(ds.Tables["Edit"].Rows.Count  >= 1)
                      {
                          

                          txtId.Text = ds.Tables["Edit"].Rows[0]["unique_personal_identifier"].ToString().Trim();
                          TextBox_PatientCtrlNum.Text = ds.Tables["Edit"].Rows[0]["patient_control_number"].ToString().Trim();

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["date_of_birth"].ToString().Trim()) != true)
                          {
                                 dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["date_of_birth"].ToString().Trim());
                          txtDOB.Text = dt.ToString("MM/dd/yyyy");
                          }
                       
                       
                          Combobox_Gender.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Gender"].ToString().Trim());

                         
                          if (IsnullString(ds.Tables["Edit"].Rows[0]["Race"].ToString().Trim()) != null)
                          {


                              ProgramNames = ds.Tables["Edit"].Rows[0]["Race"].ToString().Trim().Split(':');
                              foreach (string Program in ProgramNames)
                              {


                                  foreach (object itemChecked in checkedListBox_Race.Items)
                                  {

                                      DataRowView castedItem = itemChecked as DataRowView;

                                      if (castedItem["ComboBox_Key"].ToString() == Program)
                                      {
                                          list.Add(temp);
                                          break;
                                      }
                                      temp++;
                                  }
                                  temp = 0;
                              }


                              for (int i = 0; i <= list.Count-1; i++)
                              {
                                  checkedListBox_Race.SetItemChecked(int.Parse(list[i].ToString()), true);
                              }
                              list.Clear();
            
                          }
                         
                          //if (checkedListBox_Race.CheckedItems.Count > 0)
                          //{
                          //    foreach (object itemChecked in checkedListBox_Race.CheckedItems)
                          //    {

                          //        DataRowView castedItem = itemChecked as DataRowView;

                          //        if (count > 0)
                          //        {
                          //            A.Race = A.Race + ":" + castedItem["ComboBox_Key"].ToString();
                          //        }
                          //        else
                          //        {
                          //            A.Race = castedItem["ComboBox_Key"].ToString();
                          //        }
                          //        count++;
                          //    }

                          //    count = 0;
                          //}
                          //else
                          //{
                          //    A.Race = null;
                          //}


                          
                          Combobox_Ethnicity.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Ethnicity"].ToString().Trim());
                          comboBox_Payor.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Payer"].ToString().Trim());
                          TextBox_InsuranceNumber.Text = ds.Tables["Edit"].Rows[0]["insurance_number"].ToString().Trim();
                          txtMRN.Text = ds.Tables["Edit"].Rows[0]["medical_record_number"].ToString().Trim();
                          TextBox_FacilityIdentifier.Text = ds.Tables["Edit"].Rows[0]["facility_identifier"].ToString().Trim();


                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["admission_datetime"].ToString().Trim()) != true)
                          {

                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["admission_datetime"].ToString().Trim(), new CultureInfo("en-US"));
                            textBox_AdmissionDateTime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                       


                          comboBox_SourceofAdmission.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["source_of_admission"].ToString().Trim());


                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["discharge_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["discharge_datetime"].ToString().Trim());
                            textBox_DischargedDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          

                          comboBox_DischargeStatus.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["discharge_status"].ToString().Trim());
                          comboBox_TransferStatus.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["transfer_status"].ToString().Trim());
                          textBox_TransferFacilityIdentifier.Text = ds.Tables["Edit"].Rows[0]["transfer_facility_identifier"].ToString().Trim();
                          comboBox_ProtocolInitiated.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["protocol_initiated"].ToString().Trim());
                          comboBox_ProtocolNotInitiatedReason.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["protocol_not_initiated_reason"].ToString().Trim());
                          textBox_ProtocolNIAdditionalDetail.Text = ds.Tables["Edit"].Rows[0]["protocol_ni_initiated_reason_additional_detail"].ToString().Trim();
                          comboBox_ProtocolInitiatedPlace.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["protocol_initiated_place"].ToString().Trim());
                          comboBox_ProtocolType.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["protocol_type"].ToString().Trim());
                          comboBox_ExcludedFromProtocol.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["excluded_from_protocol"].ToString().Trim());






                          if (IsnullString(ds.Tables["Edit"].Rows[0]["excluded_reason"].ToString().Trim()) != null)
                          {


                            ProgramNames = ds.Tables["Edit"].Rows[0]["excluded_reason"].ToString().Trim().Split(':');
                              foreach (string Program in ProgramNames)
                              {


                                  foreach (object itemChecked in checkedListBox_ExcludedReason.Items)
                                  {

                                      DataRowView castedItem = itemChecked as DataRowView;

                                      if (castedItem["ComboBox_Key"].ToString() == Program)
                                      {
                                          list.Add(temp);
                                          break;
                                      }
                                      temp++;
                                  }
                                  temp = 0;
                              }


                              for (int i = 0; i <= list.Count - 1; i++)
                              {
                                  checkedListBox_ExcludedReason.SetItemChecked(int.Parse(list[i].ToString()), true);
                              }
                              list.Clear();

                          }




                          //if (checkedListBox_ExcludedReason.CheckedItems.Count > 0)
                          //{
                          //    foreach (object itemChecked in checkedListBox_ExcludedReason.CheckedItems)
                          //    {

                          //        DataRowView castedItem = itemChecked as DataRowView;

                          //        if (count > 0)
                          //        {
                          //            A.ExcludedReason = A.ExcludedReason + ":" + castedItem["ComboBox_Key"].ToString();
                          //        }
                          //        else
                          //        {
                          //            A.ExcludedReason = castedItem["ComboBox_Key"].ToString();
                          //        }
                          //        count++;
                          //    }
                          //    count = 0;
                          //}
                          //else
                          //{
                          //    A.ExcludedReason = null;
                          //}





                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["Excluded_Datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["Excluded_Datetime"].ToString().Trim());
                              textBox_ExcludedDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }





                          if (IsnullString(ds.Tables["Edit"].Rows[0]["Excluded_Explain"].ToString().Trim()) != null)
                          {


                            ProgramNames = ds.Tables["Edit"].Rows[0]["Excluded_Explain"].ToString().Trim().Split(':');
                              foreach (string Program in ProgramNames)
                              {


                                  foreach (object itemChecked in checkedListBox_ExcludedExplain.Items)
                                  {

                                      DataRowView castedItem = itemChecked as DataRowView;

                                      if (castedItem["ComboBox_Key"].ToString() == Program)
                                      {
                                          list.Add(temp);
                                          break;
                                      }
                                      temp++;
                                  }
                                  temp = 0;
                              }


                              for (int i = 0; i <= list.Count - 1; i++)
                              {
                                  checkedListBox_ExcludedExplain.SetItemChecked(int.Parse(list[i].ToString()), true);
                              }
                              list.Clear();

                          }



                          //if (checkedListBox_ExcludedExplain.CheckedItems.Count > 0)
                          //{
                          //    foreach (object itemChecked in checkedListBox_ExcludedExplain.CheckedItems)
                          //    {

                          //        DataRowView castedItem = itemChecked as DataRowView;

                          //        if (count > 0)
                          //        {
                          //            A.ExcludedExplain = A.ExcludedExplain + ":" + castedItem["ComboBox_Key"].ToString();
                          //        }
                          //        else
                          //        {
                          //            A.ExcludedExplain = castedItem["ComboBox_Key"].ToString();
                          //        }
                          //        count++;
                          //    }
                          //    count = 0;
                          //}
                          //else
                          //{
                          //    A.ExcludedExplain = null;
                          //}



                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["Earliest_DateTime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["Earliest_DateTime"].ToString().Trim());
                              textBox_EarliestDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["Triage_Datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["Triage_Datetime"].ToString().Trim());
                              textbox_TriageDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                      

                        
                          comboBox_SevereSepsisPresent.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Severe_Sepsis_Present"].ToString().Trim());
                         // textBox_SevereSepsisPresentationDatetime.Text = ds.Tables["Edit"].Rows[0]["severe_sepsis_present_datetime"].ToString().Trim();


                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["severe_sepsis_present_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["severe_sepsis_present_datetime"].ToString().Trim());
                              textBox_SevereSepsisPresentationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }


                          comboBox_SepticShockPresent.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Septic_Shock_Present"].ToString().Trim());


                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["septic_shock_present_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["septic_shock_present_datetime"].ToString().Trim());
                              textBox_septicShockPresentationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                         // textBox_septicShockPresentationDatetime.Text = ds.Tables["Edit"].Rows[0]["septic_shock_present_datetime"].ToString().Trim();
                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["Left_ED_Datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["Left_ED_Datetime"].ToString().Trim());
                              textBox_LeftEDDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }

                          //textBox_LeftEDDatetime.Text = ds.Tables["Edit"].Rows[0]["Left_ED_Datetime"].ToString().Trim();
                          comboBox_DestinationafterED.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Destination_After_ED"].ToString().Trim());
                          comboBox_InitialLactateLevelCollection.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["initial_lactate_level_collection"].ToString().Trim());
                         // textBox_InitialLactateLevelCollectionDatetime.Text = ds.Tables["Edit"].Rows[0]["initial_lactate_level_collection_datetime"].ToString().Trim();

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["initial_lactate_level_collection_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["initial_lactate_level_collection_datetime"].ToString().Trim());
                              textBox_InitialLactateLevelCollectionDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }

                          textBox_InitialLactateLevel.Text = ds.Tables["Edit"].Rows[0]["initial_lactate_level"].ToString().Trim();

                          textBox_InitialLactateLevel.Text.PadLeft(4);
                          comboBox_InitialLactateLevelUnit.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["initial_lactate_level_unit"].ToString().Trim());
                          comboBox_RepeatLactateLevelCollection.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["repeat_lactate_level_collection"].ToString().Trim());


                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["repeat_lactate_level_collection_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["repeat_lactate_level_collection_datetime"].ToString().Trim());
                              textbox_RepeatLactateLevelCollectionDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          
                          
                          //textbox_RepeatLactateLevelCollectionDatetime.Text = ds.Tables["Edit"].Rows[0]["repeat_lactate_level_collection_datetime"].ToString().Trim();
                          comboBox_BloodCultureCollection.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["blood_culture_collection"].ToString().Trim());
                          comboBox_BloodCultureCollectionAcceptableDelay.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["blood_culture_collection_acceptable_delay"].ToString().Trim());



                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["blood_culture_collection_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["blood_culture_collection_datetime"].ToString().Trim());
                              textBox_BloodCultureCollectionDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          
                          //textBox_BloodCultureCollectionDatetime.Text = ds.Tables["Edit"].Rows[0]["blood_culture_collection_datetime"].ToString().Trim();
                          comboBoX_BloodCultureResult.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["blood_culture_result"].ToString().Trim());
                          comboBox_BloodCulturePathogen.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["blood_culture_pathogen"].ToString().Trim());
                          comboBox_AntibioticAdministration.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["antibiotic_administration"].ToString().Trim());
                          comboBox_AntibioticAdministrationSelection.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["antibiotic_administration_selection"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["antibiotic_administration_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["antibiotic_administration_datetime"].ToString().Trim());
                              textBox_AntibioticAdministrationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                         // textBox_AntibioticAdministrationDatetime.Text = ds.Tables["Edit"].Rows[0]["antibiotic_administration_datetime"].ToString().Trim();
                          comboBox_AdultCrystalloidFluidAdministration.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["adult_crystalloid_fluid_administration"].ToString().Trim());
                          comboBox_PediatricCrystalloidFluidAdministration.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["pediatric_crystalloid_fluid_administration"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["crystalloid_fluid_administration_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["crystalloid_fluid_administration_datetime"].ToString().Trim());
                              textBox_CrystalloidFluidAdministrationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          //textBox_CrystalloidFluidAdministrationDatetime.Text = ds.Tables["Edit"].Rows[0]["crystalloid_fluid_administration_datetime"].ToString().Trim();
                          comboBox_InitialHypotension.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["initial_hypotension"].ToString().Trim());
                          comboBox_PersistentHypotension.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["persistent_hypotension"].ToString().Trim());
                          comboBox_VasopressorAdministration.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["vasopressor_administration"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["vasopressor_administration_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["vasopressor_administration_datetime"].ToString().Trim());
                              textBox_VasopressorAdministrationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          //textBox_VasopressorAdministrationDatetime.Text = ds.Tables["Edit"].Rows[0]["vasopressor_administration_datetime"].ToString().Trim();
                          comboBox_BedsideCardiovascularUltrasound.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["bedside_cardiovascular_ultrasound"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["bedside_cardiovascular_ultrasound_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["bedside_cardiovascular_ultrasound_datetime"].ToString().Trim());
                              textBox_BedsideCardiovascularUltrasoundDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          //textBox_BedsideCardiovascularUltrasoundDatetime.Text = ds.Tables["Edit"].Rows[0]["bedside_cardiovascular_ultrasound_datetime"].ToString().Trim();
                          comboBox_CapillaryRefillExamination.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["capillary_refill_examination"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["capillary_refill_examination_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["capillary_refill_examination_datetime"].ToString().Trim());
                              textBox_CapillaryRefillExaminationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          //textBox_CapillaryRefillExaminationDatetime.Text = ds.Tables["Edit"].Rows[0]["capillary_refill_examination_datetime"].ToString().Trim();
                          comboBox_CardiopulmonaryEvaluation.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["cardiopulmonary_evaluation"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["cardiopulmonary_evaluation_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["cardiopulmonary_evaluation_datetime"].ToString().Trim());
                              textBox_CardiopulmonaryEvaluationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          //textBox_CardiopulmonaryEvaluationDatetime.Text = ds.Tables["Edit"].Rows[0]["cardiopulmonary_evaluation_datetime"].ToString().Trim();
                          comboBox_PassiveLegRaiseExamination.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["passive_leg_raise_examination"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["passive_leg_raise_examination_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["passive_leg_raise_examination_datetime"].ToString().Trim());
                              textBox_PassiveLegRaiseExaminationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          
                          
                          //textBox_PassiveLegRaiseExaminationDatetime.Text = ds.Tables["Edit"].Rows[0]["passive_leg_raise_examination_datetime"].ToString().Trim();
                          comboBox_PeripheralPulseEvaluation.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["peripheral_pulse_evaluation"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["peripheral_pulse_evaluation_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["peripheral_pulse_evaluation_datetime"].ToString().Trim());
                              textBox_PeripheralPulseEvaluationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                         // textBox_PeripheralPulseEvaluationDatetime.Text = ds.Tables["Edit"].Rows[0]["peripheral_pulse_evaluation_datetime"].ToString().Trim();
                          comboBox_SkinExamination.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["skin_examination"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["skin_examination_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["skin_examination_datetime"].ToString().Trim());
                              textBox_SkinExaminationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                         // textBox_SkinExaminationDatetime.Text = ds.Tables["Edit"].Rows[0]["skin_examination_datetime"].ToString().Trim();
                          comboBox_CentralVenousOxygenMeasurement.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["central_venous_oxygen_measurement"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["central_venous_oxygen_measurement_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["central_venous_oxygen_measurement_datetime"].ToString().Trim());
                              textBox_CentralVenousOxygenMeasurementDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          //textBox_CentralVenousOxygenMeasurementDatetime.Text = ds.Tables["Edit"].Rows[0]["central_venus_oxygen_measurement_datetime"].ToString().Trim();
                          comboBox_CentralVenousPressureMeasurement.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["central_venous_pressure_measurement"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["central_venous_pressure_measurement_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["central_venous_pressure_measurement_datetime"].ToString().Trim());
                              textBox_CentralVenousPressureMeasurementDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          //textBox_CentralVenousPressureMeasurementDatetime.Text = ds.Tables["Edit"].Rows[0]["central_venus_pressure_measurement_datetime"].ToString().Trim();
                          comboBox_FluidChallengePerformed.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["fluid_challenge_performed"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["fluid_challenge_performed_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["fluid_challenge_performed_datetime"].ToString().Trim());
                              textBox_FluidChallengePerformedDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                         // textBox_FluidChallengePerformedDatetime.Text = ds.Tables["Edit"].Rows[0]["fluid_challenge_performed_datetime"].ToString().Trim();
                          comboBox_VitalSignsReview.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["vital_signs_review"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["vital_signs_review_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["vital_signs_review_datetime"].ToString().Trim());
                              textBox_VitalSignsReviewDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                         // textBox_VitalSignsReviewDatetime.Text = ds.Tables["Edit"].Rows[0]["vital_signs_review_datetime"].ToString().Trim();
                          comboBox_PlateletCount.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["platelet_count"].ToString().Trim());
                          comboBox_Bandemia.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Bandemia"].ToString().Trim());
                          comboBox_LowerRespiratoryInfection.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["lower_respiratory_infection"].ToString().Trim());
                          comboBox_AlteredMentalStatus.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["altered_mental_status"].ToString().Trim());
                          comboBox_InfectionEtiology.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["infection_etiology"].ToString().Trim());
                          comboBox_SiteofInfection.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["site_of_infection"].ToString().Trim());
                          comboBox_MechanicalVentilation.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["mechanical_ventilation"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["mechanical_ventilation_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["mechanical_ventilation_datetime"].ToString().Trim());
                              textBox_MechanicalVentilationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          //textBox_MechanicalVentilationDatetime.Text = ds.Tables["Edit"].Rows[0]["mechanical_ventilation_datetime"].ToString().Trim();
                          comboBox_ICU.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["ICU"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["icu_admission_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["icu_admission_datetime"].ToString().Trim());
                              textBox_ICUAdmissionDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          //textBox_ICUAdmissionDatetime.Text = ds.Tables["Edit"].Rows[0]["icu_admission_datetime"].ToString().Trim();

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["icu_discharge_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["icu_discharge_datetime"].ToString().Trim());
                              textBox_ICUDischargeDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                         // textBox_ICUDischargeDatetime.Text = ds.Tables["Edit"].Rows[0]["icu_discharge_datetime"].ToString().Trim();
                          comboBox_ChronicRespiratoryFailure.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["chronic_respiratory_failure"].ToString().Trim());
                          comboBox_AIDSDisease.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["aids_hiv_disease"].ToString().Trim());
                          comboBox_MetastaticCancer.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["metastatic_cancer"].ToString().Trim());
                          comboBox_Lymphoma.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["lymphoma_leukemia_multiple_myeloma"].ToString().Trim());
                          comboBox_ImmuneModifyingMedications.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["immune_modifying_medications"].ToString().Trim());
                          comboBox_CongestiveHeartFailure.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["congestive_heart_failure"].ToString().Trim());
                          comboBox_ChronicRenalFailure.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["chronic_renal_failure"].ToString().Trim());
                          comboBox_ChronicLiverDisease.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["chronic_liver_disease"].ToString().Trim());
                          comboBox_Diabetes.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Diabetes"].ToString().Trim());
                          comboBox_OrganTransplant.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["organ_transplant"].ToString().Trim());
                          //A.Year = "4.1";
                          //A.Version = "2017";
                          //A.Quarter = "Q1";
                          //A.DateCreated = DateTime.Now;
                          //A.RecordCompleted = false;
                          //A.CSVGenerated = false;




                      }


              


                  }


                  Conn.Close();
              }

            }
            catch (Exception ex)
            {
                int line = 0;

                StackTrace st = new StackTrace(true);
                for (int i = 0; i < st.FrameCount; i++)
                {
               
                    StackFrame sf = st.GetFrame(i);
                      var frame =  sf.GetMethod();
                      line =  sf.GetFileLineNumber();

                      if (line > 0)
                          break;

                }


                using (Conn = new OdbcConnection(ConnectionString))
                {
                    Conn.Open();

                    query = "{call Sepsis_ErrorLog(?,?,?,?)}";

                    //using (SqlCommand Sqlcmd = new SqlCommand())
                    using (OdbcCommand Sqlcmd = new OdbcCommand())
                    {

                        Sqlcmd.CommandText = query;
                        Sqlcmd.CommandType = CommandType.StoredProcedure;
                        Sqlcmd.Connection = Conn;

                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Line",line));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Desc", ex.Message));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Form", "SepsisCaseDetails.cs"));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Datetime", DateTime.Now));
                 

                        Sqlcmd.ExecuteNonQuery();

        

                      
                        Conn.Close();
                  


                    }
                }



               //MessageBox.Show(ex.Message);
            }
             
          }

          public void HideDependentFields()
          {
              lbl_ExcludedReason.Hide();
              lbl_ExcludedExplain.Hide();
              lbl_ExcludedDatetime.Hide();
              lbl_LeftEDDatetime.Hide();
              lbl_DestinationafterED.Hide();
              lbl_InitialLactateLevelCollectionDatetime.Hide();
              lbl_InitialLactateLevelUnit.Hide();
              lbl_BloodCultureCollection.Hide();
              lbl_InitialLactateLevelCollection.Hide();
              lbl_RepeatLactateLevelCollectionDatetime.Hide();
              lbl_BloodCultureCollectionDatetime.Hide();
              lbl_BloodCultureCollectionAcceptableDelay.Hide();
              lbl_BloodCultureResult.Hide();
              lbl_BloodCulturePathogen.Hide();
              lbl_AntibioticAdministrationSelection.Hide();
              lbl_AntibioticAdministrationDatetime.Hide();
              lbl_AdultCrystalloidFluidAdministration.Hide();
              lbl_PediatricCrystalloidFluidAdministration.Hide();
              lbl_CrystalloidFluidAdministrationDatetime.Hide();
              lbl_InitialHypotension.Hide();
              lbl_PersistentHypotension.Hide();
              lbl_VasopressorAdministration.Hide();
              lbl_VasopressorAdministrationDateTime.Hide();
              lbl_CapillaryRefillExaminationDatetime.Hide();
              lbl_PeripheralPulseEvaluationDatetime.Hide();
              lbl_CentralVenousOxygenMeasurementDatetime.Hide();
              lbl_FluidChallengePerformedDatetime.Hide();
              lbl_BedsideCardioUltrasoundDateTime.Hide();
              lbl_CardiopulmonaryEvaluation.Hide();
              lbl_CardiopulmonaryEvaluationDatetime.Hide();
              lbl_PassiveLegRaiseExaminationDatetime.Hide();
              lbl_SkinExaminationDateTime.Hide();
              lbl_CVPressureMeasurementDateTime.Hide();
              lblVitalSignsReviewDatetime.Hide();
              lbl_BedsideCardiovascularUltrasound.Hide();
              lbl_PassiveLegRaiseExamination.Hide();
              lbl_SkinExamination.Hide();
              lbl_CVPressureMeasurement.Hide();
              lbl_VitalSignsReview.Hide();
              lbl_CapillaryRefillExamination.Hide();
              lbl_PeripheralPulseEvaluation.Hide();
              //label_CentralVenousOxygenMeasurement.Hide();
              lbl_FluidChallengePerformed.Hide();
              lbl_MechanicalVentilationDatetime.Hide();
              lbl_ICUAdmissionDatetime.Hide();
              lbl_ICUDischargeDatetime.Hide();
              lbl_ProtocolNotInitiatedReason.Hide();
              lbl_ExcludedExplain.Hide();
              lbl_TransferFacilityIdentifier.Hide();
              lbl_InsuranceNumber.Hide();


              textBox_LeftEDDatetime.Enabled = false;
              comboBox_DestinationafterED.Enabled = false;
              textBox_ICUAdmissionDatetime.Enabled = false;
              textBox_ICUDischargeDatetime.Enabled = false;
              textBox_MechanicalVentilationDatetime.Enabled = false;
              textBox_VitalSignsReviewDatetime.Enabled = false;
              textBox_FluidChallengePerformedDatetime.Enabled = false;
              textBox_CentralVenousOxygenMeasurementDatetime.Enabled = false;
              textBox_PeripheralPulseEvaluationDatetime.Enabled = false;
              textBox_CapillaryRefillExaminationDatetime.Enabled = false;
              textBox_VasopressorAdministrationDatetime.Enabled = false;
              textBox_BedsideCardiovascularUltrasoundDatetime.Enabled = false;
              textBox_CardiopulmonaryEvaluationDatetime.Enabled = false;
              textBox_PassiveLegRaiseExaminationDatetime.Enabled = false;
              textBox_SkinExaminationDatetime.Enabled = false;
              textBox_CentralVenousPressureMeasurementDatetime.Enabled = false;
              textBox_CrystalloidFluidAdministrationDatetime.Enabled = false;
              comboBox_BedsideCardiovascularUltrasound.Enabled = false;
              comboBox_CapillaryRefillExamination.Enabled = false;
              comboBox_CardiopulmonaryEvaluation.Enabled = false;
              comboBox_PassiveLegRaiseExamination.Enabled = false;
              comboBox_PeripheralPulseEvaluation.Enabled = false;
              comboBox_SkinExamination.Enabled = false;
              comboBox_VitalSignsReview.Enabled = false;
              comboBox_CentralVenousOxygenMeasurement.Enabled = false;
              comboBox_CentralVenousPressureMeasurement.Enabled = false;
              comboBox_FluidChallengePerformed.Enabled = false;
              comboBox_InitialHypotension.Enabled = false;
              comboBox_PersistentHypotension.Enabled = false;
              comboBox_VasopressorAdministration.Enabled = false;
              comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
              comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
              //comboBox_BloodCultureCollection.Enabled = false;
              textBox_ExcludedDatetime.Enabled = false;
              checkedListBox_ExcludedReason.Enabled = false;
              textBox_AntibioticAdministrationDatetime.Enabled = false;
              comboBox_AntibioticAdministrationSelection.Enabled = false;
              textBox_BloodCultureCollectionDatetime.Enabled = false;
              comboBox_BloodCulturePathogen.Enabled = false;
              comboBoX_BloodCultureResult.Enabled = false;
              comboBox_BloodCultureCollectionAcceptableDelay.Enabled = false;
              textbox_RepeatLactateLevelCollectionDatetime.Enabled = false;
              textBox_InitialLactateLevelCollectionDatetime.Enabled = false;
              comboBox_InitialLactateLevelUnit.Enabled = false;
             // textBox_TransferFacilityIdentifier.Enabled = false;
              comboBox_RepeatLactateLevelCollection.Enabled = false;
              checkedListBox_ExcludedExplain.Enabled = false;


          }

          private void comboBox_ICU_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_ICU.SelectedValue.ToString() == "1")
              {
                  lbl_ICUAdmissionDatetime.Show();
                  lbl_ICUDischargeDatetime.Show();
                  textBox_ICUAdmissionDatetime.Enabled = true;
                  textBox_ICUDischargeDatetime.Enabled = true;
                  textBox_ICUAdmissionDatetime.BackColor = MandatoryColor(Color.White);
                  textBox_ICUDischargeDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lbl_ICUAdmissionDatetime.Hide();
                  lbl_ICUDischargeDatetime.Hide();
                  textBox_ICUAdmissionDatetime.Enabled = false;
                  textBox_ICUDischargeDatetime.Enabled = false;

                  textBox_ICUAdmissionDatetime.BackColor = MandatoryColor(Color.Gray);
                  textBox_ICUDischargeDatetime.BackColor = MandatoryColor(Color.Gray);
                  textBox_ICUAdmissionDatetime.Text = "";
                  textBox_ICUDischargeDatetime.Text = "";
              }



          }

          private void comboBox_MechanicalVentilation_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "1")
              {
                  lbl_MechanicalVentilationDatetime.Show();
                  textBox_MechanicalVentilationDatetime.Enabled = true;
                  textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lbl_MechanicalVentilationDatetime.Hide();
                  textBox_MechanicalVentilationDatetime.Enabled = false;
                  textBox_MechanicalVentilationDatetime.Text = "";
                  textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.Gray);
              }

          }

          private void comboBox_VitalSignsReview_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_VitalSignsReview.SelectedValue.ToString() == "1")
              {
                  lblVitalSignsReviewDatetime.Show();
                  textBox_VitalSignsReviewDatetime.Enabled = true;
                  textBox_VitalSignsReviewDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lblVitalSignsReviewDatetime.Hide();
                  textBox_VitalSignsReviewDatetime.Enabled = false;
                  textBox_VitalSignsReviewDatetime.Text = "";
                  textBox_VitalSignsReviewDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void comboBox_FluidChallengePerformed_SelectedIndexChanged(object sender, EventArgs e)
          {
              
              if (comboBox_FluidChallengePerformed.SelectedValue.ToString() == "1")
              {
                  lbl_FluidChallengePerformedDatetime.Show();
                  textBox_FluidChallengePerformedDatetime.Enabled = true;
                  textBox_FluidChallengePerformedDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lbl_FluidChallengePerformedDatetime.Hide();
                  textBox_FluidChallengePerformedDatetime.Enabled = false;
                  textBox_FluidChallengePerformedDatetime.Text = "";

                  textBox_FluidChallengePerformedDatetime.BackColor = MandatoryColor(Color.Gray);
              }

          }

          private void comboBox_CentralVenousOxygenMeasurement_SelectedIndexChanged(object sender, EventArgs e)
          {
              
              if (comboBox_CentralVenousOxygenMeasurement.SelectedValue.ToString() == "1")
              {
                  lbl_CentralVenousOxygenMeasurementDatetime.Show();
                  textBox_CentralVenousOxygenMeasurementDatetime.Enabled = true;
                  textBox_CentralVenousOxygenMeasurementDatetime.BackColor = MandatoryColor(Color.White);

              }
              else
              {
                  lbl_CentralVenousOxygenMeasurementDatetime.Hide();
                  textBox_CentralVenousOxygenMeasurementDatetime.Enabled = false;
                  textBox_CentralVenousOxygenMeasurementDatetime.Text = "";
                  textBox_CentralVenousOxygenMeasurementDatetime.BackColor = MandatoryColor(Color.Gray);
              }

          }

          private void comboBox_PeripheralPulseEvaluation_SelectedIndexChanged(object sender, EventArgs e)
          {
              
              if (comboBox_PeripheralPulseEvaluation.SelectedValue.ToString() == "1")
              {
                  lbl_PeripheralPulseEvaluationDatetime.Show();
                  textBox_PeripheralPulseEvaluationDatetime.Enabled = true;
                  textBox_PeripheralPulseEvaluationDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lbl_PeripheralPulseEvaluationDatetime.Hide();
                  textBox_PeripheralPulseEvaluationDatetime.Enabled = false;
                  textBox_PeripheralPulseEvaluationDatetime.Text = "";

                  textBox_PeripheralPulseEvaluationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void comboBox_CapillaryRefillExamination_SelectedIndexChanged(object sender, EventArgs e)
          {
              
              if (comboBox_CapillaryRefillExamination.SelectedValue.ToString() == "1")
              {
                  lbl_CapillaryRefillExaminationDatetime.Show();
                  textBox_CapillaryRefillExaminationDatetime.Enabled = true;
                  textBox_CapillaryRefillExaminationDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lbl_CapillaryRefillExaminationDatetime.Hide();
                  textBox_CapillaryRefillExaminationDatetime.Enabled = false;
                  textBox_CapillaryRefillExaminationDatetime.Text = "";

                  textBox_CapillaryRefillExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void comboBox_VasopressorAdministration_SelectedIndexChanged(object sender, EventArgs e)
          {
              
              if (comboBox_VasopressorAdministration.SelectedValue.ToString() == "1")
              {
                  lbl_VasopressorAdministrationDateTime.Show();
                  textBox_VasopressorAdministrationDatetime.Enabled = true;
                  textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lbl_VasopressorAdministrationDateTime.Hide();
                  textBox_VasopressorAdministrationDatetime.Enabled = false;
                  textBox_VasopressorAdministrationDatetime.Text = "";

                  textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void comboBox_BedsideCardiovascularUltrasound_SelectedIndexChanged(object sender, EventArgs e)
          {

              if (comboBox_BedsideCardiovascularUltrasound.SelectedValue.ToString() == "1")
              {
                  lbl_BedsideCardioUltrasoundDateTime.Show();
                  textBox_BedsideCardiovascularUltrasoundDatetime.Enabled = true;
                  textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lbl_BedsideCardioUltrasoundDateTime.Hide();
                  textBox_BedsideCardiovascularUltrasoundDatetime.Enabled = false;
                  textBox_BedsideCardiovascularUltrasoundDatetime.Text = "";
                  textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void comboBox_CardiopulmonaryEvaluation_SelectedIndexChanged(object sender, EventArgs e)
          {

              if (comboBox_CardiopulmonaryEvaluation.SelectedValue.ToString() == "1")
              {
                  lbl_CardiopulmonaryEvaluationDatetime.Show();
                  textBox_CardiopulmonaryEvaluationDatetime.Enabled = true;
                  textBox_CardiopulmonaryEvaluationDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lbl_CardiopulmonaryEvaluationDatetime.Hide();
                  textBox_CardiopulmonaryEvaluationDatetime.Enabled = false;
                  textBox_CardiopulmonaryEvaluationDatetime.Text = "";
                  textBox_CardiopulmonaryEvaluationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void comboBox_PassiveLegRaiseExamination_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_PassiveLegRaiseExamination.SelectedValue.ToString() == "1")
              {

                  lbl_PassiveLegRaiseExaminationDatetime.Show();
                  textBox_PassiveLegRaiseExaminationDatetime.Enabled = true;
                  textBox_PassiveLegRaiseExaminationDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lbl_PassiveLegRaiseExaminationDatetime.Hide();
                  textBox_PassiveLegRaiseExaminationDatetime.Enabled = false;
                  textBox_PassiveLegRaiseExaminationDatetime.Text = "";

                  textBox_PassiveLegRaiseExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
              }

          }

          private void comboBox_SkinExamination_SelectedIndexChanged(object sender, EventArgs e)
          {
              

              if (comboBox_SkinExamination.SelectedValue.ToString() == "1")
              {
                  lbl_SkinExaminationDateTime.Show();
                  textBox_SkinExaminationDatetime.Enabled = true;
                  textBox_SkinExaminationDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lbl_SkinExaminationDateTime.Hide();
                  textBox_SkinExaminationDatetime.Enabled = false;
                  textBox_SkinExaminationDatetime.Text = "";
                  textBox_SkinExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void comboBox_CentralVenousPressureMeasurement_SelectedIndexChanged(object sender, EventArgs e)
          {

              
              if (comboBox_CentralVenousPressureMeasurement.SelectedValue.ToString() == "1")
              {
                  lbl_CVPressureMeasurementDateTime.Show();
                  textBox_CentralVenousPressureMeasurementDatetime.Enabled = true;
                  textBox_CentralVenousPressureMeasurementDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lbl_CVPressureMeasurementDateTime.Hide();
                  textBox_CentralVenousPressureMeasurementDatetime.Enabled = false;
                  textBox_CentralVenousPressureMeasurementDatetime.Text = "";
                  textBox_CentralVenousPressureMeasurementDatetime.BackColor = MandatoryColor(Color.Gray);
              }

          }

          private void comboBox_AdultCrystalloidFluidAdministration_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1" && comboBox_ProtocolType.SelectedValue.ToString() == "0")
              {

                  if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1")
                  {
                      lbl_CrystalloidFluidAdministrationDatetime.Show();
                      lbl_BedsideCardiovascularUltrasound.Show();
                      lbl_CapillaryRefillExamination.Show();
                      lbl_CardiopulmonaryEvaluation.Show();
                      lbl_PassiveLegRaiseExamination.Show();
                      lbl_PeripheralPulseEvaluation.Show();
                      lbl_SkinExamination.Show();
                      lbl_VitalSignsReview.Show();
                      lbl_CentralVenousOxygenMeasurement.Show();
                      lbl_CVPressureMeasurement.Show();
                      lbl_FluidChallengePerformed.Show();

                      textBox_CrystalloidFluidAdministrationDatetime.Enabled = true;
                      comboBox_BedsideCardiovascularUltrasound.Enabled = true;
                      comboBox_CapillaryRefillExamination.Enabled = true;
                      comboBox_CardiopulmonaryEvaluation.Enabled = true;
                      comboBox_PassiveLegRaiseExamination.Enabled = true;
                      comboBox_PeripheralPulseEvaluation.Enabled = true;
                      comboBox_SkinExamination.Enabled = true;
                      comboBox_VitalSignsReview.Enabled = true;
                      comboBox_CentralVenousOxygenMeasurement.Enabled = true;
                      comboBox_CentralVenousPressureMeasurement.Enabled = true;
                      comboBox_FluidChallengePerformed.Enabled = true;


                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.White);
                      comboBox_BedsideCardiovascularUltrasound.BackColor = result;
                      comboBox_CapillaryRefillExamination.BackColor = result;
                      comboBox_CardiopulmonaryEvaluation.BackColor = result;
                      comboBox_PassiveLegRaiseExamination.BackColor = result;
                      comboBox_PeripheralPulseEvaluation.BackColor = result;
                      comboBox_SkinExamination.BackColor = result;
                      comboBox_VitalSignsReview.BackColor = result;
                      comboBox_CentralVenousOxygenMeasurement.BackColor = result;
                      comboBox_CentralVenousPressureMeasurement.BackColor = result;
                      comboBox_FluidChallengePerformed.BackColor = result;
                  }
                  else
                  {
                      lbl_CrystalloidFluidAdministrationDatetime.Hide();
                      lbl_BedsideCardiovascularUltrasound.Hide();
                      lbl_CapillaryRefillExamination.Hide();
                      lbl_CardiopulmonaryEvaluation.Hide();
                      lbl_PassiveLegRaiseExamination.Hide();
                      lbl_PeripheralPulseEvaluation.Hide();
                      lbl_SkinExamination.Hide();
                      lbl_VitalSignsReview.Hide();
                      lbl_CentralVenousOxygenMeasurement.Hide();
                      lbl_CVPressureMeasurement.Hide();
                      lbl_FluidChallengePerformed.Hide();

                      textBox_CrystalloidFluidAdministrationDatetime.Enabled = false;
                      comboBox_BedsideCardiovascularUltrasound.Enabled = false;
                      comboBox_CapillaryRefillExamination.Enabled = false;
                      comboBox_CardiopulmonaryEvaluation.Enabled = false;
                      comboBox_PassiveLegRaiseExamination.Enabled = false;
                      comboBox_PeripheralPulseEvaluation.Enabled = false;
                      comboBox_SkinExamination.Enabled = false;
                      comboBox_VitalSignsReview.Enabled = false;
                      comboBox_CentralVenousOxygenMeasurement.Enabled = false;
                      comboBox_CentralVenousPressureMeasurement.Enabled = false;
                      comboBox_FluidChallengePerformed.Enabled = false;

                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                      comboBox_BedsideCardiovascularUltrasound.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CapillaryRefillExamination.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CardiopulmonaryEvaluation.BackColor = MandatoryColor(Color.Gray);
                      comboBox_PassiveLegRaiseExamination.BackColor = MandatoryColor(Color.Gray);
                      comboBox_PeripheralPulseEvaluation.BackColor = MandatoryColor(Color.Gray);
                      comboBox_SkinExamination.BackColor = MandatoryColor(Color.Gray);
                      comboBox_VitalSignsReview.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CentralVenousOxygenMeasurement.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CentralVenousPressureMeasurement.BackColor = MandatoryColor(Color.Gray);
                      comboBox_FluidChallengePerformed.BackColor = MandatoryColor(Color.Gray);

                      textBox_CrystalloidFluidAdministrationDatetime.Text = "";
                      comboBox_BedsideCardiovascularUltrasound.SelectedValue = "Select";
                      comboBox_CapillaryRefillExamination.SelectedValue = "Select";
                      comboBox_CardiopulmonaryEvaluation.SelectedValue = "Select";
                      comboBox_PassiveLegRaiseExamination.SelectedValue = "Select";
                      comboBox_PeripheralPulseEvaluation.SelectedValue = "Select";
                      comboBox_SkinExamination.SelectedValue = "Select";
                      comboBox_VitalSignsReview.SelectedValue = "Select";
                      comboBox_CentralVenousOxygenMeasurement.SelectedValue = "Select";
                      comboBox_CentralVenousPressureMeasurement.SelectedValue = "Select";
                      comboBox_FluidChallengePerformed.SelectedValue = "Select";
                  }



              }

              else
              {



                  if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1")
                  {

                      lbl_CrystalloidFluidAdministrationDatetime.Show();
                      lbl_BedsideCardiovascularUltrasound.Show();
                      lbl_CapillaryRefillExamination.Show();
                      lbl_CardiopulmonaryEvaluation.Show();
                      lbl_PassiveLegRaiseExamination.Show();
                      lbl_PeripheralPulseEvaluation.Show();
                      lbl_SkinExamination.Show();
                      lbl_VitalSignsReview.Show();
                      lbl_CentralVenousOxygenMeasurement.Show();
                      lbl_CVPressureMeasurement.Show();
                      lbl_FluidChallengePerformed.Show();

                      textBox_CrystalloidFluidAdministrationDatetime.Enabled = true;
                      comboBox_BedsideCardiovascularUltrasound.Enabled = true;
                      comboBox_CapillaryRefillExamination.Enabled = true;
                      comboBox_CardiopulmonaryEvaluation.Enabled = true;
                      comboBox_PassiveLegRaiseExamination.Enabled = true;
                      comboBox_PeripheralPulseEvaluation.Enabled = true;
                      comboBox_SkinExamination.Enabled = true;
                      comboBox_VitalSignsReview.Enabled = true;
                      comboBox_CentralVenousOxygenMeasurement.Enabled = true;
                      comboBox_CentralVenousPressureMeasurement.Enabled = true;
                      comboBox_FluidChallengePerformed.Enabled = true;


                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.White);
                      comboBox_BedsideCardiovascularUltrasound.BackColor = result;
                      comboBox_CapillaryRefillExamination.BackColor = result;
                      comboBox_CardiopulmonaryEvaluation.BackColor = result;
                      comboBox_PassiveLegRaiseExamination.BackColor = result;
                      comboBox_PeripheralPulseEvaluation.BackColor = result;
                      comboBox_SkinExamination.BackColor = result;
                      comboBox_VitalSignsReview.BackColor = result;
                      comboBox_CentralVenousOxygenMeasurement.BackColor = result;
                      comboBox_CentralVenousPressureMeasurement.BackColor = result;
                      comboBox_FluidChallengePerformed.BackColor = result;


                  }
                  else
                  {
                      lbl_CrystalloidFluidAdministrationDatetime.Hide();
                      lbl_BedsideCardiovascularUltrasound.Hide();
                      lbl_CapillaryRefillExamination.Hide();
                      lbl_CardiopulmonaryEvaluation.Hide();
                      lbl_PassiveLegRaiseExamination.Hide();
                      lbl_PeripheralPulseEvaluation.Hide();
                      lbl_SkinExamination.Hide();
                      lbl_VitalSignsReview.Hide();
                      lbl_CentralVenousOxygenMeasurement.Hide();
                      lbl_CVPressureMeasurement.Hide();
                      lbl_FluidChallengePerformed.Hide();

                      textBox_CrystalloidFluidAdministrationDatetime.Enabled = false;
                      comboBox_BedsideCardiovascularUltrasound.Enabled = false;
                      comboBox_CapillaryRefillExamination.Enabled = false;
                      comboBox_CardiopulmonaryEvaluation.Enabled = false;
                      comboBox_PassiveLegRaiseExamination.Enabled = false;
                      comboBox_PeripheralPulseEvaluation.Enabled = false;
                      comboBox_SkinExamination.Enabled = false;
                      comboBox_VitalSignsReview.Enabled = false;
                      comboBox_CentralVenousOxygenMeasurement.Enabled = false;
                      comboBox_CentralVenousPressureMeasurement.Enabled = false;
                      comboBox_FluidChallengePerformed.Enabled = false;

                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                      comboBox_BedsideCardiovascularUltrasound.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CapillaryRefillExamination.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CardiopulmonaryEvaluation.BackColor = MandatoryColor(Color.Gray);
                      comboBox_PassiveLegRaiseExamination.BackColor = MandatoryColor(Color.Gray);
                      comboBox_PeripheralPulseEvaluation.BackColor = MandatoryColor(Color.Gray);
                      comboBox_SkinExamination.BackColor = MandatoryColor(Color.Gray);
                      comboBox_VitalSignsReview.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CentralVenousOxygenMeasurement.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CentralVenousPressureMeasurement.BackColor = MandatoryColor(Color.Gray);
                      comboBox_FluidChallengePerformed.BackColor = MandatoryColor(Color.Gray);

                      textBox_CrystalloidFluidAdministrationDatetime.Text = "";
                      comboBox_BedsideCardiovascularUltrasound.SelectedValue = "Select";
                      comboBox_CapillaryRefillExamination.SelectedValue = "Select";
                      comboBox_CardiopulmonaryEvaluation.SelectedValue = "Select";
                      comboBox_PassiveLegRaiseExamination.SelectedValue = "Select";
                      comboBox_PeripheralPulseEvaluation.SelectedValue = "Select";
                      comboBox_SkinExamination.SelectedValue = "Select";
                      comboBox_VitalSignsReview.SelectedValue = "Select";
                      comboBox_CentralVenousOxygenMeasurement.SelectedValue = "Select";
                      comboBox_CentralVenousPressureMeasurement.SelectedValue = "Select";
                      comboBox_FluidChallengePerformed.SelectedValue = "Select";

                  }
              }
          }

          private void comboBox_PediatricCrystalloidFluidAdministration_SelectedIndexChanged(object sender, EventArgs e)
          {


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1" && comboBox_ProtocolType.SelectedValue.ToString() == "0")
              {

                  if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1")
                  {
                      lbl_CrystalloidFluidAdministrationDatetime.Show();
                      lbl_BedsideCardiovascularUltrasound.Show();
                      lbl_CapillaryRefillExamination.Show();
                      lbl_CardiopulmonaryEvaluation.Show();
                      lbl_PassiveLegRaiseExamination.Show();
                      lbl_PeripheralPulseEvaluation.Show();
                      lbl_SkinExamination.Show();
                      lbl_VitalSignsReview.Show();
                      lbl_CentralVenousOxygenMeasurement.Show();
                      lbl_CVPressureMeasurement.Show();
                      lbl_FluidChallengePerformed.Show();

                      textBox_CrystalloidFluidAdministrationDatetime.Enabled = true;
                      comboBox_BedsideCardiovascularUltrasound.Enabled = true;
                      comboBox_CapillaryRefillExamination.Enabled = true;
                      comboBox_CardiopulmonaryEvaluation.Enabled = true;
                      comboBox_PassiveLegRaiseExamination.Enabled = true;
                      comboBox_PeripheralPulseEvaluation.Enabled = true;
                      comboBox_SkinExamination.Enabled = true;
                      comboBox_VitalSignsReview.Enabled = true;
                      comboBox_CentralVenousOxygenMeasurement.Enabled = true;
                      comboBox_CentralVenousPressureMeasurement.Enabled = true;
                      comboBox_FluidChallengePerformed.Enabled = true;


                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.White);
                      comboBox_BedsideCardiovascularUltrasound.BackColor = result;
                      comboBox_CapillaryRefillExamination.BackColor = result;
                      comboBox_CardiopulmonaryEvaluation.BackColor = result;
                      comboBox_PassiveLegRaiseExamination.BackColor = result;
                      comboBox_PeripheralPulseEvaluation.BackColor = result;
                      comboBox_SkinExamination.BackColor = result;
                      comboBox_VitalSignsReview.BackColor = result;
                      comboBox_CentralVenousOxygenMeasurement.BackColor = result;
                      comboBox_CentralVenousPressureMeasurement.BackColor = result;
                      comboBox_FluidChallengePerformed.BackColor = result;
                  }
                  else
                  {
                      lbl_CrystalloidFluidAdministrationDatetime.Hide();
                      lbl_BedsideCardiovascularUltrasound.Hide();
                      lbl_CapillaryRefillExamination.Hide();
                      lbl_CardiopulmonaryEvaluation.Hide();
                      lbl_PassiveLegRaiseExamination.Hide();
                      lbl_PeripheralPulseEvaluation.Hide();
                      lbl_SkinExamination.Hide();
                      lbl_VitalSignsReview.Hide();
                      lbl_CentralVenousOxygenMeasurement.Hide();
                      lbl_CVPressureMeasurement.Hide();
                      lbl_FluidChallengePerformed.Hide();

                      textBox_CrystalloidFluidAdministrationDatetime.Enabled = false;
                      comboBox_BedsideCardiovascularUltrasound.Enabled = false;
                      comboBox_CapillaryRefillExamination.Enabled = false;
                      comboBox_CardiopulmonaryEvaluation.Enabled = false;
                      comboBox_PassiveLegRaiseExamination.Enabled = false;
                      comboBox_PeripheralPulseEvaluation.Enabled = false;
                      comboBox_SkinExamination.Enabled = false;
                      comboBox_VitalSignsReview.Enabled = false;
                      comboBox_CentralVenousOxygenMeasurement.Enabled = false;
                      comboBox_CentralVenousPressureMeasurement.Enabled = false;
                      comboBox_FluidChallengePerformed.Enabled = false;

                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                      comboBox_BedsideCardiovascularUltrasound.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CapillaryRefillExamination.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CardiopulmonaryEvaluation.BackColor = MandatoryColor(Color.Gray);
                      comboBox_PassiveLegRaiseExamination.BackColor = MandatoryColor(Color.Gray);
                      comboBox_PeripheralPulseEvaluation.BackColor = MandatoryColor(Color.Gray);
                      comboBox_SkinExamination.BackColor = MandatoryColor(Color.Gray);
                      comboBox_VitalSignsReview.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CentralVenousOxygenMeasurement.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CentralVenousPressureMeasurement.BackColor = MandatoryColor(Color.Gray);
                      comboBox_FluidChallengePerformed.BackColor = MandatoryColor(Color.Gray);

                      textBox_CrystalloidFluidAdministrationDatetime.Text = "";
                      comboBox_BedsideCardiovascularUltrasound.SelectedValue = "Select";
                      comboBox_CapillaryRefillExamination.SelectedValue = "Select";
                      comboBox_CardiopulmonaryEvaluation.SelectedValue = "Select";
                      comboBox_PassiveLegRaiseExamination.SelectedValue = "Select";
                      comboBox_PeripheralPulseEvaluation.SelectedValue = "Select";
                      comboBox_SkinExamination.SelectedValue = "Select";
                      comboBox_VitalSignsReview.SelectedValue = "Select";
                      comboBox_CentralVenousOxygenMeasurement.SelectedValue = "Select";
                      comboBox_CentralVenousPressureMeasurement.SelectedValue = "Select";
                      comboBox_FluidChallengePerformed.SelectedValue = "Select";
                  }



              }

              else
              {

                  if (comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1")
                  {

                      lbl_CrystalloidFluidAdministrationDatetime.Show();
                      lbl_BedsideCardiovascularUltrasound.Show();
                      lbl_CapillaryRefillExamination.Show();
                      lbl_CardiopulmonaryEvaluation.Show();
                      lbl_PassiveLegRaiseExamination.Show();
                      lbl_PeripheralPulseEvaluation.Show();
                      lbl_SkinExamination.Show();
                      lbl_VitalSignsReview.Show();
                      lbl_CentralVenousOxygenMeasurement.Show();
                      lbl_CVPressureMeasurement.Show();
                      lbl_FluidChallengePerformed.Show();

                      textBox_CrystalloidFluidAdministrationDatetime.Enabled = true;
                      comboBox_BedsideCardiovascularUltrasound.Enabled = true;
                      comboBox_CapillaryRefillExamination.Enabled = true;
                      comboBox_CardiopulmonaryEvaluation.Enabled = true;
                      comboBox_PassiveLegRaiseExamination.Enabled = true;
                      comboBox_PeripheralPulseEvaluation.Enabled = true;
                      comboBox_SkinExamination.Enabled = true;
                      comboBox_VitalSignsReview.Enabled = true;
                      comboBox_CentralVenousOxygenMeasurement.Enabled = true;
                      comboBox_CentralVenousPressureMeasurement.Enabled = true;
                      //lbl_CVPressureMeasurement.Enabled = true;
                      comboBox_FluidChallengePerformed.Enabled = true;


                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.White);
                      comboBox_BedsideCardiovascularUltrasound.BackColor = result;
                      comboBox_CapillaryRefillExamination.BackColor = result;
                      comboBox_CardiopulmonaryEvaluation.BackColor = result;
                      comboBox_PassiveLegRaiseExamination.BackColor = result;
                      comboBox_PeripheralPulseEvaluation.BackColor = result;
                      comboBox_SkinExamination.BackColor = result;
                      comboBox_VitalSignsReview.BackColor = result;
                      comboBox_CentralVenousOxygenMeasurement.BackColor = result;
                      comboBox_CentralVenousPressureMeasurement.BackColor = result;
                      comboBox_FluidChallengePerformed.BackColor = result;
                  }
                  else
                  {
                      lbl_CrystalloidFluidAdministrationDatetime.Hide();
                      lbl_BedsideCardiovascularUltrasound.Hide();
                      lbl_CapillaryRefillExamination.Hide();
                      lbl_CardiopulmonaryEvaluation.Hide();
                      lbl_PassiveLegRaiseExamination.Hide();
                      lbl_PeripheralPulseEvaluation.Hide();
                      lbl_SkinExamination.Hide();
                      lbl_VitalSignsReview.Hide();
                      lbl_CentralVenousOxygenMeasurement.Hide();
                      lbl_CVPressureMeasurement.Hide();
                      lbl_FluidChallengePerformed.Hide();

                      textBox_CrystalloidFluidAdministrationDatetime.Enabled = false;
                      comboBox_BedsideCardiovascularUltrasound.Enabled = false;
                      comboBox_CapillaryRefillExamination.Enabled = false;
                      comboBox_CardiopulmonaryEvaluation.Enabled = false;
                      comboBox_PassiveLegRaiseExamination.Enabled = false;
                      comboBox_PeripheralPulseEvaluation.Enabled = false;
                      comboBox_SkinExamination.Enabled = false;
                      comboBox_VitalSignsReview.Enabled = false;
                      comboBox_CentralVenousOxygenMeasurement.Enabled = false;
                      comboBox_CentralVenousPressureMeasurement.Enabled = false;
                      comboBox_FluidChallengePerformed.Enabled = false;

                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                      comboBox_BedsideCardiovascularUltrasound.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CapillaryRefillExamination.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CardiopulmonaryEvaluation.BackColor = MandatoryColor(Color.Gray);
                      comboBox_PassiveLegRaiseExamination.BackColor = MandatoryColor(Color.Gray);
                      comboBox_PeripheralPulseEvaluation.BackColor = MandatoryColor(Color.Gray);
                      comboBox_SkinExamination.BackColor = MandatoryColor(Color.Gray);
                      comboBox_VitalSignsReview.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CentralVenousOxygenMeasurement.BackColor = MandatoryColor(Color.Gray);
                      comboBox_CentralVenousPressureMeasurement.BackColor = MandatoryColor(Color.Gray);
                      comboBox_FluidChallengePerformed.BackColor = MandatoryColor(Color.Gray);

                      textBox_CrystalloidFluidAdministrationDatetime.Text = "";
                      comboBox_BedsideCardiovascularUltrasound.SelectedValue = "Select";
                      comboBox_CapillaryRefillExamination.SelectedValue = "Select";
                      comboBox_CardiopulmonaryEvaluation.SelectedValue = "Select";
                      comboBox_PassiveLegRaiseExamination.SelectedValue = "Select";
                      comboBox_PeripheralPulseEvaluation.SelectedValue = "Select";
                      comboBox_SkinExamination.SelectedValue = "Select";
                      comboBox_VitalSignsReview.SelectedValue = "Select";
                      comboBox_CentralVenousOxygenMeasurement.SelectedValue = "Select";
                      comboBox_CentralVenousPressureMeasurement.SelectedValue = "Select";
                      comboBox_FluidChallengePerformed.SelectedValue = "Select";
                  }
              }
          }

          private void comboBox_ExcludedFromProtocol_SelectedIndexChanged(object sender, EventArgs e)
          {
              
             
              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0")
              {
                  lbl_InitialHypotension.Show();
                  lbl_PersistentHypotension.Show();
                  lbl_VasopressorAdministration.Show();
                
                
                  lbl_BloodCultureCollection.Show();
                  lbl_AntibioticAdministration.Show();
                  lbl_InitialLactateLevelCollection.Show();





                  comboBox_InitialHypotension.Enabled = true;
                  comboBox_PersistentHypotension.Enabled = true;
                  comboBox_VasopressorAdministration.Enabled = true;
                  //comboBox_BloodCultureCollection.Enabled = true;

                  comboBox_InitialHypotension.BackColor = result;
                  comboBox_PersistentHypotension.BackColor = result;
                  comboBox_VasopressorAdministration.BackColor = result;
                  comboBox_BloodCultureCollection.BackColor = result;
                  comboBox_InitialLactateLevelCollection.BackColor = result;
                  comboBox_AntibioticAdministration.BackColor = result;

                  if (comboBox_ProtocolType.SelectedValue.ToString() == "1")
                  {
                      lbl_AdultCrystalloidFluidAdministration.Show();
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = true;
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = result;

                      lbl_PediatricCrystalloidFluidAdministration.Hide();
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                      comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);


                  }
                  else if (comboBox_ProtocolType.SelectedValue.ToString() == "2")
                  {
                      lbl_PediatricCrystalloidFluidAdministration.Show();
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;

                      lbl_AdultCrystalloidFluidAdministration.Hide();
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                      comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                  }
                  else if (comboBox_ProtocolType.SelectedValue.ToString() == "0")
                  {
                      lbl_AdultCrystalloidFluidAdministration.Hide();
                      lbl_PediatricCrystalloidFluidAdministration.Hide();
                      //lbl_AdultCrystalloidFluidAdministration.Show();
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = true;
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                      //lbl_PediatricCrystalloidFluidAdministration.Show();
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                  }

                  //if (comboBox_ProtocolType.SelectedValue.ToString() == "1")
                  //{
                  //    lbl_AdultCrystalloidFluidAdministration.Show();
                  //    comboBox_AdultCrystalloidFluidAdministration.Enabled = true;
                  //    comboBox_AdultCrystalloidFluidAdministration.BackColor = result;
                     

                  //}
                  //else
                  //{
                  //    lbl_AdultCrystalloidFluidAdministration.Hide();
                  //    comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                  //    comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                  //    comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                  //}

                  //if (comboBox_ProtocolType.SelectedValue.ToString() == "2")
                  //{
                  //    lbl_PediatricCrystalloidFluidAdministration.Show();
                  //    comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;
                  //    comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;

                  //}
                  //else
                  //{
                  //    lbl_PediatricCrystalloidFluidAdministration.Hide();
                  //    comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                  //    comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";
                  //    comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                  //}



              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1")
              {
                  lbl_BloodCultureCollection.Hide();
                  lbl_InitialHypotension.Hide();
                  lbl_PersistentHypotension.Hide();
                  lbl_VasopressorAdministration.Hide();
                  lbl_InitialLactateLevelCollection.Hide();
                  //lbl_AdultCrystalloidFluidAdministration.Hide();
                 // lbl_PediatricCrystalloidFluidAdministration.Hide();
                  lbl_AntibioticAdministration.Hide();


                  comboBox_InitialHypotension.Enabled = false;
                  comboBox_PersistentHypotension.Enabled = false;
                  comboBox_VasopressorAdministration.Enabled = false;
                 // comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                 // comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                  //comboBox_BloodCultureCollection.Enabled = false;
                 


                  comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray);
                  comboBox_PersistentHypotension.BackColor = MandatoryColor(Color.Gray);
                  comboBox_VasopressorAdministration.BackColor = MandatoryColor(Color.Gray);
                  comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);
                 // comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                  //comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);


                  comboBox_InitialHypotension.SelectedValue = "Select";
                  comboBox_PersistentHypotension.SelectedValue = "Select";
                  comboBox_VasopressorAdministration.SelectedValue = "Select";
                 // comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                 // comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";
                  comboBox_BloodCultureCollection.SelectedValue = "Select";
                  comboBox_InitialLactateLevelCollection.SelectedValue = "Select";



                  if (comboBox_ProtocolType.SelectedValue.ToString() == "1")
                  {
                      lbl_AdultCrystalloidFluidAdministration.Show();
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = true;
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = result;

                      lbl_PediatricCrystalloidFluidAdministration.Hide();
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                      comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);


                  }
                  else if (comboBox_ProtocolType.SelectedValue.ToString() == "2")
                  {
                      lbl_PediatricCrystalloidFluidAdministration.Show();
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;

                      lbl_AdultCrystalloidFluidAdministration.Hide();
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                      comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                  }
                  else if (comboBox_ProtocolType.SelectedValue.ToString() == "0")
                  {
                      lbl_AdultCrystalloidFluidAdministration.Hide();
                      lbl_PediatricCrystalloidFluidAdministration.Hide();
                      //lbl_AdultCrystalloidFluidAdministration.Show();
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = true;
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                      //lbl_PediatricCrystalloidFluidAdministration.Show();
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                  }

              }
              else
              {
                  lbl_InitialLactateLevelCollection.Hide();
                  lbl_BloodCultureCollection.Hide();
                  lbl_InitialHypotension.Hide();
                  lbl_PersistentHypotension.Hide();
                  lbl_VasopressorAdministration.Hide();
                  lbl_AdultCrystalloidFluidAdministration.Hide();
                  lbl_PediatricCrystalloidFluidAdministration.Hide();
                  lbl_AntibioticAdministration.Hide();


                  comboBox_InitialHypotension.Enabled = false;
                  comboBox_PersistentHypotension.Enabled = false;
                  comboBox_VasopressorAdministration.Enabled = false;
                  comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                  comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                  //comboBox_BloodCultureCollection.Enabled = false;


                  comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray);
                  comboBox_PersistentHypotension.BackColor = MandatoryColor(Color.Gray);
                  comboBox_VasopressorAdministration.BackColor = MandatoryColor(Color.Gray);
                  comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);
                  comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                  comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);


                  comboBox_InitialHypotension.SelectedValue = "Select";
                  comboBox_PersistentHypotension.SelectedValue = "Select";
                  comboBox_VasopressorAdministration.SelectedValue = "Select";
                  comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                  comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";
                  //comboBox_BloodCultureCollection.SelectedValue = "Select";

                  //if (comboBox_ProtocolType.SelectedValue.ToString() == "2")
                  //{
                  //    lbl_PediatricCrystalloidFluidAdministration.Show();
                  //    comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;

                  //}
                  //else
                  //{
                  //    lbl_PediatricCrystalloidFluidAdministration.Hide();
                  //    comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                  //    comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";

                  //}



              }



              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1")
              {

                  lbl_ExcludedDatetime.Show();
                  lbl_ExcludedReason.Show();

                  textBox_ExcludedDatetime.Enabled = true;
                  checkedListBox_ExcludedReason.Enabled = true;

                  textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.White);
                  checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.White);

              }
              else
              {
                  lbl_ExcludedDatetime.Hide();
                  lbl_ExcludedReason.Hide();
                  textBox_ExcludedDatetime.Enabled = false;
                  checkedListBox_ExcludedReason.Enabled = false;

                  textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.Gray);
                  checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.Gray);

                  textBox_ExcludedDatetime.Text = "";
                  foreach (int i in checkedListBox_ExcludedReason.CheckedIndices)
                  {
                      checkedListBox_ExcludedReason.SetItemCheckState(i, CheckState.Unchecked);
                  }
              }
          }

          private void comboBox_AntibioticAdministration_SelectedIndexChanged(object sender, EventArgs e)
          {

              if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1")
              {

                  lbl_AntibioticAdministrationDatetime.Show();
                  lbl_AntibioticAdministrationSelection.Show();

                  textBox_AntibioticAdministrationDatetime.Enabled = true;
                  comboBox_AntibioticAdministrationSelection.Enabled = true;
                  textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.White);
                  comboBox_AntibioticAdministrationSelection.BackColor = result;

              }
              else
              {

                  lbl_AntibioticAdministrationDatetime.Hide();
                  lbl_AntibioticAdministrationSelection.Hide();

                  textBox_AntibioticAdministrationDatetime.Enabled = false;
                  comboBox_AntibioticAdministrationSelection.Enabled = false;

                  textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                  comboBox_AntibioticAdministrationSelection.BackColor = MandatoryColor(Color.Gray);

                  textBox_AntibioticAdministrationDatetime.Text = "";
                  comboBox_AntibioticAdministrationSelection.SelectedValue = "Select";
              }
          }

          private void comboBox_BloodCultureCollection_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1")
              {
                 
                 
                  lbl_BloodCultureCollectionDatetime.Show();
                  lbl_BloodCulturePathogen.Show();
                  lbl_BloodCultureResult.Show();
                  lbl_BloodCultureCollectionAcceptableDelay.Show();

                  textBox_BloodCultureCollectionDatetime.Enabled = true;
                  comboBox_BloodCulturePathogen.Enabled = true;
                  comboBoX_BloodCultureResult.Enabled = true;
                  comboBox_BloodCultureCollectionAcceptableDelay.Enabled = true;

                  textBox_BloodCultureCollectionDatetime.BackColor =  MandatoryColor(Color.White);
                  comboBox_BloodCulturePathogen.BackColor = result;
                  comboBoX_BloodCultureResult.BackColor = result;
                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = result;
                
              }
              else
              {
                  lbl_BloodCultureCollectionAcceptableDelay.Hide();
                  lbl_BloodCultureCollectionDatetime.Hide();
                  lbl_BloodCulturePathogen.Hide();
                  lbl_BloodCultureResult.Hide();

                  textBox_BloodCultureCollectionDatetime.Enabled = false;
                  comboBox_BloodCulturePathogen.Enabled = false;
                  comboBoX_BloodCultureResult.Enabled = false;
                  comboBox_BloodCultureCollectionAcceptableDelay.Enabled = false;
                  textBox_BloodCultureCollectionDatetime.Text = "";
                  comboBox_BloodCulturePathogen.SelectedValue = "Select";
                  comboBoX_BloodCultureResult.SelectedValue = "Select";
                  comboBox_BloodCultureCollectionAcceptableDelay.SelectedValue = "Select";


                  textBox_BloodCultureCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
                  comboBox_BloodCulturePathogen.BackColor = MandatoryColor(Color.Gray);
                  comboBoX_BloodCultureResult.BackColor = MandatoryColor(Color.Gray);
                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void comboBox_RepeatLactateLevelCollection_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "1")
              {

                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = true;
                  lbl_RepeatLactateLevelCollectionDatetime.Show();
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.White);
               
              }
              else
              {
                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = false;
                  lbl_RepeatLactateLevelCollectionDatetime.Hide();
                  textbox_RepeatLactateLevelCollectionDatetime.Text = "";
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
               
              }
          }

          private void comboBox_InitialLactateLevelCollection_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1")
              {


                  lbl_InitialLactateLevelCollectionDatetime.Show();
                  lbl_InitialLactateLevelUnit.Show();
                  lbl_InitialLactateLevel.Show();
                  lbl_RepeatLactateLevelCollection.Show();
                  lbl_RepeatLactateLevelCollectionDatetime.Show();

                  textBox_InitialLactateLevel.Enabled = true;
                  textBox_InitialLactateLevelCollectionDatetime.Enabled = true;
                  comboBox_InitialLactateLevelUnit.Enabled = true;
                  comboBox_RepeatLactateLevelCollection.Enabled = true;
                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = true;

                  textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.White);
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.White);
                  comboBox_InitialLactateLevelUnit.BackColor = result;
                  comboBox_RepeatLactateLevelCollection.BackColor = result;
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.White);


              }
              else //if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "2")
              {

                  lbl_InitialLactateLevelCollectionDatetime.Hide();
                  lbl_InitialLactateLevelUnit.Hide();
                  lbl_InitialLactateLevel.Hide();
                  lbl_RepeatLactateLevelCollection.Hide();
                  lbl_RepeatLactateLevelCollectionDatetime.Hide();
                  textBox_InitialLactateLevel.Enabled = false;
                  textBox_InitialLactateLevelCollectionDatetime.Enabled = false;
                  comboBox_InitialLactateLevelUnit.Enabled = false;
                  comboBox_RepeatLactateLevelCollection.Enabled = false;
                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = false;
                  textBox_InitialLactateLevelCollectionDatetime.Text = "";
                  comboBox_InitialLactateLevelUnit.SelectedValue = "Select";
                  textBox_InitialLactateLevel.Text = "";
                  comboBox_RepeatLactateLevelCollection.SelectedValue = "Select";
                  textbox_RepeatLactateLevelCollectionDatetime.Text = "";


                  textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
                  comboBox_InitialLactateLevelUnit.BackColor = MandatoryColor(Color.Gray);
                  comboBox_RepeatLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
              }

          }

        

          private void checkedListBox_ExcludedReason_SelectedIndexChanged(object sender, EventArgs e)
          {

              ////else
              ////{
              ////    lbl_ExcludedExplain.Hide();
              ////    checkedListBox_ExcludedExplain.Enabled = false;
              ////    for (int i = 0; i <= checkedListBox_ExcludedExplain.Items.Count - 1; i++)
              ////    {
              ////        checkedListBox_ExcludedExplain.SetItemChecked(i, false);
              ////    }
              ////}
          
          }

          private void comboBox_TransferStatus_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_TransferStatus.SelectedValue.ToString() == "3" || comboBox_TransferStatus.SelectedValue.ToString() == "4" || comboBox_TransferStatus.SelectedValue.ToString() == "5")
              {

                  lbl_TransferFacilityIdentifier.Show();
                  textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.White);

              }
              else
              {

                  lbl_TransferFacilityIdentifier.Hide();
                  textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.Gray);

                 // textBox_TransferFacilityIdentifier.Enabled = false;
                  //textBox_TransferFacilityIdentifier.Text = "";
                
              }
          }

          private void comboBox_Payor_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_Payor.SelectedValue.ToString() == "C" || comboBox_Payor.SelectedValue.ToString() == "D" || comboBox_Payor.SelectedValue.ToString() == "F" || comboBox_Payor.SelectedValue.ToString() == "G")
              {

                  lbl_InsuranceNumber.Show();
                  TextBox_InsuranceNumber.BackColor = MandatoryColor(Color.White);

              }
              else
              {

                  lbl_InsuranceNumber.Hide();
                  TextBox_InsuranceNumber.BackColor = MandatoryColor(Color.Gray);

              }
          }

          //private void textBox_InitialLactateLevel_Leave(object sender, EventArgs e)
          //{
          //    if (textBox_InitialLactateLevel.Text.ToString().Trim() != "")
          //    {
          //        foreach (char c in textBox_InitialLactateLevel.Text.ToString().Trim())
          //        {
          //            if (c == '.')
          //            {
          //                d = c;
          //                break;
          //            }

          //        }

          //        if (d == '.')
          //        {
             
                     

          //        }
               
          //    }
             
          //}

     

          //private void textBox_InitialLactateLevel_TypeValidationCompleted(object sender, TypeValidationEventArgs e)
          //  {
          //      if (textBox_InitialLactateLevel.Text.ToString().Trim() != "  .")
          //      {
          //          if (!e.IsValidInput)
          //          {
          //              MessageBox.Show("Initial Lactate level should be in format '00.0'.", "Initial Lactate level Error");
          //              textBox_InitialLactateLevel.Focus();
          //          }
          //      }

          //}

          public void Dropdowncolor()
          {

          

              Combobox_Gender.BackColor = result;
              Combobox_Ethnicity.BackColor = result;
              comboBox_Payor.BackColor = result;
              comboBox_SourceofAdmission.BackColor = result;
              comboBox_DischargeStatus.BackColor = result;
              comboBox_TransferStatus.BackColor = result;
              comboBox_ProtocolInitiated.BackColor = result;
              comboBox_ProtocolNotInitiatedReason.BackColor = result;
              comboBox_ProtocolInitiatedPlace.BackColor = result;
              comboBox_ProtocolType.BackColor = result;
              comboBox_ExcludedFromProtocol.BackColor = result;
              comboBox_SevereSepsisPresent.BackColor = result;
              comboBox_SepticShockPresent.BackColor = result;
              comboBox_DestinationafterED.BackColor = result;
              comboBox_InitialLactateLevelCollection.BackColor = result;
              comboBox_InitialLactateLevelUnit.BackColor = result;
              comboBox_RepeatLactateLevelCollection.BackColor = result;
              comboBox_BloodCultureCollection.BackColor = result;
              comboBox_BloodCultureCollectionAcceptableDelay.BackColor = result;
              comboBoX_BloodCultureResult.BackColor = result;
              comboBox_BloodCulturePathogen.BackColor = result;
              comboBox_AntibioticAdministration.BackColor = result;
              comboBox_AntibioticAdministrationSelection.BackColor = result;
              comboBox_AdultCrystalloidFluidAdministration.BackColor = result;
              comboBox_InitialHypotension.BackColor = result;
              comboBox_PersistentHypotension.BackColor = result;
              comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;
              comboBox_BedsideCardiovascularUltrasound.BackColor = result;
              comboBox_VasopressorAdministration.BackColor = result;
              comboBox_CardiopulmonaryEvaluation.BackColor = result;
              comboBox_CapillaryRefillExamination.BackColor = result;
              comboBox_PassiveLegRaiseExamination.BackColor = result;
              comboBox_PeripheralPulseEvaluation.BackColor = result;
              comboBox_SkinExamination.BackColor = result;
              comboBox_CentralVenousOxygenMeasurement.BackColor = result;
              comboBox_CentralVenousPressureMeasurement.BackColor = result;
              comboBox_FluidChallengePerformed.BackColor = result;
              comboBox_VitalSignsReview.BackColor = result;
              comboBox_PlateletCount.BackColor = result;
              comboBox_AlteredMentalStatus.BackColor = result;
              comboBox_Bandemia.BackColor = result;
              comboBox_InfectionEtiology.BackColor = result;
              comboBox_LowerRespiratoryInfection.BackColor = result;
              comboBox_SiteofInfection.BackColor = result;
              comboBox_MechanicalVentilation.BackColor = result;
              comboBox_ICU.BackColor = result;
              comboBox_ChronicRespiratoryFailure.BackColor = result;
              comboBox_AIDSDisease.BackColor = result;
              comboBox_MetastaticCancer.BackColor = result;
              comboBox_Lymphoma.BackColor = result;
              comboBox_ImmuneModifyingMedications.BackColor = result;
              comboBox_CongestiveHeartFailure.BackColor = result;
              comboBox_ChronicRenalFailure.BackColor = result;
              comboBox_ChronicLiverDisease.BackColor = result;
              comboBox_Diabetes.BackColor = result;
              comboBox_OrganTransplant.BackColor = result;


          }


          public void MandatoryColorChange()
          {

              Color temp = System.Drawing.ColorTranslator.FromHtml("#FFF7D1");
             // Color color = (Color)ColorConverter.ConvertFromString("#FFDFD991");
              Color Mandatoryresult = Color.FromArgb(temp.R, temp.G, temp.B);
              // Actual Mandatory Fields
              if (txtId.Text.ToString().Trim() == "")
              {
                 txtId.BackColor = Mandatoryresult;
              }
              else
                  txtId.BackColor = MandatoryColor(Color.White);



              if (TextBox_PatientCtrlNum.Text.ToString().Trim() == "")
              {
                  TextBox_PatientCtrlNum.BackColor = Mandatoryresult;
              }
              else
                  TextBox_PatientCtrlNum.BackColor = MandatoryColor(Color.White);


              if (txtDOB.Text.ToString().Trim() == "/  /")
              {
                  txtDOB.BackColor = Mandatoryresult;
              }
              else
                  txtDOB.BackColor = MandatoryColor(Color.White);


              if (Combobox_Gender.SelectedValue.ToString() == "Select")
              {
                  Combobox_Gender.BackColor = Mandatoryresult;
              }
              else
                  Combobox_Gender.BackColor = result;



              if (checkedListBox_Race.CheckedItems.Count == 0)
              {
                checkedListBox_Race.BackColor = Mandatoryresult;
              }
              else
                  checkedListBox_Race.BackColor = MandatoryColor(Color.White);




              if (Combobox_Ethnicity.SelectedValue.ToString() == "Select")
              {
                  Combobox_Ethnicity.BackColor = Mandatoryresult;
              }
              else
                  Combobox_Ethnicity.BackColor = result;


              if (comboBox_Payor.SelectedValue.ToString() == "Select")
              {
                  comboBox_Payor.BackColor = Mandatoryresult;
              }
              else
                  comboBox_Payor.BackColor = result;



              //if (TextBox_InsuranceNumber.Text.ToString().Trim() == "")
              //{
              //    TextBox_InsuranceNumber.BackColor = Mandatoryresult;
              //}




              if (txtMRN.Text.ToString().Trim() == "")
              {
                  txtMRN.BackColor = Mandatoryresult;
              }
              else
                  txtMRN.BackColor = MandatoryColor(Color.White);


              if (TextBox_FacilityIdentifier.Text.ToString().Trim() == "")
              {
                  TextBox_FacilityIdentifier.BackColor = Mandatoryresult;
              }
              else
                  TextBox_FacilityIdentifier.BackColor = MandatoryColor(Color.White);




              if (textBox_AdmissionDateTime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_AdmissionDateTime.BackColor = Mandatoryresult;
              }
              else
                  textBox_AdmissionDateTime.BackColor = MandatoryColor(Color.White);

              if (textBox_DischargedDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_DischargedDatetime.BackColor = Mandatoryresult;
              }
              else
                  textBox_DischargedDatetime.BackColor = MandatoryColor(Color.White);

              if (comboBox_SourceofAdmission.SelectedValue.ToString() == "Select")
              {
                  comboBox_SourceofAdmission.BackColor = Mandatoryresult;
              }
              else
                  comboBox_SourceofAdmission.BackColor = result;

              if (comboBox_DischargeStatus.SelectedValue.ToString() == "Select")
              {
                  comboBox_DischargeStatus.BackColor = Mandatoryresult;
              }
              else
                  comboBox_DischargeStatus.BackColor = result;


              if (comboBox_TransferStatus.SelectedValue.ToString() == "Select")
              {
                  comboBox_TransferStatus.BackColor = Mandatoryresult;
              }
              else
                  comboBox_TransferStatus.BackColor = result;

              if (comboBox_ProtocolInitiated.SelectedValue.ToString() == "Select")
              {
                  comboBox_ProtocolInitiated.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ProtocolInitiated.BackColor = result;


              if (comboBox_ProtocolInitiatedPlace.SelectedValue.ToString() == "Select")
              {
                  comboBox_ProtocolInitiatedPlace.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ProtocolInitiatedPlace.BackColor = result;

              if (comboBox_ProtocolType.SelectedValue.ToString() == "Select")
              {
                  comboBox_ProtocolType.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ProtocolType.BackColor = result;


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "Select")
              {
                  comboBox_ExcludedFromProtocol.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ExcludedFromProtocol.BackColor = result;


              if (textBox_EarliestDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_EarliestDatetime.BackColor = Mandatoryresult;
              }
              else
                  textBox_EarliestDatetime.BackColor = MandatoryColor(Color.White);

              if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "Select")
              {
                  comboBox_SevereSepsisPresent.BackColor = Mandatoryresult;
              }
              else
                  comboBox_SevereSepsisPresent.BackColor = result;


              //if (textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim() == "/  /       :")
              //{
              //    textBox_SevereSepsisPresentationDatetime.BackColor = Mandatoryresult;
              //}


              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "Select")
              {
                  comboBox_SepticShockPresent.BackColor = Mandatoryresult;
              }
              else
                  comboBox_SepticShockPresent.BackColor = result;

              if (comboBox_PlateletCount.SelectedValue.ToString() == "Select")
              {
                  comboBox_PlateletCount.BackColor = Mandatoryresult;
              }
              else
                  comboBox_PlateletCount.BackColor = result;


              if (comboBox_AlteredMentalStatus.SelectedValue.ToString() == "Select")
              {
                  comboBox_AlteredMentalStatus.BackColor = Mandatoryresult;
              }
              else
                  comboBox_AlteredMentalStatus.BackColor = result;

              if (comboBox_InfectionEtiology.SelectedValue.ToString() == "Select")
              {
                  comboBox_InfectionEtiology.BackColor = Mandatoryresult;
              }
              else
                  comboBox_InfectionEtiology.BackColor = result;


              if (comboBox_LowerRespiratoryInfection.SelectedValue.ToString() == "Select")
              {
                  comboBox_LowerRespiratoryInfection.BackColor = Mandatoryresult;
              }
              else
                  comboBox_LowerRespiratoryInfection.BackColor = result;

              if (comboBox_Bandemia.SelectedValue.ToString() == "Select")
              {
                  //comboBox_Bandemia.BackColor = Mandatoryresult;
                  comboBox_Bandemia.BackColor = Mandatoryresult;
              }
              else
                  comboBox_Bandemia.BackColor = result;


              if (comboBox_SiteofInfection.SelectedValue.ToString() == "Select")
              {
                  comboBox_SiteofInfection.BackColor = Mandatoryresult;
              }
              else
                  comboBox_SiteofInfection.BackColor = result;

              if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "Select")
              {
                  comboBox_MechanicalVentilation.BackColor = Mandatoryresult;
              }
              else
                  comboBox_MechanicalVentilation.BackColor = result;



              if (comboBox_ICU.SelectedValue.ToString() == "Select")
              {
                  comboBox_ICU.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ICU.BackColor = result;

              if (comboBox_ChronicRespiratoryFailure.SelectedValue.ToString() == "Select")
              {
                  comboBox_ChronicRespiratoryFailure.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ChronicRespiratoryFailure.BackColor = result;



              if (comboBox_AIDSDisease.SelectedValue.ToString() == "Select")
              {
                  comboBox_AIDSDisease.BackColor = Mandatoryresult;
              }
              else
                  comboBox_AIDSDisease.BackColor = result;


              if (comboBox_MetastaticCancer.SelectedValue.ToString() == "Select")
              {
                  comboBox_MetastaticCancer.BackColor = Mandatoryresult;
              }
              else
                  comboBox_MetastaticCancer.BackColor = result;


              if (comboBox_Lymphoma.SelectedValue.ToString() == "Select")
              {
                  comboBox_Lymphoma.BackColor = Mandatoryresult;
              }
              else
                  comboBox_Lymphoma.BackColor = result;

              if (comboBox_ImmuneModifyingMedications.SelectedValue.ToString() == "Select")
              {
                  comboBox_ImmuneModifyingMedications.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ImmuneModifyingMedications.BackColor = result;


              if (comboBox_CongestiveHeartFailure.SelectedValue.ToString() == "Select")
              {
                  comboBox_CongestiveHeartFailure.BackColor = Mandatoryresult;
              }
              else
                  comboBox_CongestiveHeartFailure.BackColor = result;

              if (comboBox_ChronicRenalFailure.SelectedValue.ToString() == "Select")
              {
                  comboBox_ChronicRenalFailure.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ChronicRenalFailure.BackColor = result;


              if (comboBox_ChronicLiverDisease.SelectedValue.ToString() == "Select")
              {
                  comboBox_ChronicLiverDisease.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ChronicLiverDisease.BackColor = result;

              if (comboBox_Diabetes.SelectedValue.ToString() == "Select")
              {
                  comboBox_Diabetes.BackColor = Mandatoryresult;
              }
              else
                  comboBox_Diabetes.BackColor = result;


              if (comboBox_OrganTransplant.SelectedValue.ToString() == "Select")
              {
                  comboBox_OrganTransplant.BackColor = Mandatoryresult;
              }
              else
                  comboBox_OrganTransplant.BackColor = result;



              // Dependency validations
              if ((comboBox_Payor.SelectedValue.ToString() == "C" || comboBox_Payor.SelectedValue.ToString() == "D" || comboBox_Payor.SelectedValue.ToString() == "F" || comboBox_Payor.SelectedValue.ToString() == "G") && TextBox_InsuranceNumber.Text.ToString().Trim() == "")
              {

                  TextBox_InsuranceNumber.BackColor = Mandatoryresult;

              }
              else  if ((comboBox_Payor.SelectedValue.ToString() == "A" || comboBox_Payor.SelectedValue.ToString() == "B" || comboBox_Payor.SelectedValue.ToString() == "E" || comboBox_Payor.SelectedValue.ToString() == "H" || comboBox_Payor.SelectedValue.ToString() == "I"))
              {
                    TextBox_InsuranceNumber.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  TextBox_InsuranceNumber.BackColor = MandatoryColor(Color.White);


              if ((comboBox_TransferStatus.SelectedValue.ToString() == "3" || comboBox_TransferStatus.SelectedValue.ToString() == "4" || comboBox_TransferStatus.SelectedValue.ToString() == "5") && textBox_TransferFacilityIdentifier.Text.Trim() == "")
              {
                  textBox_TransferFacilityIdentifier.BackColor = Mandatoryresult;
              }
              else if (comboBox_TransferStatus.SelectedValue.ToString() == "1" || comboBox_TransferStatus.SelectedValue.ToString() == "2")
              {
                  textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.White);


              if (comboBox_ICU.SelectedValue.ToString() == "1" && textBox_ICUAdmissionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_ICUAdmissionDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_ICU.SelectedValue.ToString() != "1")
              {
                  textBox_ICUAdmissionDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_ICUAdmissionDatetime.BackColor = MandatoryColor(Color.White);


              if (comboBox_ICU.SelectedValue.ToString() == "1" && textBox_ICUDischargeDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_ICUDischargeDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_ICU.SelectedValue.ToString() != "1")
              {
                  textBox_ICUDischargeDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_ICUDischargeDatetime.BackColor = MandatoryColor(Color.White);


              if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "1" && textBox_MechanicalVentilationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_MechanicalVentilationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_MechanicalVentilation.SelectedValue.ToString() != "1")
              {
                  textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.White);


              if (comboBox_VitalSignsReview.SelectedValue.ToString() == "1" && textBox_VitalSignsReviewDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_VitalSignsReviewDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_VitalSignsReview.SelectedValue.ToString() != "1")
              {
                  textBox_VitalSignsReviewDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_VitalSignsReviewDatetime.BackColor = MandatoryColor(Color.White);



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_VitalSignsReview.SelectedValue.ToString() == "Select")
              {
                  comboBox_VitalSignsReview.BackColor = Mandatoryresult;
              }
              else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() != "1" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() != "1")
              {
                  comboBox_VitalSignsReview.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_VitalSignsReview.BackColor = result;


              if (comboBox_FluidChallengePerformed.SelectedValue.ToString() == "1" && textBox_FluidChallengePerformedDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_FluidChallengePerformedDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_FluidChallengePerformed.SelectedValue.ToString() != "1")
              {
                  textBox_FluidChallengePerformedDatetime.BackColor = MandatoryColor(Color.Gray);
              }

              else
                  textBox_FluidChallengePerformedDatetime.BackColor = MandatoryColor(Color.White);


              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_FluidChallengePerformed.SelectedValue.ToString() == "Select")
              {
                  comboBox_FluidChallengePerformed.BackColor = Mandatoryresult;
              }
              else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() != "1" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() != "1")
              {
                  comboBox_FluidChallengePerformed.BackColor = MandatoryColor(Color.Gray);
              }

              else
                  comboBox_FluidChallengePerformed.BackColor = result;



              if (comboBox_CentralVenousPressureMeasurement.SelectedValue.ToString() == "1" && textBox_CentralVenousPressureMeasurementDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_CentralVenousPressureMeasurementDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_CentralVenousPressureMeasurement.SelectedValue.ToString() != "1")
              {
                  textBox_CentralVenousPressureMeasurementDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_CentralVenousPressureMeasurementDatetime.BackColor = MandatoryColor(Color.White);



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_CentralVenousPressureMeasurement.SelectedValue.ToString() == "Select")
              {
                   comboBox_CentralVenousPressureMeasurement.BackColor = Mandatoryresult;
              }
              else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() != "1" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() != "1")
              {
                  comboBox_CentralVenousPressureMeasurement.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_CentralVenousPressureMeasurement.BackColor = result;




              if (comboBox_CentralVenousOxygenMeasurement.SelectedValue.ToString() == "1" && textBox_CentralVenousOxygenMeasurementDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_CentralVenousOxygenMeasurementDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_CentralVenousOxygenMeasurement.SelectedValue.ToString() != "1")
              {
                  textBox_CentralVenousOxygenMeasurementDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_CentralVenousOxygenMeasurementDatetime.BackColor = MandatoryColor(Color.White);



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_CentralVenousOxygenMeasurement.SelectedValue.ToString() == "Select")
              {
                   comboBox_CentralVenousOxygenMeasurement.BackColor = Mandatoryresult;
              }
              else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() != "1" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() != "1")
              {
                  comboBox_CentralVenousOxygenMeasurement.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_CentralVenousOxygenMeasurement.BackColor = result;


              if (comboBox_SkinExamination.SelectedValue.ToString() == "1" && textBox_SkinExaminationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_SkinExaminationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_SkinExamination.SelectedValue.ToString() != "1")
              {
                  textBox_SkinExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_SkinExaminationDatetime.BackColor = MandatoryColor(Color.White);



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_SkinExamination.SelectedValue.ToString() == "Select")
              {
                   comboBox_SkinExamination.BackColor = Mandatoryresult;
              }
              else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() != "1" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() != "1")
              {
                  comboBox_SkinExamination.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_SkinExamination.BackColor = result;



              if (comboBox_PeripheralPulseEvaluation.SelectedValue.ToString() == "1" && textBox_PeripheralPulseEvaluationDatetime.Text.ToString().Trim() == "")
              {
                   textBox_PeripheralPulseEvaluationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_PeripheralPulseEvaluation.SelectedValue.ToString() != "1")
              {
                  textBox_PeripheralPulseEvaluationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_PeripheralPulseEvaluationDatetime.BackColor = MandatoryColor(Color.White);



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_PeripheralPulseEvaluation.SelectedValue.ToString() == "Select")
              {
                   comboBox_PeripheralPulseEvaluation.BackColor = Mandatoryresult;
              }
              else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() != "1" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() != "1")
              {
                  comboBox_PeripheralPulseEvaluation.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_PeripheralPulseEvaluation.BackColor = result;



              if (comboBox_PassiveLegRaiseExamination.SelectedValue.ToString() == "1" && textBox_PassiveLegRaiseExaminationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_PassiveLegRaiseExaminationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_PassiveLegRaiseExamination.SelectedValue.ToString() != "1")
              {
                  textBox_PassiveLegRaiseExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_PassiveLegRaiseExaminationDatetime.BackColor = MandatoryColor(Color.White);



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_PassiveLegRaiseExamination.SelectedValue.ToString() == "Select")
              {
                   comboBox_PassiveLegRaiseExamination.BackColor = Mandatoryresult;
              }
              else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() != "1" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() != "1")
              {
                  comboBox_PassiveLegRaiseExamination.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_PassiveLegRaiseExamination.BackColor = result;



              if (comboBox_CardiopulmonaryEvaluation.SelectedValue.ToString() == "1" && textBox_CardiopulmonaryEvaluationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_CardiopulmonaryEvaluationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_CardiopulmonaryEvaluation.SelectedValue.ToString() != "1")
              {
                  textBox_CardiopulmonaryEvaluationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_CardiopulmonaryEvaluationDatetime.BackColor = MandatoryColor(Color.White);



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_CardiopulmonaryEvaluation.SelectedValue.ToString() == "Select")
              {
                   comboBox_CardiopulmonaryEvaluation.BackColor = Mandatoryresult;
              }
              else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() != "1" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() != "1")
              {
                  comboBox_CardiopulmonaryEvaluation.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_CardiopulmonaryEvaluation.BackColor = result;



              if (comboBox_CapillaryRefillExamination.SelectedValue.ToString() == "1" && textBox_CapillaryRefillExaminationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_CapillaryRefillExaminationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_CapillaryRefillExamination.SelectedValue.ToString() != "1")
              {
                  textBox_CapillaryRefillExaminationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_CapillaryRefillExaminationDatetime.BackColor = MandatoryColor(Color.White);



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_CapillaryRefillExamination.SelectedValue.ToString() == "Select")
              {
                   comboBox_CapillaryRefillExamination.BackColor = Mandatoryresult;
              }
              else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() != "1" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() != "1")
              {
                  comboBox_CapillaryRefillExamination.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_CapillaryRefillExamination.BackColor = result;



              if (comboBox_BedsideCardiovascularUltrasound.SelectedValue.ToString() == "1" && textBox_BedsideCardiovascularUltrasoundDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_BedsideCardiovascularUltrasound.SelectedValue.ToString() != "1")
              {
                  textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = MandatoryColor(Color.White);



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_BedsideCardiovascularUltrasound.SelectedValue.ToString() == "Select")
              {
                   comboBox_BedsideCardiovascularUltrasound.BackColor = Mandatoryresult;
              }
              else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() != "1" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() != "1")
              {
                  comboBox_BedsideCardiovascularUltrasound.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_BedsideCardiovascularUltrasound.BackColor = result;



              //if (comboBox_BedsideCardiovascularUltrasound.SelectedValue.ToString() == "1" && textBox_BedsideCardiovascularUltrasoundDatetime.Text.ToString().Trim() == "/  /       :")
              //{
              //     textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = Mandatoryresult;
              //}
              //else
              //    textBox_BedsideCardiovascularUltrasoundDatetime.BackColor = MandatoryColor(Color.White);




              //if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && comboBox_BedsideCardiovascularUltrasound.SelectedValue.ToString() == "Select")
              //{
              //     Combobox_Ethnicity.BackColor = Mandatoryresult;
              //}



              if (comboBox_VasopressorAdministration.SelectedValue.ToString() == "1" && textBox_VasopressorAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_VasopressorAdministrationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_VasopressorAdministration.SelectedValue.ToString() != "1")
              {
                  textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.White);


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_AntibioticAdministration.SelectedValue.ToString() == "Select")
              {
                   comboBox_AntibioticAdministration.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
              {
                  comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_AntibioticAdministration.BackColor = result;


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_InitialHypotension.SelectedValue.ToString() == "Select")
              {
                   comboBox_InitialHypotension.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
              {
                  comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_InitialHypotension.BackColor = result;

              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_PersistentHypotension.SelectedValue.ToString() == "Select")
              {
                   comboBox_PersistentHypotension.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
              {
                  comboBox_PersistentHypotension.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_PersistentHypotension.BackColor = result;

              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_VasopressorAdministration.SelectedValue.ToString() == "Select")
              {
                   comboBox_VasopressorAdministration.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
              {
                  comboBox_VasopressorAdministration.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_VasopressorAdministration.BackColor = result;


              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && textBox_CrystalloidFluidAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_CrystalloidFluidAdministrationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "Select" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
              {
                  textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.White);

              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_ProtocolType.SelectedValue.ToString() == "1" && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
              {
                   comboBox_AdultCrystalloidFluidAdministration.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_ProtocolType.SelectedValue.ToString() != "1")
              {
                  comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
              }

              else
                  comboBox_AdultCrystalloidFluidAdministration.BackColor = result;

              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_ProtocolType.SelectedValue.ToString() == "2" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
              {
                   comboBox_PediatricCrystalloidFluidAdministration.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_ProtocolType.SelectedValue.ToString() != "2")
              {
                  comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;


              if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1" && textBox_AntibioticAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_AntibioticAdministrationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_AntibioticAdministration.SelectedValue.ToString() != "1")
              {
                  textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.White);


              if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1" && comboBox_AntibioticAdministrationSelection.SelectedValue.ToString() == "Select")
              {
                   comboBox_AntibioticAdministrationSelection.BackColor = Mandatoryresult;
              }
              else if (comboBox_AntibioticAdministration.SelectedValue.ToString() != "1")
              {
                  comboBox_AntibioticAdministrationSelection.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_AntibioticAdministrationSelection.BackColor = result;


              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && comboBox_BloodCulturePathogen.SelectedValue.ToString() == "Select")
              {
                   comboBox_BloodCulturePathogen.BackColor = Mandatoryresult;
              }
              else if (comboBox_BloodCultureCollection.SelectedValue.ToString() != "1")
              {
                  comboBox_BloodCulturePathogen.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_BloodCulturePathogen.BackColor = result;




              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && comboBoX_BloodCultureResult.SelectedValue.ToString() == "Select")
              {
                   comboBoX_BloodCultureResult.BackColor = Mandatoryresult;
              }
              else if (comboBox_BloodCultureCollection.SelectedValue.ToString() != "1")
              {
                  comboBoX_BloodCultureResult.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBoX_BloodCultureResult.BackColor = result;


              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && textBox_BloodCultureCollectionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_BloodCultureCollectionDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_BloodCultureCollection.SelectedValue.ToString() != "1")
              {
                  textBox_BloodCultureCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_BloodCultureCollectionDatetime.BackColor = MandatoryColor(Color.White);


              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && comboBox_BloodCultureCollectionAcceptableDelay.SelectedValue.ToString() == "Select")
              {
                   comboBox_BloodCultureCollectionAcceptableDelay.BackColor = Mandatoryresult;
              }
              else if (comboBox_BloodCultureCollection.SelectedValue.ToString() != "1")
              {
                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = result;


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_BloodCultureCollection.SelectedValue.ToString() == "Select")
              {
                   comboBox_BloodCultureCollection.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
              {
                  comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_BloodCultureCollection.BackColor = result;


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "Select")
              {
                  comboBox_InitialLactateLevelCollection.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
              {
                  comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_InitialLactateLevelCollection.BackColor = result;


              if (comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "1" && textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textbox_RepeatLactateLevelCollectionDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() != "1")
                  {
                      textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
              else
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.White);


              if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1" && textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_InitialLactateLevelCollectionDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() != "1")
              {
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.White);


              if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1" && comboBox_InitialLactateLevelUnit.SelectedValue.ToString() == "Select")
              {
                   comboBox_InitialLactateLevelUnit.BackColor = Mandatoryresult;
              }
              else if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() != "1")
              {
                  comboBox_InitialLactateLevelUnit.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_InitialLactateLevelUnit.BackColor = result;


              if (textBox_LeftEDDatetime.Text.ToString().Trim() != "/  /       :" && comboBox_DestinationafterED.SelectedValue.ToString() == "Select")
              {
                   comboBox_DestinationafterED.BackColor = Mandatoryresult;
              }
              else if (textBox_LeftEDDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  comboBox_DestinationafterED.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_DestinationafterED.BackColor = result;



              if (textbox_TriageDatetime.Text.ToString().Trim() != "/  /       :" && textBox_LeftEDDatetime.Text.ToString().Trim() == "/  /       :")
              {
                 
                   textBox_LeftEDDatetime.BackColor = Mandatoryresult;
              }
              else if (textbox_TriageDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_LeftEDDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_LeftEDDatetime.BackColor = MandatoryColor(Color.White);



              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1" && checkedListBox_ExcludedReason.CheckedItems.Count == 0)
              {
                   checkedListBox_ExcludedReason.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "1")
              {
                  checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.White);



              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1" && textBox_ExcludedDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_ExcludedDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "1")
              {
                  textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.White);


              if (comboBox_ProtocolInitiated.SelectedValue.ToString() == "0" && comboBox_ProtocolNotInitiatedReason.SelectedValue.ToString().Trim() == "Select")
              {
                   comboBox_ProtocolNotInitiatedReason.BackColor = Mandatoryresult;
              }
              else if (comboBox_ProtocolInitiated.SelectedValue.ToString() != "0")
              {
                  comboBox_ProtocolNotInitiatedReason.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_ProtocolNotInitiatedReason.BackColor = result;


              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && textBox_septicShockPresentationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_septicShockPresentationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_SepticShockPresent.SelectedValue.ToString() != "1")
              {
                  textBox_septicShockPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_septicShockPresentationDatetime.BackColor = MandatoryColor(Color.White);


              if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "1" && textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_SevereSepsisPresentationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_SevereSepsisPresent.SelectedValue.ToString() != "1")
              {
                  textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.White);



              for (int i = 0; i < checkedListBox_ExcludedReason.Items.Count; i++)
              {
                  if (checkedListBox_ExcludedReason.GetItemChecked(i) == true)
                  {
                      DataRowView castedItem = checkedListBox_ExcludedReason.Items[i] as DataRowView;
                      if (castedItem["ComboBox_Key"].ToString() == "1")
                      {
                          ExcludedResonChecked = 1;
                          break;
                      }
                  }

              }


              if (ExcludedResonChecked == 1 && checkedListBox_ExcludedExplain.CheckedItems.Count <= 0)
              {
                  ExcludedResonChecked = 0;
                  checkedListBox_ExcludedExplain.BackColor = Mandatoryresult;
              }
              else if (ExcludedResonChecked  != 1)
              {
                  checkedListBox_ExcludedExplain.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  checkedListBox_ExcludedExplain.BackColor = MandatoryColor(Color.White);




              if (comboBox_ProtocolType.SelectedValue.ToString() == "1" && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
              {
                  comboBox_AdultCrystalloidFluidAdministration.BackColor = Mandatoryresult;
              }
              else if (comboBox_ProtocolType.SelectedValue.ToString() != "1")
              {
                  comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
              }



              if (comboBox_ProtocolType.SelectedValue.ToString() == "2" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
              {
                  comboBox_PediatricCrystalloidFluidAdministration.BackColor = Mandatoryresult;
              }
              else if (comboBox_ProtocolType.SelectedValue.ToString() != "2")
              {
                  comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
              }
              //else
              //    checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.White);
         

          }

          public void SituationalDisplayforEdit()
          {
              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1")
              {

                  lbl_SepticShockPresentationDatetime.Show();
                  textBox_septicShockPresentationDatetime.Enabled = true;
              }
              else
              {
                  lbl_SepticShockPresentationDatetime.Hide();
                  textBox_septicShockPresentationDatetime.Enabled = false;
                  textBox_septicShockPresentationDatetime.Text = "";
              }


              if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "1")
              {

                  lbl_SevereSepsisPresentationDatetime.Show();
                  textBox_SevereSepsisPresentationDatetime.Enabled = true;
              }
              else
              {
                  lbl_SevereSepsisPresentationDatetime.Hide();
                  textBox_SevereSepsisPresentationDatetime.Enabled = false;
                  textBox_SevereSepsisPresentationDatetime.Text = "";
              }





              if (comboBox_Payor.SelectedValue.ToString() == "C" || comboBox_Payor.SelectedValue.ToString() == "D" || comboBox_Payor.SelectedValue.ToString() == "F" || comboBox_Payor.SelectedValue.ToString() == "G")
              {

                  lbl_InsuranceNumber.Show();

              }
              else
              {

                  lbl_InsuranceNumber.Hide();

              }

              if (comboBox_TransferStatus.SelectedValue.ToString() == "3" || comboBox_TransferStatus.SelectedValue.ToString() == "4" || comboBox_TransferStatus.SelectedValue.ToString() == "5")
              {

                  lbl_TransferFacilityIdentifier.Show();
                  // textBox_TransferFacilityIdentifier.Enabled =true;

              }
              else
              {

                  lbl_TransferFacilityIdentifier.Hide();
                  // textBox_TransferFacilityIdentifier.Enabled = false;
                  //textBox_TransferFacilityIdentifier.Text = "";

              }

              if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1")
              {


                  lbl_InitialLactateLevelCollectionDatetime.Show();
                  lbl_InitialLactateLevelUnit.Show();
                  lbl_InitialLactateLevel.Show();
                  lbl_RepeatLactateLevelCollection.Show();
                  lbl_RepeatLactateLevelCollectionDatetime.Show();

                  textBox_InitialLactateLevel.Enabled = true;
                  textBox_InitialLactateLevelCollectionDatetime.Enabled = true;
                  comboBox_InitialLactateLevelUnit.Enabled = true;
                  comboBox_RepeatLactateLevelCollection.Enabled = true;
                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = true;


              }
              else //if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "2")
              {

                  lbl_InitialLactateLevelCollectionDatetime.Hide();
                  lbl_InitialLactateLevelUnit.Hide();
                  lbl_InitialLactateLevel.Hide();
                  lbl_RepeatLactateLevelCollection.Hide();
                  lbl_RepeatLactateLevelCollectionDatetime.Hide();
                  textBox_InitialLactateLevel.Enabled = false;
                  textBox_InitialLactateLevelCollectionDatetime.Enabled = false;
                  comboBox_InitialLactateLevelUnit.Enabled = false;
                  comboBox_RepeatLactateLevelCollection.Enabled = false;
                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = false;
                  textBox_InitialLactateLevelCollectionDatetime.Text = "";
                  comboBox_InitialLactateLevelUnit.SelectedValue = "Select";
                  textBox_InitialLactateLevel.Text = "";
                  comboBox_RepeatLactateLevelCollection.SelectedValue = "Select";
                  textbox_RepeatLactateLevelCollectionDatetime.Text = "";
              }


              if (comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "1")
              {

                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = true;
                  lbl_RepeatLactateLevelCollectionDatetime.Show();

              }
              else
              {
                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = false;
                  lbl_RepeatLactateLevelCollectionDatetime.Hide();
                  textbox_RepeatLactateLevelCollectionDatetime.Text = "";

              }


              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1")
              {


                  lbl_BloodCultureCollectionDatetime.Show();
                  lbl_BloodCulturePathogen.Show();
                  lbl_BloodCultureResult.Show();
                  lbl_BloodCultureCollectionAcceptableDelay.Show();

                  textBox_BloodCultureCollectionDatetime.Enabled = true;
                  comboBox_BloodCulturePathogen.Enabled = true;
                  comboBoX_BloodCultureResult.Enabled = true;
                  comboBox_BloodCultureCollectionAcceptableDelay.Enabled = true;

              }
              else
              {
                  lbl_BloodCultureCollectionAcceptableDelay.Hide();
                  lbl_BloodCultureCollectionDatetime.Hide();
                  lbl_BloodCulturePathogen.Hide();
                  lbl_BloodCultureResult.Hide();

                  textBox_BloodCultureCollectionDatetime.Enabled = false;
                  comboBox_BloodCulturePathogen.Enabled = false;
                  comboBoX_BloodCultureResult.Enabled = false;
                  comboBox_BloodCultureCollectionAcceptableDelay.Enabled = false;
                  textBox_BloodCultureCollectionDatetime.Text = "";
                  comboBox_BloodCulturePathogen.SelectedValue = "Select";
                  comboBoX_BloodCultureResult.SelectedValue = "Select";
                  comboBox_BloodCultureCollectionAcceptableDelay.SelectedValue = "Select";
              }



              if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1")
              {

                  lbl_AntibioticAdministrationDatetime.Show();
                  lbl_AntibioticAdministrationSelection.Show();

                  textBox_AntibioticAdministrationDatetime.Enabled = true;
                  comboBox_AntibioticAdministrationSelection.Enabled = true;
              }
              else
              {

                  lbl_AntibioticAdministrationDatetime.Hide();
                  lbl_AntibioticAdministrationSelection.Hide();

                  textBox_AntibioticAdministrationDatetime.Enabled = false;
                  comboBox_AntibioticAdministrationSelection.Enabled = false;

                  textBox_AntibioticAdministrationDatetime.Text = "";
                  comboBox_AntibioticAdministrationSelection.SelectedValue = "Select";
              }



              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1")
              {

                  lbl_ExcludedDatetime.Show();
                  lbl_ExcludedReason.Show();

                  textBox_ExcludedDatetime.Enabled = true;
                  checkedListBox_ExcludedReason.Enabled = true;

              }
              else
              {
                  lbl_ExcludedDatetime.Hide();
                  lbl_ExcludedReason.Hide();
                  textBox_ExcludedDatetime.Enabled = false;
                  checkedListBox_ExcludedReason.Enabled = false;
                  textBox_ExcludedDatetime.Text = "";
                  foreach (int i in checkedListBox_ExcludedReason.CheckedIndices)
                  {
                      checkedListBox_ExcludedReason.SetItemCheckState(i, CheckState.Unchecked);
                  }
              }



              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0")
              {
                  lbl_InitialHypotension.Show();
                  lbl_PersistentHypotension.Show();
                  lbl_VasopressorAdministration.Show();

                  lbl_InitialLactateLevelCollection.Show();
                  lbl_BloodCultureCollection.Show();
                  lbl_AntibioticAdministration.Show();





                  comboBox_InitialHypotension.Enabled = true;
                  comboBox_PersistentHypotension.Enabled = true;
                  comboBox_VasopressorAdministration.Enabled = true;

                  if (comboBox_ProtocolType.SelectedValue.ToString() == "1")
                  {
                      lbl_AdultCrystalloidFluidAdministration.Show();
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = true;
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = result;

                      lbl_PediatricCrystalloidFluidAdministration.Hide();
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                      comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);


                  }
                  else if (comboBox_ProtocolType.SelectedValue.ToString() == "2")
                  {
                      lbl_PediatricCrystalloidFluidAdministration.Show();
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;

                      lbl_AdultCrystalloidFluidAdministration.Hide();
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                      comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                  }
                  else if (comboBox_ProtocolType.SelectedValue.ToString() == "0")
                  {
                      lbl_AdultCrystalloidFluidAdministration.Hide();
                      lbl_PediatricCrystalloidFluidAdministration.Hide();
                      //lbl_AdultCrystalloidFluidAdministration.Show();
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = true;
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                      //lbl_PediatricCrystalloidFluidAdministration.Show();
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                  }
                 // comboBox_BloodCultureCollection.Enabled = true;


                  //if (comboBox_ProtocolType.SelectedValue.ToString() == "1")
                  //{
                  //    lbl_AdultCrystalloidFluidAdministration.Show();
                  //    comboBox_AdultCrystalloidFluidAdministration.Enabled = true;


                  //}
                  //else
                  //{
                  //    lbl_AdultCrystalloidFluidAdministration.Hide();
                  //    comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                  //    comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                  //}
                

                  //if (comboBox_ProtocolType.SelectedValue.ToString() == "2")
                  //{
                  //    lbl_PediatricCrystalloidFluidAdministration.Show();
                  //    comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;

                  //}
                  //else
                  //{
                  //    lbl_PediatricCrystalloidFluidAdministration.Hide();
                  //    comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                  //    comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";

                  //}


              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1")
              {

                  lbl_BloodCultureCollection.Hide();
                  lbl_InitialLactateLevelCollection.Hide();
                  lbl_InitialHypotension.Hide();
                  lbl_PersistentHypotension.Hide();
                  lbl_VasopressorAdministration.Hide();
                  //lbl_AdultCrystalloidFluidAdministration.Hide();
                  // lbl_PediatricCrystalloidFluidAdministration.Hide();
                  lbl_AntibioticAdministration.Hide();


                  comboBox_InitialHypotension.Enabled = false;
                  comboBox_PersistentHypotension.Enabled = false;
                  comboBox_VasopressorAdministration.Enabled = false;
                  // comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                  // comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                 // comboBox_BloodCultureCollection.Enabled = false;


                  comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray);
                  comboBox_PersistentHypotension.BackColor = MandatoryColor(Color.Gray);
                  comboBox_VasopressorAdministration.BackColor = MandatoryColor(Color.Gray);
                  comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);
                  // comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                  //comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);


                  comboBox_InitialHypotension.SelectedValue = "Select";
                  comboBox_PersistentHypotension.SelectedValue = "Select";
                  comboBox_VasopressorAdministration.SelectedValue = "Select";
                  // comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                  // comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";
                  //comboBox_BloodCultureCollection.SelectedValue = "Select";

                  if (comboBox_ProtocolType.SelectedValue.ToString() == "1")
                  {
                      lbl_AdultCrystalloidFluidAdministration.Show();
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = true;
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = result;

                      lbl_PediatricCrystalloidFluidAdministration.Hide();
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                      comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);


                  }
                  else if (comboBox_ProtocolType.SelectedValue.ToString() == "2")
                  {
                      lbl_PediatricCrystalloidFluidAdministration.Show();
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;

                      lbl_AdultCrystalloidFluidAdministration.Hide();
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                      comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                  }
                  else if (comboBox_ProtocolType.SelectedValue.ToString() == "0")
                  {
                      lbl_AdultCrystalloidFluidAdministration.Hide();
                      lbl_PediatricCrystalloidFluidAdministration.Hide();
                      //lbl_AdultCrystalloidFluidAdministration.Show();
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = true;
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                      //lbl_PediatricCrystalloidFluidAdministration.Show();
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                  }

              }

              else
              {
                  lbl_InitialLactateLevelCollection.Hide();
                  lbl_BloodCultureCollection.Hide();
                  lbl_InitialHypotension.Hide();
                  lbl_PersistentHypotension.Hide();
                  lbl_VasopressorAdministration.Hide();
                  lbl_AdultCrystalloidFluidAdministration.Hide();
                  lbl_PediatricCrystalloidFluidAdministration.Hide();
                  lbl_AntibioticAdministration.Hide();


                  comboBox_InitialHypotension.Enabled = false;
                  comboBox_PersistentHypotension.Enabled = false;
                  comboBox_VasopressorAdministration.Enabled = false;
                  comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                  comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                  //comboBox_BloodCultureCollection.Enabled = false;

                  comboBox_InitialHypotension.SelectedValue = "Select";
                  comboBox_PersistentHypotension.SelectedValue = "Select";
                  comboBox_VasopressorAdministration.SelectedValue = "Select";
                  comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
                  comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";
                 // comboBox_BloodCultureCollection.SelectedValue = "Select";
              }


              if (comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1")
              {

                  lbl_CrystalloidFluidAdministrationDatetime.Show();
                  lbl_BedsideCardiovascularUltrasound.Show();
                  lbl_CapillaryRefillExamination.Show();
                  lbl_CardiopulmonaryEvaluation.Show();
                  lbl_PassiveLegRaiseExamination.Show();
                  lbl_PeripheralPulseEvaluation.Show();
                  lbl_SkinExamination.Show();
                  lbl_VitalSignsReview.Show();
                  lbl_CentralVenousOxygenMeasurement.Show();
                  lbl_CVPressureMeasurement.Show();
                  lbl_FluidChallengePerformed.Show();

                  textBox_CrystalloidFluidAdministrationDatetime.Enabled = true;
                  comboBox_BedsideCardiovascularUltrasound.Enabled = true;
                  comboBox_CapillaryRefillExamination.Enabled = true;
                  comboBox_CardiopulmonaryEvaluation.Enabled = true;
                  comboBox_PassiveLegRaiseExamination.Enabled = true;
                  comboBox_PeripheralPulseEvaluation.Enabled = true;
                  comboBox_SkinExamination.Enabled = true;
                  comboBox_VitalSignsReview.Enabled = true;
                  comboBox_CentralVenousOxygenMeasurement.Enabled = true;
                  lbl_CVPressureMeasurement.Enabled = true;
                  comboBox_FluidChallengePerformed.Enabled = true;
              }
              else
              {
                  lbl_CrystalloidFluidAdministrationDatetime.Hide();
                  lbl_BedsideCardiovascularUltrasound.Hide();
                  lbl_CapillaryRefillExamination.Hide();
                  lbl_CardiopulmonaryEvaluation.Hide();
                  lbl_PassiveLegRaiseExamination.Hide();
                  lbl_PeripheralPulseEvaluation.Hide();
                  lbl_SkinExamination.Hide();
                  lbl_VitalSignsReview.Hide();
                  lbl_CentralVenousOxygenMeasurement.Hide();
                  lbl_CVPressureMeasurement.Hide();
                  lbl_FluidChallengePerformed.Hide();

                  textBox_CrystalloidFluidAdministrationDatetime.Enabled = false;
                  comboBox_BedsideCardiovascularUltrasound.Enabled = false;
                  comboBox_CapillaryRefillExamination.Enabled = false;
                  comboBox_CardiopulmonaryEvaluation.Enabled = false;
                  comboBox_PassiveLegRaiseExamination.Enabled = false;
                  comboBox_PeripheralPulseEvaluation.Enabled = false;
                  comboBox_SkinExamination.Enabled = false;
                  comboBox_VitalSignsReview.Enabled = false;
                  comboBox_CentralVenousOxygenMeasurement.Enabled = false;
                  comboBox_CentralVenousPressureMeasurement.Enabled = false;
                  comboBox_FluidChallengePerformed.Enabled = false;

                  textBox_CrystalloidFluidAdministrationDatetime.Text = "";
                  comboBox_BedsideCardiovascularUltrasound.SelectedValue = "Select";
                  comboBox_CapillaryRefillExamination.SelectedValue = "Select";
                  comboBox_CardiopulmonaryEvaluation.SelectedValue = "Select";
                  comboBox_PassiveLegRaiseExamination.SelectedValue = "Select";
                  comboBox_PeripheralPulseEvaluation.SelectedValue = "Select";
                  comboBox_SkinExamination.SelectedValue = "Select";
                  comboBox_VitalSignsReview.SelectedValue = "Select";
                  comboBox_CentralVenousOxygenMeasurement.SelectedValue = "Select";
                  comboBox_CentralVenousPressureMeasurement.SelectedValue = "Select";
                  comboBox_FluidChallengePerformed.SelectedValue = "Select";
              }


              if (comboBox_CentralVenousPressureMeasurement.SelectedValue.ToString() == "1")
              {
                  lbl_CVPressureMeasurementDateTime.Show();
                  textBox_CentralVenousPressureMeasurementDatetime.Enabled = true;
              }
              else
              {
                  lbl_CVPressureMeasurementDateTime.Hide();
                  textBox_CentralVenousPressureMeasurementDatetime.Enabled = false;
                  textBox_CentralVenousPressureMeasurementDatetime.Text = "";
              }

              if (comboBox_SkinExamination.SelectedValue.ToString() == "1")
              {
                  lbl_SkinExaminationDateTime.Show();
                  textBox_SkinExaminationDatetime.Enabled = true;
              }
              else
              {
                  lbl_SkinExaminationDateTime.Hide();
                  textBox_SkinExaminationDatetime.Enabled = false;
                  textBox_SkinExaminationDatetime.Text = "";
              }

              if (comboBox_PassiveLegRaiseExamination.SelectedValue.ToString() == "1")
              {

                  lbl_PassiveLegRaiseExaminationDatetime.Show();
                  textBox_PassiveLegRaiseExaminationDatetime.Enabled = true;
              }
              else
              {
                  lbl_PassiveLegRaiseExaminationDatetime.Hide();
                  textBox_PassiveLegRaiseExaminationDatetime.Enabled = false;
                  textBox_PassiveLegRaiseExaminationDatetime.Text = "";
              }

              if (comboBox_CardiopulmonaryEvaluation.SelectedValue.ToString() == "1")
              {
                  lbl_CardiopulmonaryEvaluationDatetime.Show();
                  textBox_CardiopulmonaryEvaluationDatetime.Enabled = true;
              }
              else
              {
                  lbl_CardiopulmonaryEvaluationDatetime.Hide();
                  textBox_CardiopulmonaryEvaluationDatetime.Enabled = false;
                  textBox_CardiopulmonaryEvaluationDatetime.Text = "";
              }

              if (comboBox_BedsideCardiovascularUltrasound.SelectedValue.ToString() == "1")
              {
                  lbl_BedsideCardioUltrasoundDateTime.Show();
                  textBox_BedsideCardiovascularUltrasoundDatetime.Enabled = true;
              }
              else
              {
                  lbl_BedsideCardioUltrasoundDateTime.Hide();
                  textBox_BedsideCardiovascularUltrasoundDatetime.Enabled = false;
                  textBox_BedsideCardiovascularUltrasoundDatetime.Text = "";
              }



              if (comboBox_VasopressorAdministration.SelectedValue.ToString() == "1")
              {
                  lbl_VasopressorAdministrationDateTime.Show();
                  textBox_VasopressorAdministrationDatetime.Enabled = true;
              }
              else
              {
                  lbl_VasopressorAdministrationDateTime.Hide();
                  textBox_VasopressorAdministrationDatetime.Enabled = false;
                  textBox_VasopressorAdministrationDatetime.Text = "";
              }



              if (comboBox_CapillaryRefillExamination.SelectedValue.ToString() == "1")
              {
                  lbl_CapillaryRefillExaminationDatetime.Show();
                  textBox_CapillaryRefillExaminationDatetime.Enabled = true;
              }
              else
              {
                  lbl_CapillaryRefillExaminationDatetime.Hide();
                  textBox_CapillaryRefillExaminationDatetime.Enabled = false;
                  textBox_CapillaryRefillExaminationDatetime.Text = "";
              }


              if (comboBox_PeripheralPulseEvaluation.SelectedValue.ToString() == "1")
              {
                  lbl_PeripheralPulseEvaluationDatetime.Show();
                  textBox_PeripheralPulseEvaluationDatetime.Enabled = true;
              }
              else
              {
                  lbl_PeripheralPulseEvaluationDatetime.Hide();
                  textBox_PeripheralPulseEvaluationDatetime.Enabled = false;
                  textBox_PeripheralPulseEvaluationDatetime.Text = "";
              }

              if (comboBox_CentralVenousOxygenMeasurement.SelectedValue.ToString() == "1")
              {
                  lbl_CentralVenousOxygenMeasurementDatetime.Show();
                  textBox_CentralVenousOxygenMeasurementDatetime.Enabled = true;
              }
              else
              {
                  lbl_CentralVenousOxygenMeasurementDatetime.Hide();
                  textBox_CentralVenousOxygenMeasurementDatetime.Enabled = false;
                  textBox_CentralVenousOxygenMeasurementDatetime.Text = "";
              }


              if (comboBox_FluidChallengePerformed.SelectedValue.ToString() == "1")
              {
                  lbl_FluidChallengePerformedDatetime.Show();
                  textBox_FluidChallengePerformedDatetime.Enabled = true;
              }
              else
              {
                  lbl_FluidChallengePerformedDatetime.Hide();
                  textBox_FluidChallengePerformedDatetime.Enabled = false;
                  textBox_FluidChallengePerformedDatetime.Text = "";
              }

              if (comboBox_VitalSignsReview.SelectedValue.ToString() == "1")
              {
                  lblVitalSignsReviewDatetime.Show();
                  textBox_VitalSignsReviewDatetime.Enabled = true;
              }
              else
              {
                  lblVitalSignsReviewDatetime.Hide();
                  textBox_VitalSignsReviewDatetime.Enabled = false;
                  textBox_VitalSignsReviewDatetime.Text = "";
              }


              if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "1")
              {
                  lbl_MechanicalVentilationDatetime.Show();
                  textBox_MechanicalVentilationDatetime.Enabled = true;
              }
              else
              {
                  lbl_MechanicalVentilationDatetime.Hide();
                  textBox_MechanicalVentilationDatetime.Enabled = false;
                  textBox_MechanicalVentilationDatetime.Text = "";
              }

              if (comboBox_ICU.SelectedValue.ToString() == "1")
              {
                  lbl_ICUAdmissionDatetime.Show();
                  lbl_ICUDischargeDatetime.Show();
                  textBox_ICUAdmissionDatetime.Enabled = true;
                  textBox_ICUDischargeDatetime.Enabled = true;
              }
              else
              {
                  lbl_ICUAdmissionDatetime.Hide();
                  lbl_ICUDischargeDatetime.Hide();
                  textBox_ICUAdmissionDatetime.Enabled = false;
                  textBox_ICUDischargeDatetime.Enabled = false;
                  textBox_ICUAdmissionDatetime.Text = "";
                  textBox_ICUDischargeDatetime.Text = "";
              }



              //if (comboBox_ProtocolType.SelectedIndex == 1)
              //{
              //    lbl_AdultCrystalloidFluidAdministration.Show();
              //    comboBox_AdultCrystalloidFluidAdministration.Enabled = true;

              //}
              //else
              //{
              //    lbl_AdultCrystalloidFluidAdministration.Hide();
              //    comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
              //    comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";
              //}

              //if (comboBox_ProtocolType.SelectedIndex == 2)
              //{
              //    lbl_PediatricCrystalloidFluidAdministration.Show();
              //    comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;

              //}
              //else
              //{
              //    lbl_PediatricCrystalloidFluidAdministration.Hide();
              //    comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
              //    comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";

              //}

              if (comboBox_ProtocolInitiated.SelectedValue.ToString() == "0")
              {
                  comboBox_ProtocolInitiatedPlace.SelectedIndex = 4;
                  comboBox_ProtocolType.SelectedIndex = 3;
                  lbl_ProtocolNotInitiatedReason.Show();
              }
              //else
              //{
              //    comboBox_ProtocolInitiatedPlace.SelectedIndex = 0;
              //    comboBox_ProtocolType.SelectedIndex = 0;
              //    lbl_ProtocolNotInitiatedReason.Hide();
              //}

              if (textBox_LeftEDDatetime.Text.ToString().Trim() != "/  /       :")
              {
                  lbl_DestinationafterED.Show();
                  comboBox_DestinationafterED.Enabled = true;
              }
              else
              {

                  lbl_DestinationafterED.Hide();
                  comboBox_DestinationafterED.Enabled = false;
                  comboBox_DestinationafterED.SelectedValue = "Select";
              }


              if (textbox_TriageDatetime.Text.ToString().Trim() != "/  /       :")
              {
                  textBox_LeftEDDatetime.Enabled = true;
                  lbl_LeftEDDatetime.Show();
              }
              else
              {
                  textBox_LeftEDDatetime.Enabled = false;
                  textBox_LeftEDDatetime.Text = "";
                  lbl_LeftEDDatetime.Hide();
              }



              for (int i = 0; i < checkedListBox_ExcludedReason.Items.Count; i++)
              {
                  if (checkedListBox_ExcludedReason.GetItemChecked(i) == true)
                  {
                      DataRowView castedItem = checkedListBox_ExcludedReason.Items[i] as DataRowView;
                      if (castedItem["ComboBox_Key"].ToString() == "1")
                      {
                          ExcludedResonChecked = 1;
                          break;
                      }
                  }

              }


              if (ExcludedResonChecked == 1)
              {
                  ExcludedResonChecked = 0;
                  lbl_ExcludedExplain.Show();
                  checkedListBox_ExcludedExplain.Enabled = true;
              }
              else
              {
                  lbl_ExcludedExplain.Hide();
                  checkedListBox_ExcludedExplain.Enabled = false;
                  for (int i = 0; i <= checkedListBox_ExcludedExplain.Items.Count - 1; i++)
                  {
                      checkedListBox_ExcludedExplain.SetItemChecked(i, false);
                  }

              }


          }

          private void comboBox_SepticShockPresent_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1")
              {
                  
                  lbl_SepticShockPresentationDatetime.Show();
                  textBox_septicShockPresentationDatetime.Enabled = true;
                  textBox_septicShockPresentationDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lbl_SepticShockPresentationDatetime.Hide();
                  textBox_septicShockPresentationDatetime.Enabled = false;
                  textBox_septicShockPresentationDatetime.Text = "";
                  textBox_septicShockPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void txtDOB_Leave(object sender, EventArgs e)
          {
              if (validateDate(txtDOB.Text.ToString().Trim()) == false)
              {
                  // textBox_AdmissionDateTime.BackColor = Color.White;
                  txtDOB.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Date of Birth should be in format MM/DD/YYYY", "Date of Birth Error");
                  txtDOB.Focus();

              }
              else
              {
                  txtDOB.BackColor = MandatoryColor(Color.White);
              }
          }

          private void SepsisCaseDetails_FormClosing(object sender, FormClosingEventArgs e)
          {
              sm.Show();
          }

          private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (this.tabControl.SelectedIndex == 0)
              {
                  txtId.Focus();
              }
              else if (this.tabControl.SelectedIndex == 1)
              {
                  comboBox_ProtocolInitiated.Focus();
              }
              else if (this.tabControl.SelectedIndex == 2)
              {
                  textBox_EarliestDatetime.Focus();
              }
              else if (this.tabControl.SelectedIndex == 3)
              {
                  comboBox_PlateletCount.Focus();
              }

          }


          public string checkdecimalpoint (string S)
          {
                  if (S.Length >= 1)
              {

                  for (int i = 0; i <= S.Length - 1; i++ )
                  {
                      if ( S[i] == '.')
                      {
                          d = S[i];
                          positionCount = S.Length - 1 - i;
                          break;
                      }


                  }
                


                  if (d=='.')
                  {
                      d=' ';
                      templactate = decimal.Parse(S);
                      if (positionCount >= 2)
                      {
                         
                          templactate = decimal.Round(templactate, 1,MidpointRounding.AwayFromZero);
                       

                      }

                      if ((templactate % 1) == 0)
                      {
                          lactatelevel = (int)templactate;
                          return lactatelevel.ToString();
                      }
                      else
                          {
                                 return templactate.ToString();
                          }






                  }

                     
              }

                  return S;
          }


          private void textBox_InitialLactateLevel_Leave(object sender, EventArgs e)
          {
              try
              {
                  if (textBox_InitialLactateLevel.Text.Length >= 1)
                  {
                      if (LactateCharcheckCheck(textBox_InitialLactateLevel.Text.ToString().Trim()) == true)
                      {
                          textBox_InitialLactateLevel.BackColor = ErrorColor(Color.Red);
                          MessageBox.Show("Initial Lactate Level only accept Numeric or Decimal Values.", "Initial Lactate Level Error");
                          textBox_InitialLactateLevel.Focus();
                          return;

                      }
                      else
                      {
                          if (lbl_InitialLactateLevel.Visible == true)
                              textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.White);
                          else
                              textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
                          // textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.Gray);
                          //textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
                      }


                      Decimaloccurance = textBox_InitialLactateLevel.Text.Count(x => x == '.');
                      if (Decimaloccurance > 1)
                      {
                          textBox_InitialLactateLevel.BackColor = ErrorColor(Color.Red);
                          MessageBox.Show("Initial Lactate Level have invalid input.", "Initial Lactate Level Error");
                          textBox_InitialLactateLevel.Focus();
                          return;
                      }
                      else if (Decimaloccurance == textBox_InitialLactateLevel.Text.ToString().Trim().Length)
                      {
                          textBox_InitialLactateLevel.BackColor = ErrorColor(Color.Red);
                          MessageBox.Show("Initial Lactate Level have invalid input.", "Initial Lactate Level Error");
                          textBox_InitialLactateLevel.Focus();
                          return;
                      }
                      else
                      {
                          if (lbl_InitialLactateLevel.Visible == true)
                              textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.White);
                          else
                              textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
                          //textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
                      }

                  }
                  else
                  {
                      if (lbl_InitialLactateLevel.Visible == true)
                          textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.White);
                      else
                          textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
                      // textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
                  }

                  textBox_InitialLactateLevel.Text = checkdecimalpoint(textBox_InitialLactateLevel.Text.ToString().Trim());

              }
              catch (Exception ex)
              {

              }
          }

      

          private void txtId_Leave(object sender, EventArgs e)
          {
              try
              {
              if (txtId.Text.ToString().Trim().Length >= 1 && txtId.Text.ToString().Trim().Length < 10)
              {
                  txtId.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Unique Personal Identifier should have a length of 10.", "Unique Personal Identifier Error");
                      txtId.Focus();
                      return;
                  }
                  else
                  {
                      txtId.BackColor = MandatoryColor(Color.White);
                  }

              txtId.Text = txtId.Text.ToUpper();

                    }
            catch (Exception ex)
            {

            }
          }

          private void checkedListBox_ExcludedReason_Click(object sender, EventArgs e)
          {

          }

          private void checkedListBox_ExcludedReason_MouseUp(object sender, MouseEventArgs e)
          {
              if (checkedListBox_ExcludedReason.Items.Count > 0)
              {
                  for (int i = 0; i < checkedListBox_ExcludedReason.Items.Count; i++)
                  {
                      if (checkedListBox_ExcludedReason.GetItemChecked(i) == true)
                      {
                          DataRowView castedItem = checkedListBox_ExcludedReason.Items[i] as DataRowView;
                          if (castedItem["ComboBox_Key"].ToString() == "1")
                          {
                              ExcludedResonChecked = 1;
                              break;
                          }
                      }

                  }


                  if (ExcludedResonChecked == 1)
                  {
                      ExcludedResonChecked = 0;
                      lbl_ExcludedExplain.Show();
                      checkedListBox_ExcludedExplain.Enabled = true;

                      checkedListBox_ExcludedExplain.BackColor = MandatoryColor(Color.White);
                  }
                  else
                  {
                      lbl_ExcludedExplain.Hide();
                      checkedListBox_ExcludedExplain.Enabled = false;
                      checkedListBox_ExcludedExplain.BackColor = MandatoryColor(Color.Gray);
                      for (int i = 0; i <= checkedListBox_ExcludedExplain.Items.Count - 1; i++)
                      {
                          checkedListBox_ExcludedExplain.SetItemChecked(i, false);
                      }

                  }



              }
          }

          private void comboBox_SevereSepsisPresent_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "1")
              {

                  lbl_SevereSepsisPresentationDatetime.Show();
                  textBox_SevereSepsisPresentationDatetime.Enabled = true;
                  textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.White);
              }
              else
              {
                  lbl_SevereSepsisPresentationDatetime.Hide();
                  textBox_SevereSepsisPresentationDatetime.Enabled = false;
                  textBox_SevereSepsisPresentationDatetime.Text = "";
                  textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

          private void txtId_Enter(object sender, EventArgs e)
          {

              this.BeginInvoke((MethodInvoker)delegate()
              {
                  txtId.Select(0, 0);
              });      
          
             
          }

          private void TextBox_PatientCtrlNum_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  TextBox_PatientCtrlNum.Select(0, 0);
              });      
          
          }

          private void txtDOB_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  txtDOB.Select(0, 0);
              });      
          }

          private void TextBox_InsuranceNumber_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  TextBox_InsuranceNumber.Select(0, 0);
              });      
          }

          private void txtMRN_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  txtMRN.Select(0, 0);
              });      
          }

          private void TextBox_FacilityIdentifier_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  TextBox_FacilityIdentifier.Select(0, 0);
              });      
          }

          private void textBox_AdmissionDateTime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_AdmissionDateTime.Select(0, 0);
              });      
          }

          private void textBox_DischargedDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_DischargedDatetime.Select(0, 0);
              });      
          }

          private void textBox_TransferFacilityIdentifier_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_TransferFacilityIdentifier.Select(0, 0);
              });      
          }

          private void textBox_ProtocolNIAdditionalDetail_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_ProtocolNIAdditionalDetail.Select(0, 0);
              });      
          }

          private void textBox_ExcludedDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_ExcludedDatetime.Select(0, 0);
              });      
          }

          private void textBox_EarliestDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_EarliestDatetime.Select(0, 0);
              });      
          }

          private void textbox_TriageDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textbox_TriageDatetime.Select(0, 0);
              });      
          }

          private void textBox_SevereSepsisPresentationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_SevereSepsisPresentationDatetime.Select(0, 0);
              });      
          }

          private void textBox_septicShockPresentationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_septicShockPresentationDatetime.Select(0, 0);
              });      
          }

          private void textBox_LeftEDDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_LeftEDDatetime.Select(0, 0);
              });      
          }

          private void textBox_InitialLactateLevelCollectionDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_InitialLactateLevelCollectionDatetime.Select(0, 0);
              });      
          }

          private void textBox_InitialLactateLevel_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_InitialLactateLevel.Select(0, 0);
              });      
          }

          private void textbox_RepeatLactateLevelCollectionDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textbox_RepeatLactateLevelCollectionDatetime.Select(0, 0);
              });      
          }

          private void textBox_BloodCultureCollectionDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_BloodCultureCollectionDatetime.Select(0, 0);
              });      
          }

          private void textBox_AntibioticAdministrationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_AntibioticAdministrationDatetime.Select(0, 0);
              });      
          }

          private void textBox_CrystalloidFluidAdministrationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_CrystalloidFluidAdministrationDatetime.Select(0, 0);
              });      
          }

          private void textBox_BedsideCardiovascularUltrasoundDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_BedsideCardiovascularUltrasoundDatetime.Select(0, 0);
              });      
          }

          private void textBox_VasopressorAdministrationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_VasopressorAdministrationDatetime.Select(0, 0);
              });      
          }

          private void textBox_CardiopulmonaryEvaluationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_CardiopulmonaryEvaluationDatetime.Select(0, 0);
              });      
          }

          private void textBox_CapillaryRefillExaminationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_CapillaryRefillExaminationDatetime.Select(0, 0);
              });      
          }

          private void textBox_PassiveLegRaiseExaminationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_PassiveLegRaiseExaminationDatetime.Select(0, 0);
              });      
          }

          private void textBox_PeripheralPulseEvaluationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_PeripheralPulseEvaluationDatetime.Select(0, 0);
              });      
          }

          private void textBox_SkinExaminationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_SkinExaminationDatetime.Select(0, 0);
              });      
          }

          private void textBox_CentralVenousOxygenMeasurementDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_CentralVenousOxygenMeasurementDatetime.Select(0, 0);
              });      
          }

          private void textBox_CentralVenousPressureMeasurementDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_CentralVenousPressureMeasurementDatetime.Select(0, 0);
              });      
          }

          private void textBox_FluidChallengePerformedDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_FluidChallengePerformedDatetime.Select(0, 0);
              });      
          }

          private void textBox_VitalSignsReviewDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_VitalSignsReviewDatetime.Select(0, 0);
              });      
          }

          private void textBox_MechanicalVentilationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_MechanicalVentilationDatetime.Select(0, 0);
              });      
          }

          private void textBox_ICUAdmissionDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_ICUAdmissionDatetime.Select(0, 0);
              });      
          }

          private void textBox_ICUDischargeDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_ICUDischargeDatetime.Select(0, 0);
              });      
          }

          private void TextBox_InsuranceNumber_Leave(object sender, EventArgs e)
          {


              if (lbl_InsuranceNumber.Visible == true)
                  TextBox_InsuranceNumber.BackColor = MandatoryColor(Color.White);
              else
                   TextBox_InsuranceNumber.BackColor = MandatoryColor(Color.Gray);
            
          }

          private void textBox_TransferFacilityIdentifier_Leave(object sender, EventArgs e)
          {
              if (lbl_TransferFacilityIdentifier.Visible == true)
                  textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.White);
              else
                  textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_ProtocolNotInitiatedReason_Leave(object sender, EventArgs e)
          {
              if (lbl_ProtocolNotInitiatedReason.Visible == true)
                  comboBox_ProtocolNotInitiatedReason.BackColor = result;
              else
                  comboBox_ProtocolNotInitiatedReason.BackColor = MandatoryColor(Color.Gray);
          }

          private void checkedListBox_ExcludedReason_Leave(object sender, EventArgs e)
          {
              if (lbl_ExcludedReason.Visible == true)
                  checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.White);
              else
                  checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_DestinationafterED_Leave(object sender, EventArgs e)
          {
              if (lbl_DestinationafterED.Visible == true)
                  comboBox_DestinationafterED.BackColor = result;
              else
                  comboBox_DestinationafterED.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_InitialLactateLevelUnit_Leave(object sender, EventArgs e)
          {
              if (lbl_InitialLactateLevelUnit.Visible == true)
                  comboBox_InitialLactateLevelUnit.BackColor = result;
              else
                  comboBox_InitialLactateLevelUnit.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_RepeatLactateLevelCollection_Leave(object sender, EventArgs e)
          {
              if (lbl_RepeatLactateLevelCollection.Visible == true)
                  comboBox_RepeatLactateLevelCollection.BackColor = result;
              else
                  comboBox_RepeatLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_BloodCultureCollection_Leave(object sender, EventArgs e)
          {
              if (lbl_BloodCultureCollection.Visible == true)
                  comboBox_BloodCultureCollection.BackColor = result;
              else
                  comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_BloodCultureCollectionAcceptableDelay_Leave(object sender, EventArgs e)
          {
              if (lbl_BloodCultureCollectionAcceptableDelay.Visible == true)
                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = result;
              else
                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBoX_BloodCultureResult_Leave(object sender, EventArgs e)
          {
              if (lbl_BloodCultureResult.Visible == true)
                  comboBoX_BloodCultureResult.BackColor = result;
              else
                  comboBoX_BloodCultureResult.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_BloodCulturePathogen_Leave(object sender, EventArgs e)
          {
              if (lbl_BloodCulturePathogen.Visible == true)
                  comboBox_BloodCulturePathogen.BackColor = result;
              else
                  comboBox_BloodCulturePathogen.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_AntibioticAdministration_Leave(object sender, EventArgs e)
          {
              if (lbl_AntibioticAdministration.Visible == true)
                  comboBox_AntibioticAdministration.BackColor = result;
              else
                  comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_AntibioticAdministrationSelection_Leave(object sender, EventArgs e)
          {
              if (lbl_AntibioticAdministrationSelection.Visible == true)
                  comboBox_AntibioticAdministrationSelection.BackColor = result;
              else
                  comboBox_AntibioticAdministrationSelection.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_AdultCrystalloidFluidAdministration_Leave(object sender, EventArgs e)
          {
              if (lbl_AdultCrystalloidFluidAdministration.Visible == true)
                  comboBox_AdultCrystalloidFluidAdministration.BackColor = result;
              else
                  comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_InitialHypotension_Leave(object sender, EventArgs e)
          {
              if (lbl_InitialHypotension.Visible == true)
                  comboBox_InitialHypotension.BackColor = result;
              else
                  comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_PersistentHypotension_Leave(object sender, EventArgs e)
          {
              if (lbl_PersistentHypotension.Visible == true)
                  comboBox_PersistentHypotension.BackColor = result;
              else
                  comboBox_PersistentHypotension.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_PediatricCrystalloidFluidAdministration_Leave(object sender, EventArgs e)
          {

              if (lbl_PediatricCrystalloidFluidAdministration.Visible == true)
                  comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;
              else
                  comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

          }

          private void comboBox_BedsideCardiovascularUltrasound_Leave(object sender, EventArgs e)
          {
              if (lbl_BedsideCardiovascularUltrasound.Visible == true)
                  comboBox_BedsideCardiovascularUltrasound.BackColor = result;
              else
                  comboBox_BedsideCardiovascularUltrasound.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_CardiopulmonaryEvaluation_Leave(object sender, EventArgs e)
          {
              if (lbl_CardiopulmonaryEvaluation.Visible == true)
                  comboBox_CardiopulmonaryEvaluation.BackColor = result;
              else
                  comboBox_CardiopulmonaryEvaluation.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_PassiveLegRaiseExamination_Leave(object sender, EventArgs e)
          {
              if (lbl_PassiveLegRaiseExamination.Visible == true)
                  comboBox_PassiveLegRaiseExamination.BackColor = result;
              else
                  comboBox_PassiveLegRaiseExamination.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_SkinExamination_Leave(object sender, EventArgs e)
          {
              if (lbl_SkinExamination.Visible == true)
                  comboBox_SkinExamination.BackColor = result;
              else
                  comboBox_SkinExamination.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_CentralVenousPressureMeasurement_Leave(object sender, EventArgs e)
          {
              if (lbl_CVPressureMeasurement.Visible == true)
                  comboBox_CentralVenousPressureMeasurement.BackColor = result;
              else
                  comboBox_CentralVenousPressureMeasurement.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_VitalSignsReview_Leave(object sender, EventArgs e)
          {
              if (lbl_VitalSignsReview.Visible == true)
                  comboBox_VitalSignsReview.BackColor = result;
              else
                  comboBox_VitalSignsReview.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_VasopressorAdministration_Leave(object sender, EventArgs e)
          {
              if (lbl_VasopressorAdministration.Visible == true)
                  comboBox_VasopressorAdministration.BackColor = result;
              else
                  comboBox_VasopressorAdministration.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_CapillaryRefillExamination_Leave(object sender, EventArgs e)
          {
              if (lbl_CapillaryRefillExamination.Visible == true)
                  comboBox_CapillaryRefillExamination.BackColor = result;
              else
                  comboBox_CapillaryRefillExamination.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_PeripheralPulseEvaluation_Leave(object sender, EventArgs e)
          {
              if (lbl_PeripheralPulseEvaluation.Visible == true)
                  comboBox_PeripheralPulseEvaluation.BackColor = result;
              else
                  comboBox_PeripheralPulseEvaluation.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_CentralVenousOxygenMeasurement_Leave(object sender, EventArgs e)
          {
              if (lbl_CentralVenousOxygenMeasurement.Visible == true)
                  comboBox_CentralVenousOxygenMeasurement.BackColor = result;
              else
                  comboBox_CentralVenousOxygenMeasurement.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_FluidChallengePerformed_Leave(object sender, EventArgs e)
          {
              if (lbl_FluidChallengePerformed.Visible == true)
                  comboBox_FluidChallengePerformed.BackColor = result;
              else
                  comboBox_FluidChallengePerformed.BackColor = MandatoryColor(Color.Gray);
          }

          //private void SepsisCaseDetails_HelpButtonClicked(object sender, CancelEventArgs e)
          //{
              
          //    Help hp = new Help();
          //    hp.Show();
          //    e.Cancel = true;
          //}

          private void Label_ClickHere_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
          {

              Help hp = new Help();
              hp.Show();

          }

          private void comboBox_InitialLactateLevelCollection_Leave(object sender, EventArgs e)
          {

              if (lbl_InitialLactateLevelCollection.Visible == true)
                  comboBox_InitialLactateLevelCollection.BackColor = result;
              else
                  comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
          }

        

         

   

        

          //private void checkedListBox_ExcludedReason_Click(object sender, EventArgs e)
          //{
          //    if (checkedListBox_ExcludedReason.Items.Count > 0)
          //    {
          //        foreach (object itemChecked in checkedListBox_ExcludedReason.CheckedItems)
          //        {

          //            DataRowView castedItem = itemChecked as DataRowView;

          //            //if (e.NewValue == CheckState.Checked)
          //            //{
          //            //    lbl_ExcludedExplain.Hide();
          //            if (castedItem["ComboBox_Key"].ToString() == "1")
          //            {
          //                lbl_ExcludedExplain.Show();
          //                break;
          //            }
          //            else
          //            {
          //                lbl_ExcludedExplain.Hide();
          //            }
          //            //}
          //            //else
          //            //{
          //            //    lbl_ExcludedExplain.Hide();
          //            //}

          //        }

          //    }
          //}

          //private void checkedListBox_ExcludedReason_Click(object sender, EventArgs e)
          //{
          //    if (checkedListBox_ExcludedReason.Items.Count > 0)
          //    {
          //        foreach (object itemChecked in checkedListBox_ExcludedReason.CheckedItems)
          //        {

          //            DataRowView castedItem = itemChecked as DataRowView;

          //            //if (e.NewValue == CheckState.Checked)
          //            //{
          //            //    lbl_ExcludedExplain.Hide();
          //            if (castedItem["ComboBox_Key"].ToString() == "1")
          //            {
          //                lbl_ExcludedExplain.Show();
          //                break;
          //            }
          //            //    else
          //            //    {
          //            //        lbl_ExcludedExplain.Hide();
          //            //    }
          //            //}
          //            //else
          //            //{
          //            //    lbl_ExcludedExplain.Hide();
          //            //}

          //        }

          //    }
          //}

      

    
    }
}
