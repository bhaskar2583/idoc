﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Data.Common;
using System.Security;
using Microsoft.VisualBasic.FileIO;

namespace EAIRawImport
{
    public partial class Import : Form
    {
        public Import()
        {
            InitializeComponent();
        }


        private static DataTable GetDataTabletFromCSVFile(string csv_file_path)
        {
            DataTable csvData = new DataTable();
            try
            {
                using (TextFieldParser csvReader = new TextFieldParser(csv_file_path))
                {
                    csvReader.SetDelimiters(new string[] { "," });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    //read column names
                    string[] colFields = csvReader.ReadFields();
                    foreach (string column in colFields)
                    {
                        DataColumn datecolumn = new DataColumn(column);
                        datecolumn.AllowDBNull = true;
                        csvData.Columns.Add(datecolumn);
                    }
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        //Making empty value as null
                        for (int i = 0; i < fieldData.Length; i++)
                        {
                            if (fieldData[i] == "")
                            {
                                fieldData[i] = null;
                            }
                        }
                        csvData.Rows.Add(fieldData);
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return csvData;
        }

        private void Import_Load(object sender, EventArgs e)
        {

            try
            {

                int line = 0;
                //string ConnectionString = @"Server=HANYS-APPS-DB;Database=CRS;User Id=sa;Password=password;";
                string ConnectionString = @"Server=ALB-SQLHNS01D\DEVSQLINST,2050;Database=CRS;Integrated Security = True;";

                //string SendEmailConnectionString = @"Server=HANYS-APPS-DB;Database=HanysNet;User Id=sa;Password=password;";

                string SendEmailConnectionString = @"Server=ALB-SQLHNS01D\DEVSQLINST,2050;Database=HanysNet;Integrated Security = True;";
                SqlConnection Conn = new SqlConnection(ConnectionString);
                int t;
                string Query = "";
                string directoryName;
                string FileName;
                //string location = @"\\SecureVM\Dept\IS\Shared\jiten_Share\Test";
                string location = @"G:\CRS";
                DirectoryInfo dir = new DirectoryInfo(location);
                string dumpData;


                int Contract;
                int Branch;
                int PlanNumber;
                string Client;
                string RegionCode;
                decimal FixedAssets;
                decimal VariableAssets;
                decimal TotalAssets;
                decimal Recur;
                decimal Withdrawl;
                decimal Commissions;




                string PlanNum;
                // string Client
                string totalAssets;
                string AssetFeeRate;
                string AssetBasedFee;
                string PerPartFeeAmt;
                string Participant;
                string PerPaFee;
                string BPAMonthlyAdminFee;
                string CommAmt;

                int CompNum;
                string AccountNumber;
                string ProdType;
                string CommType;
                decimal Amount;
                decimal Paid;
                DateTime StatementDate;
                string[] tempMet;


                string CompName;
                string PlanName;
                DateTime PaidDate;
                string Reference;



                DataTable objTable;
                DataTable tempobjTable;

                SqlCommand SQlCMD = new SqlCommand(Query, Conn);
                SQlCMD.CommandTimeout = 0;
                DateTime EntryDate = DateTime.Now;

                DateTime StatementDt = DateTime.Now;

                string EntryDatetemp;

                string[] fileDirectory = Directory.GetDirectories(location);

                string ExeName;
                string Extension;


                foreach (string Dir in fileDirectory)
                {

                    string[] filePaths = Directory.GetFiles(Dir);
                    directoryName = new DirectoryInfo(Dir).Name;

                    switch (directoryName)
                    {
                        case "Dazl Com": //Interface 5
                            StreamReader fileReadDazz;

                            Conn.Open();
                            foreach (string Filepath in filePaths)
                            {
                                try
                                {

                                    FileName = new DirectoryInfo(Filepath).Name;

                                    fileReadDazz = new StreamReader(Filepath);


                                    Query = "";
                                    Query = @"Truncate table IntfcDAZLRaw";

                                    SQlCMD = new SqlCommand(Query, Conn);

                                    //SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();

                                    while ((dumpData = fileReadDazz.ReadLine()) != null)
                                    {
                                        line++;
                                        //  dumpData = fileRead.ReadLine();


                                        dumpData = dumpData.Replace("'", "''");
                                        Query = "";
                                        Query = @"Insert into IntfcDAZLRaw (DataLine1,RawId,RawLoadDate,RawLoadUser,ProcessedInd,FileName) values";
                                        Query = Query + "('" + dumpData + "'," + line + ",'" + DateTime.Now + "','Auto'," + 0 + ",'" + FileName + "')";


                                        SQlCMD.CommandText = Query;
                                        SQlCMD.CommandType = CommandType.Text;
                                        t = SQlCMD.ExecuteNonQuery();
                                    }

                                    // Job for each file
                                    // DAZL files don't have to input Job ID

                                    //Query = "";
                                    //Query = @"Insert into IntfcJob ([InterfaceID], [Status]";
                                    //Query = Query + ",[InputFName], [EntryDate]) ";
                                    //Query = Query + "VALUES (" + 5 + "," + 0 + ",'" + FileName + "','" + DateTime.Now + "')";


                                    //SQlCMD.CommandText = Query;
                                    //SQlCMD.CommandType = CommandType.Text;
                                    //t = SQlCMD.ExecuteNonQuery();


                                    //Run Respective Stored procedures to laod data
                                    Query = "";
                                    Query = @"IntfcDAZLMain";

                                    SQlCMD.Parameters.Add("@LoadDBName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@LoadDBName"].Value = null;

                                    SQlCMD.Parameters.Add("@InputFileName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@InputFileName"].Value = FileName;



                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.StoredProcedure;
                                    SQlCMD.CommandTimeout = 0;
                                    t = SQlCMD.ExecuteNonQuery();

                                    fileReadDazz.Dispose();
                                    fileReadDazz.Close();

                                    if (File.Exists(Filepath))
                                    {
                                        //File.Move(path, @"\\ALB-FS2\Users\VFRequests\ViewfinityRequests\Processed\" + Path.GetFileName(path));
                                        File.Move(Filepath, @"G:\CRS\Dazl Com\Processed\" + FileName);
                                        //File.Move(Filepath, @"\\SecureVM\Dept\IS\Shared\jiten_Share\Test\Dazl Com\Processed\" + FileName);
                                    }

                                }
                                catch (Exception E)
                                {
                                    //log  (or whatever you want to do with it)


                                    Conn = new SqlConnection(SendEmailConnectionString);

                                    Conn.Open();
                                    Query = "";
                                    Query = @"Insert into EmailHistory (EmailType,Recipients,CCRecipients,BCCRecipients,EmailSubject,EmailBody,SentDate,SendStatus,Priority) values";
                                    Query = Query + "('HBS Error','jkarnik@hanys.org','MJakubow@hanys.org',";
                                    Query = Query + " Null,'Dazl File Error','" + E.Message + "',";
                                    Query = Query + System.Data.SqlTypes.SqlDateTime.Null + "," + System.Data.SqlTypes.SqlBoolean.Null + ",'High')";
                                    SQlCMD = new SqlCommand(Query, Conn);
                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    int j = SQlCMD.ExecuteNonQuery();
                                }

                            }







                            Conn.Close();



                            break;
                        case "DST": //Interface 3,8
                            StreamReader fileReadDST;


                            Conn.Open();
                            foreach (string Filepath in filePaths)
                            {
                                try
                                {

                                    FileName = new DirectoryInfo(Filepath).Name;

                                    fileReadDST = new StreamReader(Filepath);

                                    Query = "";
                                    Query = @"Truncate table IntfcDSTRaw";

                                    SQlCMD = new SqlCommand(Query, Conn);
                                    //SQlCMD.CommandTimeout = 0;
                                    //SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();

                                    while ((dumpData = fileReadDST.ReadLine()) != null)
                                    {
                                        line++;
                                        //  dumpData = fileRead.ReadLine();


                                        dumpData = dumpData.Replace("'", "''");
                                        Query = "";
                                        Query = @"Insert into IntfcDSTRaw (DataLine1,RawLoadDate,RawLoadUser,ProcessedInd,FileName) values";
                                        Query = Query + "('" + dumpData + "','" + DateTime.Now + "','Auto'," + 0 + ",'" + FileName + "')";


                                        SQlCMD.CommandText = Query;
                                        SQlCMD.CommandType = CommandType.Text;
                                        t = SQlCMD.ExecuteNonQuery();
                                    }



                                    // Job for each file
                                    // DST files don't have to input Job ID
                                    //Query = "";
                                    //Query = @"Insert into IntfcJob ([InterfaceID], [Status]";
                                    //Query = Query + ",[InputFName], [EntryDate]) ";
                                    //Query = Query + "VALUES (" + 1 + "," + 0 + ",'" + FileName + "','" + DateTime.Now + "')";


                                    //SQlCMD.CommandText = Query;
                                    //SQlCMD.CommandType = CommandType.Text;
                                    //t = SQlCMD.ExecuteNonQuery();


                                    //Run Respective Stored procedures to laod data
                                    Query = "";
                                    Query = @"IntfcDSTMain";

                                    SQlCMD.Parameters.Add("@LoadDBName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@LoadDBName"].Value = null;

                                    SQlCMD.Parameters.Add("@InputFileName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@InputFileName"].Value = FileName;



                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.StoredProcedure;
                                    SQlCMD.CommandTimeout = 0;
                                    t = SQlCMD.ExecuteNonQuery();


                                    fileReadDST.Dispose();
                                    fileReadDST.Close();

                                    if (File.Exists(Filepath))
                                    {
                                        //File.Move(path, @"\\ALB-FS2\Users\VFRequests\ViewfinityRequests\Processed\" + Path.GetFileName(path));
                                        File.Move(Filepath, @"G:\CRS\DST\Processed\" + FileName);
                                        //File.Move(Filepath, @"\\SecureVM\Dept\IS\Shared\jiten_Share\Test\DST\Processed\" + FileName);
                                    }

                                }
                                catch (Exception E)
                                {
                                    //log  (or whatever you want to do with it)

                                    Conn = new SqlConnection(SendEmailConnectionString);

                                    Conn.Open();
                                    Query = "";
                                    Query = @"Insert into EmailHistory (EmailType,Recipients,CCRecipients,BCCRecipients,EmailSubject,EmailBody,SentDate,SendStatus,Priority) values";
                                    Query = Query + "('HBS Error','jkarnik@hanys.org','MJakubow@hanys.org',";
                                    Query = Query + " Null,'DST File Error','" + E.Message + "',";
                                    Query = Query + System.Data.SqlTypes.SqlDateTime.Null + "," + System.Data.SqlTypes.SqlBoolean.Null + ",'High')";
                                    SQlCMD = new SqlCommand(Query, Conn);
                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    int j = SQlCMD.ExecuteNonQuery();
                                }

                            }


                            Conn.Close();

                            break;
                        case "Lincoln NY Com": //Interface 1

                            foreach (string Filepath in filePaths)
                            {

                                try
                                {

                                    FileName = new DirectoryInfo(Filepath).Name;
                                    //////string conn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source='" + File + "';Extended Properties= \"Excel 8.0;HDR=Yes;IMEX=1\";";
                                    ////string conn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + Filepath + "';Extended Properties='Excel 12.0'";
                                    //////DbProviderFactory objDbFactory = DbProviderFactories.GetFactory("System.Data.OleDb");



                                    ////OleDbConnection objConn = new OleDbConnection(conn);
                                    ////objConn.Open();

                                    ////    //DataTable dtSchema = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                                    ////    //string sheetname = dtSchema.Rows[0].Field<string>("TABLE_NAME");

                                    ////    OleDbCommand objCmdSelect = new OleDbCommand("SELECT * FROM [Lincoln$A1:K]", objConn);
                                    ////OleDbDataAdapter objAdapter = new OleDbDataAdapter();
                                    ////objAdapter.SelectCommand = objCmdSelect;
                                    //// DataSet objDataset = new DataSet();

                                    // DataTable Sheets = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                                    //var sheetnames = objConn.GetSchema();
                                    ////// objAdapter.Fill(objDataset);
                                    ////// tempobjTable = objDataset.Tables[0];
                                    ///////objConn.Close();

                                    tempobjTable = GetDataTabletFromCSVFile(Filepath);
                                    Console.WriteLine("Rows count:" + tempobjTable.Rows.Count);
                                    Console.ReadLine();


                                    for (int i = tempobjTable.Rows.Count - 1; i >= 0; i--)
                                    {
                                        DataRow dr = tempobjTable.Rows[i];
                                        //Console.WriteLine(dr[3].ToString());
                                        // dr[3] = dr[3].ToString().Replace(".00", "");
                                        // dr[3] = dr[3].ToString().Replace(".00", "");
                                        dr["FIXED ASSETS"] = dr["FIXED ASSETS"].ToString().Replace(",", "");
                                        // dr["FIXED ASSETS"] = dr["FIXED ASSETS"].ToString().Replace(".00", "");
                                        dr["FIXED ASSETS"] = dr["FIXED ASSETS"].ToString().Replace("$", "");
                                        dr["VARIABLE ASSETS"] = dr["VARIABLE ASSETS"].ToString().Replace(",", "");
                                        //  dr[4] = dr[4].ToString().Replace(".00", "");
                                        dr["VARIABLE ASSETS"] = dr["VARIABLE ASSETS"].ToString().Replace("$", "");
                                        dr["TTL ASSETS"] = dr["TTL ASSETS"].ToString().Replace(",", "");
                                        //dr["TTL ASSETS"] = dr["TTL ASSETS"].ToString().Replace(".00", "");
                                        dr["TTL ASSETS"] = dr["TTL ASSETS"].ToString().Replace("$", "");
                                        dr["RECUR"] = dr["RECUR"].ToString().Replace(",", "");
                                        // dr["RECUR"] = dr["RECUR"].ToString().Replace(".00", "");
                                        dr["RECUR"] = dr["RECUR"].ToString().Replace("$", "");
                                        dr["W/D"] = dr["W/D"].ToString().Replace(",", "");
                                        // dr["W/D"] = dr["W/D"].ToString().Replace(".00", "");
                                        dr["W/D"] = dr["W/D"].ToString().Replace("$", "");

                                        dr["COMM"] = dr["COMM"].ToString().Replace(",", "");
                                        // dr["COMM"] = dr["COMM"].ToString().Replace(".00", "");
                                        dr["COMM"] = dr["COMM"].ToString().Replace("$", "");
                                    }



                                    IEnumerable<DataRow> rows = tempobjTable.AsEnumerable().Where(x => x.Field<string>(0) != "TOTALS").Where(x => x.IsNull(0) == false).Where(x => x.Field<string>(5) != "");



                                    objTable = rows.CopyToDataTable();

                                    // objTable.Rows.RemoveAt(objTable.Rows.Count - 1);

                                    Conn = new SqlConnection(ConnectionString);

                                    Conn.Open();
                                    // SQlCMD = new SqlCommand(Query, Conn);



                                    EntryDatetemp = FileName.Substring(0, 6);
                                    EntryDatetemp = EntryDatetemp.Insert(2, "-");
                                    EntryDatetemp = EntryDatetemp.Insert(5, "-");


                                    EntryDate = DateTime.Parse(EntryDatetemp);


                                    Query = "";
                                    Query = @"Truncate table IntfcLincolnRaw";
                                    SQlCMD = new SqlCommand(Query, Conn);
                                    //SQlCMD.CommandTimeout = 0;
                                    // SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();


                                    for (int p = 0; p <= objTable.Rows.Count - 1; p++)
                                    {
                                        Query = "";
                                        Query = @"Insert into IntfcLincolnRaw (PlanNumber,PlanName,RegionCode,FixedAssets,VariableAssets,TotalAssets,Recur,Withdrawl,Commissions,RawLoadDate,RawLoadUser,ProcessedInd,FileName) values";



                                        // Contract = Convert.ToInt32(objTable.Rows[p]["CONTRACT"]);
                                        // Branch = Convert.ToInt32(objTable.Rows[p]["BRANCH"]);
                                        PlanNumber = Convert.ToInt32(objTable.Rows[p]["PLAN_ID"]);
                                        Client = objTable.Rows[p]["CLIENT"].ToString();
                                        RegionCode = objTable.Rows[p]["DIV"].ToString();
                                        FixedAssets = Convert.ToDecimal(objTable.Rows[p]["FIXED ASSETS"]);
                                        VariableAssets = Convert.ToDecimal(objTable.Rows[p]["VARIABLE ASSETS"]);
                                        TotalAssets = Convert.ToDecimal(objTable.Rows[p]["TTL ASSETS"]);
                                        Recur = Convert.ToDecimal(objTable.Rows[p]["RECUR"]);
                                        Withdrawl = Convert.ToDecimal(objTable.Rows[p]["W/D"]);
                                        Commissions = Convert.ToDecimal(objTable.Rows[p]["COMM"]);

                                        RegionCode = RegionCode.Replace("'", "''");
                                        Client = Client.Replace("'", "''");



                                        Client = Client.Replace("'", "''");
                                        RegionCode = RegionCode.Replace("'", "''");


                                        //Query = Query + "(" + Contract + "," + Branch + "," + PlanNumber + ",'";
                                        Query = Query + "(" + PlanNumber + ",'";
                                        Query = Query + Client + "','" + RegionCode + "'," + FixedAssets + ",";
                                        Query = Query + VariableAssets + "," + TotalAssets + ",";
                                        Query = Query + Recur + "," + Withdrawl + "," + Commissions + ",'" + DateTime.Now + "','Auto'," + 0 + ",'" + FileName + "')";

                                        SQlCMD = new SqlCommand(Query, Conn);
                                        SQlCMD.CommandText = Query;
                                        SQlCMD.CommandType = CommandType.Text;
                                        t = SQlCMD.ExecuteNonQuery();


                                    }


                                    // Job for each file
                                    Query = "";
                                    Query = @"Insert into IntfcJob ([InterfaceID], [Status]";
                                    Query = Query + ",[InputFName], [EntryDate]) ";
                                    Query = Query + "VALUES (" + 1 + "," + 0 + ",'" + FileName + "','" + EntryDate + "')";


                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();


                                    //Run Respective Stored procedures to laod data
                                    Query = "";
                                    Query = @"IntfcLincolnMain";

                                    SQlCMD.Parameters.Add("@LoadDBName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@LoadDBName"].Value = null;

                                    SQlCMD.Parameters.Add("@InputFileName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@InputFileName"].Value = FileName;



                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.StoredProcedure;
                                    SQlCMD.CommandTimeout = 0;
                                    t = SQlCMD.ExecuteNonQuery();



                                    Conn.Close();


                                    if (File.Exists(Filepath))
                                    {
                                        //File.Move(path, @"\\ALB-FS2\Users\VFRequests\ViewfinityRequests\Processed\" + Path.GetFileName(path));
                                        File.Move(Filepath, @"G:\CRS\Lincoln NY Com\Processed\" + FileName);
                                        // File.Move(Filepath, @"\\SecureVM\Dept\IS\Shared\jiten_Share\Test\Lincoln NY Com\Processed\" + FileName);
                                    }

                                }
                                catch (Exception E)
                                {




                                    Conn = new SqlConnection(SendEmailConnectionString);

                                    Conn.Open();
                                    Query = "";
                                    Query = @"Insert into EmailHistory (EmailType,Recipients,CCRecipients,BCCRecipients,EmailSubject,EmailBody,SentDate,SendStatus,Priority) values";
                                    Query = Query + "('HBS Error','jkarnik@hanys.org','MJakubow@hanys.org',";
                                    Query = Query + " Null,'Lincoln File Error','" + E.Message + "',";
                                    Query = Query + System.Data.SqlTypes.SqlDateTime.Null + "," + System.Data.SqlTypes.SqlBoolean.Null + ",'High')";
                                    SQlCMD = new SqlCommand(Query, Conn);
                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    int j = SQlCMD.ExecuteNonQuery();



                                    //log  (or whatever you want to do with it)
                                }
                            }



                            break;
                        case "Diversified": //Interface 2

                            StreamReader fileReadDiv;


                            Conn.Open();
                            foreach (string Filepath in filePaths)
                            {
                                try
                                {

                                    FileName = new DirectoryInfo(Filepath).Name;

                                    fileReadDiv = new StreamReader(Filepath);



                                    EntryDatetemp = FileName.Substring(0, 6);
                                    EntryDatetemp = EntryDatetemp.Insert(2, "-");
                                    EntryDatetemp = EntryDatetemp.Insert(5, "-");


                                    EntryDate = DateTime.Parse(EntryDatetemp);


                                    Query = "";
                                    Query = @"Truncate table IntfcDIARaw";

                                    SQlCMD = new SqlCommand(Query, Conn);


                                    //SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();

                                    while ((dumpData = fileReadDiv.ReadLine()) != null)
                                    {
                                        line++;
                                        //  dumpData = fileRead.ReadLine();


                                        dumpData = dumpData.Replace("'", "''");
                                        Query = "";
                                        Query = @"Insert into IntfcDIARaw (DataLine1,RawId,RawLoadDate,RawLoadUser,ProcessedInd,FileName) values";
                                        Query = Query + "('" + dumpData + "'," + line + ",'" + DateTime.Now + "','Auto'," + 0 + ",'" + FileName + "')";


                                        SQlCMD.CommandText = Query;
                                        SQlCMD.CommandType = CommandType.Text;
                                        t = SQlCMD.ExecuteNonQuery();
                                    }


                                    // Job for each file
                                    Query = "";
                                    Query = @"Insert into IntfcJob ([InterfaceID], [Status]";
                                    Query = Query + ",[InputFName], [EntryDate]) ";
                                    Query = Query + "VALUES (" + 2 + "," + 0 + ",'" + FileName + "','" + EntryDate + "')";


                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();


                                    //Run Respective Stored procedures to laod data
                                    Query = "";
                                    Query = @"IntfcDIAMain";

                                    SQlCMD.Parameters.Add("@LoadDBName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@LoadDBName"].Value = null;

                                    SQlCMD.Parameters.Add("@InputFileName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@InputFileName"].Value = FileName;



                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.StoredProcedure;
                                    SQlCMD.CommandTimeout = 0;
                                    t = SQlCMD.ExecuteNonQuery();

                                    fileReadDiv.Dispose();
                                    fileReadDiv.Close();

                                    if (File.Exists(Filepath))
                                    {
                                        //File.Move(path, @"\\ALB-FS2\Users\VFRequests\ViewfinityRequests\Processed\" + Path.GetFileName(path));
                                        File.Move(Filepath, @"G:\CRS\Diversified\Processed\" + FileName);
                                        // File.Move(Filepath, @"\\SecureVM\Dept\IS\Shared\jiten_Share\Test\Diversified\Processed\" + FileName);

                                    }


                                }
                                catch (Exception E)
                                {
                                    //log  (or whatever you want to do with it)


                                    Conn = new SqlConnection(SendEmailConnectionString);

                                    Conn.Open();
                                    Query = "";
                                    Query = @"Insert into EmailHistory (EmailType,Recipients,CCRecipients,BCCRecipients,EmailSubject,EmailBody,SentDate,SendStatus,Priority) values";
                                    Query = Query + "('HBS Error','jkarnik@hanys.org','MJakubow@hanys.org',";
                                    Query = Query + " Null,'Diversified File Error','" + E.Message + "',";
                                    Query = Query + System.Data.SqlTypes.SqlDateTime.Null + "," + System.Data.SqlTypes.SqlBoolean.Null + ",'High')";
                                    SQlCMD = new SqlCommand(Query, Conn);
                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    int j = SQlCMD.ExecuteNonQuery();
                                }


                            }


                            Conn.Close();

                            break;

                        case "Oppenheimer": //Interface 7

                            StreamReader fileReadOpp;


                            Conn.Open();
                            foreach (string Filepath in filePaths)
                            {
                                try
                                {
                                    FileName = new DirectoryInfo(Filepath).Name;

                                    fileReadOpp = new StreamReader(Filepath);



                                    EntryDatetemp = FileName.Substring(0, 6);
                                    EntryDatetemp = EntryDatetemp.Insert(2, "-");
                                    EntryDatetemp = EntryDatetemp.Insert(5, "-");


                                    EntryDate = DateTime.Parse(EntryDatetemp);

                                    Query = "";
                                    Query = @"Truncate table IntfcOpp12B1Raw";

                                    SQlCMD = new SqlCommand(Query, Conn);
                                    //SQlCMD.CommandTimeout = 0;
                                    // SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();

                                    while ((dumpData = fileReadOpp.ReadLine()) != null)
                                    {
                                        line++;
                                        //  dumpData = fileRead.ReadLine();


                                        dumpData = dumpData.Replace("'", "''");
                                        Query = "";
                                        Query = @"Insert into IntfcOpp12B1Raw (DataLine1,RawId,RawLoadDate,RawLoadUser,ProcessedInd,FileName) values";
                                        Query = Query + "('" + dumpData + "'," + line + ",'" + DateTime.Now + "','Auto'," + 0 + ",'" + FileName + "')";


                                        SQlCMD.CommandText = Query;
                                        SQlCMD.CommandType = CommandType.Text;
                                        t = SQlCMD.ExecuteNonQuery();
                                    }


                                    // Job for each file
                                    Query = "";
                                    Query = @"Insert into IntfcJob ([InterfaceID], [Status]";
                                    Query = Query + ",[InputFName], [EntryDate]) ";
                                    Query = Query + "VALUES (" + 7 + "," + 0 + ",'" + FileName + "','" + EntryDate + "')";


                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();


                                    //Run Respective Stored procedures to laod data
                                    Query = "";
                                    Query = @"IntfcOpp12B1Main";

                                    SQlCMD.Parameters.Add("@LoadDBName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@LoadDBName"].Value = null;

                                    SQlCMD.Parameters.Add("@InputFileName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@InputFileName"].Value = FileName;



                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.StoredProcedure;
                                    SQlCMD.CommandTimeout = 0;
                                    t = SQlCMD.ExecuteNonQuery();



                                    fileReadOpp.Dispose();
                                    fileReadOpp.Close();

                                    if (File.Exists(Filepath))
                                    {
                                        //File.Move(path, @"\\ALB-FS2\Users\VFRequests\ViewfinityRequests\Processed\" + Path.GetFileName(path));
                                        File.Move(Filepath, @"G:\CRS\Oppenheimer\Processed\" + FileName);
                                        //File.Move(Filepath, @"\\SecureVM\Dept\IS\Shared\jiten_Share\Test\Oppenheimer\Processed\" + FileName);
                                    }

                                }
                                catch (Exception E)
                                {
                                    //log  (or whatever you want to do with it)

                                    Conn = new SqlConnection(SendEmailConnectionString);

                                    Conn.Open();
                                    Query = "";
                                    Query = @"Insert into EmailHistory (EmailType,Recipients,CCRecipients,BCCRecipients,EmailSubject,EmailBody,SentDate,SendStatus,Priority) values";
                                    Query = Query + "('HBS Error','jkarnik@hanys.org','MJakubow@hanys.org',";
                                    Query = Query + " Null,'Oppenheimer File Error','" + E.Message + "',";
                                    Query = Query + System.Data.SqlTypes.SqlDateTime.Null + "," + System.Data.SqlTypes.SqlBoolean.Null + ",'High')";
                                    SQlCMD = new SqlCommand(Query, Conn);
                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    int j = SQlCMD.ExecuteNonQuery();
                                }

                            }


                            Conn.Close();

                            break;
                        case "BPA": // Interface 6
                            foreach (string Filepath in filePaths)
                            {
                                try
                                {
                                    FileName = new DirectoryInfo(Filepath).Name;
                                    //string conn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source='" + File + "';Extended Properties= \"Excel 8.0;HDR=Yes;IMEX=1\";";
                                    ////////string conn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + Filepath + "';Extended Properties='Excel 12.0'";




                                    ////////OleDbConnection objConn = new OleDbConnection(conn);
                                    ////////objConn.Open();
                                    ////////OleDbCommand objCmdSelect = new OleDbCommand("SELECT * FROM [SUMMARY$A7:H]", objConn);
                                    ////////OleDbDataAdapter objAdapter = new OleDbDataAdapter();
                                    ////////objAdapter.SelectCommand = objCmdSelect;
                                    ////////DataSet objDataset = new DataSet();

                                    ////////objAdapter.Fill(objDataset);
                                    ////////tempobjTable = objDataset.Tables[0];
                                    ////////objConn.Close();



                                    tempobjTable = GetDataTabletFromCSVFile(Filepath);
                                    Console.WriteLine("Rows count:" + tempobjTable.Rows.Count);
                                    Console.ReadLine();



                                    for (int i = tempobjTable.Rows.Count - 1; i >= 0; i--)
                                    {
                                        DataRow dr = tempobjTable.Rows[i];
                                        Console.WriteLine(dr[3].ToString());
                                        // dr[3] = dr[3].ToString().Replace(".00", "");
                                        dr[3] = dr[3].ToString().Replace(",", "");
                                        dr[2] = dr[2].ToString().Replace(",", "");
                                        dr[2] = dr[2].ToString().Replace(".00", "");
                                        dr[2] = dr[2].ToString().Replace("$", "");
                                        dr[4] = dr[4].ToString().Replace(",", "");
                                        dr[4] = dr[4].ToString().Replace(".00", "");
                                        dr[4] = dr[4].ToString().Replace("$", "");
                                        dr[5] = dr[5].ToString().Replace(",", "");
                                        dr[5] = dr[5].ToString().Replace(".00", "");
                                        dr[5] = dr[5].ToString().Replace("$", "");
                                        dr[6] = dr[6].ToString().Replace(",", "");
                                        dr[6] = dr[6].ToString().Replace(".00", "");
                                        dr[6] = dr[6].ToString().Replace("$", "");
                                        dr[7] = dr[7].ToString().Replace(",", "");
                                        dr[7] = dr[7].ToString().Replace(".00", "");
                                        dr[7] = dr[7].ToString().Replace("$", "");
                                    }





                                    IEnumerable<DataRow> rows = tempobjTable.AsEnumerable().Skip(8).Where(x => x.IsNull(0) == false);


                                    objTable = rows.CopyToDataTable();






                                    Conn = new SqlConnection(ConnectionString);

                                    Conn.Open();


                                    EntryDatetemp = FileName.Substring(0, 6);
                                    EntryDatetemp = EntryDatetemp.Insert(2, "-");
                                    EntryDatetemp = EntryDatetemp.Insert(5, "-");


                                    EntryDate = DateTime.Parse(EntryDatetemp);

                                    //SQlCMD = new SqlCommand(Query, Conn);

                                    Query = "";
                                    Query = @"Truncate table IntfcBPARaw";

                                    SQlCMD = new SqlCommand(Query, Conn);
                                    //SQlCMD.CommandTimeout = 0;
                                    //SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();


                                    for (int p = 0; p <= objTable.Rows.Count - 1; p++)
                                    {




                                        Query = "";
                                        Query = @"Insert into IntfcBPARaw (Plan#,Client,TotalAssets,AssetFeeRate,AssetBasedFee,PerPartFeeAmt,Participant#,PerPaFee,BPAMonthlyAdminFee,CommAmt,RawLoadDate,RawLoadUser,ProcessedInd,FileName) values";



                                        PlanNum = objTable.Rows[p][0].ToString();
                                        Client = objTable.Rows[p][1].ToString();
                                        totalAssets = objTable.Rows[p][2].ToString();
                                        AssetFeeRate = "";
                                        AssetBasedFee = objTable.Rows[p][4].ToString();
                                        PerPartFeeAmt = objTable.Rows[p][5].ToString();
                                        Participant = objTable.Rows[p][3].ToString();
                                        PerPaFee = "";
                                        BPAMonthlyAdminFee = objTable.Rows[p][6].ToString();
                                        CommAmt = objTable.Rows[p][7].ToString();

                                        PlanNum = PlanNum.Replace("'", "''");
                                        Client = Client.Replace("'", "''");
                                        totalAssets = totalAssets.Replace("'", "''");
                                        AssetFeeRate = AssetFeeRate.Replace("'", "''");
                                        AssetBasedFee = AssetBasedFee.Replace("'", "''");
                                        PerPartFeeAmt = PerPartFeeAmt.Replace("'", "''");
                                        Participant = Participant.Replace("'", "''");
                                        PerPaFee = PerPaFee.Replace("'", "''");
                                        BPAMonthlyAdminFee = BPAMonthlyAdminFee.Replace("'", "''");
                                        CommAmt = CommAmt.Replace("'", "''");


                                        Query = Query + "('" + PlanNum + "','" + Client + "','" + totalAssets + "','";
                                        Query = Query + AssetFeeRate + "','" + AssetBasedFee + "','" + PerPartFeeAmt + "','";
                                        Query = Query + Participant + "','" + PerPaFee + "','";
                                        Query = Query + BPAMonthlyAdminFee + "','" + CommAmt + "','" + DateTime.Now + "','Auto'," + 0 + ",'" + FileName + "')";


                                        SQlCMD.CommandText = Query;
                                        SQlCMD.CommandType = CommandType.Text;
                                        t = SQlCMD.ExecuteNonQuery();


                                    }


                                    // Job for each file
                                    Query = "";
                                    Query = @"Insert into IntfcJob ([InterfaceID], [Status]";
                                    Query = Query + ",[InputFName], [EntryDate]) ";
                                    Query = Query + "VALUES (" + 6 + "," + 0 + ",'" + FileName + "','" + EntryDate + "')";


                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();


                                    //Run Respective Stored procedures to laod data
                                    Query = "";
                                    Query = @"IntfcBPAMain";

                                    SQlCMD.Parameters.Add("@LoadDBName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@LoadDBName"].Value = null;

                                    SQlCMD.Parameters.Add("@InputFileName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@InputFileName"].Value = FileName;

                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.StoredProcedure;
                                    SQlCMD.CommandTimeout = 0;
                                    t = SQlCMD.ExecuteNonQuery();


                                    Conn.Close();

                                    if (File.Exists(Filepath))
                                    {
                                        //File.Move(path, @"\\ALB-FS2\Users\VFRequests\ViewfinityRequests\Processed\" + Path.GetFileName(path));
                                        File.Move(Filepath, @"G:\CRS\BPA\Processed\" + FileName);
                                        // File.Move(Filepath, @"\\SecureVM\Dept\IS\Shared\jiten_Share\Test\BPA\Processed\" + FileName);
                                    }

                                }
                                catch (Exception E)
                                {
                                    //log  (or whatever you want to do with it)

                                    Conn = new SqlConnection(SendEmailConnectionString);

                                    Conn.Open();
                                    Query = "";
                                    Query = @"Insert into EmailHistory (EmailType,Recipients,CCRecipients,BCCRecipients,EmailSubject,EmailBody,SentDate,SendStatus,Priority) values";
                                    Query = Query + "('HBS Error','jkarnik@hanys.org','MJakubow@hanys.org',";
                                    Query = Query + " Null,'BPA File Error','" + E.Message + "',";
                                    Query = Query + System.Data.SqlTypes.SqlDateTime.Null + "," + System.Data.SqlTypes.SqlBoolean.Null + ",'High')";
                                    SQlCMD = new SqlCommand(Query, Conn);
                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    int j = SQlCMD.ExecuteNonQuery();
                                }
                            }



                            break;

                        case "Manual Upload TAB": // Interface 9


                            StreamReader fileReadManualMET;


                            Conn.Open();
                            foreach (string Filepath in filePaths)
                            {
                                try
                                {

                                    FileName = new DirectoryInfo(Filepath).Name;

                                    fileReadManualMET = new StreamReader(Filepath);


                                    EntryDatetemp = FileName.Substring(0, 6);
                                    EntryDatetemp = EntryDatetemp.Insert(2, "-");
                                    EntryDatetemp = EntryDatetemp.Insert(5, "-");


                                    EntryDate = DateTime.Parse(EntryDatetemp);

                                    Query = "";
                                    Query = @"Truncate table IntfcManualMetRawSingleLine";
                                    SQlCMD = new SqlCommand(Query, Conn);
                                    //SQlCMD.CommandTimeout = 0;
                                    //SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();

                                    while ((dumpData = fileReadManualMET.ReadLine()) != null)
                                    {

                                        line++;

                                        dumpData = dumpData.Replace("'", "''");
                                        Query = "";



                                        Query = @"Insert into IntfcManualMetRawSingleLine (DataLine1,RawLoadDate,RawLoadUser,ProcessedInd,FileName) values";
                                        Query = Query + "('" + dumpData + "','" + DateTime.Now + "','Auto'," + 0 + ",'" + FileName + "')";


                                        SQlCMD.CommandText = Query;
                                        SQlCMD.CommandType = CommandType.Text;
                                        t = SQlCMD.ExecuteNonQuery();

                                    }

                                    // Job for each file
                                    Query = "";
                                    Query = @"Insert into IntfcJob ([InterfaceID], [Status]";
                                    Query = Query + ",[InputFName], [EntryDate]) ";
                                    Query = Query + "VALUES (" + 9 + "," + 0 + ",'" + FileName + "','" + EntryDate + "')";


                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();


                                    //Run Respective Stored procedures to laod data
                                    Query = "";
                                    Query = @"IntfcManualMain";

                                    SQlCMD.Parameters.Add("@LoadDBName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@LoadDBName"].Value = null;

                                    SQlCMD.Parameters.Add("@InputFileName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@InputFileName"].Value = FileName;

                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.StoredProcedure;
                                    SQlCMD.CommandTimeout = 0;
                                    t = SQlCMD.ExecuteNonQuery();

                                    fileReadManualMET.Dispose();
                                    fileReadManualMET.Close();

                                    if (File.Exists(Filepath))
                                    {
                                        //File.Move(path, @"\\ALB-FS2\Users\VFRequests\ViewfinityRequests\Processed\" + Path.GetFileName(path));
                                        File.Move(Filepath, @"G:\CRS\Manual Upload TAB\Processed\" + FileName);
                                        //File.Move(Filepath, @"\\SecureVM\Dept\IS\Shared\jiten_Share\Test\Manual Upload TAB\Processed\" + FileName);
                                    }
                                }
                                catch (Exception E)
                                {
                                    //log  (or whatever you want to do with it)

                                    Conn = new SqlConnection(SendEmailConnectionString);

                                    Conn.Open();
                                    Query = "";
                                    Query = @"Insert into EmailHistory (EmailType,Recipients,CCRecipients,BCCRecipients,EmailSubject,EmailBody,SentDate,SendStatus,Priority) values";
                                    Query = Query + "('HBS Error','jkarnik@hanys.org','MJakubow@hanys.org',";
                                    Query = Query + " Null,'Manual Upload Tab File Error','" + E.Message + "',";
                                    Query = Query + System.Data.SqlTypes.SqlDateTime.Null + "," + System.Data.SqlTypes.SqlBoolean.Null + ",'High')";
                                    SQlCMD = new SqlCommand(Query, Conn);
                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    int j = SQlCMD.ExecuteNonQuery();
                                }

                            }




                            Conn.Close();

                            break;

                        case "TMTXT": //  Interface 11
                            StreamReader fileReadTXT;


                            Conn.Open();
                            foreach (string Filepath in filePaths)
                            {
                                try
                                {

                                    FileName = new DirectoryInfo(Filepath).Name;

                                    fileReadTXT = new StreamReader(Filepath);




                                    //while (lastfriday.DayOfWeek != DayOfWeek.Friday)
                                    //    lastfriday = lastfriday.AddDays(-1);

                                    EntryDatetemp = FileName.Substring(0, 6);
                                    EntryDatetemp = EntryDatetemp.Insert(2, "-");
                                    EntryDatetemp = EntryDatetemp.Insert(5, "-");


                                    EntryDate = DateTime.Parse(EntryDatetemp);

                                    // Get statement date from file
                                    EntryDatetemp = FileName.Substring(7, 6);
                                    EntryDatetemp = EntryDatetemp.Insert(2, "-");
                                    EntryDatetemp = EntryDatetemp.Insert(5, "-");

                                    StatementDt = DateTime.Parse(EntryDatetemp);

                                    Query = "";
                                    Query = @"Truncate table IntfcMetVendorRawSingleLine";
                                    SQlCMD = new SqlCommand(Query, Conn);
                                    //SQlCMD.CommandTimeout = 0;
                                    //SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();



                                    //Query = @"Insert into IntfcJob ([InterfaceID], [PreRun], [AllowOverWrite], [CancelRun], [ScheduledStart], [Params], [Status]";
                                    //Query = Query + ",[InputFName], [OutputFName], [EMail], [UserStamp], [DateStamp], [AutomatedYN], [ExceptionLog], [ExceptionFile], [ConfirmLog], [EntryDate]) ";
                                    //Query = Query + "VALUES (" + 11 + "," + nullValue + "," + nullValue + "," + nullValue + "," + nullValue + "," + nullValue + "," + 0 + ",'" + FileName + "'," + nullValue + "," + nullValue + "," + nullValue + "," + nullValue + "," + nullValue + "," + nullValue + "," + nullValue + "," + nullValue + ",'" + DateTime.Now + "')";


                                    while ((dumpData = fileReadTXT.ReadLine()) != null)
                                    {


                                        line++;
                                        //  dumpData = fileRead.ReadLine();
                                        //if (line > 1)


                                        //{


                                        //if (line == 1)
                                        //{
                                        //    dumpData = dumpData + "\tStatement Date";
                                        //}
                                        //else
                                        //{
                                        //    dumpData = dumpData + "\t" + StatementDt.ToString("MM/dd/yyyy");
                                        //}



                                        dumpData = dumpData.Replace("'", "''");
                                        Query = "";



                                        Query = @"Insert into IntfcMetVendorRawSingleLine (DataLine1,RawLoadDate,RawLoadUser,ProcessedInd,FileName) values";
                                        Query = Query + "('" + dumpData + "','" + DateTime.Now + "','Auto'," + 0 + ",'" + FileName + "')";


                                        SQlCMD.CommandText = Query;
                                        SQlCMD.CommandType = CommandType.Text;
                                        t = SQlCMD.ExecuteNonQuery();

                                    }

                                    // Job for each file
                                    Query = "";
                                    Query = @"Insert into IntfcJob ([InterfaceID], [Status]";
                                    Query = Query + ",[InputFName], [EntryDate]) ";
                                    Query = Query + "VALUES (" + 11 + "," + 0 + ",'" + FileName + "','" + EntryDate + "')";


                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    t = SQlCMD.ExecuteNonQuery();


                                    //Run Respective Stored procedures to laod data
                                    Query = "";
                                    Query = @"IntfcMetVendorMain";

                                    SQlCMD.Parameters.Add("@LoadDBName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@LoadDBName"].Value = null;

                                    SQlCMD.Parameters.Add("@InputFileName", SqlDbType.VarChar);
                                    SQlCMD.Parameters["@InputFileName"].Value = FileName;

                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.StoredProcedure;
                                    SQlCMD.CommandTimeout = 0;
                                    t = SQlCMD.ExecuteNonQuery();


                                    fileReadTXT.Dispose();
                                    fileReadTXT.Close();


                                    if (File.Exists(Filepath))
                                    {
                                        //File.Move(path, @"\\ALB-FS2\Users\VFRequests\ViewfinityRequests\Processed\" + Path.GetFileName(path));
                                        File.Move(Filepath, @"G:\CRS\TMTXT\Processed\" + FileName);
                                        //File.Move(Filepath, @"\\SecureVM\Dept\IS\Shared\jiten_Share\Test\TMTXT\Processed\" + FileName);
                                    }

                                }
                                catch (Exception E)
                                {
                                    //log  (or whatever you want to do with it)

                                    Conn = new SqlConnection(SendEmailConnectionString);

                                    Conn.Open();
                                    Query = "";
                                    Query = @"Insert into EmailHistory (EmailType,Recipients,CCRecipients,BCCRecipients,EmailSubject,EmailBody,SentDate,SendStatus,Priority) values";
                                    Query = Query + "('HBS Error','jkarnik@hanys.org','MJakubow@hanys.org',";
                                    Query = Query + " Null,'TMTXT File Error','" + E.Message + "',";
                                    Query = Query + System.Data.SqlTypes.SqlDateTime.Null + "," + System.Data.SqlTypes.SqlBoolean.Null + ",'High')";
                                    SQlCMD = new SqlCommand(Query, Conn);
                                    SQlCMD.CommandText = Query;
                                    SQlCMD.CommandType = CommandType.Text;
                                    int j = SQlCMD.ExecuteNonQuery();
                                }

                            }


                            Conn.Close();

                            break;

                    }




                }


                Application.Exit();
            }
            catch (Exception Ex)
            {


                Application.Exit();



            }
        }
    }
}
