﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LicenseValidator
{
    public class DataBaseConnection
    {
        public string DSN = "HANYS_sepsis";
        public string UserName = "HANYS_SEPSIS_APPLICATION";
        public string Password = "Myr@str@st87";
        //public string Password = "na@c4Y@V@";
    }
}
