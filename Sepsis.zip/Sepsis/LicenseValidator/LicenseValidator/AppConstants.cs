﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LicenseValidator
{
    public class AppConstants
    {
        public const string LEVEL1 = "Level1";
        public const string LEVEL2 = "Level2";
        public const string LEVEL3 = "Level3";
    }
}
