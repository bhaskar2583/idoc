﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LicenseValidator
{
    public class Class2
    {
        public static string Finish { get; set; }
        public static string Key { get; set; }
        public static string Net { get; set; }
        public static string Level { get; set; }
    }
}
