﻿ using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LicenseValidator
{
    public class MetaData
    {
        public int Id { get; set; }
        public string Key1 { get; set; }
        public string Key2 { get; set; }
        public string Key3 { get; set; }
        public string Key4 { get; set; }
    }
    public static class LicenseManager
    {
        public static void Trigger(bool isTrigger = true)
        {
            var watch = new System.Diagnostics.Stopwatch();
            watch.Start();
            var metaData = LicenseManager.GetMetadata();
            Class2.Finish = metaData.Key1;
            Class2.Key = metaData.Key2;
            Class2.Net = metaData.Key3;
            Class2.Level = metaData.Key4;
            var endDate = GetEndDate();
            var timeDiffInDays = (endDate - Convert.ToDateTime(Class1.Begin)).Days;
            var timeDiffInMS = (endDate - Convert.ToDateTime(Class1.Begin)).Minutes;
            int milliseconds = timeDiffInMS * 60 * 1000;
            if (milliseconds <= 0)
            {
                if (!isTrigger)
                {
                    IsLicenseExpired = true;
                    IsLicenseExpiredForLevel1 = true;
                    //if (GetLevel() == AppConstants.LEVEL2)
                    //    IsLicenseExpiredForLevel2 = true;
                    //if (GetLevel() == AppConstants.LEVEL3)
                    //    IsLicenseExpiredForLevel3 = true;
                }

                if (isTrigger)
                {
                    Class1.Begin = DateTime.Now.ToString();
                    Trigger(!isTrigger);
                }
            }


            var thread = new Thread(() =>
            {
                while (!IsLicenseExpired)
                {
                    if (watch.ElapsedMilliseconds > milliseconds)
                    {
                        IsLicenseExpired = true;
                        IsLicenseExpiredForLevel1 = true;
                        //if (GetLevel() == AppConstants.LEVEL2)
                        //    IsLicenseExpiredForLevel2 = true;
                        //if (GetLevel() == AppConstants.LEVEL3)
                        //    IsLicenseExpiredForLevel3 = true;
                    }                        
                }
            });
            thread.Start();
            if (GetLevel() == AppConstants.LEVEL2)
                IsLicenseExpiredForLevel2 = true;
            //if (GetLevel() == AppConstants.LEVEL3)
            //    IsLicenseExpiredForLevel3 = true;
        }
        public static bool IsLicenseExpired { get; set; }
        public static bool IsLicenseExpiredForLevel1 { get; set; }
        public static bool IsLicenseExpiredForLevel2 { get; set; }
        //public static bool IsLicenseExpiredForLevel3 { get; set; }
        public static DateTime GetEndDate()
        {
            string endDate = string.Empty;
            var endDateAsBits = DecryptKey(Class2.Finish, "sblw-3hn8-sqoy19");
            String[] arr = endDateAsBits.Split('-');
            byte[] array = new byte[arr.Length];
            for (int i = 0; i < arr.Length; i++) array[i] = Convert.ToByte(arr[i], 16);

            String[] key = DecryptKey(Class2.Key, "sblw-3hn8-sqoy19").Split('-');
            byte[] keyArray = new byte[key.Length];
            for (int i = 0; i < key.Length; i++) keyArray[i] = Convert.ToByte(key[i], 16);

            String[] iv = DecryptKey(Class2.Net, "sblw-3hn8-sqoy19").Split('-');
            byte[] iVArray = new byte[iv.Length];
            for (int i = 0; i < iv.Length; i++) iVArray[i] = Convert.ToByte(iv[i], 16);


            using (AesManaged myAes = new AesManaged())
            {
                endDate = Decrypt(array, keyArray, iVArray);
            }
            return Convert.ToDateTime(endDate);
        }
        static string Decrypt(byte[] cipherText, byte[] Key, byte[] IV)
        {

            string plaintext = null;
            using (AesManaged aesAlg = new AesManaged())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }
            }
            return plaintext;
        }
        public static string DecryptKey(string input, string key)
        {
            try
            {
                byte[] inputArray = Convert.FromBase64String(input);
                TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
                tripleDES.Key = UTF8Encoding.UTF8.GetBytes(key);
                tripleDES.Mode = CipherMode.ECB;
                tripleDES.Padding = PaddingMode.PKCS7;
                ICryptoTransform cTransform = tripleDES.CreateDecryptor();
                byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
                tripleDES.Clear();
                return UTF8Encoding.UTF8.GetString(resultArray);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error with licence keys:   "+ ex.Message);
                Kill();
                return null;
            }
        }

        public static MetaData GetMetadata()
        {
            OdbcConnection Conn;
            DataBaseConnection Db = new DataBaseConnection();

            string ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;
            try
            {
                using (Conn = new OdbcConnection(ConnectionString))
                {
                    Conn.Open();
                    var result = Conn.Query<MetaData>("select * from Metadata", commandType: CommandType.Text).FirstOrDefault();
                    Conn.Close();
                    return result;
                }
            }
            catch
            {
                MessageBox.Show("Error with Database connection, Please Contact Hanys Support!");
                Kill();
                return null;
            }
        }
        private static void Kill()
        {
            foreach (var process in Process.GetProcessesByName("HANYSSepsisReporting"))
            {
                process.Kill();
            }
        }
        public static string GetLevel()
        {
            string endDate = string.Empty;
            var level = DecryptKey(Class2.Level, "sblw-3hn8-sqoy19");
            return level;
        }
        public static bool GetEndDate_Check()
        {
            var metaData = LicenseManager.GetMetadata();
            if (metaData == null)
            {
                return false;
            }
            else
            {
                Class2.Finish = metaData.Key1;
                Class2.Key = metaData.Key2;
                Class2.Net = metaData.Key3;
                Class2.Level = metaData.Key4;

                try
                {
                    string endDate = string.Empty;
                    var endDateAsBits = DecryptKey1(Class2.Finish, "sblw-3hn8-sqoy19");
                    String[] arr = endDateAsBits.Split('-');
                    byte[] array = new byte[arr.Length];
                    for (int i = 0; i < arr.Length; i++) array[i] = Convert.ToByte(arr[i], 16);

                    String[] key = DecryptKey1(Class2.Key, "sblw-3hn8-sqoy19").Split('-');
                    byte[] keyArray = new byte[key.Length];
                    for (int i = 0; i < key.Length; i++) keyArray[i] = Convert.ToByte(key[i], 16);

                    String[] iv = DecryptKey1(Class2.Net, "sblw-3hn8-sqoy19").Split('-');
                    byte[] iVArray = new byte[iv.Length];
                    for (int i = 0; i < iv.Length; i++) iVArray[i] = Convert.ToByte(iv[i], 16);


                    using (AesManaged myAes = new AesManaged())
                    {
                        endDate = Decrypt(array, keyArray, iVArray);
                    }
                    return true;
                }
                catch
                {
                    return false;
                }
            }
        }
        public static bool GetLevel_Check()
        {
            var metaData = LicenseManager.GetMetadata();
            if (metaData == null)
            {
                return false;
            }
            else
            {
                var level = DecryptKey1(Class2.Level, "sblw-3hn8-sqoy19");
                if (level != null)
                {
                    return true;
                }
                else
                    return false;
            }                          
        }
        public static string DecryptKey1(string input, string key)
        {
            try
            {
                byte[] inputArray = Convert.FromBase64String(input);
                TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
                tripleDES.Key = UTF8Encoding.UTF8.GetBytes(key);
                tripleDES.Mode = CipherMode.ECB;
                tripleDES.Padding = PaddingMode.PKCS7;
                ICryptoTransform cTransform = tripleDES.CreateDecryptor();
                byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
                tripleDES.Clear();
                return UTF8Encoding.UTF8.GetString(resultArray);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
