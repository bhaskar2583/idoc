﻿namespace WindowsFormsApplication1
{
    partial class SepsisCaseDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SepsisCaseDetails));
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lbl_TransferFacilityIdentifier = new System.Windows.Forms.Label();
            this.lbl_TransferStatus = new System.Windows.Forms.Label();
            this.lbl_DischargedStatus = new System.Windows.Forms.Label();
            this.lbl_SourceofAdmission = new System.Windows.Forms.Label();
            this.lbl_DischargeDatetime = new System.Windows.Forms.Label();
            this.lbl_AdmissionDateTime = new System.Windows.Forms.Label();
            this.lbl_FacilityIdentifier = new System.Windows.Forms.Label();
            this.lbl_MRN = new System.Windows.Forms.Label();
            this.lbl_InsuranceNumber = new System.Windows.Forms.Label();
            this.lbl_Payor = new System.Windows.Forms.Label();
            this.lbl_Ethnicity = new System.Windows.Forms.Label();
            this.lbl_Race = new System.Windows.Forms.Label();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.lbl_DOB = new System.Windows.Forms.Label();
            this.lbl_PatientCtrlNum = new System.Windows.Forms.Label();
            this.lbl_txID = new System.Windows.Forms.Label();
            this.textBox_TransferFacilityIdentifier = new System.Windows.Forms.MaskedTextBox();
            this.TextBox_FacilityIdentifier = new System.Windows.Forms.MaskedTextBox();
            this.TextBox_InsuranceNumber = new System.Windows.Forms.MaskedTextBox();
            this.TextBox_PatientCtrlNum = new System.Windows.Forms.MaskedTextBox();
            this.txtId = new System.Windows.Forms.MaskedTextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.txtMRN = new System.Windows.Forms.MaskedTextBox();
            this.textBox_DischargedDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_AdmissionDateTime = new System.Windows.Forms.MaskedTextBox();
            this.txtDOB = new System.Windows.Forms.MaskedTextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button_SourceofAdmission = new System.Windows.Forms.Button();
            this.comboBox_SourceofAdmission = new System.Windows.Forms.ComboBox();
            this.comboBox_DischargeStatus = new System.Windows.Forms.ComboBox();
            this.comboBox_TransferStatus = new System.Windows.Forms.ComboBox();
            this.Label_AdmissionDatetime = new System.Windows.Forms.Label();
            this.Label_SourceofAdmission = new System.Windows.Forms.Label();
            this.Label_DischargeDatetime = new System.Windows.Forms.Label();
            this.Label_DischargedStatus = new System.Windows.Forms.Label();
            this.Label_Transfer = new System.Windows.Forms.Label();
            this.checkedListBox_Race = new System.Windows.Forms.CheckedListBox();
            this.comboBox_Payor = new System.Windows.Forms.ComboBox();
            this.Combobox_Ethnicity = new System.Windows.Forms.ComboBox();
            this.Combobox_Gender = new System.Windows.Forms.ComboBox();
            this.Label_PatientCtrlNum = new System.Windows.Forms.Label();
            this.Label_Ethnicity = new System.Windows.Forms.Label();
            this.Label_InsuranceNumber = new System.Windows.Forms.Label();
            this.Label_Race = new System.Windows.Forms.Label();
            this.Label_Payor = new System.Windows.Forms.Label();
            this.Label_Gender = new System.Windows.Forms.Label();
            this.Label_FacilityIdentifier = new System.Windows.Forms.Label();
            this.Label_MRN = new System.Windows.Forms.Label();
            this.Label_DateofBirth = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lbl_ExcludedExplain = new System.Windows.Forms.Label();
            this.lbl_ProtocolNotInitiatedReason = new System.Windows.Forms.Label();
            this.lbl_ExcludedDatetime = new System.Windows.Forms.Label();
            this.lbl_ExcludedReason = new System.Windows.Forms.Label();
            this.lbl_ProtocolInitaitedPlace = new System.Windows.Forms.Label();
            this.lbl_ExcludedFromProtocol = new System.Windows.Forms.Label();
            this.lbl_ProtocolInitiatedType = new System.Windows.Forms.Label();
            this.lbl_ProtocolInitiated = new System.Windows.Forms.Label();
            this.textBox_ProtocolNIAdditionalDetail = new System.Windows.Forms.MaskedTextBox();
            this.textBox_ExcludedDatetime = new System.Windows.Forms.MaskedTextBox();
            this.checkedListBox_ExcludedReason = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox_ExcludedExplain = new System.Windows.Forms.CheckedListBox();
            this.comboBox_ProtocolInitiated = new System.Windows.Forms.ComboBox();
            this.comboBox_ProtocolNotInitiatedReason = new System.Windows.Forms.ComboBox();
            this.comboBox_ProtocolInitiatedPlace = new System.Windows.Forms.ComboBox();
            this.comboBox_ProtocolType = new System.Windows.Forms.ComboBox();
            this.comboBox_ExcludedFromProtocol = new System.Windows.Forms.ComboBox();
            this.Label_ExcludedFromProtocol = new System.Windows.Forms.Label();
            this.Label_ExcludedDatetime = new System.Windows.Forms.Label();
            this.Label_ExcludedExplain = new System.Windows.Forms.Label();
            this.Label_ProtocolType = new System.Windows.Forms.Label();
            this.Label_ProtocolInitiatedPlace = new System.Windows.Forms.Label();
            this.Label_ExcludedReason = new System.Windows.Forms.Label();
            this.Label_ProtocolNIAdditionalDetail = new System.Windows.Forms.Label();
            this.Label_ProtocolNotInitiatedReason = new System.Windows.Forms.Label();
            this.Label_ProtocolInitiated = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.textBox_InitialLactateLevel = new System.Windows.Forms.TextBox();
            this.lbl_SepticShockPresentationDatetime = new System.Windows.Forms.Label();
            this.lbl_RepeatLactateLevelCollection = new System.Windows.Forms.Label();
            this.lbl_InitialLactateLevel = new System.Windows.Forms.Label();
            this.lbl_AntibioticAdministration = new System.Windows.Forms.Label();
            this.lbl_FluidChallengePerformed = new System.Windows.Forms.Label();
            this.lbl_CentralVenousOxygenMeasurement = new System.Windows.Forms.Label();
            this.lbl_PeripheralPulseEvaluation = new System.Windows.Forms.Label();
            this.lbl_CapillaryRefillExamination = new System.Windows.Forms.Label();
            this.lbl_VitalSignsReview = new System.Windows.Forms.Label();
            this.lbl_CVPressureMeasurement = new System.Windows.Forms.Label();
            this.lbl_SkinExamination = new System.Windows.Forms.Label();
            this.lbl_PassiveLegRaiseExamination = new System.Windows.Forms.Label();
            this.lbl_CardiopulmonaryEvaluation = new System.Windows.Forms.Label();
            this.lbl_BedsideCardiovascularUltrasound = new System.Windows.Forms.Label();
            this.lblVitalSignsReviewDatetime = new System.Windows.Forms.Label();
            this.lbl_CVPressureMeasurementDateTime = new System.Windows.Forms.Label();
            this.lbl_SkinExaminationDateTime = new System.Windows.Forms.Label();
            this.lbl_PassiveLegRaiseExaminationDatetime = new System.Windows.Forms.Label();
            this.lbl_CardiopulmonaryEvaluationDatetime = new System.Windows.Forms.Label();
            this.lbl_BedsideCardioUltrasoundDateTime = new System.Windows.Forms.Label();
            this.lbl_FluidChallengePerformedDatetime = new System.Windows.Forms.Label();
            this.lbl_CentralVenousOxygenMeasurementDatetime = new System.Windows.Forms.Label();
            this.lbl_PeripheralPulseEvaluationDatetime = new System.Windows.Forms.Label();
            this.lbl_CapillaryRefillExaminationDatetime = new System.Windows.Forms.Label();
            this.lbl_VasopressorAdministrationDateTime = new System.Windows.Forms.Label();
            this.lbl_VasopressorAdministration = new System.Windows.Forms.Label();
            this.lbl_PersistentHypotension = new System.Windows.Forms.Label();
            this.lbl_InitialHypotension = new System.Windows.Forms.Label();
            this.lbl_CrystalloidFluidAdministrationDatetime = new System.Windows.Forms.Label();
            this.lbl_PediatricCrystalloidFluidAdministration = new System.Windows.Forms.Label();
            this.lbl_AdultCrystalloidFluidAdministration = new System.Windows.Forms.Label();
            this.lbl_AntibioticAdministrationDatetime = new System.Windows.Forms.Label();
            this.lbl_AntibioticAdministrationSelection = new System.Windows.Forms.Label();
            this.lbl_BloodCulturePathogen = new System.Windows.Forms.Label();
            this.lbl_BloodCultureResult = new System.Windows.Forms.Label();
            this.lbl_BloodCultureCollectionDatetime = new System.Windows.Forms.Label();
            this.lbl_BloodCultureCollectionAcceptableDelay = new System.Windows.Forms.Label();
            this.lbl_RepeatLactateLevelCollectionDatetime = new System.Windows.Forms.Label();
            this.lbl_BloodCultureCollection = new System.Windows.Forms.Label();
            this.lbl_InitialLactateLevelUnit = new System.Windows.Forms.Label();
            this.lbl_InitialLactateLevelCollectionDatetime = new System.Windows.Forms.Label();
            this.lbl_DestinationafterED = new System.Windows.Forms.Label();
            this.lbl_LeftEDDatetime = new System.Windows.Forms.Label();
            this.lbl_SepticShockPresent = new System.Windows.Forms.Label();
            this.lbl_SevereSepsisPresentationDatetime = new System.Windows.Forms.Label();
            this.lbl_SevereSepsisPresent = new System.Windows.Forms.Label();
            this.lbl_EarliestDatetime = new System.Windows.Forms.Label();
            this.textBox_VitalSignsReviewDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_CentralVenousPressureMeasurementDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_FluidChallengePerformedDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_CentralVenousOxygenMeasurementDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_PeripheralPulseEvaluationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_CapillaryRefillExaminationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_PassiveLegRaiseExaminationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_CardiopulmonaryEvaluationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_SkinExaminationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_BedsideCardiovascularUltrasoundDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_AntibioticAdministrationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_BloodCultureCollectionDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_VasopressorAdministrationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_CrystalloidFluidAdministrationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textbox_RepeatLactateLevelCollectionDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_InitialLactateLevelCollectionDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_LeftEDDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_septicShockPresentationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_SevereSepsisPresentationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textbox_TriageDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_EarliestDatetime = new System.Windows.Forms.MaskedTextBox();
            this.comboBox_SkinExamination = new System.Windows.Forms.ComboBox();
            this.comboBox_CentralVenousOxygenMeasurement = new System.Windows.Forms.ComboBox();
            this.comboBox_FluidChallengePerformed = new System.Windows.Forms.ComboBox();
            this.comboBox_CentralVenousPressureMeasurement = new System.Windows.Forms.ComboBox();
            this.comboBox_VitalSignsReview = new System.Windows.Forms.ComboBox();
            this.comboBox_PassiveLegRaiseExamination = new System.Windows.Forms.ComboBox();
            this.comboBox_PeripheralPulseEvaluation = new System.Windows.Forms.ComboBox();
            this.comboBox_BedsideCardiovascularUltrasound = new System.Windows.Forms.ComboBox();
            this.comboBox_CapillaryRefillExamination = new System.Windows.Forms.ComboBox();
            this.comboBox_CardiopulmonaryEvaluation = new System.Windows.Forms.ComboBox();
            this.comboBox_RepeatLactateLevelCollection = new System.Windows.Forms.ComboBox();
            this.comboBox_PersistentHypotension = new System.Windows.Forms.ComboBox();
            this.comboBox_VasopressorAdministration = new System.Windows.Forms.ComboBox();
            this.comboBox_InitialHypotension = new System.Windows.Forms.ComboBox();
            this.comboBox_PediatricCrystalloidFluidAdministration = new System.Windows.Forms.ComboBox();
            this.comboBox_BloodCultureCollection = new System.Windows.Forms.ComboBox();
            this.comboBox_BloodCultureCollectionAcceptableDelay = new System.Windows.Forms.ComboBox();
            this.comboBox_AntibioticAdministrationSelection = new System.Windows.Forms.ComboBox();
            this.comboBox_AdultCrystalloidFluidAdministration = new System.Windows.Forms.ComboBox();
            this.comboBox_InitialLactateLevelUnit = new System.Windows.Forms.ComboBox();
            this.comboBox_BloodCulturePathogen = new System.Windows.Forms.ComboBox();
            this.comboBox_AntibioticAdministration = new System.Windows.Forms.ComboBox();
            this.comboBox_SepticShockPresent = new System.Windows.Forms.ComboBox();
            this.comboBox_InitialLactateLevelCollection = new System.Windows.Forms.ComboBox();
            this.comboBoX_BloodCultureResult = new System.Windows.Forms.ComboBox();
            this.comboBox_DestinationafterED = new System.Windows.Forms.ComboBox();
            this.comboBox_SevereSepsisPresent = new System.Windows.Forms.ComboBox();
            this.label_CentralVenousOxygenMeasurement = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.Label_AntibioticAdministrationSelection = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label_VasopressorAdministration = new System.Windows.Forms.Label();
            this.label_VasopressorAdministrationDateTime = new System.Windows.Forms.Label();
            this.Label_InitialHypotension = new System.Windows.Forms.Label();
            this.label_PersistentHypotension = new System.Windows.Forms.Label();
            this.Label_CrystalloidFluidAdministrationDatetime = new System.Windows.Forms.Label();
            this.Label_AdultCrystalloidFluidAdministration = new System.Windows.Forms.Label();
            this.PediatricCrystalloidFluidAdministration = new System.Windows.Forms.Label();
            this.Label_AntibioticAdministrationDatetime = new System.Windows.Forms.Label();
            this.Label_BloodCulturePathogen = new System.Windows.Forms.Label();
            this.Label_BloodCultureCollection = new System.Windows.Forms.Label();
            this.Label_LeftEDDatetime = new System.Windows.Forms.Label();
            this.Label_InitialLactateLevel = new System.Windows.Forms.Label();
            this.Label_SevereSepsisPresent = new System.Windows.Forms.Label();
            this.Label_BloodCultureCollectionAcceptableDelay = new System.Windows.Forms.Label();
            this.Label_SevereSepsisPresentationDatetime = new System.Windows.Forms.Label();
            this.Label_InitialLactateLevelUnit = new System.Windows.Forms.Label();
            this.Label_AntibioticAdministration = new System.Windows.Forms.Label();
            this.Label_DestinationafterED = new System.Windows.Forms.Label();
            this.Label_BloodCultureResult = new System.Windows.Forms.Label();
            this.Label_RepeatLactateLevelCollectionDatetime = new System.Windows.Forms.Label();
            this.Label_InitialLactateLevelCollectionDatetime = new System.Windows.Forms.Label();
            this.Label_SepticShockPresentationDatetime = new System.Windows.Forms.Label();
            this.Label_BloodCultureCollectionDatetime = new System.Windows.Forms.Label();
            this.Label_SepticShockPresent = new System.Windows.Forms.Label();
            this.Label_InitialLactateLevelCollection = new System.Windows.Forms.Label();
            this.Label_RepeatLactateLevelCollection = new System.Windows.Forms.Label();
            this.Label_TriageDatetime = new System.Windows.Forms.Label();
            this.Label_EarliestDatetime = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.lbl_ICUDischargeDatetime = new System.Windows.Forms.Label();
            this.lbl_ICUAdmissionDatetime = new System.Windows.Forms.Label();
            this.lbl_MechanicalVentilationDatetime = new System.Windows.Forms.Label();
            this.lbl_Diabetes = new System.Windows.Forms.Label();
            this.lbl_ChronicRenalFailure = new System.Windows.Forms.Label();
            this.lbl_OrganTransplant = new System.Windows.Forms.Label();
            this.lbl_ChronicLiverDisease = new System.Windows.Forms.Label();
            this.lbl_CongestiveHeartFailure = new System.Windows.Forms.Label();
            this.lbl_ImmuneModifyingMedications = new System.Windows.Forms.Label();
            this.lbl_Lymphoma = new System.Windows.Forms.Label();
            this.lbl_MetastaticCancer = new System.Windows.Forms.Label();
            this.lbl_AIDSDisease = new System.Windows.Forms.Label();
            this.lbl_ChronicRespiratoryFailure = new System.Windows.Forms.Label();
            this.lbl_ICU = new System.Windows.Forms.Label();
            this.lbl_MechanicalVentilation = new System.Windows.Forms.Label();
            this.lbl_SiteofInfection = new System.Windows.Forms.Label();
            this.lbl_LowerRespiratoryInfection = new System.Windows.Forms.Label();
            this.lbl_InfectionEtiology = new System.Windows.Forms.Label();
            this.lbl_Bandemia = new System.Windows.Forms.Label();
            this.lbl_AlteredMentalStatus = new System.Windows.Forms.Label();
            this.lbl_PlateletCount = new System.Windows.Forms.Label();
            this.textBox_ICUDischargeDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_ICUAdmissionDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_MechanicalVentilationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.comboBox_ICU = new System.Windows.Forms.ComboBox();
            this.comboBox_AIDSDisease = new System.Windows.Forms.ComboBox();
            this.comboBox_ChronicRespiratoryFailure = new System.Windows.Forms.ComboBox();
            this.comboBox_MechanicalVentilation = new System.Windows.Forms.ComboBox();
            this.comboBox_InfectionEtiology = new System.Windows.Forms.ComboBox();
            this.comboBox_SiteofInfection = new System.Windows.Forms.ComboBox();
            this.comboBox_Lymphoma = new System.Windows.Forms.ComboBox();
            this.comboBox_AlteredMentalStatus = new System.Windows.Forms.ComboBox();
            this.comboBox_Diabetes = new System.Windows.Forms.ComboBox();
            this.comboBox_ChronicLiverDisease = new System.Windows.Forms.ComboBox();
            this.comboBox_OrganTransplant = new System.Windows.Forms.ComboBox();
            this.comboBox_ImmuneModifyingMedications = new System.Windows.Forms.ComboBox();
            this.comboBox_ChronicRenalFailure = new System.Windows.Forms.ComboBox();
            this.comboBox_CongestiveHeartFailure = new System.Windows.Forms.ComboBox();
            this.comboBox_PlateletCount = new System.Windows.Forms.ComboBox();
            this.comboBox_Bandemia = new System.Windows.Forms.ComboBox();
            this.comboBox_LowerRespiratoryInfection = new System.Windows.Forms.ComboBox();
            this.comboBox_MetastaticCancer = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.button_SaveCase = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.lbl_nt = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label_Copyright = new System.Windows.Forms.Label();
            this.Label_Contact = new System.Windows.Forms.Label();
            this.Label_ClickHere = new System.Windows.Forms.LinkLabel();
            this.lbl_InitialLactateLevelCollection = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Controls.Add(this.tabPage4);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1241, 577);
            this.tabControl.TabIndex = 300;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lbl_TransferFacilityIdentifier);
            this.tabPage1.Controls.Add(this.lbl_TransferStatus);
            this.tabPage1.Controls.Add(this.lbl_DischargedStatus);
            this.tabPage1.Controls.Add(this.lbl_SourceofAdmission);
            this.tabPage1.Controls.Add(this.lbl_DischargeDatetime);
            this.tabPage1.Controls.Add(this.lbl_AdmissionDateTime);
            this.tabPage1.Controls.Add(this.lbl_FacilityIdentifier);
            this.tabPage1.Controls.Add(this.lbl_MRN);
            this.tabPage1.Controls.Add(this.lbl_InsuranceNumber);
            this.tabPage1.Controls.Add(this.lbl_Payor);
            this.tabPage1.Controls.Add(this.lbl_Ethnicity);
            this.tabPage1.Controls.Add(this.lbl_Race);
            this.tabPage1.Controls.Add(this.lbl_Gender);
            this.tabPage1.Controls.Add(this.lbl_DOB);
            this.tabPage1.Controls.Add(this.lbl_PatientCtrlNum);
            this.tabPage1.Controls.Add(this.lbl_txID);
            this.tabPage1.Controls.Add(this.textBox_TransferFacilityIdentifier);
            this.tabPage1.Controls.Add(this.TextBox_FacilityIdentifier);
            this.tabPage1.Controls.Add(this.TextBox_InsuranceNumber);
            this.tabPage1.Controls.Add(this.TextBox_PatientCtrlNum);
            this.tabPage1.Controls.Add(this.txtId);
            this.tabPage1.Controls.Add(this.label38);
            this.tabPage1.Controls.Add(this.label32);
            this.tabPage1.Controls.Add(this.txtMRN);
            this.tabPage1.Controls.Add(this.textBox_DischargedDatetime);
            this.tabPage1.Controls.Add(this.textBox_AdmissionDateTime);
            this.tabPage1.Controls.Add(this.txtDOB);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button_SourceofAdmission);
            this.tabPage1.Controls.Add(this.comboBox_SourceofAdmission);
            this.tabPage1.Controls.Add(this.comboBox_DischargeStatus);
            this.tabPage1.Controls.Add(this.comboBox_TransferStatus);
            this.tabPage1.Controls.Add(this.Label_AdmissionDatetime);
            this.tabPage1.Controls.Add(this.Label_SourceofAdmission);
            this.tabPage1.Controls.Add(this.Label_DischargeDatetime);
            this.tabPage1.Controls.Add(this.Label_DischargedStatus);
            this.tabPage1.Controls.Add(this.Label_Transfer);
            this.tabPage1.Controls.Add(this.checkedListBox_Race);
            this.tabPage1.Controls.Add(this.comboBox_Payor);
            this.tabPage1.Controls.Add(this.Combobox_Ethnicity);
            this.tabPage1.Controls.Add(this.Combobox_Gender);
            this.tabPage1.Controls.Add(this.Label_PatientCtrlNum);
            this.tabPage1.Controls.Add(this.Label_Ethnicity);
            this.tabPage1.Controls.Add(this.Label_InsuranceNumber);
            this.tabPage1.Controls.Add(this.Label_Race);
            this.tabPage1.Controls.Add(this.Label_Payor);
            this.tabPage1.Controls.Add(this.Label_Gender);
            this.tabPage1.Controls.Add(this.Label_FacilityIdentifier);
            this.tabPage1.Controls.Add(this.Label_MRN);
            this.tabPage1.Controls.Add(this.Label_DateofBirth);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1233, 551);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Demographics";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lbl_TransferFacilityIdentifier
            // 
            this.lbl_TransferFacilityIdentifier.AutoSize = true;
            this.lbl_TransferFacilityIdentifier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_TransferFacilityIdentifier.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TransferFacilityIdentifier.ForeColor = System.Drawing.Color.Black;
            this.lbl_TransferFacilityIdentifier.Location = new System.Drawing.Point(11, 452);
            this.lbl_TransferFacilityIdentifier.Name = "lbl_TransferFacilityIdentifier";
            this.lbl_TransferFacilityIdentifier.Size = new System.Drawing.Size(14, 16);
            this.lbl_TransferFacilityIdentifier.TabIndex = 60;
            this.lbl_TransferFacilityIdentifier.Text = "*";
            // 
            // lbl_TransferStatus
            // 
            this.lbl_TransferStatus.AutoSize = true;
            this.lbl_TransferStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_TransferStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TransferStatus.ForeColor = System.Drawing.Color.Black;
            this.lbl_TransferStatus.Location = new System.Drawing.Point(9, 393);
            this.lbl_TransferStatus.Name = "lbl_TransferStatus";
            this.lbl_TransferStatus.Size = new System.Drawing.Size(14, 16);
            this.lbl_TransferStatus.TabIndex = 59;
            this.lbl_TransferStatus.Text = "*";
            // 
            // lbl_DischargedStatus
            // 
            this.lbl_DischargedStatus.AutoSize = true;
            this.lbl_DischargedStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_DischargedStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DischargedStatus.ForeColor = System.Drawing.Color.Black;
            this.lbl_DischargedStatus.Location = new System.Drawing.Point(9, 349);
            this.lbl_DischargedStatus.Name = "lbl_DischargedStatus";
            this.lbl_DischargedStatus.Size = new System.Drawing.Size(14, 16);
            this.lbl_DischargedStatus.TabIndex = 58;
            this.lbl_DischargedStatus.Text = "*";
            // 
            // lbl_SourceofAdmission
            // 
            this.lbl_SourceofAdmission.AutoSize = true;
            this.lbl_SourceofAdmission.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SourceofAdmission.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SourceofAdmission.ForeColor = System.Drawing.Color.Black;
            this.lbl_SourceofAdmission.Location = new System.Drawing.Point(8, 303);
            this.lbl_SourceofAdmission.Name = "lbl_SourceofAdmission";
            this.lbl_SourceofAdmission.Size = new System.Drawing.Size(14, 16);
            this.lbl_SourceofAdmission.TabIndex = 57;
            this.lbl_SourceofAdmission.Text = "*";
            // 
            // lbl_DischargeDatetime
            // 
            this.lbl_DischargeDatetime.AutoSize = true;
            this.lbl_DischargeDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_DischargeDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DischargeDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_DischargeDatetime.Location = new System.Drawing.Point(688, 166);
            this.lbl_DischargeDatetime.Name = "lbl_DischargeDatetime";
            this.lbl_DischargeDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_DischargeDatetime.TabIndex = 56;
            this.lbl_DischargeDatetime.Text = "*";
            // 
            // lbl_AdmissionDateTime
            // 
            this.lbl_AdmissionDateTime.AutoSize = true;
            this.lbl_AdmissionDateTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_AdmissionDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AdmissionDateTime.ForeColor = System.Drawing.Color.Black;
            this.lbl_AdmissionDateTime.Location = new System.Drawing.Point(555, 165);
            this.lbl_AdmissionDateTime.Name = "lbl_AdmissionDateTime";
            this.lbl_AdmissionDateTime.Size = new System.Drawing.Size(14, 16);
            this.lbl_AdmissionDateTime.TabIndex = 55;
            this.lbl_AdmissionDateTime.Text = "*";
            // 
            // lbl_FacilityIdentifier
            // 
            this.lbl_FacilityIdentifier.AutoSize = true;
            this.lbl_FacilityIdentifier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_FacilityIdentifier.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FacilityIdentifier.ForeColor = System.Drawing.Color.Black;
            this.lbl_FacilityIdentifier.Location = new System.Drawing.Point(287, 165);
            this.lbl_FacilityIdentifier.Name = "lbl_FacilityIdentifier";
            this.lbl_FacilityIdentifier.Size = new System.Drawing.Size(14, 16);
            this.lbl_FacilityIdentifier.TabIndex = 54;
            this.lbl_FacilityIdentifier.Text = "*";
            // 
            // lbl_MRN
            // 
            this.lbl_MRN.AutoSize = true;
            this.lbl_MRN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_MRN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MRN.ForeColor = System.Drawing.Color.Black;
            this.lbl_MRN.Location = new System.Drawing.Point(10, 165);
            this.lbl_MRN.Name = "lbl_MRN";
            this.lbl_MRN.Size = new System.Drawing.Size(14, 16);
            this.lbl_MRN.TabIndex = 53;
            this.lbl_MRN.Text = "*";
            // 
            // lbl_InsuranceNumber
            // 
            this.lbl_InsuranceNumber.AutoSize = true;
            this.lbl_InsuranceNumber.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_InsuranceNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_InsuranceNumber.ForeColor = System.Drawing.Color.Black;
            this.lbl_InsuranceNumber.Location = new System.Drawing.Point(554, 94);
            this.lbl_InsuranceNumber.Name = "lbl_InsuranceNumber";
            this.lbl_InsuranceNumber.Size = new System.Drawing.Size(14, 16);
            this.lbl_InsuranceNumber.TabIndex = 52;
            this.lbl_InsuranceNumber.Text = "*";
            // 
            // lbl_Payor
            // 
            this.lbl_Payor.AutoSize = true;
            this.lbl_Payor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Payor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Payor.ForeColor = System.Drawing.Color.Black;
            this.lbl_Payor.Location = new System.Drawing.Point(287, 94);
            this.lbl_Payor.Name = "lbl_Payor";
            this.lbl_Payor.Size = new System.Drawing.Size(14, 16);
            this.lbl_Payor.TabIndex = 51;
            this.lbl_Payor.Text = "*";
            // 
            // lbl_Ethnicity
            // 
            this.lbl_Ethnicity.AutoSize = true;
            this.lbl_Ethnicity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Ethnicity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ethnicity.ForeColor = System.Drawing.Color.Black;
            this.lbl_Ethnicity.Location = new System.Drawing.Point(10, 94);
            this.lbl_Ethnicity.Name = "lbl_Ethnicity";
            this.lbl_Ethnicity.Size = new System.Drawing.Size(14, 16);
            this.lbl_Ethnicity.TabIndex = 50;
            this.lbl_Ethnicity.Text = "*";
            // 
            // lbl_Race
            // 
            this.lbl_Race.AutoSize = true;
            this.lbl_Race.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Race.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Race.ForeColor = System.Drawing.Color.Black;
            this.lbl_Race.Location = new System.Drawing.Point(829, 38);
            this.lbl_Race.Name = "lbl_Race";
            this.lbl_Race.Size = new System.Drawing.Size(14, 16);
            this.lbl_Race.TabIndex = 49;
            this.lbl_Race.Text = "*";
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.ForeColor = System.Drawing.Color.Black;
            this.lbl_Gender.Location = new System.Drawing.Point(682, 37);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(14, 16);
            this.lbl_Gender.TabIndex = 48;
            this.lbl_Gender.Text = "*";
            // 
            // lbl_DOB
            // 
            this.lbl_DOB.AutoSize = true;
            this.lbl_DOB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_DOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DOB.ForeColor = System.Drawing.Color.Black;
            this.lbl_DOB.Location = new System.Drawing.Point(550, 38);
            this.lbl_DOB.Name = "lbl_DOB";
            this.lbl_DOB.Size = new System.Drawing.Size(14, 16);
            this.lbl_DOB.TabIndex = 47;
            this.lbl_DOB.Text = "*";
            // 
            // lbl_PatientCtrlNum
            // 
            this.lbl_PatientCtrlNum.AutoSize = true;
            this.lbl_PatientCtrlNum.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_PatientCtrlNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatientCtrlNum.ForeColor = System.Drawing.Color.Black;
            this.lbl_PatientCtrlNum.Location = new System.Drawing.Point(289, 37);
            this.lbl_PatientCtrlNum.Name = "lbl_PatientCtrlNum";
            this.lbl_PatientCtrlNum.Size = new System.Drawing.Size(14, 16);
            this.lbl_PatientCtrlNum.TabIndex = 46;
            this.lbl_PatientCtrlNum.Text = "*";
            // 
            // lbl_txID
            // 
            this.lbl_txID.AutoSize = true;
            this.lbl_txID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_txID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_txID.ForeColor = System.Drawing.Color.Black;
            this.lbl_txID.Location = new System.Drawing.Point(12, 36);
            this.lbl_txID.Name = "lbl_txID";
            this.lbl_txID.Size = new System.Drawing.Size(14, 16);
            this.lbl_txID.TabIndex = 45;
            this.lbl_txID.Text = "*";
            // 
            // textBox_TransferFacilityIdentifier
            // 
            this.textBox_TransferFacilityIdentifier.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_TransferFacilityIdentifier.Location = new System.Drawing.Point(25, 451);
            this.textBox_TransferFacilityIdentifier.Mask = "000000";
            this.textBox_TransferFacilityIdentifier.Name = "textBox_TransferFacilityIdentifier";
            this.textBox_TransferFacilityIdentifier.Size = new System.Drawing.Size(100, 20);
            this.textBox_TransferFacilityIdentifier.TabIndex = 15;
            this.textBox_TransferFacilityIdentifier.Enter += new System.EventHandler(this.textBox_TransferFacilityIdentifier_Enter);
            this.textBox_TransferFacilityIdentifier.Leave += new System.EventHandler(this.textBox_TransferFacilityIdentifier_Leave);
            // 
            // TextBox_FacilityIdentifier
            // 
            this.TextBox_FacilityIdentifier.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.TextBox_FacilityIdentifier.Location = new System.Drawing.Point(303, 165);
            this.TextBox_FacilityIdentifier.Mask = "AAAAAA";
            this.TextBox_FacilityIdentifier.Name = "TextBox_FacilityIdentifier";
            this.TextBox_FacilityIdentifier.Size = new System.Drawing.Size(219, 20);
            this.TextBox_FacilityIdentifier.TabIndex = 9;
            this.TextBox_FacilityIdentifier.Enter += new System.EventHandler(this.TextBox_FacilityIdentifier_Enter);
            // 
            // TextBox_InsuranceNumber
            // 
            this.TextBox_InsuranceNumber.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.TextBox_InsuranceNumber.Location = new System.Drawing.Point(570, 94);
            this.TextBox_InsuranceNumber.Mask = "AAAAAAAAAAAAAAAAAAA";
            this.TextBox_InsuranceNumber.Name = "TextBox_InsuranceNumber";
            this.TextBox_InsuranceNumber.Size = new System.Drawing.Size(255, 20);
            this.TextBox_InsuranceNumber.TabIndex = 7;
            this.TextBox_InsuranceNumber.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.TextBox_InsuranceNumber_MaskInputRejected);
            this.TextBox_InsuranceNumber.Enter += new System.EventHandler(this.TextBox_InsuranceNumber_Enter);
            this.TextBox_InsuranceNumber.Leave += new System.EventHandler(this.TextBox_InsuranceNumber_Leave);
            // 
            // TextBox_PatientCtrlNum
            // 
            this.TextBox_PatientCtrlNum.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.TextBox_PatientCtrlNum.Location = new System.Drawing.Point(302, 37);
            this.TextBox_PatientCtrlNum.Mask = "AAAAAAAAAAAAAAAAAAAA";
            this.TextBox_PatientCtrlNum.Name = "TextBox_PatientCtrlNum";
            this.TextBox_PatientCtrlNum.Size = new System.Drawing.Size(220, 20);
            this.TextBox_PatientCtrlNum.TabIndex = 1;
            this.TextBox_PatientCtrlNum.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.TextBox_PatientCtrlNum_MaskInputRejected);
            this.TextBox_PatientCtrlNum.Enter += new System.EventHandler(this.TextBox_PatientCtrlNum_Enter);
            // 
            // txtId
            // 
            this.txtId.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtId.Location = new System.Drawing.Point(25, 36);
            this.txtId.Mask = "??????0000";
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(220, 20);
            this.txtId.TabIndex = 0;
            this.txtId.Enter += new System.EventHandler(this.txtId_Enter);
            this.txtId.Leave += new System.EventHandler(this.txtId_Leave);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(21, 21);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(131, 13);
            this.label38.TabIndex = 44;
            this.label38.Text = "Unique Personal Identifier:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(22, 426);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(127, 13);
            this.label32.TabIndex = 42;
            this.label32.Text = "Transfer Facility Identifier:";
            // 
            // txtMRN
            // 
            this.txtMRN.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtMRN.Location = new System.Drawing.Point(25, 166);
            this.txtMRN.Mask = "AAAAAAAAAAAAAAAAA";
            this.txtMRN.Name = "txtMRN";
            this.txtMRN.Size = new System.Drawing.Size(219, 20);
            this.txtMRN.TabIndex = 8;
            this.txtMRN.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.txtMRN_MaskInputRejected);
            this.txtMRN.Enter += new System.EventHandler(this.txtMRN_Enter);
            // 
            // textBox_DischargedDatetime
            // 
            this.textBox_DischargedDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_DischargedDatetime.Location = new System.Drawing.Point(704, 166);
            this.textBox_DischargedDatetime.Mask = "00/00/0000 90:00";
            this.textBox_DischargedDatetime.Name = "textBox_DischargedDatetime";
            this.textBox_DischargedDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_DischargedDatetime.TabIndex = 11;
            this.textBox_DischargedDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_DischargedDatetime.Enter += new System.EventHandler(this.textBox_DischargedDatetime_Enter);
            this.textBox_DischargedDatetime.Leave += new System.EventHandler(this.textBox_DischargedDatetime_Leave);
            // 
            // textBox_AdmissionDateTime
            // 
            this.textBox_AdmissionDateTime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_AdmissionDateTime.Location = new System.Drawing.Point(570, 166);
            this.textBox_AdmissionDateTime.Mask = "00/00/0000 90:00";
            this.textBox_AdmissionDateTime.Name = "textBox_AdmissionDateTime";
            this.textBox_AdmissionDateTime.Size = new System.Drawing.Size(100, 20);
            this.textBox_AdmissionDateTime.TabIndex = 10;
            this.textBox_AdmissionDateTime.ValidatingType = typeof(System.DateTime);
            this.textBox_AdmissionDateTime.Enter += new System.EventHandler(this.textBox_AdmissionDateTime_Enter);
            this.textBox_AdmissionDateTime.Leave += new System.EventHandler(this.textBox_AdmissionDateTime_Leave);
            // 
            // txtDOB
            // 
            this.txtDOB.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtDOB.Location = new System.Drawing.Point(570, 37);
            this.txtDOB.Mask = "00/00/0000";
            this.txtDOB.Name = "txtDOB";
            this.txtDOB.Size = new System.Drawing.Size(100, 20);
            this.txtDOB.TabIndex = 2;
            this.txtDOB.ValidatingType = typeof(System.DateTime);
            this.txtDOB.Enter += new System.EventHandler(this.txtDOB_Enter);
            this.txtDOB.Leave += new System.EventHandler(this.txtDOB_Leave);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(1106, 390);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(17, 19);
            this.button4.TabIndex = 37;
            this.button4.Text = "?";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1106, 347);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(17, 19);
            this.button3.TabIndex = 36;
            this.button3.Text = "?";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            // 
            // button_SourceofAdmission
            // 
            this.button_SourceofAdmission.Location = new System.Drawing.Point(1106, 301);
            this.button_SourceofAdmission.Name = "button_SourceofAdmission";
            this.button_SourceofAdmission.Size = new System.Drawing.Size(17, 19);
            this.button_SourceofAdmission.TabIndex = 35;
            this.button_SourceofAdmission.Text = "?";
            this.button_SourceofAdmission.UseVisualStyleBackColor = true;
            this.button_SourceofAdmission.Visible = false;
            // 
            // comboBox_SourceofAdmission
            // 
            this.comboBox_SourceofAdmission.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_SourceofAdmission.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_SourceofAdmission.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_SourceofAdmission.FormattingEnabled = true;
            this.comboBox_SourceofAdmission.ImeMode = System.Windows.Forms.ImeMode.On;
            this.comboBox_SourceofAdmission.Items.AddRange(new object[] {
            "Select",
            "Non-Health Facility Point of Origin-The patient was admitted to this facility fro" +
                "m home or from an assisted living facility.",
            "Clinic-The patient was referred to this facility as a transfer from a freestandin" +
                "g or non-freestanding clinic.",
            "Transfer from a Hospital (Different Facility)-The patient was admitted to this fa" +
                "cility as a hospital transfer from an acute care facility where he or she was an" +
                " inpatient or outpatient.",
            "Transfer From a Skilled Nursing Facility (SNF) or Intermediate Care Facility (ICF" +
                ")-The patient was admitted to this facility as a transfer from a SNF or ICF wher" +
                "e he or she was a resident.",
            "Transfer From Another Health Care Facility-The patient was admitted to this facil" +
                "ity as a transfer from another type of health care facility not defined elsewher" +
                "e in this code list.",
            "Court/Law Enforcement- The patient was admitted to this facility upon the directi" +
                "on of a court of law, or upon the request of a law enforcement agency representa" +
                "tive.",
            "Information Not Available-The means by which the patient was admitted to this hos" +
                "pital was not known.",
            "Transfer from a Rural Primary Care Hospital. The patient was admitted to this fac" +
                "ility as a transfer from a Rural Primary Care Hospital (RPCH) where he or she wa" +
                "s an inpatient.",
            resources.GetString("comboBox_SourceofAdmission.Items"),
            "Transfer from Ambulatory Surgery Center-The patient was admitted to this facility" +
                " as a transfer from an ambulatory surgery center.",
            "Transfer from Hospice and is Under a Hospice Plan of Care or Enrolled in a Hospic" +
                "e Program- The patient was admitted to this facility as a transfer from a hospic" +
                "e."});
            this.comboBox_SourceofAdmission.Location = new System.Drawing.Point(24, 301);
            this.comboBox_SourceofAdmission.Name = "comboBox_SourceofAdmission";
            this.comboBox_SourceofAdmission.Size = new System.Drawing.Size(1076, 21);
            this.comboBox_SourceofAdmission.TabIndex = 12;
            // 
            // comboBox_DischargeStatus
            // 
            this.comboBox_DischargeStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_DischargeStatus.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_DischargeStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_DischargeStatus.FormattingEnabled = true;
            this.comboBox_DischargeStatus.Items.AddRange(new object[] {
            "Select",
            resources.GetString("comboBox_DischargeStatus.Items"),
            "Discharged/transferred to a Short-Term General Hospital for Inpatient Care.",
            resources.GetString("comboBox_DischargeStatus.Items1"),
            resources.GetString("comboBox_DischargeStatus.Items2"),
            "Discharged/transferred to a Designated Cancer Center or Children\'s Hospital.",
            resources.GetString("comboBox_DischargeStatus.Items3"),
            "Left against Medical Advice or Discontinued Care.",
            resources.GetString("comboBox_DischargeStatus.Items4"),
            "Expired.",
            "Discharged/transferred to Court/Law Enforcement.",
            "Hospice – Home.",
            "Hospice – Medical Facility (Certified) Providing Hospice Level of Care.",
            "Discharged/transferred to Hospital-Based Medicare Approved Swing Bed.",
            "Discharged/transferred to an Inpatient Rehabilitation Facility (IRF) including Re" +
                "habilitation Distinct Part Unit of a Hospital.",
            "Discharged/transferred to a Medicare Certified Long Term Care Hospital (LTCH).",
            "Discharged/transferred to a Nursing Facility Certified under Medicaid but not cer" +
                "tified under Medicare.",
            "Discharged/transferred to a Psychiatric Hospital or Psychiatric Distinct Part Uni" +
                "t of a Hospital.",
            "Discharged/transferred to a Critical Access Hospital (CAH).",
            "Discharged/transferred to a Designated Disaster Alternative Care Site.",
            "Discharged/transferred to another Type of Health Care Institution not defined Els" +
                "ewhere in this Code List.",
            "Discharged to Home or Self Care with a Planned Acute Care Hospital Inpatient Read" +
                "mission.",
            "Discharged/transferred to a Short-Term General Hospital for Inpatient Care with a" +
                " Planned Acute Care Hospital Inpatient Readmission.",
            "Discharged/transferred to Skilled Nursing Facility (SNF) with Medicare Certificat" +
                "ion with a Planned Acute Care Hospital Inpatient Readmission.",
            "Discharged/transferred to a Facility that Provides Custodial or Supportive Care w" +
                "ith a Planned Acute Care Hospital Inpatient Readmission.",
            "Discharged/transferred to a Designated Cancer Center or Children\'s Hospital with " +
                "a Planned Acute Care Hospital Inpatient Readmission.",
            "Discharged/transferred to Home under Care of Organized Home Health Service Organi" +
                "zation with a Planned Acute Care Hospital Inpatient Readmission.",
            "Discharged/transferred to Court/Law Enforcement with a Planned Acute Care Hospita" +
                "l Inpatient Readmission.",
            "Discharged/transferred to a Federal Health Care Facility with a Planned Acute Car" +
                "e Hospital Inpatient Readmission.",
            "Discharged/transferred to Hospital-Based Medicare Approved Swing Bed with a Plann" +
                "ed Acute Care Hospital Inpatient Readmission.",
            "Discharged/transferred to an Inpatient Rehabilitation Facility (IRF) including Re" +
                "habilitation Distinct Part Units of a Hospital with a Planned Acute Care Hospita" +
                "l Inpatient Readmission.",
            "Discharged/transferred to a Medicare Certified Long Term Care Hospital (LTCH) wit" +
                "h a Planned Acute Care Hospital Inpatient Readmission.",
            "Discharged/transferred to a Nursing Facility Certified under Medicaid but not Cer" +
                "tified under Medicare with a Planned Acute Care Hospital Inpatient Readmission.",
            "Discharged/transferred to a Psychiatric Hospital or Psychiatric Distinct Part Uni" +
                "t of a Hospital with a Planned Acute Care Hospital Inpatient Readmission.",
            "Discharged/transferred to a Critical Access Hospital (CAH) with a Planned Acute C" +
                "are Hospital Inpatient Readmission.",
            "Discharged/transferred to another Type of Health Care Institution not Defined Els" +
                "ewhere in this Code List with a Planned Acute Care Hospital Inpatient Readmissio" +
                "n."});
            this.comboBox_DischargeStatus.Location = new System.Drawing.Point(24, 347);
            this.comboBox_DischargeStatus.Name = "comboBox_DischargeStatus";
            this.comboBox_DischargeStatus.Size = new System.Drawing.Size(1076, 21);
            this.comboBox_DischargeStatus.TabIndex = 13;
            // 
            // comboBox_TransferStatus
            // 
            this.comboBox_TransferStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_TransferStatus.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_TransferStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_TransferStatus.FormattingEnabled = true;
            this.comboBox_TransferStatus.Items.AddRange(new object[] {
            "Select",
            "Not a Transfer – Patient was neither admitted as a transfer nor discharged as a t" +
                "ransfer to/from a different acute care hospital.",
            resources.GetString("comboBox_TransferStatus.Items"),
            resources.GetString("comboBox_TransferStatus.Items1"),
            resources.GetString("comboBox_TransferStatus.Items2"),
            resources.GetString("comboBox_TransferStatus.Items3")});
            this.comboBox_TransferStatus.Location = new System.Drawing.Point(25, 390);
            this.comboBox_TransferStatus.Name = "comboBox_TransferStatus";
            this.comboBox_TransferStatus.Size = new System.Drawing.Size(1075, 21);
            this.comboBox_TransferStatus.TabIndex = 14;
            this.comboBox_TransferStatus.SelectedIndexChanged += new System.EventHandler(this.comboBox_TransferStatus_SelectedIndexChanged);
            // 
            // Label_AdmissionDatetime
            // 
            this.Label_AdmissionDatetime.AutoSize = true;
            this.Label_AdmissionDatetime.Location = new System.Drawing.Point(567, 150);
            this.Label_AdmissionDatetime.Name = "Label_AdmissionDatetime";
            this.Label_AdmissionDatetime.Size = new System.Drawing.Size(111, 13);
            this.Label_AdmissionDatetime.TabIndex = 29;
            this.Label_AdmissionDatetime.Text = "Admission Date/Time:";
            // 
            // Label_SourceofAdmission
            // 
            this.Label_SourceofAdmission.AutoSize = true;
            this.Label_SourceofAdmission.Location = new System.Drawing.Point(21, 285);
            this.Label_SourceofAdmission.Name = "Label_SourceofAdmission";
            this.Label_SourceofAdmission.Size = new System.Drawing.Size(106, 13);
            this.Label_SourceofAdmission.TabIndex = 28;
            this.Label_SourceofAdmission.Text = "Source of Admission:";
            // 
            // Label_DischargeDatetime
            // 
            this.Label_DischargeDatetime.AutoSize = true;
            this.Label_DischargeDatetime.Location = new System.Drawing.Point(701, 150);
            this.Label_DischargeDatetime.Name = "Label_DischargeDatetime";
            this.Label_DischargeDatetime.Size = new System.Drawing.Size(112, 13);
            this.Label_DischargeDatetime.TabIndex = 27;
            this.Label_DischargeDatetime.Text = "Discharge Date/Time:";
            // 
            // Label_DischargedStatus
            // 
            this.Label_DischargedStatus.AutoSize = true;
            this.Label_DischargedStatus.Location = new System.Drawing.Point(21, 331);
            this.Label_DischargedStatus.Name = "Label_DischargedStatus";
            this.Label_DischargedStatus.Size = new System.Drawing.Size(97, 13);
            this.Label_DischargedStatus.TabIndex = 26;
            this.Label_DischargedStatus.Text = "Discharged Status:";
            // 
            // Label_Transfer
            // 
            this.Label_Transfer.AutoSize = true;
            this.Label_Transfer.Location = new System.Drawing.Point(22, 374);
            this.Label_Transfer.Name = "Label_Transfer";
            this.Label_Transfer.Size = new System.Drawing.Size(82, 13);
            this.Label_Transfer.TabIndex = 25;
            this.Label_Transfer.Text = "Transfer Status:";
            // 
            // checkedListBox_Race
            // 
            this.checkedListBox_Race.FormattingEnabled = true;
            this.checkedListBox_Race.Location = new System.Drawing.Point(844, 37);
            this.checkedListBox_Race.Name = "checkedListBox_Race";
            this.checkedListBox_Race.Size = new System.Drawing.Size(284, 244);
            this.checkedListBox_Race.TabIndex = 4;
            // 
            // comboBox_Payor
            // 
            this.comboBox_Payor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Payor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_Payor.FormattingEnabled = true;
            this.comboBox_Payor.Items.AddRange(new object[] {
            "Select",
            "Self Pay",
            "Workers Comp",
            "Medicare",
            "Medicaid",
            "Other Federal Program",
            "Commercial Insurance",
            "Blue Cross",
            "CHAMPUS",
            "Other Non-Federal Program"});
            this.comboBox_Payor.Location = new System.Drawing.Point(302, 94);
            this.comboBox_Payor.Name = "comboBox_Payor";
            this.comboBox_Payor.Size = new System.Drawing.Size(220, 21);
            this.comboBox_Payor.TabIndex = 6;
            this.comboBox_Payor.SelectedIndexChanged += new System.EventHandler(this.comboBox_Payor_SelectedIndexChanged);
            // 
            // Combobox_Ethnicity
            // 
            this.Combobox_Ethnicity.BackColor = System.Drawing.SystemColors.Window;
            this.Combobox_Ethnicity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Combobox_Ethnicity.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Combobox_Ethnicity.FormattingEnabled = true;
            this.Combobox_Ethnicity.Items.AddRange(new object[] {
            "Select",
            "Spanish/Hispanic Origin",
            "Not of Spanish/Hispanic Origin",
            "Unknown"});
            this.Combobox_Ethnicity.Location = new System.Drawing.Point(24, 94);
            this.Combobox_Ethnicity.Name = "Combobox_Ethnicity";
            this.Combobox_Ethnicity.Size = new System.Drawing.Size(220, 21);
            this.Combobox_Ethnicity.TabIndex = 5;
            // 
            // Combobox_Gender
            // 
            this.Combobox_Gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Combobox_Gender.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Combobox_Gender.FormattingEnabled = true;
            this.Combobox_Gender.Items.AddRange(new object[] {
            "Select",
            "Male",
            "Female",
            "Unknown"});
            this.Combobox_Gender.Location = new System.Drawing.Point(697, 36);
            this.Combobox_Gender.Name = "Combobox_Gender";
            this.Combobox_Gender.Size = new System.Drawing.Size(121, 21);
            this.Combobox_Gender.TabIndex = 3;
            // 
            // Label_PatientCtrlNum
            // 
            this.Label_PatientCtrlNum.AutoSize = true;
            this.Label_PatientCtrlNum.Location = new System.Drawing.Point(300, 21);
            this.Label_PatientCtrlNum.Name = "Label_PatientCtrlNum";
            this.Label_PatientCtrlNum.Size = new System.Drawing.Size(122, 13);
            this.Label_PatientCtrlNum.TabIndex = 15;
            this.Label_PatientCtrlNum.Text = " Patient Control Number:";
            // 
            // Label_Ethnicity
            // 
            this.Label_Ethnicity.AutoSize = true;
            this.Label_Ethnicity.Location = new System.Drawing.Point(22, 78);
            this.Label_Ethnicity.Name = "Label_Ethnicity";
            this.Label_Ethnicity.Size = new System.Drawing.Size(50, 13);
            this.Label_Ethnicity.TabIndex = 13;
            this.Label_Ethnicity.Text = "Ethnicity:";
            // 
            // Label_InsuranceNumber
            // 
            this.Label_InsuranceNumber.AutoSize = true;
            this.Label_InsuranceNumber.Location = new System.Drawing.Point(567, 78);
            this.Label_InsuranceNumber.Name = "Label_InsuranceNumber";
            this.Label_InsuranceNumber.Size = new System.Drawing.Size(97, 13);
            this.Label_InsuranceNumber.TabIndex = 12;
            this.Label_InsuranceNumber.Text = "Insurance Number:";
            // 
            // Label_Race
            // 
            this.Label_Race.AutoSize = true;
            this.Label_Race.Location = new System.Drawing.Point(841, 21);
            this.Label_Race.Name = "Label_Race";
            this.Label_Race.Size = new System.Drawing.Size(36, 13);
            this.Label_Race.TabIndex = 11;
            this.Label_Race.Text = "Race:";
            // 
            // Label_Payor
            // 
            this.Label_Payor.AutoSize = true;
            this.Label_Payor.Location = new System.Drawing.Point(299, 78);
            this.Label_Payor.Name = "Label_Payor";
            this.Label_Payor.Size = new System.Drawing.Size(37, 13);
            this.Label_Payor.TabIndex = 10;
            this.Label_Payor.Text = "Payor:";
            // 
            // Label_Gender
            // 
            this.Label_Gender.AutoSize = true;
            this.Label_Gender.Location = new System.Drawing.Point(701, 21);
            this.Label_Gender.Name = "Label_Gender";
            this.Label_Gender.Size = new System.Drawing.Size(45, 13);
            this.Label_Gender.TabIndex = 9;
            this.Label_Gender.Text = "Gender:";
            // 
            // Label_FacilityIdentifier
            // 
            this.Label_FacilityIdentifier.AutoSize = true;
            this.Label_FacilityIdentifier.Location = new System.Drawing.Point(299, 148);
            this.Label_FacilityIdentifier.Name = "Label_FacilityIdentifier";
            this.Label_FacilityIdentifier.Size = new System.Drawing.Size(85, 13);
            this.Label_FacilityIdentifier.TabIndex = 8;
            this.Label_FacilityIdentifier.Text = "Facility Identifier:";
            // 
            // Label_MRN
            // 
            this.Label_MRN.AutoSize = true;
            this.Label_MRN.Location = new System.Drawing.Point(22, 148);
            this.Label_MRN.Name = "Label_MRN";
            this.Label_MRN.Size = new System.Drawing.Size(102, 13);
            this.Label_MRN.TabIndex = 7;
            this.Label_MRN.Text = "Medical Record No:";
            // 
            // Label_DateofBirth
            // 
            this.Label_DateofBirth.AutoSize = true;
            this.Label_DateofBirth.Location = new System.Drawing.Point(567, 21);
            this.Label_DateofBirth.Name = "Label_DateofBirth";
            this.Label_DateofBirth.Size = new System.Drawing.Size(69, 13);
            this.Label_DateofBirth.TabIndex = 6;
            this.Label_DateofBirth.Text = "Date of Birth:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lbl_ExcludedExplain);
            this.tabPage2.Controls.Add(this.lbl_ProtocolNotInitiatedReason);
            this.tabPage2.Controls.Add(this.lbl_ExcludedDatetime);
            this.tabPage2.Controls.Add(this.lbl_ExcludedReason);
            this.tabPage2.Controls.Add(this.lbl_ProtocolInitaitedPlace);
            this.tabPage2.Controls.Add(this.lbl_ExcludedFromProtocol);
            this.tabPage2.Controls.Add(this.lbl_ProtocolInitiatedType);
            this.tabPage2.Controls.Add(this.lbl_ProtocolInitiated);
            this.tabPage2.Controls.Add(this.textBox_ProtocolNIAdditionalDetail);
            this.tabPage2.Controls.Add(this.textBox_ExcludedDatetime);
            this.tabPage2.Controls.Add(this.checkedListBox_ExcludedReason);
            this.tabPage2.Controls.Add(this.checkedListBox_ExcludedExplain);
            this.tabPage2.Controls.Add(this.comboBox_ProtocolInitiated);
            this.tabPage2.Controls.Add(this.comboBox_ProtocolNotInitiatedReason);
            this.tabPage2.Controls.Add(this.comboBox_ProtocolInitiatedPlace);
            this.tabPage2.Controls.Add(this.comboBox_ProtocolType);
            this.tabPage2.Controls.Add(this.comboBox_ExcludedFromProtocol);
            this.tabPage2.Controls.Add(this.Label_ExcludedFromProtocol);
            this.tabPage2.Controls.Add(this.Label_ExcludedDatetime);
            this.tabPage2.Controls.Add(this.Label_ExcludedExplain);
            this.tabPage2.Controls.Add(this.Label_ProtocolType);
            this.tabPage2.Controls.Add(this.Label_ProtocolInitiatedPlace);
            this.tabPage2.Controls.Add(this.Label_ExcludedReason);
            this.tabPage2.Controls.Add(this.Label_ProtocolNIAdditionalDetail);
            this.tabPage2.Controls.Add(this.Label_ProtocolNotInitiatedReason);
            this.tabPage2.Controls.Add(this.Label_ProtocolInitiated);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1233, 551);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Sepsis Protocol";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lbl_ExcludedExplain
            // 
            this.lbl_ExcludedExplain.AutoSize = true;
            this.lbl_ExcludedExplain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ExcludedExplain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ExcludedExplain.ForeColor = System.Drawing.Color.Black;
            this.lbl_ExcludedExplain.Location = new System.Drawing.Point(354, 363);
            this.lbl_ExcludedExplain.Name = "lbl_ExcludedExplain";
            this.lbl_ExcludedExplain.Size = new System.Drawing.Size(14, 16);
            this.lbl_ExcludedExplain.TabIndex = 68;
            this.lbl_ExcludedExplain.Text = "*";
            // 
            // lbl_ProtocolNotInitiatedReason
            // 
            this.lbl_ProtocolNotInitiatedReason.AutoSize = true;
            this.lbl_ProtocolNotInitiatedReason.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ProtocolNotInitiatedReason.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ProtocolNotInitiatedReason.ForeColor = System.Drawing.Color.Black;
            this.lbl_ProtocolNotInitiatedReason.Location = new System.Drawing.Point(32, 90);
            this.lbl_ProtocolNotInitiatedReason.Name = "lbl_ProtocolNotInitiatedReason";
            this.lbl_ProtocolNotInitiatedReason.Size = new System.Drawing.Size(14, 16);
            this.lbl_ProtocolNotInitiatedReason.TabIndex = 67;
            this.lbl_ProtocolNotInitiatedReason.Text = "*";
            // 
            // lbl_ExcludedDatetime
            // 
            this.lbl_ExcludedDatetime.AutoSize = true;
            this.lbl_ExcludedDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ExcludedDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ExcludedDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_ExcludedDatetime.Location = new System.Drawing.Point(33, 373);
            this.lbl_ExcludedDatetime.Name = "lbl_ExcludedDatetime";
            this.lbl_ExcludedDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_ExcludedDatetime.TabIndex = 66;
            this.lbl_ExcludedDatetime.Text = "*";
            // 
            // lbl_ExcludedReason
            // 
            this.lbl_ExcludedReason.AutoSize = true;
            this.lbl_ExcludedReason.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ExcludedReason.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ExcludedReason.ForeColor = System.Drawing.Color.Black;
            this.lbl_ExcludedReason.Location = new System.Drawing.Point(356, 269);
            this.lbl_ExcludedReason.Name = "lbl_ExcludedReason";
            this.lbl_ExcludedReason.Size = new System.Drawing.Size(14, 16);
            this.lbl_ExcludedReason.TabIndex = 65;
            this.lbl_ExcludedReason.Text = "*";
            // 
            // lbl_ProtocolInitaitedPlace
            // 
            this.lbl_ProtocolInitaitedPlace.AutoSize = true;
            this.lbl_ProtocolInitaitedPlace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ProtocolInitaitedPlace.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ProtocolInitaitedPlace.ForeColor = System.Drawing.Color.Black;
            this.lbl_ProtocolInitaitedPlace.Location = new System.Drawing.Point(33, 206);
            this.lbl_ProtocolInitaitedPlace.Name = "lbl_ProtocolInitaitedPlace";
            this.lbl_ProtocolInitaitedPlace.Size = new System.Drawing.Size(14, 16);
            this.lbl_ProtocolInitaitedPlace.TabIndex = 64;
            this.lbl_ProtocolInitaitedPlace.Text = "*";
            // 
            // lbl_ExcludedFromProtocol
            // 
            this.lbl_ExcludedFromProtocol.AutoSize = true;
            this.lbl_ExcludedFromProtocol.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ExcludedFromProtocol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ExcludedFromProtocol.ForeColor = System.Drawing.Color.Black;
            this.lbl_ExcludedFromProtocol.Location = new System.Drawing.Point(33, 269);
            this.lbl_ExcludedFromProtocol.Name = "lbl_ExcludedFromProtocol";
            this.lbl_ExcludedFromProtocol.Size = new System.Drawing.Size(14, 16);
            this.lbl_ExcludedFromProtocol.TabIndex = 63;
            this.lbl_ExcludedFromProtocol.Text = "*";
            // 
            // lbl_ProtocolInitiatedType
            // 
            this.lbl_ProtocolInitiatedType.AutoSize = true;
            this.lbl_ProtocolInitiatedType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ProtocolInitiatedType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ProtocolInitiatedType.ForeColor = System.Drawing.Color.Black;
            this.lbl_ProtocolInitiatedType.Location = new System.Drawing.Point(395, 206);
            this.lbl_ProtocolInitiatedType.Name = "lbl_ProtocolInitiatedType";
            this.lbl_ProtocolInitiatedType.Size = new System.Drawing.Size(14, 16);
            this.lbl_ProtocolInitiatedType.TabIndex = 62;
            this.lbl_ProtocolInitiatedType.Text = "*";
            // 
            // lbl_ProtocolInitiated
            // 
            this.lbl_ProtocolInitiated.AutoSize = true;
            this.lbl_ProtocolInitiated.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ProtocolInitiated.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ProtocolInitiated.ForeColor = System.Drawing.Color.Black;
            this.lbl_ProtocolInitiated.Location = new System.Drawing.Point(31, 36);
            this.lbl_ProtocolInitiated.Name = "lbl_ProtocolInitiated";
            this.lbl_ProtocolInitiated.Size = new System.Drawing.Size(14, 16);
            this.lbl_ProtocolInitiated.TabIndex = 61;
            this.lbl_ProtocolInitiated.Text = "*";
            // 
            // textBox_ProtocolNIAdditionalDetail
            // 
            this.textBox_ProtocolNIAdditionalDetail.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_ProtocolNIAdditionalDetail.Location = new System.Drawing.Point(51, 151);
            this.textBox_ProtocolNIAdditionalDetail.Name = "textBox_ProtocolNIAdditionalDetail";
            this.textBox_ProtocolNIAdditionalDetail.Size = new System.Drawing.Size(893, 20);
            this.textBox_ProtocolNIAdditionalDetail.TabIndex = 2;
            this.textBox_ProtocolNIAdditionalDetail.Enter += new System.EventHandler(this.textBox_ProtocolNIAdditionalDetail_Enter);
            // 
            // textBox_ExcludedDatetime
            // 
            this.textBox_ExcludedDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_ExcludedDatetime.Location = new System.Drawing.Point(48, 373);
            this.textBox_ExcludedDatetime.Mask = "00/00/0000 90:00";
            this.textBox_ExcludedDatetime.Name = "textBox_ExcludedDatetime";
            this.textBox_ExcludedDatetime.Size = new System.Drawing.Size(116, 20);
            this.textBox_ExcludedDatetime.TabIndex = 7;
            this.textBox_ExcludedDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_ExcludedDatetime.Enter += new System.EventHandler(this.textBox_ExcludedDatetime_Enter);
            this.textBox_ExcludedDatetime.Leave += new System.EventHandler(this.textBox_ExcludedDatetime_Leave);
            // 
            // checkedListBox_ExcludedReason
            // 
            this.checkedListBox_ExcludedReason.FormattingEnabled = true;
            this.checkedListBox_ExcludedReason.Items.AddRange(new object[] {
            "Interventions were clinically contraindicated",
            "Patient had advanced directives in place that precluded one or more elements of t" +
                "he protocol",
            "Patient, or surrogate decision maker, declined interventions",
            "Patient was enrolled in an IRB approved trial that was inconsistent with the prot" +
                "ocol interventions"});
            this.checkedListBox_ExcludedReason.Location = new System.Drawing.Point(579, 269);
            this.checkedListBox_ExcludedReason.Name = "checkedListBox_ExcludedReason";
            this.checkedListBox_ExcludedReason.Size = new System.Drawing.Size(543, 64);
            this.checkedListBox_ExcludedReason.TabIndex = 6;
            this.checkedListBox_ExcludedReason.Click += new System.EventHandler(this.checkedListBox_ExcludedReason_Click);
            this.checkedListBox_ExcludedReason.SelectedIndexChanged += new System.EventHandler(this.checkedListBox_ExcludedReason_SelectedIndexChanged);
            this.checkedListBox_ExcludedReason.Leave += new System.EventHandler(this.checkedListBox_ExcludedReason_Leave);
            this.checkedListBox_ExcludedReason.MouseUp += new System.Windows.Forms.MouseEventHandler(this.checkedListBox_ExcludedReason_MouseUp);
            // 
            // checkedListBox_ExcludedExplain
            // 
            this.checkedListBox_ExcludedExplain.FormattingEnabled = true;
            this.checkedListBox_ExcludedExplain.Items.AddRange(new object[] {
            "IV or IO fluids (acute, decompensated congestive heart failure, pulmonary edema a" +
                "nd LVAD)",
            "IV or IO fluids (end stage renal disease with signs of fluid overload)",
            "Central Line (significant, uncorrectable coagulation abnormalities)",
            "Central Line (anatomic obstacles or limitations)",
            "Vasopressors or inotropes for refractory hypotension (significant, uncorrectable " +
                "coagulation abnormalities)",
            "Vasopressors or inotropes for refractory hypotension (anatomic obstacles or limit" +
                "ations)"});
            this.checkedListBox_ExcludedExplain.Location = new System.Drawing.Point(579, 363);
            this.checkedListBox_ExcludedExplain.Name = "checkedListBox_ExcludedExplain";
            this.checkedListBox_ExcludedExplain.Size = new System.Drawing.Size(543, 94);
            this.checkedListBox_ExcludedExplain.TabIndex = 8;
            // 
            // comboBox_ProtocolInitiated
            // 
            this.comboBox_ProtocolInitiated.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ProtocolInitiated.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ProtocolInitiated.FormattingEnabled = true;
            this.comboBox_ProtocolInitiated.Items.AddRange(new object[] {
            "Select",
            "Protocol not initiated",
            "Protocol initiated"});
            this.comboBox_ProtocolInitiated.Location = new System.Drawing.Point(48, 34);
            this.comboBox_ProtocolInitiated.Name = "comboBox_ProtocolInitiated";
            this.comboBox_ProtocolInitiated.Size = new System.Drawing.Size(245, 21);
            this.comboBox_ProtocolInitiated.TabIndex = 0;
            this.comboBox_ProtocolInitiated.SelectedIndexChanged += new System.EventHandler(this.comboBox_ProtocolInitiated_SelectedIndexChanged);
            // 
            // comboBox_ProtocolNotInitiatedReason
            // 
            this.comboBox_ProtocolNotInitiatedReason.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ProtocolNotInitiatedReason.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ProtocolNotInitiatedReason.FormattingEnabled = true;
            this.comboBox_ProtocolNotInitiatedReason.Items.AddRange(new object[] {
            "Patient was excluded from the sepsis protocol. This MUST align with a valid repor" +
                "ted Excluded Reason which was in place at the time for which the protocol would " +
                "have been initiated",
            "Transfer case and unaware of how to handle treatment at prior facility and how it" +
                " relates to our protocol",
            "Late diagnosis of sepsis: Diagnosis made after the time for which protocol initia" +
                "tion was appropriate",
            "Clinical evidence not initially determined to meet our protocol definition of sep" +
                "sis",
            "Responsible clinical staff unaware of our sepsis protocol",
            "Clear documentation of sepsis protocol initiation per our own protocol definition" +
                " not found in the medical record"});
            this.comboBox_ProtocolNotInitiatedReason.Location = new System.Drawing.Point(48, 90);
            this.comboBox_ProtocolNotInitiatedReason.Name = "comboBox_ProtocolNotInitiatedReason";
            this.comboBox_ProtocolNotInitiatedReason.Size = new System.Drawing.Size(1074, 21);
            this.comboBox_ProtocolNotInitiatedReason.TabIndex = 1;
            this.comboBox_ProtocolNotInitiatedReason.SelectedIndexChanged += new System.EventHandler(this.comboBox_ProtocolNotInitiatedReason_SelectedIndexChanged);
            this.comboBox_ProtocolNotInitiatedReason.Leave += new System.EventHandler(this.comboBox_ProtocolNotInitiatedReason_Leave);
            // 
            // comboBox_ProtocolInitiatedPlace
            // 
            this.comboBox_ProtocolInitiatedPlace.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ProtocolInitiatedPlace.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ProtocolInitiatedPlace.FormattingEnabled = true;
            this.comboBox_ProtocolInitiatedPlace.Items.AddRange(new object[] {
            "Select",
            "Protocol initiated in the Emergency Department",
            "Protocol initiated on an inpatient floor (not ICU)",
            "Protocol initiated in the ICU",
            "Protocol not initiated"});
            this.comboBox_ProtocolInitiatedPlace.Location = new System.Drawing.Point(48, 205);
            this.comboBox_ProtocolInitiatedPlace.Name = "comboBox_ProtocolInitiatedPlace";
            this.comboBox_ProtocolInitiatedPlace.Size = new System.Drawing.Size(245, 21);
            this.comboBox_ProtocolInitiatedPlace.TabIndex = 3;
            this.comboBox_ProtocolInitiatedPlace.SelectedIndexChanged += new System.EventHandler(this.comboBox_ProtocolInitiatedPlace_SelectedIndexChanged);
            // 
            // comboBox_ProtocolType
            // 
            this.comboBox_ProtocolType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ProtocolType.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ProtocolType.FormattingEnabled = true;
            this.comboBox_ProtocolType.Items.AddRange(new object[] {
            "Select",
            "Adult protocol",
            "Pediatric protocol",
            "Protocol not initiated"});
            this.comboBox_ProtocolType.Location = new System.Drawing.Point(411, 204);
            this.comboBox_ProtocolType.Name = "comboBox_ProtocolType";
            this.comboBox_ProtocolType.Size = new System.Drawing.Size(245, 21);
            this.comboBox_ProtocolType.TabIndex = 4;
            this.comboBox_ProtocolType.SelectedIndexChanged += new System.EventHandler(this.comboBox_ProtocolType_SelectedIndexChanged);
            // 
            // comboBox_ExcludedFromProtocol
            // 
            this.comboBox_ExcludedFromProtocol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ExcludedFromProtocol.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ExcludedFromProtocol.FormattingEnabled = true;
            this.comboBox_ExcludedFromProtocol.Items.AddRange(new object[] {
            "Select",
            "Patient was not excluded from the protocol",
            "Patient was excluded from the protocol"});
            this.comboBox_ExcludedFromProtocol.Location = new System.Drawing.Point(48, 269);
            this.comboBox_ExcludedFromProtocol.Name = "comboBox_ExcludedFromProtocol";
            this.comboBox_ExcludedFromProtocol.Size = new System.Drawing.Size(245, 21);
            this.comboBox_ExcludedFromProtocol.TabIndex = 5;
            this.comboBox_ExcludedFromProtocol.SelectedIndexChanged += new System.EventHandler(this.comboBox_ExcludedFromProtocol_SelectedIndexChanged);
            // 
            // Label_ExcludedFromProtocol
            // 
            this.Label_ExcludedFromProtocol.AutoSize = true;
            this.Label_ExcludedFromProtocol.Location = new System.Drawing.Point(45, 253);
            this.Label_ExcludedFromProtocol.Name = "Label_ExcludedFromProtocol";
            this.Label_ExcludedFromProtocol.Size = new System.Drawing.Size(122, 13);
            this.Label_ExcludedFromProtocol.TabIndex = 10;
            this.Label_ExcludedFromProtocol.Text = "Excluded From Protocol:";
            // 
            // Label_ExcludedDatetime
            // 
            this.Label_ExcludedDatetime.AutoSize = true;
            this.Label_ExcludedDatetime.Location = new System.Drawing.Point(45, 347);
            this.Label_ExcludedDatetime.Name = "Label_ExcludedDatetime";
            this.Label_ExcludedDatetime.Size = new System.Drawing.Size(108, 13);
            this.Label_ExcludedDatetime.TabIndex = 9;
            this.Label_ExcludedDatetime.Text = "Excluded Date/Time:";
            // 
            // Label_ExcludedExplain
            // 
            this.Label_ExcludedExplain.AutoSize = true;
            this.Label_ExcludedExplain.Location = new System.Drawing.Point(365, 363);
            this.Label_ExcludedExplain.Name = "Label_ExcludedExplain";
            this.Label_ExcludedExplain.Size = new System.Drawing.Size(193, 13);
            this.Label_ExcludedExplain.TabIndex = 8;
            this.Label_ExcludedExplain.Text = "Excluded Explain: (Check all that apply)";
            // 
            // Label_ProtocolType
            // 
            this.Label_ProtocolType.AutoSize = true;
            this.Label_ProtocolType.Location = new System.Drawing.Point(408, 188);
            this.Label_ProtocolType.Name = "Label_ProtocolType";
            this.Label_ProtocolType.Size = new System.Drawing.Size(76, 13);
            this.Label_ProtocolType.TabIndex = 7;
            this.Label_ProtocolType.Text = "Protocol Type:";
            // 
            // Label_ProtocolInitiatedPlace
            // 
            this.Label_ProtocolInitiatedPlace.AutoSize = true;
            this.Label_ProtocolInitiatedPlace.Location = new System.Drawing.Point(45, 187);
            this.Label_ProtocolInitiatedPlace.Name = "Label_ProtocolInitiatedPlace";
            this.Label_ProtocolInitiatedPlace.Size = new System.Drawing.Size(119, 13);
            this.Label_ProtocolInitiatedPlace.TabIndex = 6;
            this.Label_ProtocolInitiatedPlace.Text = "Protocol Initiated Place:";
            // 
            // Label_ExcludedReason
            // 
            this.Label_ExcludedReason.AutoSize = true;
            this.Label_ExcludedReason.Location = new System.Drawing.Point(365, 269);
            this.Label_ExcludedReason.Name = "Label_ExcludedReason";
            this.Label_ExcludedReason.Size = new System.Drawing.Size(199, 13);
            this.Label_ExcludedReason.TabIndex = 5;
            this.Label_ExcludedReason.Text = " Excluded Reason: (Check all that apply)";
            // 
            // Label_ProtocolNIAdditionalDetail
            // 
            this.Label_ProtocolNIAdditionalDetail.AutoSize = true;
            this.Label_ProtocolNIAdditionalDetail.Location = new System.Drawing.Point(45, 133);
            this.Label_ProtocolNIAdditionalDetail.Name = "Label_ProtocolNIAdditionalDetail";
            this.Label_ProtocolNIAdditionalDetail.Size = new System.Drawing.Size(188, 13);
            this.Label_ProtocolNIAdditionalDetail.TabIndex = 4;
            this.Label_ProtocolNIAdditionalDetail.Text = "Protocol Not Initiated Additional Detail:";
            // 
            // Label_ProtocolNotInitiatedReason
            // 
            this.Label_ProtocolNotInitiatedReason.AutoSize = true;
            this.Label_ProtocolNotInitiatedReason.Location = new System.Drawing.Point(45, 74);
            this.Label_ProtocolNotInitiatedReason.Name = "Label_ProtocolNotInitiatedReason";
            this.Label_ProtocolNotInitiatedReason.Size = new System.Drawing.Size(149, 13);
            this.Label_ProtocolNotInitiatedReason.TabIndex = 3;
            this.Label_ProtocolNotInitiatedReason.Text = "Protocol Not Initiated Reason:";
            // 
            // Label_ProtocolInitiated
            // 
            this.Label_ProtocolInitiated.AutoSize = true;
            this.Label_ProtocolInitiated.Location = new System.Drawing.Point(45, 18);
            this.Label_ProtocolInitiated.Name = "Label_ProtocolInitiated";
            this.Label_ProtocolInitiated.Size = new System.Drawing.Size(89, 13);
            this.Label_ProtocolInitiated.TabIndex = 2;
            this.Label_ProtocolInitiated.Text = "Protocol Initiated:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lbl_InitialLactateLevelCollection);
            this.tabPage3.Controls.Add(this.textBox_InitialLactateLevel);
            this.tabPage3.Controls.Add(this.lbl_SepticShockPresentationDatetime);
            this.tabPage3.Controls.Add(this.lbl_RepeatLactateLevelCollection);
            this.tabPage3.Controls.Add(this.lbl_InitialLactateLevel);
            this.tabPage3.Controls.Add(this.lbl_AntibioticAdministration);
            this.tabPage3.Controls.Add(this.lbl_FluidChallengePerformed);
            this.tabPage3.Controls.Add(this.lbl_CentralVenousOxygenMeasurement);
            this.tabPage3.Controls.Add(this.lbl_PeripheralPulseEvaluation);
            this.tabPage3.Controls.Add(this.lbl_CapillaryRefillExamination);
            this.tabPage3.Controls.Add(this.lbl_VitalSignsReview);
            this.tabPage3.Controls.Add(this.lbl_CVPressureMeasurement);
            this.tabPage3.Controls.Add(this.lbl_SkinExamination);
            this.tabPage3.Controls.Add(this.lbl_PassiveLegRaiseExamination);
            this.tabPage3.Controls.Add(this.lbl_CardiopulmonaryEvaluation);
            this.tabPage3.Controls.Add(this.lbl_BedsideCardiovascularUltrasound);
            this.tabPage3.Controls.Add(this.lblVitalSignsReviewDatetime);
            this.tabPage3.Controls.Add(this.lbl_CVPressureMeasurementDateTime);
            this.tabPage3.Controls.Add(this.lbl_SkinExaminationDateTime);
            this.tabPage3.Controls.Add(this.lbl_PassiveLegRaiseExaminationDatetime);
            this.tabPage3.Controls.Add(this.lbl_CardiopulmonaryEvaluationDatetime);
            this.tabPage3.Controls.Add(this.lbl_BedsideCardioUltrasoundDateTime);
            this.tabPage3.Controls.Add(this.lbl_FluidChallengePerformedDatetime);
            this.tabPage3.Controls.Add(this.lbl_CentralVenousOxygenMeasurementDatetime);
            this.tabPage3.Controls.Add(this.lbl_PeripheralPulseEvaluationDatetime);
            this.tabPage3.Controls.Add(this.lbl_CapillaryRefillExaminationDatetime);
            this.tabPage3.Controls.Add(this.lbl_VasopressorAdministrationDateTime);
            this.tabPage3.Controls.Add(this.lbl_VasopressorAdministration);
            this.tabPage3.Controls.Add(this.lbl_PersistentHypotension);
            this.tabPage3.Controls.Add(this.lbl_InitialHypotension);
            this.tabPage3.Controls.Add(this.lbl_CrystalloidFluidAdministrationDatetime);
            this.tabPage3.Controls.Add(this.lbl_PediatricCrystalloidFluidAdministration);
            this.tabPage3.Controls.Add(this.lbl_AdultCrystalloidFluidAdministration);
            this.tabPage3.Controls.Add(this.lbl_AntibioticAdministrationDatetime);
            this.tabPage3.Controls.Add(this.lbl_AntibioticAdministrationSelection);
            this.tabPage3.Controls.Add(this.lbl_BloodCulturePathogen);
            this.tabPage3.Controls.Add(this.lbl_BloodCultureResult);
            this.tabPage3.Controls.Add(this.lbl_BloodCultureCollectionDatetime);
            this.tabPage3.Controls.Add(this.lbl_BloodCultureCollectionAcceptableDelay);
            this.tabPage3.Controls.Add(this.lbl_RepeatLactateLevelCollectionDatetime);
            this.tabPage3.Controls.Add(this.lbl_BloodCultureCollection);
            this.tabPage3.Controls.Add(this.lbl_InitialLactateLevelUnit);
            this.tabPage3.Controls.Add(this.lbl_InitialLactateLevelCollectionDatetime);
            this.tabPage3.Controls.Add(this.lbl_DestinationafterED);
            this.tabPage3.Controls.Add(this.lbl_LeftEDDatetime);
            this.tabPage3.Controls.Add(this.lbl_SepticShockPresent);
            this.tabPage3.Controls.Add(this.lbl_SevereSepsisPresentationDatetime);
            this.tabPage3.Controls.Add(this.lbl_SevereSepsisPresent);
            this.tabPage3.Controls.Add(this.lbl_EarliestDatetime);
            this.tabPage3.Controls.Add(this.textBox_VitalSignsReviewDatetime);
            this.tabPage3.Controls.Add(this.textBox_CentralVenousPressureMeasurementDatetime);
            this.tabPage3.Controls.Add(this.textBox_FluidChallengePerformedDatetime);
            this.tabPage3.Controls.Add(this.textBox_CentralVenousOxygenMeasurementDatetime);
            this.tabPage3.Controls.Add(this.textBox_PeripheralPulseEvaluationDatetime);
            this.tabPage3.Controls.Add(this.textBox_CapillaryRefillExaminationDatetime);
            this.tabPage3.Controls.Add(this.textBox_PassiveLegRaiseExaminationDatetime);
            this.tabPage3.Controls.Add(this.textBox_CardiopulmonaryEvaluationDatetime);
            this.tabPage3.Controls.Add(this.textBox_SkinExaminationDatetime);
            this.tabPage3.Controls.Add(this.textBox_BedsideCardiovascularUltrasoundDatetime);
            this.tabPage3.Controls.Add(this.textBox_AntibioticAdministrationDatetime);
            this.tabPage3.Controls.Add(this.textBox_BloodCultureCollectionDatetime);
            this.tabPage3.Controls.Add(this.textBox_VasopressorAdministrationDatetime);
            this.tabPage3.Controls.Add(this.textBox_CrystalloidFluidAdministrationDatetime);
            this.tabPage3.Controls.Add(this.textbox_RepeatLactateLevelCollectionDatetime);
            this.tabPage3.Controls.Add(this.textBox_InitialLactateLevelCollectionDatetime);
            this.tabPage3.Controls.Add(this.textBox_LeftEDDatetime);
            this.tabPage3.Controls.Add(this.textBox_septicShockPresentationDatetime);
            this.tabPage3.Controls.Add(this.textBox_SevereSepsisPresentationDatetime);
            this.tabPage3.Controls.Add(this.textbox_TriageDatetime);
            this.tabPage3.Controls.Add(this.textBox_EarliestDatetime);
            this.tabPage3.Controls.Add(this.comboBox_SkinExamination);
            this.tabPage3.Controls.Add(this.comboBox_CentralVenousOxygenMeasurement);
            this.tabPage3.Controls.Add(this.comboBox_FluidChallengePerformed);
            this.tabPage3.Controls.Add(this.comboBox_CentralVenousPressureMeasurement);
            this.tabPage3.Controls.Add(this.comboBox_VitalSignsReview);
            this.tabPage3.Controls.Add(this.comboBox_PassiveLegRaiseExamination);
            this.tabPage3.Controls.Add(this.comboBox_PeripheralPulseEvaluation);
            this.tabPage3.Controls.Add(this.comboBox_BedsideCardiovascularUltrasound);
            this.tabPage3.Controls.Add(this.comboBox_CapillaryRefillExamination);
            this.tabPage3.Controls.Add(this.comboBox_CardiopulmonaryEvaluation);
            this.tabPage3.Controls.Add(this.comboBox_RepeatLactateLevelCollection);
            this.tabPage3.Controls.Add(this.comboBox_PersistentHypotension);
            this.tabPage3.Controls.Add(this.comboBox_VasopressorAdministration);
            this.tabPage3.Controls.Add(this.comboBox_InitialHypotension);
            this.tabPage3.Controls.Add(this.comboBox_PediatricCrystalloidFluidAdministration);
            this.tabPage3.Controls.Add(this.comboBox_BloodCultureCollection);
            this.tabPage3.Controls.Add(this.comboBox_BloodCultureCollectionAcceptableDelay);
            this.tabPage3.Controls.Add(this.comboBox_AntibioticAdministrationSelection);
            this.tabPage3.Controls.Add(this.comboBox_AdultCrystalloidFluidAdministration);
            this.tabPage3.Controls.Add(this.comboBox_InitialLactateLevelUnit);
            this.tabPage3.Controls.Add(this.comboBox_BloodCulturePathogen);
            this.tabPage3.Controls.Add(this.comboBox_AntibioticAdministration);
            this.tabPage3.Controls.Add(this.comboBox_SepticShockPresent);
            this.tabPage3.Controls.Add(this.comboBox_InitialLactateLevelCollection);
            this.tabPage3.Controls.Add(this.comboBoX_BloodCultureResult);
            this.tabPage3.Controls.Add(this.comboBox_DestinationafterED);
            this.tabPage3.Controls.Add(this.comboBox_SevereSepsisPresent);
            this.tabPage3.Controls.Add(this.label_CentralVenousOxygenMeasurement);
            this.tabPage3.Controls.Add(this.label24);
            this.tabPage3.Controls.Add(this.label25);
            this.tabPage3.Controls.Add(this.label26);
            this.tabPage3.Controls.Add(this.label27);
            this.tabPage3.Controls.Add(this.label28);
            this.tabPage3.Controls.Add(this.label30);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.Label_AntibioticAdministrationSelection);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.label_VasopressorAdministration);
            this.tabPage3.Controls.Add(this.label_VasopressorAdministrationDateTime);
            this.tabPage3.Controls.Add(this.Label_InitialHypotension);
            this.tabPage3.Controls.Add(this.label_PersistentHypotension);
            this.tabPage3.Controls.Add(this.Label_CrystalloidFluidAdministrationDatetime);
            this.tabPage3.Controls.Add(this.Label_AdultCrystalloidFluidAdministration);
            this.tabPage3.Controls.Add(this.PediatricCrystalloidFluidAdministration);
            this.tabPage3.Controls.Add(this.Label_AntibioticAdministrationDatetime);
            this.tabPage3.Controls.Add(this.Label_BloodCulturePathogen);
            this.tabPage3.Controls.Add(this.Label_BloodCultureCollection);
            this.tabPage3.Controls.Add(this.Label_LeftEDDatetime);
            this.tabPage3.Controls.Add(this.Label_InitialLactateLevel);
            this.tabPage3.Controls.Add(this.Label_SevereSepsisPresent);
            this.tabPage3.Controls.Add(this.Label_BloodCultureCollectionAcceptableDelay);
            this.tabPage3.Controls.Add(this.Label_SevereSepsisPresentationDatetime);
            this.tabPage3.Controls.Add(this.Label_InitialLactateLevelUnit);
            this.tabPage3.Controls.Add(this.Label_AntibioticAdministration);
            this.tabPage3.Controls.Add(this.Label_DestinationafterED);
            this.tabPage3.Controls.Add(this.Label_BloodCultureResult);
            this.tabPage3.Controls.Add(this.Label_RepeatLactateLevelCollectionDatetime);
            this.tabPage3.Controls.Add(this.Label_InitialLactateLevelCollectionDatetime);
            this.tabPage3.Controls.Add(this.Label_SepticShockPresentationDatetime);
            this.tabPage3.Controls.Add(this.Label_BloodCultureCollectionDatetime);
            this.tabPage3.Controls.Add(this.Label_SepticShockPresent);
            this.tabPage3.Controls.Add(this.Label_InitialLactateLevelCollection);
            this.tabPage3.Controls.Add(this.Label_RepeatLactateLevelCollection);
            this.tabPage3.Controls.Add(this.Label_TriageDatetime);
            this.tabPage3.Controls.Add(this.Label_EarliestDatetime);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1233, 551);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Adherence";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // textBox_InitialLactateLevel
            // 
            this.textBox_InitialLactateLevel.Location = new System.Drawing.Point(421, 108);
            this.textBox_InitialLactateLevel.MaxLength = 4;
            this.textBox_InitialLactateLevel.Name = "textBox_InitialLactateLevel";
            this.textBox_InitialLactateLevel.Size = new System.Drawing.Size(100, 20);
            this.textBox_InitialLactateLevel.TabIndex = 10;
            this.textBox_InitialLactateLevel.Enter += new System.EventHandler(this.textBox_InitialLactateLevel_Enter);
            this.textBox_InitialLactateLevel.Leave += new System.EventHandler(this.textBox_InitialLactateLevel_Leave);
            // 
            // lbl_SepticShockPresentationDatetime
            // 
            this.lbl_SepticShockPresentationDatetime.AutoSize = true;
            this.lbl_SepticShockPresentationDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SepticShockPresentationDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SepticShockPresentationDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_SepticShockPresentationDatetime.Location = new System.Drawing.Point(742, 44);
            this.lbl_SepticShockPresentationDatetime.Name = "lbl_SepticShockPresentationDatetime";
            this.lbl_SepticShockPresentationDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_SepticShockPresentationDatetime.TabIndex = 110;
            this.lbl_SepticShockPresentationDatetime.Text = "*";
            // 
            // lbl_RepeatLactateLevelCollection
            // 
            this.lbl_RepeatLactateLevelCollection.AutoSize = true;
            this.lbl_RepeatLactateLevelCollection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_RepeatLactateLevelCollection.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_RepeatLactateLevelCollection.ForeColor = System.Drawing.Color.Black;
            this.lbl_RepeatLactateLevelCollection.Location = new System.Drawing.Point(833, 108);
            this.lbl_RepeatLactateLevelCollection.Name = "lbl_RepeatLactateLevelCollection";
            this.lbl_RepeatLactateLevelCollection.Size = new System.Drawing.Size(14, 16);
            this.lbl_RepeatLactateLevelCollection.TabIndex = 109;
            this.lbl_RepeatLactateLevelCollection.Text = "*";
            // 
            // lbl_InitialLactateLevel
            // 
            this.lbl_InitialLactateLevel.AutoSize = true;
            this.lbl_InitialLactateLevel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_InitialLactateLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_InitialLactateLevel.ForeColor = System.Drawing.Color.Black;
            this.lbl_InitialLactateLevel.Location = new System.Drawing.Point(401, 109);
            this.lbl_InitialLactateLevel.Name = "lbl_InitialLactateLevel";
            this.lbl_InitialLactateLevel.Size = new System.Drawing.Size(14, 16);
            this.lbl_InitialLactateLevel.TabIndex = 108;
            this.lbl_InitialLactateLevel.Text = "*";
            // 
            // lbl_AntibioticAdministration
            // 
            this.lbl_AntibioticAdministration.AutoSize = true;
            this.lbl_AntibioticAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_AntibioticAdministration.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AntibioticAdministration.ForeColor = System.Drawing.Color.Black;
            this.lbl_AntibioticAdministration.Location = new System.Drawing.Point(12, 208);
            this.lbl_AntibioticAdministration.Name = "lbl_AntibioticAdministration";
            this.lbl_AntibioticAdministration.Size = new System.Drawing.Size(14, 16);
            this.lbl_AntibioticAdministration.TabIndex = 107;
            this.lbl_AntibioticAdministration.Text = "*";
            // 
            // lbl_FluidChallengePerformed
            // 
            this.lbl_FluidChallengePerformed.AutoSize = true;
            this.lbl_FluidChallengePerformed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_FluidChallengePerformed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FluidChallengePerformed.ForeColor = System.Drawing.Color.Black;
            this.lbl_FluidChallengePerformed.Location = new System.Drawing.Point(619, 480);
            this.lbl_FluidChallengePerformed.Name = "lbl_FluidChallengePerformed";
            this.lbl_FluidChallengePerformed.Size = new System.Drawing.Size(14, 16);
            this.lbl_FluidChallengePerformed.TabIndex = 106;
            this.lbl_FluidChallengePerformed.Text = "*";
            // 
            // lbl_CentralVenousOxygenMeasurement
            // 
            this.lbl_CentralVenousOxygenMeasurement.AutoSize = true;
            this.lbl_CentralVenousOxygenMeasurement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_CentralVenousOxygenMeasurement.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CentralVenousOxygenMeasurement.ForeColor = System.Drawing.Color.Black;
            this.lbl_CentralVenousOxygenMeasurement.Location = new System.Drawing.Point(619, 435);
            this.lbl_CentralVenousOxygenMeasurement.Name = "lbl_CentralVenousOxygenMeasurement";
            this.lbl_CentralVenousOxygenMeasurement.Size = new System.Drawing.Size(14, 16);
            this.lbl_CentralVenousOxygenMeasurement.TabIndex = 105;
            this.lbl_CentralVenousOxygenMeasurement.Text = "*";
            // 
            // lbl_PeripheralPulseEvaluation
            // 
            this.lbl_PeripheralPulseEvaluation.AutoSize = true;
            this.lbl_PeripheralPulseEvaluation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_PeripheralPulseEvaluation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PeripheralPulseEvaluation.ForeColor = System.Drawing.Color.Black;
            this.lbl_PeripheralPulseEvaluation.Location = new System.Drawing.Point(619, 391);
            this.lbl_PeripheralPulseEvaluation.Name = "lbl_PeripheralPulseEvaluation";
            this.lbl_PeripheralPulseEvaluation.Size = new System.Drawing.Size(14, 16);
            this.lbl_PeripheralPulseEvaluation.TabIndex = 104;
            this.lbl_PeripheralPulseEvaluation.Text = "*";
            // 
            // lbl_CapillaryRefillExamination
            // 
            this.lbl_CapillaryRefillExamination.AutoSize = true;
            this.lbl_CapillaryRefillExamination.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_CapillaryRefillExamination.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CapillaryRefillExamination.ForeColor = System.Drawing.Color.Black;
            this.lbl_CapillaryRefillExamination.Location = new System.Drawing.Point(619, 344);
            this.lbl_CapillaryRefillExamination.Name = "lbl_CapillaryRefillExamination";
            this.lbl_CapillaryRefillExamination.Size = new System.Drawing.Size(14, 16);
            this.lbl_CapillaryRefillExamination.TabIndex = 103;
            this.lbl_CapillaryRefillExamination.Text = "*";
            // 
            // lbl_VitalSignsReview
            // 
            this.lbl_VitalSignsReview.AutoSize = true;
            this.lbl_VitalSignsReview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_VitalSignsReview.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_VitalSignsReview.ForeColor = System.Drawing.Color.Black;
            this.lbl_VitalSignsReview.Location = new System.Drawing.Point(12, 527);
            this.lbl_VitalSignsReview.Name = "lbl_VitalSignsReview";
            this.lbl_VitalSignsReview.Size = new System.Drawing.Size(14, 16);
            this.lbl_VitalSignsReview.TabIndex = 102;
            this.lbl_VitalSignsReview.Text = "*";
            // 
            // lbl_CVPressureMeasurement
            // 
            this.lbl_CVPressureMeasurement.AutoSize = true;
            this.lbl_CVPressureMeasurement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_CVPressureMeasurement.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CVPressureMeasurement.ForeColor = System.Drawing.Color.Black;
            this.lbl_CVPressureMeasurement.Location = new System.Drawing.Point(12, 478);
            this.lbl_CVPressureMeasurement.Name = "lbl_CVPressureMeasurement";
            this.lbl_CVPressureMeasurement.Size = new System.Drawing.Size(14, 16);
            this.lbl_CVPressureMeasurement.TabIndex = 101;
            this.lbl_CVPressureMeasurement.Text = "*";
            // 
            // lbl_SkinExamination
            // 
            this.lbl_SkinExamination.AutoSize = true;
            this.lbl_SkinExamination.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SkinExamination.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SkinExamination.ForeColor = System.Drawing.Color.Black;
            this.lbl_SkinExamination.Location = new System.Drawing.Point(12, 432);
            this.lbl_SkinExamination.Name = "lbl_SkinExamination";
            this.lbl_SkinExamination.Size = new System.Drawing.Size(14, 16);
            this.lbl_SkinExamination.TabIndex = 100;
            this.lbl_SkinExamination.Text = "*";
            // 
            // lbl_PassiveLegRaiseExamination
            // 
            this.lbl_PassiveLegRaiseExamination.AutoSize = true;
            this.lbl_PassiveLegRaiseExamination.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_PassiveLegRaiseExamination.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PassiveLegRaiseExamination.ForeColor = System.Drawing.Color.Black;
            this.lbl_PassiveLegRaiseExamination.Location = new System.Drawing.Point(12, 389);
            this.lbl_PassiveLegRaiseExamination.Name = "lbl_PassiveLegRaiseExamination";
            this.lbl_PassiveLegRaiseExamination.Size = new System.Drawing.Size(14, 16);
            this.lbl_PassiveLegRaiseExamination.TabIndex = 99;
            this.lbl_PassiveLegRaiseExamination.Text = "*";
            // 
            // lbl_CardiopulmonaryEvaluation
            // 
            this.lbl_CardiopulmonaryEvaluation.AutoSize = true;
            this.lbl_CardiopulmonaryEvaluation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_CardiopulmonaryEvaluation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CardiopulmonaryEvaluation.ForeColor = System.Drawing.Color.Black;
            this.lbl_CardiopulmonaryEvaluation.Location = new System.Drawing.Point(12, 345);
            this.lbl_CardiopulmonaryEvaluation.Name = "lbl_CardiopulmonaryEvaluation";
            this.lbl_CardiopulmonaryEvaluation.Size = new System.Drawing.Size(14, 16);
            this.lbl_CardiopulmonaryEvaluation.TabIndex = 98;
            this.lbl_CardiopulmonaryEvaluation.Text = "*";
            // 
            // lbl_BedsideCardiovascularUltrasound
            // 
            this.lbl_BedsideCardiovascularUltrasound.AutoSize = true;
            this.lbl_BedsideCardiovascularUltrasound.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_BedsideCardiovascularUltrasound.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_BedsideCardiovascularUltrasound.ForeColor = System.Drawing.Color.Black;
            this.lbl_BedsideCardiovascularUltrasound.Location = new System.Drawing.Point(12, 301);
            this.lbl_BedsideCardiovascularUltrasound.Name = "lbl_BedsideCardiovascularUltrasound";
            this.lbl_BedsideCardiovascularUltrasound.Size = new System.Drawing.Size(14, 16);
            this.lbl_BedsideCardiovascularUltrasound.TabIndex = 97;
            this.lbl_BedsideCardiovascularUltrasound.Text = "*";
            // 
            // lblVitalSignsReviewDatetime
            // 
            this.lblVitalSignsReviewDatetime.AutoSize = true;
            this.lblVitalSignsReviewDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblVitalSignsReviewDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVitalSignsReviewDatetime.ForeColor = System.Drawing.Color.Black;
            this.lblVitalSignsReviewDatetime.Location = new System.Drawing.Point(187, 527);
            this.lblVitalSignsReviewDatetime.Name = "lblVitalSignsReviewDatetime";
            this.lblVitalSignsReviewDatetime.Size = new System.Drawing.Size(14, 16);
            this.lblVitalSignsReviewDatetime.TabIndex = 96;
            this.lblVitalSignsReviewDatetime.Text = "*";
            // 
            // lbl_CVPressureMeasurementDateTime
            // 
            this.lbl_CVPressureMeasurementDateTime.AutoSize = true;
            this.lbl_CVPressureMeasurementDateTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_CVPressureMeasurementDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CVPressureMeasurementDateTime.ForeColor = System.Drawing.Color.Black;
            this.lbl_CVPressureMeasurementDateTime.Location = new System.Drawing.Point(187, 478);
            this.lbl_CVPressureMeasurementDateTime.Name = "lbl_CVPressureMeasurementDateTime";
            this.lbl_CVPressureMeasurementDateTime.Size = new System.Drawing.Size(14, 16);
            this.lbl_CVPressureMeasurementDateTime.TabIndex = 95;
            this.lbl_CVPressureMeasurementDateTime.Text = "*";
            // 
            // lbl_SkinExaminationDateTime
            // 
            this.lbl_SkinExaminationDateTime.AutoSize = true;
            this.lbl_SkinExaminationDateTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SkinExaminationDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SkinExaminationDateTime.ForeColor = System.Drawing.Color.Black;
            this.lbl_SkinExaminationDateTime.Location = new System.Drawing.Point(187, 435);
            this.lbl_SkinExaminationDateTime.Name = "lbl_SkinExaminationDateTime";
            this.lbl_SkinExaminationDateTime.Size = new System.Drawing.Size(14, 16);
            this.lbl_SkinExaminationDateTime.TabIndex = 94;
            this.lbl_SkinExaminationDateTime.Text = "*";
            // 
            // lbl_PassiveLegRaiseExaminationDatetime
            // 
            this.lbl_PassiveLegRaiseExaminationDatetime.AutoSize = true;
            this.lbl_PassiveLegRaiseExaminationDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_PassiveLegRaiseExaminationDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PassiveLegRaiseExaminationDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_PassiveLegRaiseExaminationDatetime.Location = new System.Drawing.Point(187, 389);
            this.lbl_PassiveLegRaiseExaminationDatetime.Name = "lbl_PassiveLegRaiseExaminationDatetime";
            this.lbl_PassiveLegRaiseExaminationDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_PassiveLegRaiseExaminationDatetime.TabIndex = 93;
            this.lbl_PassiveLegRaiseExaminationDatetime.Text = "*";
            // 
            // lbl_CardiopulmonaryEvaluationDatetime
            // 
            this.lbl_CardiopulmonaryEvaluationDatetime.AutoSize = true;
            this.lbl_CardiopulmonaryEvaluationDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_CardiopulmonaryEvaluationDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CardiopulmonaryEvaluationDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_CardiopulmonaryEvaluationDatetime.Location = new System.Drawing.Point(187, 347);
            this.lbl_CardiopulmonaryEvaluationDatetime.Name = "lbl_CardiopulmonaryEvaluationDatetime";
            this.lbl_CardiopulmonaryEvaluationDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_CardiopulmonaryEvaluationDatetime.TabIndex = 92;
            this.lbl_CardiopulmonaryEvaluationDatetime.Text = "*";
            // 
            // lbl_BedsideCardioUltrasoundDateTime
            // 
            this.lbl_BedsideCardioUltrasoundDateTime.AutoSize = true;
            this.lbl_BedsideCardioUltrasoundDateTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_BedsideCardioUltrasoundDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_BedsideCardioUltrasoundDateTime.ForeColor = System.Drawing.Color.Black;
            this.lbl_BedsideCardioUltrasoundDateTime.Location = new System.Drawing.Point(187, 300);
            this.lbl_BedsideCardioUltrasoundDateTime.Name = "lbl_BedsideCardioUltrasoundDateTime";
            this.lbl_BedsideCardioUltrasoundDateTime.Size = new System.Drawing.Size(14, 16);
            this.lbl_BedsideCardioUltrasoundDateTime.TabIndex = 91;
            this.lbl_BedsideCardioUltrasoundDateTime.Text = "*";
            // 
            // lbl_FluidChallengePerformedDatetime
            // 
            this.lbl_FluidChallengePerformedDatetime.AutoSize = true;
            this.lbl_FluidChallengePerformedDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_FluidChallengePerformedDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FluidChallengePerformedDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_FluidChallengePerformedDatetime.Location = new System.Drawing.Point(834, 482);
            this.lbl_FluidChallengePerformedDatetime.Name = "lbl_FluidChallengePerformedDatetime";
            this.lbl_FluidChallengePerformedDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_FluidChallengePerformedDatetime.TabIndex = 90;
            this.lbl_FluidChallengePerformedDatetime.Text = "*";
            // 
            // lbl_CentralVenousOxygenMeasurementDatetime
            // 
            this.lbl_CentralVenousOxygenMeasurementDatetime.AutoSize = true;
            this.lbl_CentralVenousOxygenMeasurementDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_CentralVenousOxygenMeasurementDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CentralVenousOxygenMeasurementDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_CentralVenousOxygenMeasurementDatetime.Location = new System.Drawing.Point(834, 437);
            this.lbl_CentralVenousOxygenMeasurementDatetime.Name = "lbl_CentralVenousOxygenMeasurementDatetime";
            this.lbl_CentralVenousOxygenMeasurementDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_CentralVenousOxygenMeasurementDatetime.TabIndex = 89;
            this.lbl_CentralVenousOxygenMeasurementDatetime.Text = "*";
            // 
            // lbl_PeripheralPulseEvaluationDatetime
            // 
            this.lbl_PeripheralPulseEvaluationDatetime.AutoSize = true;
            this.lbl_PeripheralPulseEvaluationDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_PeripheralPulseEvaluationDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PeripheralPulseEvaluationDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_PeripheralPulseEvaluationDatetime.Location = new System.Drawing.Point(834, 390);
            this.lbl_PeripheralPulseEvaluationDatetime.Name = "lbl_PeripheralPulseEvaluationDatetime";
            this.lbl_PeripheralPulseEvaluationDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_PeripheralPulseEvaluationDatetime.TabIndex = 88;
            this.lbl_PeripheralPulseEvaluationDatetime.Text = "*";
            // 
            // lbl_CapillaryRefillExaminationDatetime
            // 
            this.lbl_CapillaryRefillExaminationDatetime.AutoSize = true;
            this.lbl_CapillaryRefillExaminationDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_CapillaryRefillExaminationDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CapillaryRefillExaminationDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_CapillaryRefillExaminationDatetime.Location = new System.Drawing.Point(834, 345);
            this.lbl_CapillaryRefillExaminationDatetime.Name = "lbl_CapillaryRefillExaminationDatetime";
            this.lbl_CapillaryRefillExaminationDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_CapillaryRefillExaminationDatetime.TabIndex = 87;
            this.lbl_CapillaryRefillExaminationDatetime.Text = "*";
            // 
            // lbl_VasopressorAdministrationDateTime
            // 
            this.lbl_VasopressorAdministrationDateTime.AutoSize = true;
            this.lbl_VasopressorAdministrationDateTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_VasopressorAdministrationDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_VasopressorAdministrationDateTime.ForeColor = System.Drawing.Color.Black;
            this.lbl_VasopressorAdministrationDateTime.Location = new System.Drawing.Point(834, 302);
            this.lbl_VasopressorAdministrationDateTime.Name = "lbl_VasopressorAdministrationDateTime";
            this.lbl_VasopressorAdministrationDateTime.Size = new System.Drawing.Size(14, 16);
            this.lbl_VasopressorAdministrationDateTime.TabIndex = 86;
            this.lbl_VasopressorAdministrationDateTime.Text = "*";
            // 
            // lbl_VasopressorAdministration
            // 
            this.lbl_VasopressorAdministration.AutoSize = true;
            this.lbl_VasopressorAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_VasopressorAdministration.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_VasopressorAdministration.ForeColor = System.Drawing.Color.Black;
            this.lbl_VasopressorAdministration.Location = new System.Drawing.Point(619, 301);
            this.lbl_VasopressorAdministration.Name = "lbl_VasopressorAdministration";
            this.lbl_VasopressorAdministration.Size = new System.Drawing.Size(14, 16);
            this.lbl_VasopressorAdministration.TabIndex = 85;
            this.lbl_VasopressorAdministration.Text = "*";
            // 
            // lbl_PersistentHypotension
            // 
            this.lbl_PersistentHypotension.AutoSize = true;
            this.lbl_PersistentHypotension.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_PersistentHypotension.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PersistentHypotension.ForeColor = System.Drawing.Color.Black;
            this.lbl_PersistentHypotension.Location = new System.Drawing.Point(187, 257);
            this.lbl_PersistentHypotension.Name = "lbl_PersistentHypotension";
            this.lbl_PersistentHypotension.Size = new System.Drawing.Size(14, 16);
            this.lbl_PersistentHypotension.TabIndex = 84;
            this.lbl_PersistentHypotension.Text = "*";
            // 
            // lbl_InitialHypotension
            // 
            this.lbl_InitialHypotension.AutoSize = true;
            this.lbl_InitialHypotension.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_InitialHypotension.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_InitialHypotension.ForeColor = System.Drawing.Color.Black;
            this.lbl_InitialHypotension.Location = new System.Drawing.Point(12, 257);
            this.lbl_InitialHypotension.Name = "lbl_InitialHypotension";
            this.lbl_InitialHypotension.Size = new System.Drawing.Size(14, 16);
            this.lbl_InitialHypotension.TabIndex = 83;
            this.lbl_InitialHypotension.Text = "*";
            // 
            // lbl_CrystalloidFluidAdministrationDatetime
            // 
            this.lbl_CrystalloidFluidAdministrationDatetime.AutoSize = true;
            this.lbl_CrystalloidFluidAdministrationDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_CrystalloidFluidAdministrationDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CrystalloidFluidAdministrationDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_CrystalloidFluidAdministrationDatetime.Location = new System.Drawing.Point(993, 236);
            this.lbl_CrystalloidFluidAdministrationDatetime.Name = "lbl_CrystalloidFluidAdministrationDatetime";
            this.lbl_CrystalloidFluidAdministrationDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_CrystalloidFluidAdministrationDatetime.TabIndex = 82;
            this.lbl_CrystalloidFluidAdministrationDatetime.Text = "*";
            // 
            // lbl_PediatricCrystalloidFluidAdministration
            // 
            this.lbl_PediatricCrystalloidFluidAdministration.AutoSize = true;
            this.lbl_PediatricCrystalloidFluidAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_PediatricCrystalloidFluidAdministration.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PediatricCrystalloidFluidAdministration.ForeColor = System.Drawing.Color.Black;
            this.lbl_PediatricCrystalloidFluidAdministration.Location = new System.Drawing.Point(619, 257);
            this.lbl_PediatricCrystalloidFluidAdministration.Name = "lbl_PediatricCrystalloidFluidAdministration";
            this.lbl_PediatricCrystalloidFluidAdministration.Size = new System.Drawing.Size(14, 16);
            this.lbl_PediatricCrystalloidFluidAdministration.TabIndex = 81;
            this.lbl_PediatricCrystalloidFluidAdministration.Text = "*";
            // 
            // lbl_AdultCrystalloidFluidAdministration
            // 
            this.lbl_AdultCrystalloidFluidAdministration.AutoSize = true;
            this.lbl_AdultCrystalloidFluidAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_AdultCrystalloidFluidAdministration.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AdultCrystalloidFluidAdministration.ForeColor = System.Drawing.Color.Black;
            this.lbl_AdultCrystalloidFluidAdministration.Location = new System.Drawing.Point(619, 208);
            this.lbl_AdultCrystalloidFluidAdministration.Name = "lbl_AdultCrystalloidFluidAdministration";
            this.lbl_AdultCrystalloidFluidAdministration.Size = new System.Drawing.Size(14, 16);
            this.lbl_AdultCrystalloidFluidAdministration.TabIndex = 80;
            this.lbl_AdultCrystalloidFluidAdministration.Text = "*";
            // 
            // lbl_AntibioticAdministrationDatetime
            // 
            this.lbl_AntibioticAdministrationDatetime.AutoSize = true;
            this.lbl_AntibioticAdministrationDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_AntibioticAdministrationDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AntibioticAdministrationDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_AntibioticAdministrationDatetime.Location = new System.Drawing.Point(401, 208);
            this.lbl_AntibioticAdministrationDatetime.Name = "lbl_AntibioticAdministrationDatetime";
            this.lbl_AntibioticAdministrationDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_AntibioticAdministrationDatetime.TabIndex = 79;
            this.lbl_AntibioticAdministrationDatetime.Text = "*";
            // 
            // lbl_AntibioticAdministrationSelection
            // 
            this.lbl_AntibioticAdministrationSelection.AutoSize = true;
            this.lbl_AntibioticAdministrationSelection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_AntibioticAdministrationSelection.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AntibioticAdministrationSelection.ForeColor = System.Drawing.Color.Black;
            this.lbl_AntibioticAdministrationSelection.Location = new System.Drawing.Point(187, 208);
            this.lbl_AntibioticAdministrationSelection.Name = "lbl_AntibioticAdministrationSelection";
            this.lbl_AntibioticAdministrationSelection.Size = new System.Drawing.Size(14, 16);
            this.lbl_AntibioticAdministrationSelection.TabIndex = 78;
            this.lbl_AntibioticAdministrationSelection.Text = "*";
            // 
            // lbl_BloodCulturePathogen
            // 
            this.lbl_BloodCulturePathogen.AutoSize = true;
            this.lbl_BloodCulturePathogen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_BloodCulturePathogen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_BloodCulturePathogen.ForeColor = System.Drawing.Color.Black;
            this.lbl_BloodCulturePathogen.Location = new System.Drawing.Point(834, 163);
            this.lbl_BloodCulturePathogen.Name = "lbl_BloodCulturePathogen";
            this.lbl_BloodCulturePathogen.Size = new System.Drawing.Size(14, 16);
            this.lbl_BloodCulturePathogen.TabIndex = 77;
            this.lbl_BloodCulturePathogen.Text = "*";
            // 
            // lbl_BloodCultureResult
            // 
            this.lbl_BloodCultureResult.AutoSize = true;
            this.lbl_BloodCultureResult.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_BloodCultureResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_BloodCultureResult.ForeColor = System.Drawing.Color.Black;
            this.lbl_BloodCultureResult.Location = new System.Drawing.Point(619, 163);
            this.lbl_BloodCultureResult.Name = "lbl_BloodCultureResult";
            this.lbl_BloodCultureResult.Size = new System.Drawing.Size(14, 16);
            this.lbl_BloodCultureResult.TabIndex = 76;
            this.lbl_BloodCultureResult.Text = "*";
            // 
            // lbl_BloodCultureCollectionDatetime
            // 
            this.lbl_BloodCultureCollectionDatetime.AutoSize = true;
            this.lbl_BloodCultureCollectionDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_BloodCultureCollectionDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_BloodCultureCollectionDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_BloodCultureCollectionDatetime.Location = new System.Drawing.Point(401, 163);
            this.lbl_BloodCultureCollectionDatetime.Name = "lbl_BloodCultureCollectionDatetime";
            this.lbl_BloodCultureCollectionDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_BloodCultureCollectionDatetime.TabIndex = 75;
            this.lbl_BloodCultureCollectionDatetime.Text = "*";
            // 
            // lbl_BloodCultureCollectionAcceptableDelay
            // 
            this.lbl_BloodCultureCollectionAcceptableDelay.AutoSize = true;
            this.lbl_BloodCultureCollectionAcceptableDelay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_BloodCultureCollectionAcceptableDelay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_BloodCultureCollectionAcceptableDelay.ForeColor = System.Drawing.Color.Black;
            this.lbl_BloodCultureCollectionAcceptableDelay.Location = new System.Drawing.Point(187, 162);
            this.lbl_BloodCultureCollectionAcceptableDelay.Name = "lbl_BloodCultureCollectionAcceptableDelay";
            this.lbl_BloodCultureCollectionAcceptableDelay.Size = new System.Drawing.Size(14, 16);
            this.lbl_BloodCultureCollectionAcceptableDelay.TabIndex = 74;
            this.lbl_BloodCultureCollectionAcceptableDelay.Text = "*";
            // 
            // lbl_RepeatLactateLevelCollectionDatetime
            // 
            this.lbl_RepeatLactateLevelCollectionDatetime.AutoSize = true;
            this.lbl_RepeatLactateLevelCollectionDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_RepeatLactateLevelCollectionDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_RepeatLactateLevelCollectionDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_RepeatLactateLevelCollectionDatetime.Location = new System.Drawing.Point(994, 107);
            this.lbl_RepeatLactateLevelCollectionDatetime.Name = "lbl_RepeatLactateLevelCollectionDatetime";
            this.lbl_RepeatLactateLevelCollectionDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_RepeatLactateLevelCollectionDatetime.TabIndex = 73;
            this.lbl_RepeatLactateLevelCollectionDatetime.Text = "*";
            // 
            // lbl_BloodCultureCollection
            // 
            this.lbl_BloodCultureCollection.AutoSize = true;
            this.lbl_BloodCultureCollection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_BloodCultureCollection.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_BloodCultureCollection.ForeColor = System.Drawing.Color.Black;
            this.lbl_BloodCultureCollection.Location = new System.Drawing.Point(12, 162);
            this.lbl_BloodCultureCollection.Name = "lbl_BloodCultureCollection";
            this.lbl_BloodCultureCollection.Size = new System.Drawing.Size(14, 16);
            this.lbl_BloodCultureCollection.TabIndex = 72;
            this.lbl_BloodCultureCollection.Text = "*";
            // 
            // lbl_InitialLactateLevelUnit
            // 
            this.lbl_InitialLactateLevelUnit.AutoSize = true;
            this.lbl_InitialLactateLevelUnit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_InitialLactateLevelUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_InitialLactateLevelUnit.ForeColor = System.Drawing.Color.Black;
            this.lbl_InitialLactateLevelUnit.Location = new System.Drawing.Point(619, 109);
            this.lbl_InitialLactateLevelUnit.Name = "lbl_InitialLactateLevelUnit";
            this.lbl_InitialLactateLevelUnit.Size = new System.Drawing.Size(14, 16);
            this.lbl_InitialLactateLevelUnit.TabIndex = 71;
            this.lbl_InitialLactateLevelUnit.Text = "*";
            // 
            // lbl_InitialLactateLevelCollectionDatetime
            // 
            this.lbl_InitialLactateLevelCollectionDatetime.AutoSize = true;
            this.lbl_InitialLactateLevelCollectionDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_InitialLactateLevelCollectionDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_InitialLactateLevelCollectionDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_InitialLactateLevelCollectionDatetime.Location = new System.Drawing.Point(187, 109);
            this.lbl_InitialLactateLevelCollectionDatetime.Name = "lbl_InitialLactateLevelCollectionDatetime";
            this.lbl_InitialLactateLevelCollectionDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_InitialLactateLevelCollectionDatetime.TabIndex = 70;
            this.lbl_InitialLactateLevelCollectionDatetime.Text = "*";
            // 
            // lbl_DestinationafterED
            // 
            this.lbl_DestinationafterED.AutoSize = true;
            this.lbl_DestinationafterED.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_DestinationafterED.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DestinationafterED.ForeColor = System.Drawing.Color.Black;
            this.lbl_DestinationafterED.Location = new System.Drawing.Point(989, 44);
            this.lbl_DestinationafterED.Name = "lbl_DestinationafterED";
            this.lbl_DestinationafterED.Size = new System.Drawing.Size(14, 16);
            this.lbl_DestinationafterED.TabIndex = 69;
            this.lbl_DestinationafterED.Text = "*";
            // 
            // lbl_LeftEDDatetime
            // 
            this.lbl_LeftEDDatetime.AutoSize = true;
            this.lbl_LeftEDDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_LeftEDDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_LeftEDDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_LeftEDDatetime.Location = new System.Drawing.Point(864, 44);
            this.lbl_LeftEDDatetime.Name = "lbl_LeftEDDatetime";
            this.lbl_LeftEDDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_LeftEDDatetime.TabIndex = 68;
            this.lbl_LeftEDDatetime.Text = "*";
            // 
            // lbl_SepticShockPresent
            // 
            this.lbl_SepticShockPresent.AutoSize = true;
            this.lbl_SepticShockPresent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SepticShockPresent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SepticShockPresent.ForeColor = System.Drawing.Color.Black;
            this.lbl_SepticShockPresent.Location = new System.Drawing.Point(663, 44);
            this.lbl_SepticShockPresent.Name = "lbl_SepticShockPresent";
            this.lbl_SepticShockPresent.Size = new System.Drawing.Size(14, 16);
            this.lbl_SepticShockPresent.TabIndex = 67;
            this.lbl_SepticShockPresent.Text = "*";
            // 
            // lbl_SevereSepsisPresentationDatetime
            // 
            this.lbl_SevereSepsisPresentationDatetime.AutoSize = true;
            this.lbl_SevereSepsisPresentationDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SevereSepsisPresentationDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SevereSepsisPresentationDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_SevereSepsisPresentationDatetime.Location = new System.Drawing.Point(554, 43);
            this.lbl_SevereSepsisPresentationDatetime.Name = "lbl_SevereSepsisPresentationDatetime";
            this.lbl_SevereSepsisPresentationDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_SevereSepsisPresentationDatetime.TabIndex = 66;
            this.lbl_SevereSepsisPresentationDatetime.Text = "*";
            // 
            // lbl_SevereSepsisPresent
            // 
            this.lbl_SevereSepsisPresent.AutoSize = true;
            this.lbl_SevereSepsisPresent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SevereSepsisPresent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SevereSepsisPresent.ForeColor = System.Drawing.Color.Black;
            this.lbl_SevereSepsisPresent.Location = new System.Drawing.Point(243, 45);
            this.lbl_SevereSepsisPresent.Name = "lbl_SevereSepsisPresent";
            this.lbl_SevereSepsisPresent.Size = new System.Drawing.Size(14, 16);
            this.lbl_SevereSepsisPresent.TabIndex = 65;
            this.lbl_SevereSepsisPresent.Text = "*";
            // 
            // lbl_EarliestDatetime
            // 
            this.lbl_EarliestDatetime.AutoSize = true;
            this.lbl_EarliestDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_EarliestDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EarliestDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_EarliestDatetime.Location = new System.Drawing.Point(12, 44);
            this.lbl_EarliestDatetime.Name = "lbl_EarliestDatetime";
            this.lbl_EarliestDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_EarliestDatetime.TabIndex = 64;
            this.lbl_EarliestDatetime.Text = "*";
            // 
            // textBox_VitalSignsReviewDatetime
            // 
            this.textBox_VitalSignsReviewDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_VitalSignsReviewDatetime.Location = new System.Drawing.Point(203, 528);
            this.textBox_VitalSignsReviewDatetime.Mask = "00/00/0000 90:00";
            this.textBox_VitalSignsReviewDatetime.Name = "textBox_VitalSignsReviewDatetime";
            this.textBox_VitalSignsReviewDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_VitalSignsReviewDatetime.TabIndex = 48;
            this.textBox_VitalSignsReviewDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_VitalSignsReviewDatetime.Enter += new System.EventHandler(this.textBox_VitalSignsReviewDatetime_Enter);
            this.textBox_VitalSignsReviewDatetime.Leave += new System.EventHandler(this.textBox_VitalSignsReviewDatetime_Leave);
            // 
            // textBox_CentralVenousPressureMeasurementDatetime
            // 
            this.textBox_CentralVenousPressureMeasurementDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_CentralVenousPressureMeasurementDatetime.Location = new System.Drawing.Point(203, 478);
            this.textBox_CentralVenousPressureMeasurementDatetime.Mask = "00/00/0000 90:00";
            this.textBox_CentralVenousPressureMeasurementDatetime.Name = "textBox_CentralVenousPressureMeasurementDatetime";
            this.textBox_CentralVenousPressureMeasurementDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_CentralVenousPressureMeasurementDatetime.TabIndex = 44;
            this.textBox_CentralVenousPressureMeasurementDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_CentralVenousPressureMeasurementDatetime.Enter += new System.EventHandler(this.textBox_CentralVenousPressureMeasurementDatetime_Enter);
            this.textBox_CentralVenousPressureMeasurementDatetime.Leave += new System.EventHandler(this.textBox_CentralVenousPressureMeasurementDatetime_Leave);
            // 
            // textBox_FluidChallengePerformedDatetime
            // 
            this.textBox_FluidChallengePerformedDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_FluidChallengePerformedDatetime.Location = new System.Drawing.Point(849, 482);
            this.textBox_FluidChallengePerformedDatetime.Mask = "00/00/0000 90:00";
            this.textBox_FluidChallengePerformedDatetime.Name = "textBox_FluidChallengePerformedDatetime";
            this.textBox_FluidChallengePerformedDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_FluidChallengePerformedDatetime.TabIndex = 46;
            this.textBox_FluidChallengePerformedDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_FluidChallengePerformedDatetime.Enter += new System.EventHandler(this.textBox_FluidChallengePerformedDatetime_Enter);
            this.textBox_FluidChallengePerformedDatetime.Leave += new System.EventHandler(this.textBox_FluidChallengePerformedDatetime_Leave);
            // 
            // textBox_CentralVenousOxygenMeasurementDatetime
            // 
            this.textBox_CentralVenousOxygenMeasurementDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_CentralVenousOxygenMeasurementDatetime.Location = new System.Drawing.Point(849, 436);
            this.textBox_CentralVenousOxygenMeasurementDatetime.Mask = "00/00/0000 90:00";
            this.textBox_CentralVenousOxygenMeasurementDatetime.Name = "textBox_CentralVenousOxygenMeasurementDatetime";
            this.textBox_CentralVenousOxygenMeasurementDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_CentralVenousOxygenMeasurementDatetime.TabIndex = 42;
            this.textBox_CentralVenousOxygenMeasurementDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_CentralVenousOxygenMeasurementDatetime.Enter += new System.EventHandler(this.textBox_CentralVenousOxygenMeasurementDatetime_Enter);
            this.textBox_CentralVenousOxygenMeasurementDatetime.Leave += new System.EventHandler(this.textBox_CentralVenousOxygenMeasurementDatetime_Leave);
            // 
            // textBox_PeripheralPulseEvaluationDatetime
            // 
            this.textBox_PeripheralPulseEvaluationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_PeripheralPulseEvaluationDatetime.Location = new System.Drawing.Point(849, 392);
            this.textBox_PeripheralPulseEvaluationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_PeripheralPulseEvaluationDatetime.Name = "textBox_PeripheralPulseEvaluationDatetime";
            this.textBox_PeripheralPulseEvaluationDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_PeripheralPulseEvaluationDatetime.TabIndex = 38;
            this.textBox_PeripheralPulseEvaluationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_PeripheralPulseEvaluationDatetime.Enter += new System.EventHandler(this.textBox_PeripheralPulseEvaluationDatetime_Enter);
            this.textBox_PeripheralPulseEvaluationDatetime.Leave += new System.EventHandler(this.textBox_PeripheralPulseEvaluationDatetime_Leave);
            // 
            // textBox_CapillaryRefillExaminationDatetime
            // 
            this.textBox_CapillaryRefillExaminationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_CapillaryRefillExaminationDatetime.Location = new System.Drawing.Point(849, 346);
            this.textBox_CapillaryRefillExaminationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_CapillaryRefillExaminationDatetime.Name = "textBox_CapillaryRefillExaminationDatetime";
            this.textBox_CapillaryRefillExaminationDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_CapillaryRefillExaminationDatetime.TabIndex = 34;
            this.textBox_CapillaryRefillExaminationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_CapillaryRefillExaminationDatetime.Enter += new System.EventHandler(this.textBox_CapillaryRefillExaminationDatetime_Enter);
            this.textBox_CapillaryRefillExaminationDatetime.Leave += new System.EventHandler(this.textBox_CapillaryRefillExaminationDatetime_Leave);
            // 
            // textBox_PassiveLegRaiseExaminationDatetime
            // 
            this.textBox_PassiveLegRaiseExaminationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_PassiveLegRaiseExaminationDatetime.Location = new System.Drawing.Point(203, 390);
            this.textBox_PassiveLegRaiseExaminationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_PassiveLegRaiseExaminationDatetime.Name = "textBox_PassiveLegRaiseExaminationDatetime";
            this.textBox_PassiveLegRaiseExaminationDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_PassiveLegRaiseExaminationDatetime.TabIndex = 36;
            this.textBox_PassiveLegRaiseExaminationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_PassiveLegRaiseExaminationDatetime.Enter += new System.EventHandler(this.textBox_PassiveLegRaiseExaminationDatetime_Enter);
            this.textBox_PassiveLegRaiseExaminationDatetime.Leave += new System.EventHandler(this.textBox_PassiveLegRaiseExaminationDatetime_Leave);
            // 
            // textBox_CardiopulmonaryEvaluationDatetime
            // 
            this.textBox_CardiopulmonaryEvaluationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_CardiopulmonaryEvaluationDatetime.Location = new System.Drawing.Point(203, 346);
            this.textBox_CardiopulmonaryEvaluationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_CardiopulmonaryEvaluationDatetime.Name = "textBox_CardiopulmonaryEvaluationDatetime";
            this.textBox_CardiopulmonaryEvaluationDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_CardiopulmonaryEvaluationDatetime.TabIndex = 32;
            this.textBox_CardiopulmonaryEvaluationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_CardiopulmonaryEvaluationDatetime.Enter += new System.EventHandler(this.textBox_CardiopulmonaryEvaluationDatetime_Enter);
            this.textBox_CardiopulmonaryEvaluationDatetime.Leave += new System.EventHandler(this.textBox_CardiopulmonaryEvaluationDatetime_Leave);
            // 
            // textBox_SkinExaminationDatetime
            // 
            this.textBox_SkinExaminationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_SkinExaminationDatetime.Location = new System.Drawing.Point(203, 436);
            this.textBox_SkinExaminationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_SkinExaminationDatetime.Name = "textBox_SkinExaminationDatetime";
            this.textBox_SkinExaminationDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_SkinExaminationDatetime.TabIndex = 40;
            this.textBox_SkinExaminationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_SkinExaminationDatetime.Enter += new System.EventHandler(this.textBox_SkinExaminationDatetime_Enter);
            this.textBox_SkinExaminationDatetime.Leave += new System.EventHandler(this.textBox_SkinExaminationDatetime_Leave);
            // 
            // textBox_BedsideCardiovascularUltrasoundDatetime
            // 
            this.textBox_BedsideCardiovascularUltrasoundDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_BedsideCardiovascularUltrasoundDatetime.Location = new System.Drawing.Point(203, 301);
            this.textBox_BedsideCardiovascularUltrasoundDatetime.Mask = "00/00/0000 90:00";
            this.textBox_BedsideCardiovascularUltrasoundDatetime.Name = "textBox_BedsideCardiovascularUltrasoundDatetime";
            this.textBox_BedsideCardiovascularUltrasoundDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_BedsideCardiovascularUltrasoundDatetime.TabIndex = 28;
            this.textBox_BedsideCardiovascularUltrasoundDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_BedsideCardiovascularUltrasoundDatetime.Enter += new System.EventHandler(this.textBox_BedsideCardiovascularUltrasoundDatetime_Enter);
            this.textBox_BedsideCardiovascularUltrasoundDatetime.Leave += new System.EventHandler(this.textBox_BedsideCardiovascularUltrasoundDatetime_Leave);
            // 
            // textBox_AntibioticAdministrationDatetime
            // 
            this.textBox_AntibioticAdministrationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_AntibioticAdministrationDatetime.Location = new System.Drawing.Point(417, 208);
            this.textBox_AntibioticAdministrationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_AntibioticAdministrationDatetime.Name = "textBox_AntibioticAdministrationDatetime";
            this.textBox_AntibioticAdministrationDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_AntibioticAdministrationDatetime.TabIndex = 21;
            this.textBox_AntibioticAdministrationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_AntibioticAdministrationDatetime.Enter += new System.EventHandler(this.textBox_AntibioticAdministrationDatetime_Enter);
            this.textBox_AntibioticAdministrationDatetime.Leave += new System.EventHandler(this.textBox_AntibioticAdministrationDatetime_Leave);
            // 
            // textBox_BloodCultureCollectionDatetime
            // 
            this.textBox_BloodCultureCollectionDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_BloodCultureCollectionDatetime.Location = new System.Drawing.Point(417, 163);
            this.textBox_BloodCultureCollectionDatetime.Mask = "00/00/0000 90:00";
            this.textBox_BloodCultureCollectionDatetime.Name = "textBox_BloodCultureCollectionDatetime";
            this.textBox_BloodCultureCollectionDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_BloodCultureCollectionDatetime.TabIndex = 16;
            this.textBox_BloodCultureCollectionDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_BloodCultureCollectionDatetime.Enter += new System.EventHandler(this.textBox_BloodCultureCollectionDatetime_Enter);
            this.textBox_BloodCultureCollectionDatetime.Leave += new System.EventHandler(this.textBox_BloodCultureCollectionDatetime_Leave);
            // 
            // textBox_VasopressorAdministrationDatetime
            // 
            this.textBox_VasopressorAdministrationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_VasopressorAdministrationDatetime.Location = new System.Drawing.Point(849, 302);
            this.textBox_VasopressorAdministrationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_VasopressorAdministrationDatetime.Name = "textBox_VasopressorAdministrationDatetime";
            this.textBox_VasopressorAdministrationDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_VasopressorAdministrationDatetime.TabIndex = 30;
            this.textBox_VasopressorAdministrationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_VasopressorAdministrationDatetime.Enter += new System.EventHandler(this.textBox_VasopressorAdministrationDatetime_Enter);
            this.textBox_VasopressorAdministrationDatetime.Leave += new System.EventHandler(this.textBox_VasopressorAdministrationDatetime_Leave);
            // 
            // textBox_CrystalloidFluidAdministrationDatetime
            // 
            this.textBox_CrystalloidFluidAdministrationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_CrystalloidFluidAdministrationDatetime.Location = new System.Drawing.Point(1010, 236);
            this.textBox_CrystalloidFluidAdministrationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_CrystalloidFluidAdministrationDatetime.Name = "textBox_CrystalloidFluidAdministrationDatetime";
            this.textBox_CrystalloidFluidAdministrationDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_CrystalloidFluidAdministrationDatetime.TabIndex = 23;
            this.textBox_CrystalloidFluidAdministrationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_CrystalloidFluidAdministrationDatetime.Enter += new System.EventHandler(this.textBox_CrystalloidFluidAdministrationDatetime_Enter);
            this.textBox_CrystalloidFluidAdministrationDatetime.Leave += new System.EventHandler(this.textBox_CrystalloidFluidAdministrationDatetime_Leave);
            // 
            // textbox_RepeatLactateLevelCollectionDatetime
            // 
            this.textbox_RepeatLactateLevelCollectionDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textbox_RepeatLactateLevelCollectionDatetime.Location = new System.Drawing.Point(1010, 107);
            this.textbox_RepeatLactateLevelCollectionDatetime.Mask = "00/00/0000 90:00";
            this.textbox_RepeatLactateLevelCollectionDatetime.Name = "textbox_RepeatLactateLevelCollectionDatetime";
            this.textbox_RepeatLactateLevelCollectionDatetime.Size = new System.Drawing.Size(100, 20);
            this.textbox_RepeatLactateLevelCollectionDatetime.TabIndex = 13;
            this.textbox_RepeatLactateLevelCollectionDatetime.ValidatingType = typeof(System.DateTime);
            this.textbox_RepeatLactateLevelCollectionDatetime.Enter += new System.EventHandler(this.textbox_RepeatLactateLevelCollectionDatetime_Enter);
            this.textbox_RepeatLactateLevelCollectionDatetime.Leave += new System.EventHandler(this.textbox_RepeatLactateLevelCollectionDatetime_Leave);
            // 
            // textBox_InitialLactateLevelCollectionDatetime
            // 
            this.textBox_InitialLactateLevelCollectionDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_InitialLactateLevelCollectionDatetime.Location = new System.Drawing.Point(203, 109);
            this.textBox_InitialLactateLevelCollectionDatetime.Mask = "00/00/0000 90:00";
            this.textBox_InitialLactateLevelCollectionDatetime.Name = "textBox_InitialLactateLevelCollectionDatetime";
            this.textBox_InitialLactateLevelCollectionDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_InitialLactateLevelCollectionDatetime.TabIndex = 9;
            this.textBox_InitialLactateLevelCollectionDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_InitialLactateLevelCollectionDatetime.Enter += new System.EventHandler(this.textBox_InitialLactateLevelCollectionDatetime_Enter);
            this.textBox_InitialLactateLevelCollectionDatetime.Leave += new System.EventHandler(this.textBox_InitialLactateLevelCollectionDatetime_Leave);
            // 
            // textBox_LeftEDDatetime
            // 
            this.textBox_LeftEDDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_LeftEDDatetime.Location = new System.Drawing.Point(879, 44);
            this.textBox_LeftEDDatetime.Mask = "00/00/0000 90:00";
            this.textBox_LeftEDDatetime.Name = "textBox_LeftEDDatetime";
            this.textBox_LeftEDDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_LeftEDDatetime.TabIndex = 6;
            this.textBox_LeftEDDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_LeftEDDatetime.Enter += new System.EventHandler(this.textBox_LeftEDDatetime_Enter);
            this.textBox_LeftEDDatetime.Leave += new System.EventHandler(this.textBox_LeftEDDatetime_Leave);
            // 
            // textBox_septicShockPresentationDatetime
            // 
            this.textBox_septicShockPresentationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_septicShockPresentationDatetime.Location = new System.Drawing.Point(756, 44);
            this.textBox_septicShockPresentationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_septicShockPresentationDatetime.Name = "textBox_septicShockPresentationDatetime";
            this.textBox_septicShockPresentationDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_septicShockPresentationDatetime.TabIndex = 5;
            this.textBox_septicShockPresentationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_septicShockPresentationDatetime.Enter += new System.EventHandler(this.textBox_septicShockPresentationDatetime_Enter);
            this.textBox_septicShockPresentationDatetime.Leave += new System.EventHandler(this.textBox_septicShockPresentationDatetime_Leave);
            // 
            // textBox_SevereSepsisPresentationDatetime
            // 
            this.textBox_SevereSepsisPresentationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_SevereSepsisPresentationDatetime.Location = new System.Drawing.Point(567, 43);
            this.textBox_SevereSepsisPresentationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_SevereSepsisPresentationDatetime.Name = "textBox_SevereSepsisPresentationDatetime";
            this.textBox_SevereSepsisPresentationDatetime.Size = new System.Drawing.Size(93, 20);
            this.textBox_SevereSepsisPresentationDatetime.TabIndex = 3;
            this.textBox_SevereSepsisPresentationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_SevereSepsisPresentationDatetime.Enter += new System.EventHandler(this.textBox_SevereSepsisPresentationDatetime_Enter);
            this.textBox_SevereSepsisPresentationDatetime.Leave += new System.EventHandler(this.textBox_SevereSepsisPresentationDatetime_Leave);
            // 
            // textbox_TriageDatetime
            // 
            this.textbox_TriageDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textbox_TriageDatetime.Location = new System.Drawing.Point(136, 43);
            this.textbox_TriageDatetime.Mask = "00/00/0000 90:00";
            this.textbox_TriageDatetime.Name = "textbox_TriageDatetime";
            this.textbox_TriageDatetime.Size = new System.Drawing.Size(100, 20);
            this.textbox_TriageDatetime.TabIndex = 1;
            this.textbox_TriageDatetime.ValidatingType = typeof(System.DateTime);
            this.textbox_TriageDatetime.Enter += new System.EventHandler(this.textbox_TriageDatetime_Enter);
            this.textbox_TriageDatetime.Leave += new System.EventHandler(this.textbox_TriageDatetime_Leave);
            // 
            // textBox_EarliestDatetime
            // 
            this.textBox_EarliestDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_EarliestDatetime.Location = new System.Drawing.Point(29, 43);
            this.textBox_EarliestDatetime.Mask = "00/00/0000 90:00";
            this.textBox_EarliestDatetime.Name = "textBox_EarliestDatetime";
            this.textBox_EarliestDatetime.Size = new System.Drawing.Size(95, 20);
            this.textBox_EarliestDatetime.TabIndex = 0;
            this.textBox_EarliestDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_EarliestDatetime.Enter += new System.EventHandler(this.textBox_EarliestDatetime_Enter);
            this.textBox_EarliestDatetime.Leave += new System.EventHandler(this.textBox_EarliestDatetime_Leave);
            // 
            // comboBox_SkinExamination
            // 
            this.comboBox_SkinExamination.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_SkinExamination.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_SkinExamination.FormattingEnabled = true;
            this.comboBox_SkinExamination.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_SkinExamination.Location = new System.Drawing.Point(29, 435);
            this.comboBox_SkinExamination.Name = "comboBox_SkinExamination";
            this.comboBox_SkinExamination.Size = new System.Drawing.Size(137, 21);
            this.comboBox_SkinExamination.TabIndex = 39;
            this.comboBox_SkinExamination.SelectedIndexChanged += new System.EventHandler(this.comboBox_SkinExamination_SelectedIndexChanged);
            this.comboBox_SkinExamination.Leave += new System.EventHandler(this.comboBox_SkinExamination_Leave);
            // 
            // comboBox_CentralVenousOxygenMeasurement
            // 
            this.comboBox_CentralVenousOxygenMeasurement.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_CentralVenousOxygenMeasurement.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_CentralVenousOxygenMeasurement.FormattingEnabled = true;
            this.comboBox_CentralVenousOxygenMeasurement.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_CentralVenousOxygenMeasurement.Location = new System.Drawing.Point(636, 435);
            this.comboBox_CentralVenousOxygenMeasurement.Name = "comboBox_CentralVenousOxygenMeasurement";
            this.comboBox_CentralVenousOxygenMeasurement.Size = new System.Drawing.Size(100, 21);
            this.comboBox_CentralVenousOxygenMeasurement.TabIndex = 41;
            this.comboBox_CentralVenousOxygenMeasurement.SelectedIndexChanged += new System.EventHandler(this.comboBox_CentralVenousOxygenMeasurement_SelectedIndexChanged);
            this.comboBox_CentralVenousOxygenMeasurement.Leave += new System.EventHandler(this.comboBox_CentralVenousOxygenMeasurement_Leave);
            // 
            // comboBox_FluidChallengePerformed
            // 
            this.comboBox_FluidChallengePerformed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_FluidChallengePerformed.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_FluidChallengePerformed.FormattingEnabled = true;
            this.comboBox_FluidChallengePerformed.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_FluidChallengePerformed.Location = new System.Drawing.Point(636, 479);
            this.comboBox_FluidChallengePerformed.Name = "comboBox_FluidChallengePerformed";
            this.comboBox_FluidChallengePerformed.Size = new System.Drawing.Size(100, 21);
            this.comboBox_FluidChallengePerformed.TabIndex = 45;
            this.comboBox_FluidChallengePerformed.SelectedIndexChanged += new System.EventHandler(this.comboBox_FluidChallengePerformed_SelectedIndexChanged);
            this.comboBox_FluidChallengePerformed.Leave += new System.EventHandler(this.comboBox_FluidChallengePerformed_Leave);
            // 
            // comboBox_CentralVenousPressureMeasurement
            // 
            this.comboBox_CentralVenousPressureMeasurement.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_CentralVenousPressureMeasurement.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_CentralVenousPressureMeasurement.FormattingEnabled = true;
            this.comboBox_CentralVenousPressureMeasurement.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_CentralVenousPressureMeasurement.Location = new System.Drawing.Point(29, 478);
            this.comboBox_CentralVenousPressureMeasurement.Name = "comboBox_CentralVenousPressureMeasurement";
            this.comboBox_CentralVenousPressureMeasurement.Size = new System.Drawing.Size(137, 21);
            this.comboBox_CentralVenousPressureMeasurement.TabIndex = 43;
            this.comboBox_CentralVenousPressureMeasurement.SelectedIndexChanged += new System.EventHandler(this.comboBox_CentralVenousPressureMeasurement_SelectedIndexChanged);
            this.comboBox_CentralVenousPressureMeasurement.Leave += new System.EventHandler(this.comboBox_CentralVenousPressureMeasurement_Leave);
            // 
            // comboBox_VitalSignsReview
            // 
            this.comboBox_VitalSignsReview.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_VitalSignsReview.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_VitalSignsReview.FormattingEnabled = true;
            this.comboBox_VitalSignsReview.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_VitalSignsReview.Location = new System.Drawing.Point(31, 528);
            this.comboBox_VitalSignsReview.Name = "comboBox_VitalSignsReview";
            this.comboBox_VitalSignsReview.Size = new System.Drawing.Size(137, 21);
            this.comboBox_VitalSignsReview.TabIndex = 47;
            this.comboBox_VitalSignsReview.SelectedIndexChanged += new System.EventHandler(this.comboBox_VitalSignsReview_SelectedIndexChanged);
            this.comboBox_VitalSignsReview.Leave += new System.EventHandler(this.comboBox_VitalSignsReview_Leave);
            // 
            // comboBox_PassiveLegRaiseExamination
            // 
            this.comboBox_PassiveLegRaiseExamination.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_PassiveLegRaiseExamination.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_PassiveLegRaiseExamination.FormattingEnabled = true;
            this.comboBox_PassiveLegRaiseExamination.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_PassiveLegRaiseExamination.Location = new System.Drawing.Point(28, 389);
            this.comboBox_PassiveLegRaiseExamination.Name = "comboBox_PassiveLegRaiseExamination";
            this.comboBox_PassiveLegRaiseExamination.Size = new System.Drawing.Size(139, 21);
            this.comboBox_PassiveLegRaiseExamination.TabIndex = 35;
            this.comboBox_PassiveLegRaiseExamination.SelectedIndexChanged += new System.EventHandler(this.comboBox_PassiveLegRaiseExamination_SelectedIndexChanged);
            this.comboBox_PassiveLegRaiseExamination.Leave += new System.EventHandler(this.comboBox_PassiveLegRaiseExamination_Leave);
            // 
            // comboBox_PeripheralPulseEvaluation
            // 
            this.comboBox_PeripheralPulseEvaluation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_PeripheralPulseEvaluation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_PeripheralPulseEvaluation.FormattingEnabled = true;
            this.comboBox_PeripheralPulseEvaluation.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_PeripheralPulseEvaluation.Location = new System.Drawing.Point(636, 391);
            this.comboBox_PeripheralPulseEvaluation.Name = "comboBox_PeripheralPulseEvaluation";
            this.comboBox_PeripheralPulseEvaluation.Size = new System.Drawing.Size(100, 21);
            this.comboBox_PeripheralPulseEvaluation.TabIndex = 37;
            this.comboBox_PeripheralPulseEvaluation.SelectedIndexChanged += new System.EventHandler(this.comboBox_PeripheralPulseEvaluation_SelectedIndexChanged);
            this.comboBox_PeripheralPulseEvaluation.Leave += new System.EventHandler(this.comboBox_PeripheralPulseEvaluation_Leave);
            // 
            // comboBox_BedsideCardiovascularUltrasound
            // 
            this.comboBox_BedsideCardiovascularUltrasound.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_BedsideCardiovascularUltrasound.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_BedsideCardiovascularUltrasound.FormattingEnabled = true;
            this.comboBox_BedsideCardiovascularUltrasound.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_BedsideCardiovascularUltrasound.Location = new System.Drawing.Point(29, 301);
            this.comboBox_BedsideCardiovascularUltrasound.Name = "comboBox_BedsideCardiovascularUltrasound";
            this.comboBox_BedsideCardiovascularUltrasound.Size = new System.Drawing.Size(138, 21);
            this.comboBox_BedsideCardiovascularUltrasound.TabIndex = 27;
            this.comboBox_BedsideCardiovascularUltrasound.SelectedIndexChanged += new System.EventHandler(this.comboBox_BedsideCardiovascularUltrasound_SelectedIndexChanged);
            this.comboBox_BedsideCardiovascularUltrasound.Leave += new System.EventHandler(this.comboBox_BedsideCardiovascularUltrasound_Leave);
            // 
            // comboBox_CapillaryRefillExamination
            // 
            this.comboBox_CapillaryRefillExamination.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_CapillaryRefillExamination.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_CapillaryRefillExamination.FormattingEnabled = true;
            this.comboBox_CapillaryRefillExamination.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_CapillaryRefillExamination.Location = new System.Drawing.Point(636, 345);
            this.comboBox_CapillaryRefillExamination.Name = "comboBox_CapillaryRefillExamination";
            this.comboBox_CapillaryRefillExamination.Size = new System.Drawing.Size(100, 21);
            this.comboBox_CapillaryRefillExamination.TabIndex = 33;
            this.comboBox_CapillaryRefillExamination.SelectedIndexChanged += new System.EventHandler(this.comboBox_CapillaryRefillExamination_SelectedIndexChanged);
            this.comboBox_CapillaryRefillExamination.Leave += new System.EventHandler(this.comboBox_CapillaryRefillExamination_Leave);
            // 
            // comboBox_CardiopulmonaryEvaluation
            // 
            this.comboBox_CardiopulmonaryEvaluation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_CardiopulmonaryEvaluation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_CardiopulmonaryEvaluation.FormattingEnabled = true;
            this.comboBox_CardiopulmonaryEvaluation.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_CardiopulmonaryEvaluation.Location = new System.Drawing.Point(29, 345);
            this.comboBox_CardiopulmonaryEvaluation.Name = "comboBox_CardiopulmonaryEvaluation";
            this.comboBox_CardiopulmonaryEvaluation.Size = new System.Drawing.Size(137, 21);
            this.comboBox_CardiopulmonaryEvaluation.TabIndex = 31;
            this.comboBox_CardiopulmonaryEvaluation.SelectedIndexChanged += new System.EventHandler(this.comboBox_CardiopulmonaryEvaluation_SelectedIndexChanged);
            this.comboBox_CardiopulmonaryEvaluation.Leave += new System.EventHandler(this.comboBox_CardiopulmonaryEvaluation_Leave);
            // 
            // comboBox_RepeatLactateLevelCollection
            // 
            this.comboBox_RepeatLactateLevelCollection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_RepeatLactateLevelCollection.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_RepeatLactateLevelCollection.FormattingEnabled = true;
            this.comboBox_RepeatLactateLevelCollection.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_RepeatLactateLevelCollection.Location = new System.Drawing.Point(849, 107);
            this.comboBox_RepeatLactateLevelCollection.Name = "comboBox_RepeatLactateLevelCollection";
            this.comboBox_RepeatLactateLevelCollection.Size = new System.Drawing.Size(138, 21);
            this.comboBox_RepeatLactateLevelCollection.TabIndex = 12;
            this.comboBox_RepeatLactateLevelCollection.SelectedIndexChanged += new System.EventHandler(this.comboBox_RepeatLactateLevelCollection_SelectedIndexChanged);
            this.comboBox_RepeatLactateLevelCollection.Leave += new System.EventHandler(this.comboBox_RepeatLactateLevelCollection_Leave);
            // 
            // comboBox_PersistentHypotension
            // 
            this.comboBox_PersistentHypotension.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_PersistentHypotension.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_PersistentHypotension.FormattingEnabled = true;
            this.comboBox_PersistentHypotension.Items.AddRange(new object[] {
            "Select",
            "(Yes) Crystalloid fluids were administered at a volume of 30 mL/kg and persistent" +
                " hypotension or new onset of hypotension was present within one hour of conclusi" +
                "on of fluid administration.",
            "(No) Persistent hypotension or new onset of hypotension was not present within on" +
                "e hour of the conclusion of crystalloid fluid administration at a volume of 30 m" +
                "L/kg.",
            resources.GetString("comboBox_PersistentHypotension.Items"),
            "(Not applicable) Crystalloid fluids were administered but at a volume less than 3" +
                "0 mL/kg."});
            this.comboBox_PersistentHypotension.Location = new System.Drawing.Point(203, 257);
            this.comboBox_PersistentHypotension.Name = "comboBox_PersistentHypotension";
            this.comboBox_PersistentHypotension.Size = new System.Drawing.Size(310, 21);
            this.comboBox_PersistentHypotension.TabIndex = 25;
            this.comboBox_PersistentHypotension.Leave += new System.EventHandler(this.comboBox_PersistentHypotension_Leave);
            // 
            // comboBox_VasopressorAdministration
            // 
            this.comboBox_VasopressorAdministration.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_VasopressorAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_VasopressorAdministration.FormattingEnabled = true;
            this.comboBox_VasopressorAdministration.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_VasopressorAdministration.Location = new System.Drawing.Point(636, 301);
            this.comboBox_VasopressorAdministration.Name = "comboBox_VasopressorAdministration";
            this.comboBox_VasopressorAdministration.Size = new System.Drawing.Size(100, 21);
            this.comboBox_VasopressorAdministration.TabIndex = 29;
            this.comboBox_VasopressorAdministration.SelectedIndexChanged += new System.EventHandler(this.comboBox_VasopressorAdministration_SelectedIndexChanged);
            this.comboBox_VasopressorAdministration.Leave += new System.EventHandler(this.comboBox_VasopressorAdministration_Leave);
            // 
            // comboBox_InitialHypotension
            // 
            this.comboBox_InitialHypotension.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_InitialHypotension.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_InitialHypotension.FormattingEnabled = true;
            this.comboBox_InitialHypotension.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_InitialHypotension.Location = new System.Drawing.Point(29, 257);
            this.comboBox_InitialHypotension.Name = "comboBox_InitialHypotension";
            this.comboBox_InitialHypotension.Size = new System.Drawing.Size(139, 21);
            this.comboBox_InitialHypotension.TabIndex = 24;
            this.comboBox_InitialHypotension.Leave += new System.EventHandler(this.comboBox_InitialHypotension_Leave);
            // 
            // comboBox_PediatricCrystalloidFluidAdministration
            // 
            this.comboBox_PediatricCrystalloidFluidAdministration.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_PediatricCrystalloidFluidAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_PediatricCrystalloidFluidAdministration.FormattingEnabled = true;
            this.comboBox_PediatricCrystalloidFluidAdministration.Items.AddRange(new object[] {
            "Select",
            "At least 20ml/kg isotonic saline or colloid were not given",
            "At least 20ml/kg isotonic saline or colloid were given",
            "Volume of fluids given is unknown"});
            this.comboBox_PediatricCrystalloidFluidAdministration.Location = new System.Drawing.Point(636, 257);
            this.comboBox_PediatricCrystalloidFluidAdministration.Name = "comboBox_PediatricCrystalloidFluidAdministration";
            this.comboBox_PediatricCrystalloidFluidAdministration.Size = new System.Drawing.Size(351, 21);
            this.comboBox_PediatricCrystalloidFluidAdministration.TabIndex = 26;
            this.comboBox_PediatricCrystalloidFluidAdministration.SelectedIndexChanged += new System.EventHandler(this.comboBox_PediatricCrystalloidFluidAdministration_SelectedIndexChanged);
            this.comboBox_PediatricCrystalloidFluidAdministration.Leave += new System.EventHandler(this.comboBox_PediatricCrystalloidFluidAdministration_Leave);
            // 
            // comboBox_BloodCultureCollection
            // 
            this.comboBox_BloodCultureCollection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_BloodCultureCollection.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_BloodCultureCollection.FormattingEnabled = true;
            this.comboBox_BloodCultureCollection.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_BloodCultureCollection.Location = new System.Drawing.Point(29, 162);
            this.comboBox_BloodCultureCollection.Name = "comboBox_BloodCultureCollection";
            this.comboBox_BloodCultureCollection.Size = new System.Drawing.Size(138, 21);
            this.comboBox_BloodCultureCollection.TabIndex = 14;
            this.comboBox_BloodCultureCollection.SelectedIndexChanged += new System.EventHandler(this.comboBox_BloodCultureCollection_SelectedIndexChanged);
            this.comboBox_BloodCultureCollection.Leave += new System.EventHandler(this.comboBox_BloodCultureCollection_Leave);
            // 
            // comboBox_BloodCultureCollectionAcceptableDelay
            // 
            this.comboBox_BloodCultureCollectionAcceptableDelay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_BloodCultureCollectionAcceptableDelay.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_BloodCultureCollectionAcceptableDelay.FormattingEnabled = true;
            this.comboBox_BloodCultureCollectionAcceptableDelay.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_BloodCultureCollectionAcceptableDelay.Location = new System.Drawing.Point(203, 162);
            this.comboBox_BloodCultureCollectionAcceptableDelay.Name = "comboBox_BloodCultureCollectionAcceptableDelay";
            this.comboBox_BloodCultureCollectionAcceptableDelay.Size = new System.Drawing.Size(100, 21);
            this.comboBox_BloodCultureCollectionAcceptableDelay.TabIndex = 15;
            this.comboBox_BloodCultureCollectionAcceptableDelay.Leave += new System.EventHandler(this.comboBox_BloodCultureCollectionAcceptableDelay_Leave);
            // 
            // comboBox_AntibioticAdministrationSelection
            // 
            this.comboBox_AntibioticAdministrationSelection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AntibioticAdministrationSelection.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_AntibioticAdministrationSelection.FormattingEnabled = true;
            this.comboBox_AntibioticAdministrationSelection.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_AntibioticAdministrationSelection.Location = new System.Drawing.Point(203, 208);
            this.comboBox_AntibioticAdministrationSelection.Name = "comboBox_AntibioticAdministrationSelection";
            this.comboBox_AntibioticAdministrationSelection.Size = new System.Drawing.Size(100, 21);
            this.comboBox_AntibioticAdministrationSelection.TabIndex = 20;
            this.comboBox_AntibioticAdministrationSelection.Leave += new System.EventHandler(this.comboBox_AntibioticAdministrationSelection_Leave);
            // 
            // comboBox_AdultCrystalloidFluidAdministration
            // 
            this.comboBox_AdultCrystalloidFluidAdministration.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AdultCrystalloidFluidAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_AdultCrystalloidFluidAdministration.FormattingEnabled = true;
            this.comboBox_AdultCrystalloidFluidAdministration.Items.AddRange(new object[] {
            "Select",
            resources.GetString("comboBox_AdultCrystalloidFluidAdministration.Items"),
            resources.GetString("comboBox_AdultCrystalloidFluidAdministration.Items1"),
            resources.GetString("comboBox_AdultCrystalloidFluidAdministration.Items2"),
            "(No) There is documentation the patient has an implanted Ventricular Assist Devic" +
                "e (VAD)."});
            this.comboBox_AdultCrystalloidFluidAdministration.Location = new System.Drawing.Point(636, 208);
            this.comboBox_AdultCrystalloidFluidAdministration.Name = "comboBox_AdultCrystalloidFluidAdministration";
            this.comboBox_AdultCrystalloidFluidAdministration.Size = new System.Drawing.Size(351, 21);
            this.comboBox_AdultCrystalloidFluidAdministration.TabIndex = 22;
            this.comboBox_AdultCrystalloidFluidAdministration.SelectedIndexChanged += new System.EventHandler(this.comboBox_AdultCrystalloidFluidAdministration_SelectedIndexChanged);
            this.comboBox_AdultCrystalloidFluidAdministration.Leave += new System.EventHandler(this.comboBox_AdultCrystalloidFluidAdministration_Leave);
            // 
            // comboBox_InitialLactateLevelUnit
            // 
            this.comboBox_InitialLactateLevelUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_InitialLactateLevelUnit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_InitialLactateLevelUnit.FormattingEnabled = true;
            this.comboBox_InitialLactateLevelUnit.Items.AddRange(new object[] {
            "Select",
            "mg/dL",
            "mmol/L"});
            this.comboBox_InitialLactateLevelUnit.Location = new System.Drawing.Point(636, 108);
            this.comboBox_InitialLactateLevelUnit.Name = "comboBox_InitialLactateLevelUnit";
            this.comboBox_InitialLactateLevelUnit.Size = new System.Drawing.Size(100, 21);
            this.comboBox_InitialLactateLevelUnit.TabIndex = 11;
            this.comboBox_InitialLactateLevelUnit.Leave += new System.EventHandler(this.comboBox_InitialLactateLevelUnit_Leave);
            // 
            // comboBox_BloodCulturePathogen
            // 
            this.comboBox_BloodCulturePathogen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_BloodCulturePathogen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_BloodCulturePathogen.FormattingEnabled = true;
            this.comboBox_BloodCulturePathogen.Items.AddRange(new object[] {
            "Select",
            "No pathogen reported",
            "Gram positive bacteria",
            "Gram negative bacteria",
            "Anaerobic bacteria",
            "Yeast",
            "Mold",
            "Mixed pathogens",
            "Viral"});
            this.comboBox_BloodCulturePathogen.Location = new System.Drawing.Point(849, 162);
            this.comboBox_BloodCulturePathogen.Name = "comboBox_BloodCulturePathogen";
            this.comboBox_BloodCulturePathogen.Size = new System.Drawing.Size(138, 21);
            this.comboBox_BloodCulturePathogen.TabIndex = 18;
            this.comboBox_BloodCulturePathogen.Leave += new System.EventHandler(this.comboBox_BloodCulturePathogen_Leave);
            // 
            // comboBox_AntibioticAdministration
            // 
            this.comboBox_AntibioticAdministration.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AntibioticAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_AntibioticAdministration.FormattingEnabled = true;
            this.comboBox_AntibioticAdministration.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_AntibioticAdministration.Location = new System.Drawing.Point(29, 208);
            this.comboBox_AntibioticAdministration.Name = "comboBox_AntibioticAdministration";
            this.comboBox_AntibioticAdministration.Size = new System.Drawing.Size(138, 21);
            this.comboBox_AntibioticAdministration.TabIndex = 19;
            this.comboBox_AntibioticAdministration.SelectedIndexChanged += new System.EventHandler(this.comboBox_AntibioticAdministration_SelectedIndexChanged);
            this.comboBox_AntibioticAdministration.Leave += new System.EventHandler(this.comboBox_AntibioticAdministration_Leave);
            // 
            // comboBox_SepticShockPresent
            // 
            this.comboBox_SepticShockPresent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_SepticShockPresent.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_SepticShockPresent.FormattingEnabled = true;
            this.comboBox_SepticShockPresent.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_SepticShockPresent.Location = new System.Drawing.Point(677, 43);
            this.comboBox_SepticShockPresent.Name = "comboBox_SepticShockPresent";
            this.comboBox_SepticShockPresent.Size = new System.Drawing.Size(59, 21);
            this.comboBox_SepticShockPresent.TabIndex = 4;
            this.comboBox_SepticShockPresent.SelectedIndexChanged += new System.EventHandler(this.comboBox_SepticShockPresent_SelectedIndexChanged);
            // 
            // comboBox_InitialLactateLevelCollection
            // 
            this.comboBox_InitialLactateLevelCollection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_InitialLactateLevelCollection.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_InitialLactateLevelCollection.FormattingEnabled = true;
            this.comboBox_InitialLactateLevelCollection.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_InitialLactateLevelCollection.Location = new System.Drawing.Point(29, 107);
            this.comboBox_InitialLactateLevelCollection.Name = "comboBox_InitialLactateLevelCollection";
            this.comboBox_InitialLactateLevelCollection.Size = new System.Drawing.Size(138, 21);
            this.comboBox_InitialLactateLevelCollection.TabIndex = 8;
            this.comboBox_InitialLactateLevelCollection.SelectedIndexChanged += new System.EventHandler(this.comboBox_InitialLactateLevelCollection_SelectedIndexChanged);
            this.comboBox_InitialLactateLevelCollection.Leave += new System.EventHandler(this.comboBox_InitialLactateLevelCollection_Leave);
            // 
            // comboBoX_BloodCultureResult
            // 
            this.comboBoX_BloodCultureResult.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoX_BloodCultureResult.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBoX_BloodCultureResult.FormattingEnabled = true;
            this.comboBoX_BloodCultureResult.Items.AddRange(new object[] {
            "Select",
            "Negative blood culture",
            "Positive blood culture"});
            this.comboBoX_BloodCultureResult.Location = new System.Drawing.Point(636, 162);
            this.comboBoX_BloodCultureResult.Name = "comboBoX_BloodCultureResult";
            this.comboBoX_BloodCultureResult.Size = new System.Drawing.Size(100, 21);
            this.comboBoX_BloodCultureResult.TabIndex = 17;
            this.comboBoX_BloodCultureResult.Leave += new System.EventHandler(this.comboBoX_BloodCultureResult_Leave);
            // 
            // comboBox_DestinationafterED
            // 
            this.comboBox_DestinationafterED.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_DestinationafterED.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_DestinationafterED.FormattingEnabled = true;
            this.comboBox_DestinationafterED.Items.AddRange(new object[] {
            "Select",
            "Non-ICU in same hospital",
            "ICU in same hospital",
            "Transfer to another hospital",
            "Discharged from hospital",
            "Patient died in Emergency Department",
            "Patient left against medical advice"});
            this.comboBox_DestinationafterED.Location = new System.Drawing.Point(1004, 43);
            this.comboBox_DestinationafterED.Name = "comboBox_DestinationafterED";
            this.comboBox_DestinationafterED.Size = new System.Drawing.Size(224, 21);
            this.comboBox_DestinationafterED.TabIndex = 7;
            this.comboBox_DestinationafterED.SelectedIndexChanged += new System.EventHandler(this.comboBox_DestinationafterED_SelectedIndexChanged);
            this.comboBox_DestinationafterED.Leave += new System.EventHandler(this.comboBox_DestinationafterED_Leave);
            // 
            // comboBox_SevereSepsisPresent
            // 
            this.comboBox_SevereSepsisPresent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_SevereSepsisPresent.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_SevereSepsisPresent.FormattingEnabled = true;
            this.comboBox_SevereSepsisPresent.Items.AddRange(new object[] {
            "",
            "Severe Sepsis was present.",
            "Severe Sepsis was not present, or Unable to Determine."});
            this.comboBox_SevereSepsisPresent.Location = new System.Drawing.Point(257, 43);
            this.comboBox_SevereSepsisPresent.Name = "comboBox_SevereSepsisPresent";
            this.comboBox_SevereSepsisPresent.Size = new System.Drawing.Size(291, 21);
            this.comboBox_SevereSepsisPresent.TabIndex = 2;
            this.comboBox_SevereSepsisPresent.SelectedIndexChanged += new System.EventHandler(this.comboBox_SevereSepsisPresent_SelectedIndexChanged);
            // 
            // label_CentralVenousOxygenMeasurement
            // 
            this.label_CentralVenousOxygenMeasurement.AutoSize = true;
            this.label_CentralVenousOxygenMeasurement.Location = new System.Drawing.Point(633, 419);
            this.label_CentralVenousOxygenMeasurement.Name = "label_CentralVenousOxygenMeasurement";
            this.label_CentralVenousOxygenMeasurement.Size = new System.Drawing.Size(188, 13);
            this.label_CentralVenousOxygenMeasurement.TabIndex = 52;
            this.label_CentralVenousOxygenMeasurement.Text = "Central Venous Oxygen Measurement:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(633, 463);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(133, 13);
            this.label24.TabIndex = 51;
            this.label24.Text = "Fluid Challenge Performed:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(26, 512);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(98, 13);
            this.label25.TabIndex = 50;
            this.label25.Text = "Vital Signs Review:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(846, 463);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(187, 13);
            this.label26.TabIndex = 49;
            this.label26.Text = "Fluid Challenge Performed Date/Time:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(200, 329);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(195, 13);
            this.label27.TabIndex = 48;
            this.label27.Text = "Cardiopulmonary Evaluation Date/Time:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(846, 419);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(242, 13);
            this.label28.TabIndex = 47;
            this.label28.Text = "Central Venous Oxygen Measurement Date/Time:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(846, 375);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(193, 13);
            this.label30.TabIndex = 45;
            this.label30.Text = "Peripheral Pulse Evaluation Date/Time:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(633, 329);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(135, 13);
            this.label12.TabIndex = 44;
            this.label12.Text = "Capillary Refill Examination:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(26, 463);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(135, 13);
            this.label13.TabIndex = 43;
            this.label13.Text = "CV Pressure Measurement:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(200, 463);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(189, 13);
            this.label14.TabIndex = 42;
            this.label14.Text = "CV Pressure Measurement Date/Time:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(200, 419);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(145, 13);
            this.label15.TabIndex = 41;
            this.label15.Text = "Skin Examination Date/Time:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(633, 375);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(139, 13);
            this.label16.TabIndex = 40;
            this.label16.Text = "Peripheral Pulse Evaluation:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(25, 329);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(141, 13);
            this.label17.TabIndex = 39;
            this.label17.Text = "Cardiopulmonary Evaluation:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(25, 419);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(91, 13);
            this.label18.TabIndex = 38;
            this.label18.Text = "Skin Examination:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(200, 375);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(212, 13);
            this.label19.TabIndex = 37;
            this.label19.Text = "Passive Leg Raise Examination Date/Time:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(200, 512);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(152, 13);
            this.label20.TabIndex = 36;
            this.label20.Text = "Vital Signs Review Date/Time:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(26, 375);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(158, 13);
            this.label21.TabIndex = 35;
            this.label21.Text = "Passive Leg Raise Examination:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(846, 329);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(189, 13);
            this.label22.TabIndex = 34;
            this.label22.Text = "Capillary Refill Examination Date/Time:";
            // 
            // Label_AntibioticAdministrationSelection
            // 
            this.Label_AntibioticAdministrationSelection.AutoSize = true;
            this.Label_AntibioticAdministrationSelection.Location = new System.Drawing.Point(200, 192);
            this.Label_AntibioticAdministrationSelection.Name = "Label_AntibioticAdministrationSelection";
            this.Label_AntibioticAdministrationSelection.Size = new System.Drawing.Size(168, 13);
            this.Label_AntibioticAdministrationSelection.TabIndex = 33;
            this.Label_AntibioticAdministrationSelection.Text = "Antibiotic Administration Selection:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(26, 285);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(175, 13);
            this.label10.TabIndex = 32;
            this.label10.Text = "Bedside Cardiovascular Ultrasound:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(200, 285);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(189, 13);
            this.label9.TabIndex = 31;
            this.label9.Text = "Bedside Cardio Ultrasound Date/Time:";
            // 
            // label_VasopressorAdministration
            // 
            this.label_VasopressorAdministration.AutoSize = true;
            this.label_VasopressorAdministration.Location = new System.Drawing.Point(633, 285);
            this.label_VasopressorAdministration.Name = "label_VasopressorAdministration";
            this.label_VasopressorAdministration.Size = new System.Drawing.Size(136, 13);
            this.label_VasopressorAdministration.TabIndex = 30;
            this.label_VasopressorAdministration.Text = "Vasopressor Administration:";
            // 
            // label_VasopressorAdministrationDateTime
            // 
            this.label_VasopressorAdministrationDateTime.AutoSize = true;
            this.label_VasopressorAdministrationDateTime.Location = new System.Drawing.Point(846, 285);
            this.label_VasopressorAdministrationDateTime.Name = "label_VasopressorAdministrationDateTime";
            this.label_VasopressorAdministrationDateTime.Size = new System.Drawing.Size(190, 13);
            this.label_VasopressorAdministrationDateTime.TabIndex = 29;
            this.label_VasopressorAdministrationDateTime.Text = "Vasopressor Administration Date/Time:";
            // 
            // Label_InitialHypotension
            // 
            this.Label_InitialHypotension.AutoSize = true;
            this.Label_InitialHypotension.Location = new System.Drawing.Point(26, 238);
            this.Label_InitialHypotension.Name = "Label_InitialHypotension";
            this.Label_InitialHypotension.Size = new System.Drawing.Size(96, 13);
            this.Label_InitialHypotension.TabIndex = 28;
            this.Label_InitialHypotension.Text = "Initial Hypotension:";
            // 
            // label_PersistentHypotension
            // 
            this.label_PersistentHypotension.AutoSize = true;
            this.label_PersistentHypotension.Location = new System.Drawing.Point(200, 238);
            this.label_PersistentHypotension.Name = "label_PersistentHypotension";
            this.label_PersistentHypotension.Size = new System.Drawing.Size(118, 13);
            this.label_PersistentHypotension.TabIndex = 27;
            this.label_PersistentHypotension.Text = "Persistent Hypotension:";
            // 
            // Label_CrystalloidFluidAdministrationDatetime
            // 
            this.Label_CrystalloidFluidAdministrationDatetime.AutoSize = true;
            this.Label_CrystalloidFluidAdministrationDatetime.Location = new System.Drawing.Point(1007, 220);
            this.Label_CrystalloidFluidAdministrationDatetime.Name = "Label_CrystalloidFluidAdministrationDatetime";
            this.Label_CrystalloidFluidAdministrationDatetime.Size = new System.Drawing.Size(204, 13);
            this.Label_CrystalloidFluidAdministrationDatetime.TabIndex = 26;
            this.Label_CrystalloidFluidAdministrationDatetime.Text = "Crystalloid Fluid Administration Date/Time:";
            // 
            // Label_AdultCrystalloidFluidAdministration
            // 
            this.Label_AdultCrystalloidFluidAdministration.AutoSize = true;
            this.Label_AdultCrystalloidFluidAdministration.Location = new System.Drawing.Point(633, 192);
            this.Label_AdultCrystalloidFluidAdministration.Name = "Label_AdultCrystalloidFluidAdministration";
            this.Label_AdultCrystalloidFluidAdministration.Size = new System.Drawing.Size(177, 13);
            this.Label_AdultCrystalloidFluidAdministration.TabIndex = 25;
            this.Label_AdultCrystalloidFluidAdministration.Text = "Adult Crystalloid Fluid Administration:";
            // 
            // PediatricCrystalloidFluidAdministration
            // 
            this.PediatricCrystalloidFluidAdministration.AutoSize = true;
            this.PediatricCrystalloidFluidAdministration.Location = new System.Drawing.Point(633, 242);
            this.PediatricCrystalloidFluidAdministration.Name = "PediatricCrystalloidFluidAdministration";
            this.PediatricCrystalloidFluidAdministration.Size = new System.Drawing.Size(194, 13);
            this.PediatricCrystalloidFluidAdministration.TabIndex = 24;
            this.PediatricCrystalloidFluidAdministration.Text = "Pediatric Crystalloid Fluid Administration:";
            // 
            // Label_AntibioticAdministrationDatetime
            // 
            this.Label_AntibioticAdministrationDatetime.AutoSize = true;
            this.Label_AntibioticAdministrationDatetime.Location = new System.Drawing.Point(414, 192);
            this.Label_AntibioticAdministrationDatetime.Name = "Label_AntibioticAdministrationDatetime";
            this.Label_AntibioticAdministrationDatetime.Size = new System.Drawing.Size(175, 13);
            this.Label_AntibioticAdministrationDatetime.TabIndex = 23;
            this.Label_AntibioticAdministrationDatetime.Text = "Antibiotic Administration Date/Time:";
            // 
            // Label_BloodCulturePathogen
            // 
            this.Label_BloodCulturePathogen.AutoSize = true;
            this.Label_BloodCulturePathogen.Location = new System.Drawing.Point(847, 144);
            this.Label_BloodCulturePathogen.Name = "Label_BloodCulturePathogen";
            this.Label_BloodCulturePathogen.Size = new System.Drawing.Size(122, 13);
            this.Label_BloodCulturePathogen.TabIndex = 22;
            this.Label_BloodCulturePathogen.Text = "Blood Culture Pathogen:";
            // 
            // Label_BloodCultureCollection
            // 
            this.Label_BloodCultureCollection.AutoSize = true;
            this.Label_BloodCultureCollection.Location = new System.Drawing.Point(25, 144);
            this.Label_BloodCultureCollection.Name = "Label_BloodCultureCollection";
            this.Label_BloodCultureCollection.Size = new System.Drawing.Size(122, 13);
            this.Label_BloodCultureCollection.TabIndex = 21;
            this.Label_BloodCultureCollection.Text = "Blood Culture Collection:";
            // 
            // Label_LeftEDDatetime
            // 
            this.Label_LeftEDDatetime.AutoSize = true;
            this.Label_LeftEDDatetime.Location = new System.Drawing.Point(860, 17);
            this.Label_LeftEDDatetime.Name = "Label_LeftEDDatetime";
            this.Label_LeftEDDatetime.Size = new System.Drawing.Size(97, 13);
            this.Label_LeftEDDatetime.TabIndex = 20;
            this.Label_LeftEDDatetime.Text = "LeftED Date/Time:";
            // 
            // Label_InitialLactateLevel
            // 
            this.Label_InitialLactateLevel.AutoSize = true;
            this.Label_InitialLactateLevel.Location = new System.Drawing.Point(414, 92);
            this.Label_InitialLactateLevel.Name = "Label_InitialLactateLevel";
            this.Label_InitialLactateLevel.Size = new System.Drawing.Size(102, 13);
            this.Label_InitialLactateLevel.TabIndex = 19;
            this.Label_InitialLactateLevel.Text = "Initial Lactate Level:";
            // 
            // Label_SevereSepsisPresent
            // 
            this.Label_SevereSepsisPresent.AutoSize = true;
            this.Label_SevereSepsisPresent.Location = new System.Drawing.Point(254, 17);
            this.Label_SevereSepsisPresent.Name = "Label_SevereSepsisPresent";
            this.Label_SevereSepsisPresent.Size = new System.Drawing.Size(117, 13);
            this.Label_SevereSepsisPresent.TabIndex = 18;
            this.Label_SevereSepsisPresent.Text = "Severe Sepsis Present:";
            // 
            // Label_BloodCultureCollectionAcceptableDelay
            // 
            this.Label_BloodCultureCollectionAcceptableDelay.AutoSize = true;
            this.Label_BloodCultureCollectionAcceptableDelay.Location = new System.Drawing.Point(200, 144);
            this.Label_BloodCultureCollectionAcceptableDelay.Name = "Label_BloodCultureCollectionAcceptableDelay";
            this.Label_BloodCultureCollectionAcceptableDelay.Size = new System.Drawing.Size(209, 13);
            this.Label_BloodCultureCollectionAcceptableDelay.TabIndex = 17;
            this.Label_BloodCultureCollectionAcceptableDelay.Text = "Blood Culture Collection Acceptable Delay:";
            // 
            // Label_SevereSepsisPresentationDatetime
            // 
            this.Label_SevereSepsisPresentationDatetime.Location = new System.Drawing.Point(542, 0);
            this.Label_SevereSepsisPresentationDatetime.Name = "Label_SevereSepsisPresentationDatetime";
            this.Label_SevereSepsisPresentationDatetime.Size = new System.Drawing.Size(118, 50);
            this.Label_SevereSepsisPresentationDatetime.TabIndex = 16;
            this.Label_SevereSepsisPresentationDatetime.Text = "Severe Sepsis Presentation Date/Time:";
            this.Label_SevereSepsisPresentationDatetime.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Label_InitialLactateLevelUnit
            // 
            this.Label_InitialLactateLevelUnit.AutoSize = true;
            this.Label_InitialLactateLevelUnit.Location = new System.Drawing.Point(633, 91);
            this.Label_InitialLactateLevelUnit.Name = "Label_InitialLactateLevelUnit";
            this.Label_InitialLactateLevelUnit.Size = new System.Drawing.Size(124, 13);
            this.Label_InitialLactateLevelUnit.TabIndex = 15;
            this.Label_InitialLactateLevelUnit.Text = "Initial Lactate Level Unit:";
            // 
            // Label_AntibioticAdministration
            // 
            this.Label_AntibioticAdministration.AutoSize = true;
            this.Label_AntibioticAdministration.Location = new System.Drawing.Point(26, 192);
            this.Label_AntibioticAdministration.Name = "Label_AntibioticAdministration";
            this.Label_AntibioticAdministration.Size = new System.Drawing.Size(121, 13);
            this.Label_AntibioticAdministration.TabIndex = 14;
            this.Label_AntibioticAdministration.Text = "Antibiotic Administration:";
            // 
            // Label_DestinationafterED
            // 
            this.Label_DestinationafterED.AutoSize = true;
            this.Label_DestinationafterED.Location = new System.Drawing.Point(997, 16);
            this.Label_DestinationafterED.Name = "Label_DestinationafterED";
            this.Label_DestinationafterED.Size = new System.Drawing.Size(105, 13);
            this.Label_DestinationafterED.TabIndex = 13;
            this.Label_DestinationafterED.Text = "Destination after ED:";
            // 
            // Label_BloodCultureResult
            // 
            this.Label_BloodCultureResult.AutoSize = true;
            this.Label_BloodCultureResult.Location = new System.Drawing.Point(633, 144);
            this.Label_BloodCultureResult.Name = "Label_BloodCultureResult";
            this.Label_BloodCultureResult.Size = new System.Drawing.Size(106, 13);
            this.Label_BloodCultureResult.TabIndex = 12;
            this.Label_BloodCultureResult.Text = "Blood Culture Result:";
            // 
            // Label_RepeatLactateLevelCollectionDatetime
            // 
            this.Label_RepeatLactateLevelCollectionDatetime.AutoSize = true;
            this.Label_RepeatLactateLevelCollectionDatetime.Location = new System.Drawing.Point(1007, 90);
            this.Label_RepeatLactateLevelCollectionDatetime.Name = "Label_RepeatLactateLevelCollectionDatetime";
            this.Label_RepeatLactateLevelCollectionDatetime.Size = new System.Drawing.Size(216, 13);
            this.Label_RepeatLactateLevelCollectionDatetime.TabIndex = 11;
            this.Label_RepeatLactateLevelCollectionDatetime.Text = "Repeat Lactate Level Collection Date/Time:";
            // 
            // Label_InitialLactateLevelCollectionDatetime
            // 
            this.Label_InitialLactateLevelCollectionDatetime.AutoSize = true;
            this.Label_InitialLactateLevelCollectionDatetime.Location = new System.Drawing.Point(200, 92);
            this.Label_InitialLactateLevelCollectionDatetime.Name = "Label_InitialLactateLevelCollectionDatetime";
            this.Label_InitialLactateLevelCollectionDatetime.Size = new System.Drawing.Size(205, 13);
            this.Label_InitialLactateLevelCollectionDatetime.TabIndex = 10;
            this.Label_InitialLactateLevelCollectionDatetime.Text = "Initial Lactate Level Collection Date/Time:";
            // 
            // Label_SepticShockPresentationDatetime
            // 
            this.Label_SepticShockPresentationDatetime.Location = new System.Drawing.Point(751, 3);
            this.Label_SepticShockPresentationDatetime.Name = "Label_SepticShockPresentationDatetime";
            this.Label_SepticShockPresentationDatetime.Size = new System.Drawing.Size(103, 50);
            this.Label_SepticShockPresentationDatetime.TabIndex = 9;
            this.Label_SepticShockPresentationDatetime.Text = "Septic Shock Presentation Date/Time:";
            // 
            // Label_BloodCultureCollectionDatetime
            // 
            this.Label_BloodCultureCollectionDatetime.AutoSize = true;
            this.Label_BloodCultureCollectionDatetime.Location = new System.Drawing.Point(414, 144);
            this.Label_BloodCultureCollectionDatetime.Name = "Label_BloodCultureCollectionDatetime";
            this.Label_BloodCultureCollectionDatetime.Size = new System.Drawing.Size(176, 13);
            this.Label_BloodCultureCollectionDatetime.TabIndex = 8;
            this.Label_BloodCultureCollectionDatetime.Text = "Blood Culture Collection Date/Time:";
            // 
            // Label_SepticShockPresent
            // 
            this.Label_SepticShockPresent.Location = new System.Drawing.Point(657, 10);
            this.Label_SepticShockPresent.Name = "Label_SepticShockPresent";
            this.Label_SepticShockPresent.Size = new System.Drawing.Size(99, 30);
            this.Label_SepticShockPresent.TabIndex = 7;
            this.Label_SepticShockPresent.Text = "Septic Shock Present:";
            this.Label_SepticShockPresent.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Label_InitialLactateLevelCollection
            // 
            this.Label_InitialLactateLevelCollection.AutoSize = true;
            this.Label_InitialLactateLevelCollection.Location = new System.Drawing.Point(26, 92);
            this.Label_InitialLactateLevelCollection.Name = "Label_InitialLactateLevelCollection";
            this.Label_InitialLactateLevelCollection.Size = new System.Drawing.Size(151, 13);
            this.Label_InitialLactateLevelCollection.TabIndex = 6;
            this.Label_InitialLactateLevelCollection.Text = "Initial Lactate Level Collection:";
            // 
            // Label_RepeatLactateLevelCollection
            // 
            this.Label_RepeatLactateLevelCollection.AutoSize = true;
            this.Label_RepeatLactateLevelCollection.Location = new System.Drawing.Point(846, 91);
            this.Label_RepeatLactateLevelCollection.Name = "Label_RepeatLactateLevelCollection";
            this.Label_RepeatLactateLevelCollection.Size = new System.Drawing.Size(162, 13);
            this.Label_RepeatLactateLevelCollection.TabIndex = 5;
            this.Label_RepeatLactateLevelCollection.Text = "Repeat Lactate Level Collection:";
            // 
            // Label_TriageDatetime
            // 
            this.Label_TriageDatetime.AutoSize = true;
            this.Label_TriageDatetime.Location = new System.Drawing.Point(133, 16);
            this.Label_TriageDatetime.Name = "Label_TriageDatetime";
            this.Label_TriageDatetime.Size = new System.Drawing.Size(94, 13);
            this.Label_TriageDatetime.TabIndex = 4;
            this.Label_TriageDatetime.Text = "Triage Date/Time:";
            // 
            // Label_EarliestDatetime
            // 
            this.Label_EarliestDatetime.AutoSize = true;
            this.Label_EarliestDatetime.Location = new System.Drawing.Point(17, 16);
            this.Label_EarliestDatetime.Name = "Label_EarliestDatetime";
            this.Label_EarliestDatetime.Size = new System.Drawing.Size(98, 13);
            this.Label_EarliestDatetime.TabIndex = 3;
            this.Label_EarliestDatetime.Text = "Earliest Date/Time:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.lbl_ICUDischargeDatetime);
            this.tabPage4.Controls.Add(this.lbl_ICUAdmissionDatetime);
            this.tabPage4.Controls.Add(this.lbl_MechanicalVentilationDatetime);
            this.tabPage4.Controls.Add(this.lbl_Diabetes);
            this.tabPage4.Controls.Add(this.lbl_ChronicRenalFailure);
            this.tabPage4.Controls.Add(this.lbl_OrganTransplant);
            this.tabPage4.Controls.Add(this.lbl_ChronicLiverDisease);
            this.tabPage4.Controls.Add(this.lbl_CongestiveHeartFailure);
            this.tabPage4.Controls.Add(this.lbl_ImmuneModifyingMedications);
            this.tabPage4.Controls.Add(this.lbl_Lymphoma);
            this.tabPage4.Controls.Add(this.lbl_MetastaticCancer);
            this.tabPage4.Controls.Add(this.lbl_AIDSDisease);
            this.tabPage4.Controls.Add(this.lbl_ChronicRespiratoryFailure);
            this.tabPage4.Controls.Add(this.lbl_ICU);
            this.tabPage4.Controls.Add(this.lbl_MechanicalVentilation);
            this.tabPage4.Controls.Add(this.lbl_SiteofInfection);
            this.tabPage4.Controls.Add(this.lbl_LowerRespiratoryInfection);
            this.tabPage4.Controls.Add(this.lbl_InfectionEtiology);
            this.tabPage4.Controls.Add(this.lbl_Bandemia);
            this.tabPage4.Controls.Add(this.lbl_AlteredMentalStatus);
            this.tabPage4.Controls.Add(this.lbl_PlateletCount);
            this.tabPage4.Controls.Add(this.textBox_ICUDischargeDatetime);
            this.tabPage4.Controls.Add(this.textBox_ICUAdmissionDatetime);
            this.tabPage4.Controls.Add(this.textBox_MechanicalVentilationDatetime);
            this.tabPage4.Controls.Add(this.comboBox_ICU);
            this.tabPage4.Controls.Add(this.comboBox_AIDSDisease);
            this.tabPage4.Controls.Add(this.comboBox_ChronicRespiratoryFailure);
            this.tabPage4.Controls.Add(this.comboBox_MechanicalVentilation);
            this.tabPage4.Controls.Add(this.comboBox_InfectionEtiology);
            this.tabPage4.Controls.Add(this.comboBox_SiteofInfection);
            this.tabPage4.Controls.Add(this.comboBox_Lymphoma);
            this.tabPage4.Controls.Add(this.comboBox_AlteredMentalStatus);
            this.tabPage4.Controls.Add(this.comboBox_Diabetes);
            this.tabPage4.Controls.Add(this.comboBox_ChronicLiverDisease);
            this.tabPage4.Controls.Add(this.comboBox_OrganTransplant);
            this.tabPage4.Controls.Add(this.comboBox_ImmuneModifyingMedications);
            this.tabPage4.Controls.Add(this.comboBox_ChronicRenalFailure);
            this.tabPage4.Controls.Add(this.comboBox_CongestiveHeartFailure);
            this.tabPage4.Controls.Add(this.comboBox_PlateletCount);
            this.tabPage4.Controls.Add(this.comboBox_Bandemia);
            this.tabPage4.Controls.Add(this.comboBox_LowerRespiratoryInfection);
            this.tabPage4.Controls.Add(this.comboBox_MetastaticCancer);
            this.tabPage4.Controls.Add(this.label43);
            this.tabPage4.Controls.Add(this.label44);
            this.tabPage4.Controls.Add(this.label45);
            this.tabPage4.Controls.Add(this.label47);
            this.tabPage4.Controls.Add(this.label48);
            this.tabPage4.Controls.Add(this.label49);
            this.tabPage4.Controls.Add(this.label50);
            this.tabPage4.Controls.Add(this.label51);
            this.tabPage4.Controls.Add(this.label1);
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.label6);
            this.tabPage4.Controls.Add(this.label11);
            this.tabPage4.Controls.Add(this.label29);
            this.tabPage4.Controls.Add(this.label31);
            this.tabPage4.Controls.Add(this.label33);
            this.tabPage4.Controls.Add(this.label34);
            this.tabPage4.Controls.Add(this.label35);
            this.tabPage4.Controls.Add(this.label36);
            this.tabPage4.Controls.Add(this.label37);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1233, 551);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Severity/Comorbidity";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // lbl_ICUDischargeDatetime
            // 
            this.lbl_ICUDischargeDatetime.AutoSize = true;
            this.lbl_ICUDischargeDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ICUDischargeDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ICUDischargeDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_ICUDischargeDatetime.Location = new System.Drawing.Point(584, 175);
            this.lbl_ICUDischargeDatetime.Name = "lbl_ICUDischargeDatetime";
            this.lbl_ICUDischargeDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_ICUDischargeDatetime.TabIndex = 94;
            this.lbl_ICUDischargeDatetime.Text = "*";
            // 
            // lbl_ICUAdmissionDatetime
            // 
            this.lbl_ICUAdmissionDatetime.AutoSize = true;
            this.lbl_ICUAdmissionDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ICUAdmissionDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ICUAdmissionDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_ICUAdmissionDatetime.Location = new System.Drawing.Point(315, 174);
            this.lbl_ICUAdmissionDatetime.Name = "lbl_ICUAdmissionDatetime";
            this.lbl_ICUAdmissionDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_ICUAdmissionDatetime.TabIndex = 93;
            this.lbl_ICUAdmissionDatetime.Text = "*";
            // 
            // lbl_MechanicalVentilationDatetime
            // 
            this.lbl_MechanicalVentilationDatetime.AutoSize = true;
            this.lbl_MechanicalVentilationDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_MechanicalVentilationDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MechanicalVentilationDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_MechanicalVentilationDatetime.Location = new System.Drawing.Point(315, 127);
            this.lbl_MechanicalVentilationDatetime.Name = "lbl_MechanicalVentilationDatetime";
            this.lbl_MechanicalVentilationDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_MechanicalVentilationDatetime.TabIndex = 92;
            this.lbl_MechanicalVentilationDatetime.Text = "*";
            // 
            // lbl_Diabetes
            // 
            this.lbl_Diabetes.AutoSize = true;
            this.lbl_Diabetes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Diabetes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Diabetes.ForeColor = System.Drawing.Color.Black;
            this.lbl_Diabetes.Location = new System.Drawing.Point(17, 429);
            this.lbl_Diabetes.Name = "lbl_Diabetes";
            this.lbl_Diabetes.Size = new System.Drawing.Size(14, 16);
            this.lbl_Diabetes.TabIndex = 91;
            this.lbl_Diabetes.Text = "*";
            // 
            // lbl_ChronicRenalFailure
            // 
            this.lbl_ChronicRenalFailure.AutoSize = true;
            this.lbl_ChronicRenalFailure.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ChronicRenalFailure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ChronicRenalFailure.ForeColor = System.Drawing.Color.Black;
            this.lbl_ChronicRenalFailure.Location = new System.Drawing.Point(17, 376);
            this.lbl_ChronicRenalFailure.Name = "lbl_ChronicRenalFailure";
            this.lbl_ChronicRenalFailure.Size = new System.Drawing.Size(14, 16);
            this.lbl_ChronicRenalFailure.TabIndex = 90;
            this.lbl_ChronicRenalFailure.Text = "*";
            // 
            // lbl_OrganTransplant
            // 
            this.lbl_OrganTransplant.AutoSize = true;
            this.lbl_OrganTransplant.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_OrganTransplant.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_OrganTransplant.ForeColor = System.Drawing.Color.Black;
            this.lbl_OrganTransplant.Location = new System.Drawing.Point(583, 426);
            this.lbl_OrganTransplant.Name = "lbl_OrganTransplant";
            this.lbl_OrganTransplant.Size = new System.Drawing.Size(14, 16);
            this.lbl_OrganTransplant.TabIndex = 89;
            this.lbl_OrganTransplant.Text = "*";
            // 
            // lbl_ChronicLiverDisease
            // 
            this.lbl_ChronicLiverDisease.AutoSize = true;
            this.lbl_ChronicLiverDisease.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ChronicLiverDisease.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ChronicLiverDisease.ForeColor = System.Drawing.Color.Black;
            this.lbl_ChronicLiverDisease.Location = new System.Drawing.Point(584, 376);
            this.lbl_ChronicLiverDisease.Name = "lbl_ChronicLiverDisease";
            this.lbl_ChronicLiverDisease.Size = new System.Drawing.Size(14, 16);
            this.lbl_ChronicLiverDisease.TabIndex = 88;
            this.lbl_ChronicLiverDisease.Text = "*";
            // 
            // lbl_CongestiveHeartFailure
            // 
            this.lbl_CongestiveHeartFailure.AutoSize = true;
            this.lbl_CongestiveHeartFailure.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_CongestiveHeartFailure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CongestiveHeartFailure.ForeColor = System.Drawing.Color.Black;
            this.lbl_CongestiveHeartFailure.Location = new System.Drawing.Point(583, 321);
            this.lbl_CongestiveHeartFailure.Name = "lbl_CongestiveHeartFailure";
            this.lbl_CongestiveHeartFailure.Size = new System.Drawing.Size(14, 16);
            this.lbl_CongestiveHeartFailure.TabIndex = 87;
            this.lbl_CongestiveHeartFailure.Text = "*";
            // 
            // lbl_ImmuneModifyingMedications
            // 
            this.lbl_ImmuneModifyingMedications.AutoSize = true;
            this.lbl_ImmuneModifyingMedications.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ImmuneModifyingMedications.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ImmuneModifyingMedications.ForeColor = System.Drawing.Color.Black;
            this.lbl_ImmuneModifyingMedications.Location = new System.Drawing.Point(17, 321);
            this.lbl_ImmuneModifyingMedications.Name = "lbl_ImmuneModifyingMedications";
            this.lbl_ImmuneModifyingMedications.Size = new System.Drawing.Size(14, 16);
            this.lbl_ImmuneModifyingMedications.TabIndex = 86;
            this.lbl_ImmuneModifyingMedications.Text = "*";
            // 
            // lbl_Lymphoma
            // 
            this.lbl_Lymphoma.AutoSize = true;
            this.lbl_Lymphoma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Lymphoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Lymphoma.ForeColor = System.Drawing.Color.Black;
            this.lbl_Lymphoma.Location = new System.Drawing.Point(584, 265);
            this.lbl_Lymphoma.Name = "lbl_Lymphoma";
            this.lbl_Lymphoma.Size = new System.Drawing.Size(14, 16);
            this.lbl_Lymphoma.TabIndex = 85;
            this.lbl_Lymphoma.Text = "*";
            // 
            // lbl_MetastaticCancer
            // 
            this.lbl_MetastaticCancer.AutoSize = true;
            this.lbl_MetastaticCancer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_MetastaticCancer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MetastaticCancer.ForeColor = System.Drawing.Color.Black;
            this.lbl_MetastaticCancer.Location = new System.Drawing.Point(17, 265);
            this.lbl_MetastaticCancer.Name = "lbl_MetastaticCancer";
            this.lbl_MetastaticCancer.Size = new System.Drawing.Size(14, 16);
            this.lbl_MetastaticCancer.TabIndex = 84;
            this.lbl_MetastaticCancer.Text = "*";
            // 
            // lbl_AIDSDisease
            // 
            this.lbl_AIDSDisease.AutoSize = true;
            this.lbl_AIDSDisease.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_AIDSDisease.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AIDSDisease.ForeColor = System.Drawing.Color.Black;
            this.lbl_AIDSDisease.Location = new System.Drawing.Point(584, 215);
            this.lbl_AIDSDisease.Name = "lbl_AIDSDisease";
            this.lbl_AIDSDisease.Size = new System.Drawing.Size(14, 16);
            this.lbl_AIDSDisease.TabIndex = 83;
            this.lbl_AIDSDisease.Text = "*";
            // 
            // lbl_ChronicRespiratoryFailure
            // 
            this.lbl_ChronicRespiratoryFailure.AutoSize = true;
            this.lbl_ChronicRespiratoryFailure.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ChronicRespiratoryFailure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ChronicRespiratoryFailure.ForeColor = System.Drawing.Color.Black;
            this.lbl_ChronicRespiratoryFailure.Location = new System.Drawing.Point(17, 215);
            this.lbl_ChronicRespiratoryFailure.Name = "lbl_ChronicRespiratoryFailure";
            this.lbl_ChronicRespiratoryFailure.Size = new System.Drawing.Size(14, 16);
            this.lbl_ChronicRespiratoryFailure.TabIndex = 82;
            this.lbl_ChronicRespiratoryFailure.Text = "*";
            // 
            // lbl_ICU
            // 
            this.lbl_ICU.AutoSize = true;
            this.lbl_ICU.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ICU.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ICU.ForeColor = System.Drawing.Color.Black;
            this.lbl_ICU.Location = new System.Drawing.Point(17, 174);
            this.lbl_ICU.Name = "lbl_ICU";
            this.lbl_ICU.Size = new System.Drawing.Size(14, 16);
            this.lbl_ICU.TabIndex = 81;
            this.lbl_ICU.Text = "*";
            // 
            // lbl_MechanicalVentilation
            // 
            this.lbl_MechanicalVentilation.AutoSize = true;
            this.lbl_MechanicalVentilation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_MechanicalVentilation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MechanicalVentilation.ForeColor = System.Drawing.Color.Black;
            this.lbl_MechanicalVentilation.Location = new System.Drawing.Point(17, 128);
            this.lbl_MechanicalVentilation.Name = "lbl_MechanicalVentilation";
            this.lbl_MechanicalVentilation.Size = new System.Drawing.Size(14, 16);
            this.lbl_MechanicalVentilation.TabIndex = 80;
            this.lbl_MechanicalVentilation.Text = "*";
            // 
            // lbl_SiteofInfection
            // 
            this.lbl_SiteofInfection.AutoSize = true;
            this.lbl_SiteofInfection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SiteofInfection.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SiteofInfection.ForeColor = System.Drawing.Color.Black;
            this.lbl_SiteofInfection.Location = new System.Drawing.Point(583, 84);
            this.lbl_SiteofInfection.Name = "lbl_SiteofInfection";
            this.lbl_SiteofInfection.Size = new System.Drawing.Size(14, 16);
            this.lbl_SiteofInfection.TabIndex = 79;
            this.lbl_SiteofInfection.Text = "*";
            // 
            // lbl_LowerRespiratoryInfection
            // 
            this.lbl_LowerRespiratoryInfection.AutoSize = true;
            this.lbl_LowerRespiratoryInfection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_LowerRespiratoryInfection.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_LowerRespiratoryInfection.ForeColor = System.Drawing.Color.Black;
            this.lbl_LowerRespiratoryInfection.Location = new System.Drawing.Point(584, 35);
            this.lbl_LowerRespiratoryInfection.Name = "lbl_LowerRespiratoryInfection";
            this.lbl_LowerRespiratoryInfection.Size = new System.Drawing.Size(14, 16);
            this.lbl_LowerRespiratoryInfection.TabIndex = 78;
            this.lbl_LowerRespiratoryInfection.Text = "*";
            // 
            // lbl_InfectionEtiology
            // 
            this.lbl_InfectionEtiology.AutoSize = true;
            this.lbl_InfectionEtiology.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_InfectionEtiology.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_InfectionEtiology.ForeColor = System.Drawing.Color.Black;
            this.lbl_InfectionEtiology.Location = new System.Drawing.Point(315, 81);
            this.lbl_InfectionEtiology.Name = "lbl_InfectionEtiology";
            this.lbl_InfectionEtiology.Size = new System.Drawing.Size(14, 16);
            this.lbl_InfectionEtiology.TabIndex = 77;
            this.lbl_InfectionEtiology.Text = "*";
            // 
            // lbl_Bandemia
            // 
            this.lbl_Bandemia.AutoSize = true;
            this.lbl_Bandemia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Bandemia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Bandemia.ForeColor = System.Drawing.Color.Black;
            this.lbl_Bandemia.Location = new System.Drawing.Point(315, 33);
            this.lbl_Bandemia.Name = "lbl_Bandemia";
            this.lbl_Bandemia.Size = new System.Drawing.Size(14, 16);
            this.lbl_Bandemia.TabIndex = 76;
            this.lbl_Bandemia.Text = "*";
            // 
            // lbl_AlteredMentalStatus
            // 
            this.lbl_AlteredMentalStatus.AutoSize = true;
            this.lbl_AlteredMentalStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_AlteredMentalStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AlteredMentalStatus.ForeColor = System.Drawing.Color.Black;
            this.lbl_AlteredMentalStatus.Location = new System.Drawing.Point(11, 83);
            this.lbl_AlteredMentalStatus.Name = "lbl_AlteredMentalStatus";
            this.lbl_AlteredMentalStatus.Size = new System.Drawing.Size(14, 16);
            this.lbl_AlteredMentalStatus.TabIndex = 75;
            this.lbl_AlteredMentalStatus.Text = "*";
            // 
            // lbl_PlateletCount
            // 
            this.lbl_PlateletCount.AutoSize = true;
            this.lbl_PlateletCount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_PlateletCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PlateletCount.ForeColor = System.Drawing.Color.Black;
            this.lbl_PlateletCount.Location = new System.Drawing.Point(17, 37);
            this.lbl_PlateletCount.Name = "lbl_PlateletCount";
            this.lbl_PlateletCount.Size = new System.Drawing.Size(14, 16);
            this.lbl_PlateletCount.TabIndex = 74;
            this.lbl_PlateletCount.Text = "*";
            // 
            // textBox_ICUDischargeDatetime
            // 
            this.textBox_ICUDischargeDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_ICUDischargeDatetime.Location = new System.Drawing.Point(598, 175);
            this.textBox_ICUDischargeDatetime.Mask = "00/00/0000 90:00";
            this.textBox_ICUDischargeDatetime.Name = "textBox_ICUDischargeDatetime";
            this.textBox_ICUDischargeDatetime.Size = new System.Drawing.Size(95, 20);
            this.textBox_ICUDischargeDatetime.TabIndex = 10;
            this.textBox_ICUDischargeDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_ICUDischargeDatetime.Enter += new System.EventHandler(this.textBox_ICUDischargeDatetime_Enter);
            this.textBox_ICUDischargeDatetime.Leave += new System.EventHandler(this.textBox_ICUDischargeDatetime_Leave);
            // 
            // textBox_ICUAdmissionDatetime
            // 
            this.textBox_ICUAdmissionDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_ICUAdmissionDatetime.Location = new System.Drawing.Point(330, 175);
            this.textBox_ICUAdmissionDatetime.Mask = "00/00/0000 90:00";
            this.textBox_ICUAdmissionDatetime.Name = "textBox_ICUAdmissionDatetime";
            this.textBox_ICUAdmissionDatetime.Size = new System.Drawing.Size(95, 20);
            this.textBox_ICUAdmissionDatetime.TabIndex = 9;
            this.textBox_ICUAdmissionDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_ICUAdmissionDatetime.Enter += new System.EventHandler(this.textBox_ICUAdmissionDatetime_Enter);
            this.textBox_ICUAdmissionDatetime.Leave += new System.EventHandler(this.textBox_ICUAdmissionDatetime_Leave);
            // 
            // textBox_MechanicalVentilationDatetime
            // 
            this.textBox_MechanicalVentilationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_MechanicalVentilationDatetime.Location = new System.Drawing.Point(330, 128);
            this.textBox_MechanicalVentilationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_MechanicalVentilationDatetime.Name = "textBox_MechanicalVentilationDatetime";
            this.textBox_MechanicalVentilationDatetime.Size = new System.Drawing.Size(95, 20);
            this.textBox_MechanicalVentilationDatetime.TabIndex = 7;
            this.textBox_MechanicalVentilationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_MechanicalVentilationDatetime.Enter += new System.EventHandler(this.textBox_MechanicalVentilationDatetime_Enter);
            this.textBox_MechanicalVentilationDatetime.Leave += new System.EventHandler(this.textBox_MechanicalVentilationDatetime_Leave);
            // 
            // comboBox_ICU
            // 
            this.comboBox_ICU.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ICU.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ICU.FormattingEnabled = true;
            this.comboBox_ICU.Items.AddRange(new object[] {
            "Select",
            "Patient not admitted to ICU",
            "Patient admitted to ICU"});
            this.comboBox_ICU.Location = new System.Drawing.Point(32, 174);
            this.comboBox_ICU.Name = "comboBox_ICU";
            this.comboBox_ICU.Size = new System.Drawing.Size(265, 21);
            this.comboBox_ICU.TabIndex = 8;
            this.comboBox_ICU.SelectedIndexChanged += new System.EventHandler(this.comboBox_ICU_SelectedIndexChanged);
            // 
            // comboBox_AIDSDisease
            // 
            this.comboBox_AIDSDisease.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AIDSDisease.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_AIDSDisease.FormattingEnabled = true;
            this.comboBox_AIDSDisease.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_AIDSDisease.Location = new System.Drawing.Point(599, 214);
            this.comboBox_AIDSDisease.Name = "comboBox_AIDSDisease";
            this.comboBox_AIDSDisease.Size = new System.Drawing.Size(476, 21);
            this.comboBox_AIDSDisease.TabIndex = 12;
            // 
            // comboBox_ChronicRespiratoryFailure
            // 
            this.comboBox_ChronicRespiratoryFailure.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ChronicRespiratoryFailure.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ChronicRespiratoryFailure.FormattingEnabled = true;
            this.comboBox_ChronicRespiratoryFailure.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_ChronicRespiratoryFailure.Location = new System.Drawing.Point(32, 214);
            this.comboBox_ChronicRespiratoryFailure.Name = "comboBox_ChronicRespiratoryFailure";
            this.comboBox_ChronicRespiratoryFailure.Size = new System.Drawing.Size(476, 21);
            this.comboBox_ChronicRespiratoryFailure.TabIndex = 11;
            // 
            // comboBox_MechanicalVentilation
            // 
            this.comboBox_MechanicalVentilation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_MechanicalVentilation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_MechanicalVentilation.FormattingEnabled = true;
            this.comboBox_MechanicalVentilation.Items.AddRange(new object[] {
            "Select",
            "No mechanical ventilation",
            "Mechanical ventilation"});
            this.comboBox_MechanicalVentilation.Location = new System.Drawing.Point(32, 128);
            this.comboBox_MechanicalVentilation.Name = "comboBox_MechanicalVentilation";
            this.comboBox_MechanicalVentilation.Size = new System.Drawing.Size(265, 21);
            this.comboBox_MechanicalVentilation.TabIndex = 6;
            this.comboBox_MechanicalVentilation.SelectedIndexChanged += new System.EventHandler(this.comboBox_MechanicalVentilation_SelectedIndexChanged);
            // 
            // comboBox_InfectionEtiology
            // 
            this.comboBox_InfectionEtiology.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_InfectionEtiology.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_InfectionEtiology.FormattingEnabled = true;
            this.comboBox_InfectionEtiology.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_InfectionEtiology.Location = new System.Drawing.Point(330, 80);
            this.comboBox_InfectionEtiology.Name = "comboBox_InfectionEtiology";
            this.comboBox_InfectionEtiology.Size = new System.Drawing.Size(95, 21);
            this.comboBox_InfectionEtiology.TabIndex = 4;
            // 
            // comboBox_SiteofInfection
            // 
            this.comboBox_SiteofInfection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_SiteofInfection.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_SiteofInfection.FormattingEnabled = true;
            this.comboBox_SiteofInfection.Items.AddRange(new object[] {
            "Select",
            "Urinary",
            "Respiratory",
            "Gastrointestinal",
            "Skin",
            "Central Nervous System",
            "Unknown"});
            this.comboBox_SiteofInfection.Location = new System.Drawing.Point(598, 83);
            this.comboBox_SiteofInfection.Name = "comboBox_SiteofInfection";
            this.comboBox_SiteofInfection.Size = new System.Drawing.Size(477, 21);
            this.comboBox_SiteofInfection.TabIndex = 5;
            // 
            // comboBox_Lymphoma
            // 
            this.comboBox_Lymphoma.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Lymphoma.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_Lymphoma.FormattingEnabled = true;
            this.comboBox_Lymphoma.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_Lymphoma.Location = new System.Drawing.Point(599, 265);
            this.comboBox_Lymphoma.Name = "comboBox_Lymphoma";
            this.comboBox_Lymphoma.Size = new System.Drawing.Size(476, 21);
            this.comboBox_Lymphoma.TabIndex = 14;
            // 
            // comboBox_AlteredMentalStatus
            // 
            this.comboBox_AlteredMentalStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AlteredMentalStatus.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_AlteredMentalStatus.FormattingEnabled = true;
            this.comboBox_AlteredMentalStatus.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_AlteredMentalStatus.Location = new System.Drawing.Point(26, 82);
            this.comboBox_AlteredMentalStatus.Name = "comboBox_AlteredMentalStatus";
            this.comboBox_AlteredMentalStatus.Size = new System.Drawing.Size(95, 21);
            this.comboBox_AlteredMentalStatus.TabIndex = 3;
            // 
            // comboBox_Diabetes
            // 
            this.comboBox_Diabetes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Diabetes.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_Diabetes.FormattingEnabled = true;
            this.comboBox_Diabetes.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_Diabetes.Location = new System.Drawing.Point(32, 429);
            this.comboBox_Diabetes.Name = "comboBox_Diabetes";
            this.comboBox_Diabetes.Size = new System.Drawing.Size(476, 21);
            this.comboBox_Diabetes.TabIndex = 19;
            // 
            // comboBox_ChronicLiverDisease
            // 
            this.comboBox_ChronicLiverDisease.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ChronicLiverDisease.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ChronicLiverDisease.FormattingEnabled = true;
            this.comboBox_ChronicLiverDisease.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_ChronicLiverDisease.Location = new System.Drawing.Point(599, 375);
            this.comboBox_ChronicLiverDisease.Name = "comboBox_ChronicLiverDisease";
            this.comboBox_ChronicLiverDisease.Size = new System.Drawing.Size(476, 21);
            this.comboBox_ChronicLiverDisease.TabIndex = 18;
            // 
            // comboBox_OrganTransplant
            // 
            this.comboBox_OrganTransplant.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_OrganTransplant.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_OrganTransplant.FormattingEnabled = true;
            this.comboBox_OrganTransplant.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_OrganTransplant.Location = new System.Drawing.Point(598, 429);
            this.comboBox_OrganTransplant.Name = "comboBox_OrganTransplant";
            this.comboBox_OrganTransplant.Size = new System.Drawing.Size(477, 21);
            this.comboBox_OrganTransplant.TabIndex = 20;
            // 
            // comboBox_ImmuneModifyingMedications
            // 
            this.comboBox_ImmuneModifyingMedications.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ImmuneModifyingMedications.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ImmuneModifyingMedications.FormattingEnabled = true;
            this.comboBox_ImmuneModifyingMedications.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_ImmuneModifyingMedications.Location = new System.Drawing.Point(32, 321);
            this.comboBox_ImmuneModifyingMedications.Name = "comboBox_ImmuneModifyingMedications";
            this.comboBox_ImmuneModifyingMedications.Size = new System.Drawing.Size(476, 21);
            this.comboBox_ImmuneModifyingMedications.TabIndex = 15;
            // 
            // comboBox_ChronicRenalFailure
            // 
            this.comboBox_ChronicRenalFailure.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ChronicRenalFailure.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ChronicRenalFailure.FormattingEnabled = true;
            this.comboBox_ChronicRenalFailure.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_ChronicRenalFailure.Location = new System.Drawing.Point(32, 375);
            this.comboBox_ChronicRenalFailure.Name = "comboBox_ChronicRenalFailure";
            this.comboBox_ChronicRenalFailure.Size = new System.Drawing.Size(476, 21);
            this.comboBox_ChronicRenalFailure.TabIndex = 17;
            // 
            // comboBox_CongestiveHeartFailure
            // 
            this.comboBox_CongestiveHeartFailure.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_CongestiveHeartFailure.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_CongestiveHeartFailure.FormattingEnabled = true;
            this.comboBox_CongestiveHeartFailure.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_CongestiveHeartFailure.Location = new System.Drawing.Point(598, 321);
            this.comboBox_CongestiveHeartFailure.Name = "comboBox_CongestiveHeartFailure";
            this.comboBox_CongestiveHeartFailure.Size = new System.Drawing.Size(477, 21);
            this.comboBox_CongestiveHeartFailure.TabIndex = 16;
            // 
            // comboBox_PlateletCount
            // 
            this.comboBox_PlateletCount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_PlateletCount.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_PlateletCount.FormattingEnabled = true;
            this.comboBox_PlateletCount.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_PlateletCount.Location = new System.Drawing.Point(32, 36);
            this.comboBox_PlateletCount.Name = "comboBox_PlateletCount";
            this.comboBox_PlateletCount.Size = new System.Drawing.Size(95, 21);
            this.comboBox_PlateletCount.TabIndex = 0;
            // 
            // comboBox_Bandemia
            // 
            this.comboBox_Bandemia.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Bandemia.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_Bandemia.FormattingEnabled = true;
            this.comboBox_Bandemia.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_Bandemia.Location = new System.Drawing.Point(330, 31);
            this.comboBox_Bandemia.Name = "comboBox_Bandemia";
            this.comboBox_Bandemia.Size = new System.Drawing.Size(95, 21);
            this.comboBox_Bandemia.TabIndex = 1;
            // 
            // comboBox_LowerRespiratoryInfection
            // 
            this.comboBox_LowerRespiratoryInfection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_LowerRespiratoryInfection.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_LowerRespiratoryInfection.FormattingEnabled = true;
            this.comboBox_LowerRespiratoryInfection.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_LowerRespiratoryInfection.Location = new System.Drawing.Point(599, 34);
            this.comboBox_LowerRespiratoryInfection.Name = "comboBox_LowerRespiratoryInfection";
            this.comboBox_LowerRespiratoryInfection.Size = new System.Drawing.Size(95, 21);
            this.comboBox_LowerRespiratoryInfection.TabIndex = 2;
            // 
            // comboBox_MetastaticCancer
            // 
            this.comboBox_MetastaticCancer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_MetastaticCancer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_MetastaticCancer.FormattingEnabled = true;
            this.comboBox_MetastaticCancer.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_MetastaticCancer.Location = new System.Drawing.Point(32, 265);
            this.comboBox_MetastaticCancer.Name = "comboBox_MetastaticCancer";
            this.comboBox_MetastaticCancer.Size = new System.Drawing.Size(476, 21);
            this.comboBox_MetastaticCancer.TabIndex = 13;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(595, 359);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(113, 13);
            this.label43.TabIndex = 73;
            this.label43.Text = "Chronic Liver Disease:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(595, 413);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(92, 13);
            this.label44.TabIndex = 72;
            this.label44.Text = "Organ Transplant:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(29, 413);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(52, 13);
            this.label45.TabIndex = 71;
            this.label45.Text = "Diabetes:";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(29, 359);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(111, 13);
            this.label47.TabIndex = 69;
            this.label47.Text = "Chronic Renal Failure:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(596, 249);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(198, 13);
            this.label48.TabIndex = 68;
            this.label48.Text = "Lymphoma/Leukemia/Multiple Myeloma:";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(29, 305);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(155, 13);
            this.label49.TabIndex = 67;
            this.label49.Text = "Immune Modifying Medications:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(595, 305);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(126, 13);
            this.label50.TabIndex = 66;
            this.label50.Text = "Congestive Heart Failure:";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(29, 249);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(96, 13);
            this.label51.TabIndex = 65;
            this.label51.Text = "Metastatic Cancer:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(595, 198);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 13);
            this.label1.TabIndex = 64;
            this.label1.Text = "AIDS/HIV Disease:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 158);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 63;
            this.label2.Text = "ICU:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 13);
            this.label3.TabIndex = 62;
            this.label3.Text = "Chronic Respiratory Failure:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(595, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 13);
            this.label4.TabIndex = 61;
            this.label4.Text = "ICU Discharge Date/Time:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(327, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 13);
            this.label6.TabIndex = 60;
            this.label6.Text = "ICU Admission Date/Time:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(595, 67);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 13);
            this.label11.TabIndex = 59;
            this.label11.Text = "Site of Infection:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(327, 112);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(171, 13);
            this.label29.TabIndex = 58;
            this.label29.Text = "Mechanical Ventilation Date/Time:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(29, 112);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(117, 13);
            this.label31.TabIndex = 57;
            this.label31.Text = "Mechanical Ventilation:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(327, 65);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(227, 13);
            this.label33.TabIndex = 55;
            this.label33.Text = "Infection Etiology (Hospital Acquired Infection):";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(327, 15);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(57, 13);
            this.label34.TabIndex = 54;
            this.label34.Text = "Bandemia:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(596, 18);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(139, 13);
            this.label35.TabIndex = 53;
            this.label35.Text = "Lower Respiratory Infection:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(23, 66);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(111, 13);
            this.label36.TabIndex = 52;
            this.label36.Text = "Altered Mental Status:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(29, 20);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(173, 13);
            this.label37.TabIndex = 51;
            this.label37.Text = "Platelet Count (Thrombocytopenia):";
            // 
            // button_SaveCase
            // 
            this.button_SaveCase.Location = new System.Drawing.Point(1141, 591);
            this.button_SaveCase.Name = "button_SaveCase";
            this.button_SaveCase.Size = new System.Drawing.Size(109, 34);
            this.button_SaveCase.TabIndex = 500;
            this.button_SaveCase.Text = "Save Case";
            this.button_SaveCase.UseVisualStyleBackColor = true;
            this.button_SaveCase.Click += new System.EventHandler(this.button_SaveCase_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Black;
            this.label39.Location = new System.Drawing.Point(16, 594);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(14, 16);
            this.label39.TabIndex = 61;
            this.label39.Text = "*";
            // 
            // lbl_nt
            // 
            this.lbl_nt.AutoSize = true;
            this.lbl_nt.Location = new System.Drawing.Point(26, 594);
            this.lbl_nt.Name = "lbl_nt";
            this.lbl_nt.Size = new System.Drawing.Size(133, 13);
            this.lbl_nt.TabIndex = 61;
            this.lbl_nt.Text = "Indicates Mandatory Fields";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(10, 637);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(170, 47);
            this.pictureBox1.TabIndex = 501;
            this.pictureBox1.TabStop = false;
            // 
            // label_Copyright
            // 
            this.label_Copyright.AutoSize = true;
            this.label_Copyright.Location = new System.Drawing.Point(558, 670);
            this.label_Copyright.Name = "label_Copyright";
            this.label_Copyright.Size = new System.Drawing.Size(86, 13);
            this.label_Copyright.TabIndex = 502;
            this.label_Copyright.Text = "© HANYS 2017.";
            // 
            // Label_Contact
            // 
            this.Label_Contact.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Contact.AutoSize = true;
            this.Label_Contact.Location = new System.Drawing.Point(1076, 667);
            this.Label_Contact.Name = "Label_Contact";
            this.Label_Contact.Size = new System.Drawing.Size(122, 13);
            this.Label_Contact.TabIndex = 504;
            this.Label_Contact.Text = "Contact Sepsis support:-";
            // 
            // Label_ClickHere
            // 
            this.Label_ClickHere.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_ClickHere.AutoSize = true;
            this.Label_ClickHere.Location = new System.Drawing.Point(1196, 667);
            this.Label_ClickHere.Name = "Label_ClickHere";
            this.Label_ClickHere.Size = new System.Drawing.Size(56, 13);
            this.Label_ClickHere.TabIndex = 503;
            this.Label_ClickHere.TabStop = true;
            this.Label_ClickHere.Text = "Click Here";
            this.Label_ClickHere.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Label_ClickHere_LinkClicked);
            // 
            // lbl_InitialLactateLevelCollection
            // 
            this.lbl_InitialLactateLevelCollection.AutoSize = true;
            this.lbl_InitialLactateLevelCollection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_InitialLactateLevelCollection.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_InitialLactateLevelCollection.ForeColor = System.Drawing.Color.Black;
            this.lbl_InitialLactateLevelCollection.Location = new System.Drawing.Point(12, 105);
            this.lbl_InitialLactateLevelCollection.Name = "lbl_InitialLactateLevelCollection";
            this.lbl_InitialLactateLevelCollection.Size = new System.Drawing.Size(14, 16);
            this.lbl_InitialLactateLevelCollection.TabIndex = 111;
            this.lbl_InitialLactateLevelCollection.Text = "*";
            // 
            // SepsisCaseDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 687);
            this.Controls.Add(this.Label_Contact);
            this.Controls.Add(this.Label_ClickHere);
            this.Controls.Add(this.label_Copyright);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbl_nt);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.button_SaveCase);
            this.Controls.Add(this.tabControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SepsisCaseDetails";
            this.Text = "HANYS Sepsis Reporting Tool";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SepsisCaseDetails_FormClosing);
            this.Load += new System.EventHandler(this.SepsisCaseDetails_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button_SaveCase;
        private System.Windows.Forms.ComboBox comboBox_ProtocolInitiated;
        private System.Windows.Forms.ComboBox comboBox_ProtocolNotInitiatedReason;
        private System.Windows.Forms.ComboBox comboBox_ProtocolInitiatedPlace;
        private System.Windows.Forms.ComboBox comboBox_ProtocolType;
        private System.Windows.Forms.ComboBox comboBox_ExcludedFromProtocol;
        private System.Windows.Forms.Label Label_ExcludedFromProtocol;
        private System.Windows.Forms.Label Label_ExcludedDatetime;
        private System.Windows.Forms.Label Label_ExcludedExplain;
        private System.Windows.Forms.Label Label_ProtocolType;
        private System.Windows.Forms.Label Label_ProtocolInitiatedPlace;
        private System.Windows.Forms.Label Label_ExcludedReason;
        private System.Windows.Forms.Label Label_ProtocolNIAdditionalDetail;
        private System.Windows.Forms.Label Label_ProtocolNotInitiatedReason;
        private System.Windows.Forms.Label Label_ProtocolInitiated;
        private System.Windows.Forms.CheckedListBox checkedListBox_ExcludedReason;
        private System.Windows.Forms.CheckedListBox checkedListBox_ExcludedExplain;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label_CentralVenousOxygenMeasurement;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label Label_AntibioticAdministrationSelection;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label_VasopressorAdministration;
        private System.Windows.Forms.Label label_VasopressorAdministrationDateTime;
        private System.Windows.Forms.Label Label_InitialHypotension;
        private System.Windows.Forms.Label label_PersistentHypotension;
        private System.Windows.Forms.Label Label_CrystalloidFluidAdministrationDatetime;
        private System.Windows.Forms.Label Label_AdultCrystalloidFluidAdministration;
        private System.Windows.Forms.Label PediatricCrystalloidFluidAdministration;
        private System.Windows.Forms.Label Label_AntibioticAdministrationDatetime;
        private System.Windows.Forms.Label Label_BloodCulturePathogen;
        private System.Windows.Forms.Label Label_BloodCultureCollection;
        private System.Windows.Forms.Label Label_LeftEDDatetime;
        private System.Windows.Forms.Label Label_InitialLactateLevel;
        private System.Windows.Forms.Label Label_SevereSepsisPresent;
        private System.Windows.Forms.Label Label_BloodCultureCollectionAcceptableDelay;
        private System.Windows.Forms.Label Label_SevereSepsisPresentationDatetime;
        private System.Windows.Forms.Label Label_InitialLactateLevelUnit;
        private System.Windows.Forms.Label Label_AntibioticAdministration;
        private System.Windows.Forms.Label Label_DestinationafterED;
        private System.Windows.Forms.Label Label_BloodCultureResult;
        private System.Windows.Forms.Label Label_RepeatLactateLevelCollectionDatetime;
        private System.Windows.Forms.Label Label_InitialLactateLevelCollectionDatetime;
        private System.Windows.Forms.Label Label_SepticShockPresentationDatetime;
        private System.Windows.Forms.Label Label_BloodCultureCollectionDatetime;
        private System.Windows.Forms.Label Label_SepticShockPresent;
        private System.Windows.Forms.Label Label_InitialLactateLevelCollection;
        private System.Windows.Forms.Label Label_RepeatLactateLevelCollection;
        private System.Windows.Forms.Label Label_TriageDatetime;
        private System.Windows.Forms.Label Label_EarliestDatetime;
        private System.Windows.Forms.ComboBox comboBox_SkinExamination;
        private System.Windows.Forms.ComboBox comboBox_CentralVenousOxygenMeasurement;
        private System.Windows.Forms.ComboBox comboBox_FluidChallengePerformed;
        private System.Windows.Forms.ComboBox comboBox_CentralVenousPressureMeasurement;
        private System.Windows.Forms.ComboBox comboBox_VitalSignsReview;
        private System.Windows.Forms.ComboBox comboBox_PassiveLegRaiseExamination;
        private System.Windows.Forms.ComboBox comboBox_PeripheralPulseEvaluation;
        private System.Windows.Forms.ComboBox comboBox_BedsideCardiovascularUltrasound;
        private System.Windows.Forms.ComboBox comboBox_CapillaryRefillExamination;
        private System.Windows.Forms.ComboBox comboBox_CardiopulmonaryEvaluation;
        private System.Windows.Forms.ComboBox comboBox_RepeatLactateLevelCollection;
        private System.Windows.Forms.ComboBox comboBox_PersistentHypotension;
        private System.Windows.Forms.ComboBox comboBox_VasopressorAdministration;
        private System.Windows.Forms.ComboBox comboBox_InitialHypotension;
        private System.Windows.Forms.ComboBox comboBox_PediatricCrystalloidFluidAdministration;
        private System.Windows.Forms.ComboBox comboBox_BloodCultureCollection;
        private System.Windows.Forms.ComboBox comboBox_BloodCultureCollectionAcceptableDelay;
        private System.Windows.Forms.ComboBox comboBox_AntibioticAdministrationSelection;
        private System.Windows.Forms.ComboBox comboBox_AdultCrystalloidFluidAdministration;
        private System.Windows.Forms.ComboBox comboBox_InitialLactateLevelUnit;
        private System.Windows.Forms.ComboBox comboBox_BloodCulturePathogen;
        private System.Windows.Forms.ComboBox comboBox_AntibioticAdministration;
        private System.Windows.Forms.ComboBox comboBox_SepticShockPresent;
        private System.Windows.Forms.ComboBox comboBox_InitialLactateLevelCollection;
        private System.Windows.Forms.ComboBox comboBoX_BloodCultureResult;
        private System.Windows.Forms.ComboBox comboBox_DestinationafterED;
        private System.Windows.Forms.ComboBox comboBox_SevereSepsisPresent;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox comboBox_ICU;
        private System.Windows.Forms.ComboBox comboBox_AIDSDisease;
        private System.Windows.Forms.ComboBox comboBox_ChronicRespiratoryFailure;
        private System.Windows.Forms.ComboBox comboBox_MechanicalVentilation;
        private System.Windows.Forms.ComboBox comboBox_InfectionEtiology;
        private System.Windows.Forms.ComboBox comboBox_SiteofInfection;
        private System.Windows.Forms.ComboBox comboBox_Lymphoma;
        private System.Windows.Forms.ComboBox comboBox_AlteredMentalStatus;
        private System.Windows.Forms.ComboBox comboBox_Diabetes;
        private System.Windows.Forms.ComboBox comboBox_ChronicLiverDisease;
        private System.Windows.Forms.ComboBox comboBox_OrganTransplant;
        private System.Windows.Forms.ComboBox comboBox_ImmuneModifyingMedications;
        private System.Windows.Forms.ComboBox comboBox_ChronicRenalFailure;
        private System.Windows.Forms.ComboBox comboBox_CongestiveHeartFailure;
        private System.Windows.Forms.ComboBox comboBox_PlateletCount;
        private System.Windows.Forms.ComboBox comboBox_Bandemia;
        private System.Windows.Forms.ComboBox comboBox_LowerRespiratoryInfection;
        private System.Windows.Forms.ComboBox comboBox_MetastaticCancer;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.MaskedTextBox txtMRN;
        private System.Windows.Forms.MaskedTextBox textBox_DischargedDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_AdmissionDateTime;
        private System.Windows.Forms.MaskedTextBox txtDOB;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button_SourceofAdmission;
        private System.Windows.Forms.ComboBox comboBox_SourceofAdmission;
        private System.Windows.Forms.ComboBox comboBox_DischargeStatus;
        private System.Windows.Forms.ComboBox comboBox_TransferStatus;
        private System.Windows.Forms.Label Label_AdmissionDatetime;
        private System.Windows.Forms.Label Label_SourceofAdmission;
        private System.Windows.Forms.Label Label_DischargeDatetime;
        private System.Windows.Forms.Label Label_DischargedStatus;
        private System.Windows.Forms.Label Label_Transfer;
        private System.Windows.Forms.CheckedListBox checkedListBox_Race;
        private System.Windows.Forms.ComboBox comboBox_Payor;
        private System.Windows.Forms.ComboBox Combobox_Ethnicity;
        private System.Windows.Forms.ComboBox Combobox_Gender;
        private System.Windows.Forms.Label Label_PatientCtrlNum;
        private System.Windows.Forms.Label Label_Ethnicity;
        private System.Windows.Forms.Label Label_InsuranceNumber;
        private System.Windows.Forms.Label Label_Race;
        private System.Windows.Forms.Label Label_Payor;
        private System.Windows.Forms.Label Label_Gender;
        private System.Windows.Forms.Label Label_FacilityIdentifier;
        private System.Windows.Forms.Label Label_MRN;
        private System.Windows.Forms.Label Label_DateofBirth;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.MaskedTextBox TextBox_InsuranceNumber;
        private System.Windows.Forms.MaskedTextBox TextBox_PatientCtrlNum;
        private System.Windows.Forms.MaskedTextBox txtId;
        private System.Windows.Forms.MaskedTextBox TextBox_FacilityIdentifier;
        private System.Windows.Forms.MaskedTextBox textbox_TriageDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_EarliestDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_septicShockPresentationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_SevereSepsisPresentationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_LeftEDDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_InitialLactateLevelCollectionDatetime;
        private System.Windows.Forms.MaskedTextBox textbox_RepeatLactateLevelCollectionDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_BedsideCardiovascularUltrasoundDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_AntibioticAdministrationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_BloodCultureCollectionDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_VasopressorAdministrationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_CrystalloidFluidAdministrationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_PassiveLegRaiseExaminationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_CardiopulmonaryEvaluationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_SkinExaminationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_VitalSignsReviewDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_CentralVenousPressureMeasurementDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_FluidChallengePerformedDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_CentralVenousOxygenMeasurementDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_PeripheralPulseEvaluationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_CapillaryRefillExaminationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_ICUDischargeDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_ICUAdmissionDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_MechanicalVentilationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_ExcludedDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_TransferFacilityIdentifier;
        private System.Windows.Forms.MaskedTextBox textBox_ProtocolNIAdditionalDetail;
        private System.Windows.Forms.Label lbl_DischargeDatetime;
        private System.Windows.Forms.Label lbl_AdmissionDateTime;
        private System.Windows.Forms.Label lbl_FacilityIdentifier;
        private System.Windows.Forms.Label lbl_MRN;
        private System.Windows.Forms.Label lbl_InsuranceNumber;
        private System.Windows.Forms.Label lbl_Payor;
        private System.Windows.Forms.Label lbl_Ethnicity;
        private System.Windows.Forms.Label lbl_Race;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.Label lbl_DOB;
        private System.Windows.Forms.Label lbl_PatientCtrlNum;
        private System.Windows.Forms.Label lbl_txID;
        private System.Windows.Forms.Label lbl_TransferFacilityIdentifier;
        private System.Windows.Forms.Label lbl_TransferStatus;
        private System.Windows.Forms.Label lbl_DischargedStatus;
        private System.Windows.Forms.Label lbl_SourceofAdmission;
        private System.Windows.Forms.Label lbl_ProtocolInitaitedPlace;
        private System.Windows.Forms.Label lbl_ExcludedFromProtocol;
        private System.Windows.Forms.Label lbl_ProtocolInitiatedType;
        private System.Windows.Forms.Label lbl_ProtocolInitiated;
        private System.Windows.Forms.Label lbl_SepticShockPresent;
        private System.Windows.Forms.Label lbl_SevereSepsisPresentationDatetime;
        private System.Windows.Forms.Label lbl_SevereSepsisPresent;
        private System.Windows.Forms.Label lbl_EarliestDatetime;
        private System.Windows.Forms.Label lbl_Diabetes;
        private System.Windows.Forms.Label lbl_ChronicRenalFailure;
        private System.Windows.Forms.Label lbl_OrganTransplant;
        private System.Windows.Forms.Label lbl_ChronicLiverDisease;
        private System.Windows.Forms.Label lbl_CongestiveHeartFailure;
        private System.Windows.Forms.Label lbl_ImmuneModifyingMedications;
        private System.Windows.Forms.Label lbl_Lymphoma;
        private System.Windows.Forms.Label lbl_MetastaticCancer;
        private System.Windows.Forms.Label lbl_AIDSDisease;
        private System.Windows.Forms.Label lbl_ChronicRespiratoryFailure;
        private System.Windows.Forms.Label lbl_ICU;
        private System.Windows.Forms.Label lbl_MechanicalVentilation;
        private System.Windows.Forms.Label lbl_SiteofInfection;
        private System.Windows.Forms.Label lbl_LowerRespiratoryInfection;
        private System.Windows.Forms.Label lbl_InfectionEtiology;
        private System.Windows.Forms.Label lbl_Bandemia;
        private System.Windows.Forms.Label lbl_AlteredMentalStatus;
        private System.Windows.Forms.Label lbl_PlateletCount;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label lbl_nt;
        private System.Windows.Forms.Label lbl_ExcludedDatetime;
        private System.Windows.Forms.Label lbl_ExcludedReason;
        private System.Windows.Forms.Label lbl_DestinationafterED;
        private System.Windows.Forms.Label lbl_LeftEDDatetime;
        private System.Windows.Forms.Label lbl_PersistentHypotension;
        private System.Windows.Forms.Label lbl_InitialHypotension;
        private System.Windows.Forms.Label lbl_CrystalloidFluidAdministrationDatetime;
        private System.Windows.Forms.Label lbl_PediatricCrystalloidFluidAdministration;
        private System.Windows.Forms.Label lbl_AdultCrystalloidFluidAdministration;
        private System.Windows.Forms.Label lbl_AntibioticAdministrationDatetime;
        private System.Windows.Forms.Label lbl_AntibioticAdministrationSelection;
        private System.Windows.Forms.Label lbl_BloodCulturePathogen;
        private System.Windows.Forms.Label lbl_BloodCultureResult;
        private System.Windows.Forms.Label lbl_BloodCultureCollectionDatetime;
        private System.Windows.Forms.Label lbl_BloodCultureCollectionAcceptableDelay;
        private System.Windows.Forms.Label lbl_RepeatLactateLevelCollectionDatetime;
        private System.Windows.Forms.Label lbl_BloodCultureCollection;
        private System.Windows.Forms.Label lbl_InitialLactateLevelUnit;
        private System.Windows.Forms.Label lbl_InitialLactateLevelCollectionDatetime;
        private System.Windows.Forms.Label lbl_VasopressorAdministration;
        private System.Windows.Forms.Label lbl_VasopressorAdministrationDateTime;
        private System.Windows.Forms.Label lblVitalSignsReviewDatetime;
        private System.Windows.Forms.Label lbl_CVPressureMeasurementDateTime;
        private System.Windows.Forms.Label lbl_SkinExaminationDateTime;
        private System.Windows.Forms.Label lbl_PassiveLegRaiseExaminationDatetime;
        private System.Windows.Forms.Label lbl_CardiopulmonaryEvaluationDatetime;
        private System.Windows.Forms.Label lbl_BedsideCardioUltrasoundDateTime;
        private System.Windows.Forms.Label lbl_FluidChallengePerformedDatetime;
        private System.Windows.Forms.Label lbl_CentralVenousOxygenMeasurementDatetime;
        private System.Windows.Forms.Label lbl_PeripheralPulseEvaluationDatetime;
        private System.Windows.Forms.Label lbl_CapillaryRefillExaminationDatetime;
        private System.Windows.Forms.Label lbl_CentralVenousOxygenMeasurement;
        private System.Windows.Forms.Label lbl_PeripheralPulseEvaluation;
        private System.Windows.Forms.Label lbl_CapillaryRefillExamination;
        private System.Windows.Forms.Label lbl_VitalSignsReview;
        private System.Windows.Forms.Label lbl_CVPressureMeasurement;
        private System.Windows.Forms.Label lbl_SkinExamination;
        private System.Windows.Forms.Label lbl_PassiveLegRaiseExamination;
        private System.Windows.Forms.Label lbl_CardiopulmonaryEvaluation;
        private System.Windows.Forms.Label lbl_BedsideCardiovascularUltrasound;
        private System.Windows.Forms.Label lbl_FluidChallengePerformed;
        private System.Windows.Forms.Label lbl_ICUDischargeDatetime;
        private System.Windows.Forms.Label lbl_ICUAdmissionDatetime;
        private System.Windows.Forms.Label lbl_MechanicalVentilationDatetime;
        private System.Windows.Forms.Label lbl_ProtocolNotInitiatedReason;
        private System.Windows.Forms.Label lbl_ExcludedExplain;
        private System.Windows.Forms.Label lbl_AntibioticAdministration;
        private System.Windows.Forms.Label lbl_RepeatLactateLevelCollection;
        private System.Windows.Forms.Label lbl_InitialLactateLevel;
        private System.Windows.Forms.Label lbl_SepticShockPresentationDatetime;
        private System.Windows.Forms.TextBox textBox_InitialLactateLevel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label_Copyright;
        private System.Windows.Forms.Label Label_Contact;
        private System.Windows.Forms.LinkLabel Label_ClickHere;
        private System.Windows.Forms.Label lbl_InitialLactateLevelCollection;
    }
}