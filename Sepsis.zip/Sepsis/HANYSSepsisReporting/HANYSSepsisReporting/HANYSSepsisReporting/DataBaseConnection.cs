﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    class DataBaseConnection
    {
        public string DSN = "HANYS_sepsis";
        public string UserName = "HANYS_SEPSIS_APPLICATION";
        public string Password = "Myr@str@st87";
    }

}
