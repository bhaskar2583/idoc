﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Odbc;
using System.IO;
using System.Collections;
using System.Globalization;
using System.Diagnostics;

namespace WindowsFormsApplication1
{
    public partial class SepsisCaseDetails_5 : Form
    {


        ArrayList list = new ArrayList();
        string ConnectionString;
        int _uniqueID = 0;
        SepsisMaster sm;
        DataBaseConnection Db = new DataBaseConnection();
        OdbcConnection Conn;
        public SepsisCaseDetails_5(SepsisMaster master)
        {
            try
            {
            InitializeComponent();
            sm = master;
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;
            // ConnectionString = @"Server=SQLCONC1;Database=Sepsis;User Id=HANYS_SEPSIS_APPLICATION;Password=nonParagamps7!;";
           //ConnectionString = @"Server=JITU-PC\JITU;Database=Sepsis;User Id=sa;Password=jitu123;";
         // ConnectionString = @"Server=HANYS-APPS-DB-D\DEVNETFORUMDB;Database=Sepsis;User Id=sa;Password=password;";
           // ConnectionString = @"Server=CFOSTER-L;Database=Sepsis;User Id=sa;Password=Password1;";
           //ConnectionString = @"Server=KRAUCH-L;Database=Sepsis;User Id=sa;Password=Password1;";
           //ConnectionString = @"Server=MTHERRIAULT-L;Database=Sepsis;User Id=sa;Password=Password1;";
            //ConnectionString = @"Server=TS5-L\SEPSIS;Database=Sepsis;User Id=sa;Password=Password1;";
            LoadCombobox();
            HideDependentFields();
            tempcolor = System.Drawing.ColorTranslator.FromHtml("#E8E8E8");
            result = Color.FromArgb(tempcolor.R, tempcolor.G, tempcolor.B);
            Dropdowncolor();
            MandatoryColorChange_NewCase();

             }
            catch (Exception ex)
            {

            }
        }
        public SepsisCaseDetails_5(int uniqueID, SepsisMaster master)
        {
         try
         {
            InitializeComponent();
            sm = master;
            HideDependentFields();
         
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;

            LoadCombobox();
            _uniqueID = uniqueID;
            LoadEditData(_uniqueID);
            tempcolor = System.Drawing.ColorTranslator.FromHtml("#E8E8E8");
            result = Color.FromArgb(tempcolor.R, tempcolor.G, tempcolor.B);
            Dropdowncolor();
            MandatoryColorChange_NewCase();
           }
            catch (Exception ex)
            {

            }

        }

        int positionCount = 0;
        string format1 = "MM/dd/yyyy HH:mm";
        string format2 = "MM/dd/yyyy";
        int lactatelevel = 0;
        string templactatelevel ="";
        string[] ProgramNames;
        int temp = 0;
        int arraycount = 0;
        string query;
        DataSet ds;
        int count = 0;
        DateTime dDateStart = DateTime.Parse("01/01/1910");
        DateTime dDateEnd = DateTime.Parse("01/01/2100");
        int sCount =0;
        char d;
        decimal templactate;
        string allowedchar = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        string Lactateallowedchar = "0123456789.";
        int Decimaloccurance = 0;
        int ExcludedResonChecked = 0;

        Color tempcolor;
        Color result;
     
          private void txtMRN_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
              try
              {
            System.Text.StringBuilder messageBoxCS = new System.Text.StringBuilder();
            
            messageBoxCS.AppendFormat("{0} : {1}", "Medical Record Error", e.RejectionHint);
            messageBoxCS.AppendLine();
            MessageBox.Show(messageBoxCS.ToString(), "Medical Record Number Error");
                 }
            catch (Exception ex)
            {

            }
        }


          public string IsnullString(string inputString)
          {
              if (inputString == "" || inputString == "Select" || inputString == null)
              {
                  inputString = null;
                  return inputString;
              }
              return inputString;

          }

          public string BlankComboEdit(string inputString)
          {
              if (inputString == "" || inputString == "Select")
              {
                  inputString = "Select";
                  return inputString;
              }
              return inputString;
          }


  


        
         

           


          public bool IsnullDate(string inputString)
          {
            

              if (inputString == "/  /       :" || inputString == "" || inputString == "/  /")
              {
                  return true;
              }
              return false;
            
          }


          private void button_SaveCase_Click(object sender, EventArgs e)
          {

             try
              {


              AllFields A = new AllFields();
              A.UniqueId = _uniqueID;
              if (MandatoryFieldCheck() == false)
              {
                 // A.RecordCompleted = false;
                  A.RecordCompleted = 0;
              }
              else
              {
                 // A.RecordCompleted = true;
                  A.RecordCompleted = 1;
              }



              if (IsnullString(txtId.Text.ToString().Trim()) == null)
              {
                  MessageBox.Show("Please enter Unique Personal Identifier.", "Unique Personal Identifier Error");
                  txtId.Focus();
                  return;
              }
              else
                  A.UniquePersonalIdentifier = txtId.Text.ToString().Trim();


              A.PatientControlNumber = IsnullString(TextBox_PatientCtrlNum.Text.ToString().Trim());

              if (IsnullDate(txtDOB.Text.ToString().Trim()) != true)
                  A.DateofBirth = DateTime.Parse(txtDOB.Text.ToString().Trim());

              A.Gender = IsnullString(Combobox_Gender.SelectedValue.ToString());

              if (checkedListBox_Race.CheckedItems.Count > 0)
              {
                  foreach (object itemChecked in checkedListBox_Race.CheckedItems)
                  {

                      DataRowView castedItem = itemChecked as DataRowView;

                      if (count > 0)
                      {
                          A.Race = A.Race + ":" + castedItem["ComboBox_Key"].ToString();
                      }
                      else
                      {
                          A.Race = castedItem["ComboBox_Key"].ToString();
                      }
                      count++;
                  }

                  count = 0;
              }
              else
              {
                  A.Race = null;
              }
              
              A.Ethnicity = IsnullString(Combobox_Ethnicity.SelectedValue.ToString());
              A.Payor = IsnullString(comboBox_Payor.SelectedValue.ToString());
              A.InsuranceNumber = IsnullString(TextBox_InsuranceNumber.Text.ToString().Trim());
              A.MedicalRecordNumber = IsnullString(txtMRN.Text.ToString().Trim());


              if (IsnullString(TextBox_FacilityIdentifier.Text.ToString().Trim()) == null)
              {
                  MessageBox.Show("Please enter Facility Identifier.", "Facility Identifier Error");
                  TextBox_FacilityIdentifier.Focus();
                  return;
              }
              else
                  A.FacilityIdentifier = IsnullString(TextBox_FacilityIdentifier.Text.ToString().Trim());

              

          
              if (IsnullDate(textBox_AdmissionDateTime.Text.ToString().Trim()) != true)
                  A.AdmissionDatetime = DateTime.Parse(textBox_AdmissionDateTime.Text.ToString().Trim());
          


              A.SourceofAdmission = IsnullString(comboBox_SourceofAdmission.SelectedValue.ToString());

         
              if (IsnullDate(textBox_DischargedDatetime.Text.ToString().Trim()) != true)
                  A.DischargeDatetime = DateTime.Parse(textBox_DischargedDatetime.Text.ToString().Trim());
            

              A.DischargedStatus = IsnullString(comboBox_DischargeStatus.SelectedValue.ToString());
              A.TransferStatus = IsnullString(comboBox_TransferStatus.SelectedValue.ToString());
              A.TransferFacilityIdentifier = IsnullString(textBox_TransferFacilityIdentifier.Text.ToString().Trim());
              A.ProtocolInitiated = "";
              A.ProtocolNotInitiatedReason = "";
              A.ProtocolNotInitiatedAdditionalDetail = "";
              A.ProtocolInitiatedPlace = "";
              A.ProtocolType = "";
              A.ExcludedFromProtocol = IsnullString(comboBox_ExcludedFromProtocol.SelectedValue.ToString());



              if (checkedListBox_ExcludedReason.CheckedItems.Count > 0)
              {
                  foreach (object itemChecked in checkedListBox_ExcludedReason.CheckedItems)
                  {

                      DataRowView castedItem = itemChecked as DataRowView;

                      if (count > 0)
                      {
                          A.ExcludedReason = A.ExcludedReason + ":" + castedItem["ComboBox_Key"].ToString();
                      }
                      else
                      {
                          A.ExcludedReason = castedItem["ComboBox_Key"].ToString();
                      }
                      count++;
                  }
                  count = 0;
              }
              else
              {
                  A.ExcludedReason = null;
              }






              if (IsnullDate(textBox_ExcludedDatetime.Text.ToString().Trim()) != true)
                  A.ExcludedDatetime = DateTime.Parse(textBox_ExcludedDatetime.Text.ToString().Trim());




              if (checkedListBox_ExcludedExplain.CheckedItems.Count > 0)
              {
                  foreach (object itemChecked in checkedListBox_ExcludedExplain.CheckedItems)
                  {

                      DataRowView castedItem = itemChecked as DataRowView;

                      if (count > 0)
                      {
                          A.ExcludedExplain = A.ExcludedExplain + ":" + castedItem["ComboBox_Key"].ToString();
                      }
                      else
                      {
                          A.ExcludedExplain = castedItem["ComboBox_Key"].ToString();
                      }
                      count++;
                  }
                  count = 0;
              }
              else
              {
                  A.ExcludedExplain = null;
              }

              if (IsnullDate(textBox_ArrivalDatetime.Text.ToString().Trim()) != true)
                  A.EarliestDateTime = DateTime.Parse(textBox_ArrivalDatetime.Text.ToString().Trim());
              if (IsnullDate(textbox_TriageDatetime.Text.ToString().Trim()) != true)
                  A.TriageDatetime = DateTime.Parse(textbox_TriageDatetime.Text.ToString().Trim());
              A.SevereSepsisPresent = IsnullString(comboBox_SevereSepsisPresent.SelectedValue.ToString());
              if (IsnullDate(textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim()) != true)
                  A.SevereSepsisPresentationDatetime = DateTime.Parse(textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim());
              A.SepticShockPresent = IsnullString(comboBox_SepticShockPresent.SelectedValue.ToString());
              if (IsnullDate(textBox_septicShockPresentationDatetime.Text.ToString().Trim()) != true)
                  A.SepticShockPresentDatetime = DateTime.Parse(textBox_septicShockPresentationDatetime.Text.ToString().Trim());
          
              A.LeftEDDatetime = DateTime.Parse("01/01/1900");
              A.DestinationAfterED = "";
              A.InitialLactateLevelCollection = IsnullString(comboBox_InitialLactateLevelCollection.SelectedValue.ToString());
              if (IsnullDate(textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim()) != true)
                  A.InitialLactateLevelCollectionDatetime = DateTime.Parse(textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim());


              A.InitialLactateLevel = IsnullString(textBox_InitialLactateLevel.Text.ToString().Trim());
         



              A.InitialLactateLevelUnit = "";
              A.RepeatLactateLevelCollection = IsnullString(comboBox_RepeatLactateLevelCollection.SelectedValue.ToString());
              if (IsnullDate(textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim()) != true)
                  A.RepeatLactateLevelCollectionDatetime = DateTime.Parse(textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim());
              A.BloodCultureCollection = IsnullString(comboBox_BloodCultureCollection.SelectedValue.ToString());
              A.BloodCultureCollectionAcceptableDelay = IsnullString(comboBox_BloodCultureCollectionAcceptableDelay.SelectedValue.ToString());
              if (IsnullDate(textBox_BloodCultureCollectionDatetime.Text.ToString().Trim()) != true)
                  A.BloodCultureCollectionDatetime = DateTime.Parse(textBox_BloodCultureCollectionDatetime.Text.ToString().Trim());
              A.BloodCultureResult = "";
              A.BloodCulturePathogen = "";
              A.AntibioticAdministration = IsnullString(comboBox_AntibioticAdministration.SelectedValue.ToString());
              A.AntibioticAdministrationSelection = IsnullString(comboBox_AntibioticAdministrationSelection.SelectedValue.ToString());
              if (IsnullDate(textBox_AntibioticAdministrationDatetime.Text.ToString().Trim()) != true)
                  A.AntibioticAdministrationDatetime = DateTime.Parse(textBox_AntibioticAdministrationDatetime.Text.ToString().Trim());
              A.AdultCrystalloidFluidAdministration = IsnullString(comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString());
              A.PediatricCrystalloidFluidAdministration = IsnullString(comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString());
              if (IsnullDate(textBox_CrystalloidFluidAdministrationDatetime.Text.ToString().Trim()) != true)
                  A.CrystalloidFluidAdministrationDatetime = DateTime.Parse(textBox_CrystalloidFluidAdministrationDatetime.Text.ToString().Trim());
              A.InitialHypotension = IsnullString(comboBox_InitialHypotension.SelectedValue.ToString());
              A.PersistentHypotension = IsnullString(comboBox_PersistentHypotension.SelectedValue.ToString());
              A.VasopressorAdministration = IsnullString(comboBox_VasopressorAdministration.SelectedValue.ToString());
              if (IsnullDate(textBox_VasopressorAdministrationDatetime.Text.ToString().Trim()) != true)
                  A.VasopressorAdministrationDatetime = DateTime.Parse(textBox_VasopressorAdministrationDatetime.Text.ToString().Trim());
              A.BesideCardiovascularUltrasound = "";
             
              A.BesideCardiovascularUltrasoundDatetime = DateTime.Parse("01/01/1900");
              A.CapillaryRefillExamination = "";
            
              A.CapillaryRefillExaminationDatetime = DateTime.Parse("01/01/1900");
              A.CardiopulmonaryEvaluation = "";
              
              A.CardiopulmonaryEvaluationDatetime = DateTime.Parse("01/01/1900");
              A.PassiveLegRaiseExamination = "";
              
              A.PassiveLegRaiseExaminationDatetime = DateTime.Parse("01/01/1900");
              A.PeripheralPulseEvaluation = "";
            
              A.PeripheralPulseEvaluationDatetime = DateTime.Parse("01/01/1900");
              A.SkinExamination = "";
             
              A.SkinExaminationDatetime = DateTime.Parse("01/01/1900");
              A.CentralVenousOxygenMeasurement = "";
           
              A.CentralVenousOxygenMeasurementDatetime = DateTime.Parse("01/01/1900");
              A.CentralVenousPressureMeasurement = "";
        
              A.CentralVenousPressureMeasurementDatetime = DateTime.Parse("01/01/1900");
              A.FluidChallengePerformed = "";
            
              A.FluidChallengePerformedDatetime = DateTime.Parse("01/01/1900");
              A.VitalSignsReview = "";
          
              A.VitalSignsReviewDatetime = DateTime.Parse("01/01/1900");
              A.PlateletCount = IsnullString(comboBox_PlateletCount.SelectedValue.ToString());
              A.Bandemia = IsnullString(comboBox_Bandemia.SelectedValue.ToString());
              A.LoweRespiratoryInfection = IsnullString(comboBox_LowerRespiratoryInfection.SelectedValue.ToString());
              A.AlteredMentalStatus = IsnullString(comboBox_AlteredMentalStatus.SelectedValue.ToString());
              A.InfectionEtiology = IsnullString(comboBox_InfectionEtiology.SelectedValue.ToString());
              A.SiteofInfection = IsnullString(comboBox_SiteofInfection.SelectedValue.ToString());
              A.MechanicalVentilation = IsnullString(comboBox_MechanicalVentilation.SelectedValue.ToString());
              if (IsnullDate(textBox_MechanicalVentilationDatetime.Text.ToString().Trim()) != true)
                  A.MechanicalVentilationDatetime = DateTime.Parse(textBox_MechanicalVentilationDatetime.Text.ToString().Trim());
              A.ICU = IsnullString(comboBox_ICU.SelectedValue.ToString());
              if (IsnullDate(textBox_ICUAdmissionDatetime.Text.ToString().Trim()) != true)
                  A.ICUAdmissionDatetime = DateTime.Parse(textBox_ICUAdmissionDatetime.Text.ToString().Trim());
              if (IsnullDate(textBox_ICUDischargeDatetime.Text.ToString().Trim()) != true)
                  A.ICUDischargeDatetime = DateTime.Parse(textBox_ICUDischargeDatetime.Text.ToString().Trim());
              A.ChronicRespiratoryFailure = IsnullString(comboBox_ChronicRespiratoryFailure.SelectedValue.ToString());
              A.AIDS = IsnullString(comboBox_AIDSDisease.SelectedValue.ToString());
              A.MetastaticCancer = IsnullString(comboBox_MetastaticCancer.SelectedValue.ToString());
              A.Lymphoma = IsnullString(comboBox_Lymphoma.SelectedValue.ToString());
              A.ImmuneModifyingMedications = IsnullString(comboBox_ImmuneModifyingMedications.SelectedValue.ToString());
              A.CongestiveHeartFailure = IsnullString(comboBox_CongestiveHeartFailure.SelectedValue.ToString());
              A.ChronicRenalFailure = IsnullString(comboBox_ChronicRenalFailure.SelectedValue.ToString());
              A.ChronicLiverDisease = IsnullString(comboBox_ChronicLiverDisease.SelectedValue.ToString());
              A.Diabetes = IsnullString(comboBox_Diabetes.SelectedValue.ToString());
              A.OrganTransplant = IsnullString(comboBox_OrganTransplant.SelectedValue.ToString());
              if (IsnullDate(textbox_InitialHypotensionDateTime.Text.ToString().Trim()) != true)
                  A.InitialHypotensionDatetime = DateTime.Parse(textbox_InitialHypotensionDateTime.Text.ToString().Trim());

              A.ElevatedLactateReason = IsnullString(comboBox_ElevatedLactateReason.SelectedValue.ToString());
              
              A.SepsisIdentificationPlace = IsnullString(Combobox_SepsisIdentificationPlace.SelectedValue.ToString());


              A.RepeatVolumeStatusandTissuePerfusionAssessmentPerformed = IsnullString(comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.SelectedValue.ToString());

              if (IsnullDate(textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Text.ToString().Trim()) != true)
                  A.RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime = DateTime.Parse(textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Text.ToString().Trim());
         

              A.Year = "2018";
              A.Version = "5.1";
              A.Quarter = "";
              A.DateCreated = DateTime.Now;
         
              A.CSVGenerated = 0;
         

              if (_uniqueID == 0)
              {

                
                  using (Conn = new OdbcConnection(ConnectionString))
                  {
                      Conn.Open();

                  query = "{call Sepsis_Insert(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
                       
                      using (OdbcCommand Sqlcmd = new OdbcCommand())
                      {

                          Sqlcmd.CommandText = query;
                          Sqlcmd.CommandType = CommandType.StoredProcedure;
                          Sqlcmd.Connection = Conn;



                          Sqlcmd.Parameters.Add(new OdbcParameter("UniquePersonalIdentifier", A.UniquePersonalIdentifier));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PatientControlNumber ", A.PatientControlNumber));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DateofBirth", A.DateofBirth));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Gender", A.Gender));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Race", A.Race));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Ethnicity", A.Ethnicity));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Payor", A.Payor));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InsuranceNumber", A.InsuranceNumber));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MedicalRecordNumber", A.MedicalRecordNumber));
                          Sqlcmd.Parameters.Add(new OdbcParameter("FacilityIdentifier", A.FacilityIdentifier));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AdmissionDatetime", A.AdmissionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SourceofAdmission", A.SourceofAdmission));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DischargeDatetime", A.DischargeDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DischargedStatus", A.DischargedStatus));
                          Sqlcmd.Parameters.Add(new OdbcParameter("TransferStatus", A.TransferStatus));
                          Sqlcmd.Parameters.Add(new OdbcParameter("TransferFacilityIdentifier", A.TransferFacilityIdentifier));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolInitiated", A.ProtocolInitiated));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolNotInitiatedReason", A.ProtocolNotInitiatedReason));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolNotInitiatedAdditionalDetail", A.ProtocolNotInitiatedAdditionalDetail));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolInitiatedPlace", A.ProtocolInitiatedPlace));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolType", A.ProtocolType));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedFromProtocol", A.ExcludedFromProtocol));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedReason", A.ExcludedReason));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedDatetime", A.ExcludedDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedExplain", A.ExcludedExplain));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ArrivalDateTime", A.EarliestDateTime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("TriageDatetime", A.TriageDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SevereSepsisPresent", A.SevereSepsisPresent));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SevereSepsisPresentationDatetime", A.SevereSepsisPresentationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SepticShockPresent", A.SepticShockPresent));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SepticShockPresentDatetime", A.SepticShockPresentDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("LeftEDDatetime", A.LeftEDDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DestinationAfterED", A.DestinationAfterED));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevelCollection", A.InitialLactateLevelCollection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevelCollectionDatetime", A.InitialLactateLevelCollectionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevel", A.InitialLactateLevel));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevelUnit", A.InitialLactateLevelUnit));
                          Sqlcmd.Parameters.Add(new OdbcParameter("RepeatLactateLevelCollection", A.RepeatLactateLevelCollection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("RepeatLactateLevelCollectionDatetime", A.RepeatLactateLevelCollectionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureCollection", A.BloodCultureCollection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureCollectionAcceptableDelay", A.BloodCultureCollectionAcceptableDelay));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureCollectionDatetime", A.BloodCultureCollectionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureResult", A.BloodCultureResult));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCulturePathogen", A.BloodCulturePathogen));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AntibioticAdministration", A.AntibioticAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AntibioticAdministrationSelection", A.AntibioticAdministrationSelection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AntibioticAdministrationDatetime", A.AntibioticAdministrationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AdultCrystalloidFluidAdministration", A.AdultCrystalloidFluidAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PediatricCrystalloidFluidAdministration", A.PediatricCrystalloidFluidAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CrystalloidFluidAdministrationDatetime", A.CrystalloidFluidAdministrationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialHypotension", A.InitialHypotension));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PersistentHypotension", A.PersistentHypotension));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VasopressorAdministration", A.VasopressorAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VasopressorAdministrationDatetime", A.VasopressorAdministrationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BesideCardiovascularUltrasound", A.BesideCardiovascularUltrasound));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BesideCardiovascularUltrasoundDatetime", A.BesideCardiovascularUltrasoundDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CapillaryRefillExamination", A.CapillaryRefillExamination));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CapillaryRefillExaminationDatetime", A.CapillaryRefillExaminationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CardiopulmonaryEvaluation", A.CardiopulmonaryEvaluation));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CardiopulmonaryEvaluationDatetime", A.CardiopulmonaryEvaluationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PassiveLegRaiseExamination", A.PassiveLegRaiseExamination));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PassiveLegRaiseExaminationDatetime", A.PassiveLegRaiseExaminationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PeripheralPulseEvaluation", A.PeripheralPulseEvaluation));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PeripheralPulseEvaluationDatetime", A.PeripheralPulseEvaluationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SkinExamination", A.SkinExamination));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SkinExaminationDatetime", A.SkinExaminationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousOxygenMeasurement", A.CentralVenousOxygenMeasurement));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousOxygenMeasurementDatetime", A.CentralVenousOxygenMeasurementDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousPressureMeasurement", A.CentralVenousPressureMeasurement));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousPressureMeasurementDatetime", A.CentralVenousPressureMeasurementDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("FluidChallengePerformed", A.FluidChallengePerformed));
                          Sqlcmd.Parameters.Add(new OdbcParameter("FluidChallengePerformedDatetime", A.FluidChallengePerformedDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VitalSignsReview", A.VitalSignsReview));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VitalSignsReviewDatetime", A.VitalSignsReviewDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PlateletCount", A.PlateletCount));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Bandemia", A.Bandemia));
                          Sqlcmd.Parameters.Add(new OdbcParameter("LoweRespiratoryInfection", A.LoweRespiratoryInfection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AlteredMentalStatus", A.AlteredMentalStatus));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InfectionEtiology", A.InfectionEtiology));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SiteofInfection", A.SiteofInfection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MechanicalVentilation", A.MechanicalVentilation));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MechanicalVentilationDatetime", A.MechanicalVentilationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ICU", A.ICU));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ICUAdmissionDatetime", A.ICUAdmissionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ICUDischargeDatetime", A.ICUDischargeDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ChronicRespiratoryFailure", A.ChronicRespiratoryFailure));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AIDS", A.AIDS));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MetastaticCancer", A.MetastaticCancer));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Lymphoma", A.Lymphoma));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ImmuneModifyingMedications", A.ImmuneModifyingMedications));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CongestiveHeartFailure", A.CongestiveHeartFailure));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ChronicRenalFailure", A.ChronicRenalFailure));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ChronicLiverDisease", A.ChronicLiverDisease));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Diabetes", A.Diabetes));
                          Sqlcmd.Parameters.Add(new OdbcParameter("OrganTransplant", A.OrganTransplant));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialHypotensionDatetime", A.InitialHypotensionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("elevatedlactatereason", A.ElevatedLactateReason));
                          Sqlcmd.Parameters.Add(new OdbcParameter("sepsisidentificationplace", A.SepsisIdentificationPlace));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Repeat_Volume_Status_and_Tissue_Perfusion_Assessment_Performed", A.RepeatVolumeStatusandTissuePerfusionAssessmentPerformed));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Repeat_Volume_Status_and_Tissue_Perfusion_Assessment_Performed_Datetime", A.RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Version", A.Version));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Year", A.Year));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Quarter", A.Quarter));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DateCreated", A.DateCreated));
                          Sqlcmd.Parameters.Add(new OdbcParameter("RecordCompleted", A.RecordCompleted));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CSVGenerated", A.CSVGenerated));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CSVGeneratedDatetime", A.CSVGeneratedDatetime));


                      

                          Sqlcmd.ExecuteNonQuery();

                      }

                      Conn.Close();

                    
                          if (A.RecordCompleted == 0)
                      {
                         
                          MessageBox.Show("Record saved successfully and marked as incomplete because all Mandatory fields are not completed", "Sepsis Data Entry");
                       
                      }
                      else
                      {
                         
                          MessageBox.Show("Record saved successfully and marked as complete.", "Sepsis Data Entry");
                      }

                      sm.LoadGrid();
                      this.Close();
                      sm.Show();


                  }
              }
              else
              {


               
                 
                  using (Conn = new OdbcConnection(ConnectionString))
                  {
                      Conn.Open();
                       query = "{call Sepsis_Update(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
                      
                    
                      using (OdbcCommand Sqlcmd = new OdbcCommand())
                      {

                          Sqlcmd.CommandText = query;
                          Sqlcmd.CommandType = CommandType.StoredProcedure;
                          Sqlcmd.Connection = Conn;

                          Sqlcmd.Parameters.Add(new OdbcParameter("id", A.UniqueId));
                          Sqlcmd.Parameters.Add(new OdbcParameter("UniquePersonalIdentifier", A.UniquePersonalIdentifier));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PatientControlNumber ", A.PatientControlNumber));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DateofBirth", A.DateofBirth));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Gender", A.Gender));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Race", A.Race));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Ethnicity", A.Ethnicity));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Payor", A.Payor));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InsuranceNumber", A.InsuranceNumber));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MedicalRecordNumber", A.MedicalRecordNumber));
                          Sqlcmd.Parameters.Add(new OdbcParameter("FacilityIdentifier", A.FacilityIdentifier));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AdmissionDatetime", A.AdmissionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SourceofAdmission", A.SourceofAdmission));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DischargeDatetime", A.DischargeDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DischargedStatus", A.DischargedStatus));
                          Sqlcmd.Parameters.Add(new OdbcParameter("TransferStatus", A.TransferStatus));
                          Sqlcmd.Parameters.Add(new OdbcParameter("TransferFacilityIdentifier", A.TransferFacilityIdentifier));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolInitiated", A.ProtocolInitiated));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolNotInitiatedReason", A.ProtocolNotInitiatedReason));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolNotInitiatedAdditionalDetail", A.ProtocolNotInitiatedAdditionalDetail));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolInitiatedPlace", A.ProtocolInitiatedPlace));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ProtocolType", A.ProtocolType));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedFromProtocol", A.ExcludedFromProtocol));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedReason", A.ExcludedReason));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedDatetime", A.ExcludedDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ExcludedExplain", A.ExcludedExplain));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ArrivalDateTime", A.EarliestDateTime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("TriageDatetime", A.TriageDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SevereSepsisPresent", A.SevereSepsisPresent));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SevereSepsisPresentationDatetime", A.SevereSepsisPresentationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SepticShockPresent", A.SepticShockPresent));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SepticShockPresentDatetime", A.SepticShockPresentDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("LeftEDDatetime", A.LeftEDDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("DestinationAfterED", A.DestinationAfterED));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevelCollection", A.InitialLactateLevelCollection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevelCollectionDatetime", A.InitialLactateLevelCollectionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevel", A.InitialLactateLevel));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialLactateLevelUnit", A.InitialLactateLevelUnit));
                          Sqlcmd.Parameters.Add(new OdbcParameter("RepeatLactateLevelCollection", A.RepeatLactateLevelCollection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("RepeatLactateLevelCollectionDatetime", A.RepeatLactateLevelCollectionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureCollection", A.BloodCultureCollection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureCollectionAcceptableDelay", A.BloodCultureCollectionAcceptableDelay));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureCollectionDatetime", A.BloodCultureCollectionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCultureResult", A.BloodCultureResult));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BloodCulturePathogen", A.BloodCulturePathogen));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AntibioticAdministration", A.AntibioticAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AntibioticAdministrationSelection", A.AntibioticAdministrationSelection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AntibioticAdministrationDatetime", A.AntibioticAdministrationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AdultCrystalloidFluidAdministration", A.AdultCrystalloidFluidAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PediatricCrystalloidFluidAdministration", A.PediatricCrystalloidFluidAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CrystalloidFluidAdministrationDatetime", A.CrystalloidFluidAdministrationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialHypotension", A.InitialHypotension));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PersistentHypotension", A.PersistentHypotension));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VasopressorAdministration", A.VasopressorAdministration));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VasopressorAdministrationDatetime", A.VasopressorAdministrationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BesideCardiovascularUltrasound", A.BesideCardiovascularUltrasound));
                          Sqlcmd.Parameters.Add(new OdbcParameter("BesideCardiovascularUltrasoundDatetime", A.BesideCardiovascularUltrasoundDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CapillaryRefillExamination", A.CapillaryRefillExamination));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CapillaryRefillExaminationDatetime", A.CapillaryRefillExaminationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CardiopulmonaryEvaluation", A.CardiopulmonaryEvaluation));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CardiopulmonaryEvaluationDatetime", A.CardiopulmonaryEvaluationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PassiveLegRaiseExamination", A.PassiveLegRaiseExamination));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PassiveLegRaiseExaminationDatetime", A.PassiveLegRaiseExaminationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PeripheralPulseEvaluation", A.PeripheralPulseEvaluation));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PeripheralPulseEvaluationDatetime", A.PeripheralPulseEvaluationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SkinExamination", A.SkinExamination));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SkinExaminationDatetime", A.SkinExaminationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousOxygenMeasurement", A.CentralVenousOxygenMeasurement));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousOxygenMeasurementDatetime", A.CentralVenousOxygenMeasurementDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousPressureMeasurement", A.CentralVenousPressureMeasurement));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CentralVenousPressureMeasurementDatetime", A.CentralVenousPressureMeasurementDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("FluidChallengePerformed", A.FluidChallengePerformed));
                          Sqlcmd.Parameters.Add(new OdbcParameter("FluidChallengePerformedDatetime", A.FluidChallengePerformedDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VitalSignsReview", A.VitalSignsReview));
                          Sqlcmd.Parameters.Add(new OdbcParameter("VitalSignsReviewDatetime", A.VitalSignsReviewDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("PlateletCount", A.PlateletCount));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Bandemia", A.Bandemia));
                          Sqlcmd.Parameters.Add(new OdbcParameter("LoweRespiratoryInfection", A.LoweRespiratoryInfection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AlteredMentalStatus", A.AlteredMentalStatus));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InfectionEtiology", A.InfectionEtiology));
                          Sqlcmd.Parameters.Add(new OdbcParameter("SiteofInfection", A.SiteofInfection));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MechanicalVentilation", A.MechanicalVentilation));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MechanicalVentilationDatetime", A.MechanicalVentilationDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ICU", A.ICU));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ICUAdmissionDatetime", A.ICUAdmissionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ICUDischargeDatetime", A.ICUDischargeDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ChronicRespiratoryFailure", A.ChronicRespiratoryFailure));
                          Sqlcmd.Parameters.Add(new OdbcParameter("AIDS", A.AIDS));
                          Sqlcmd.Parameters.Add(new OdbcParameter("MetastaticCancer", A.MetastaticCancer));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Lymphoma", A.Lymphoma));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ImmuneModifyingMedications", A.ImmuneModifyingMedications));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CongestiveHeartFailure", A.CongestiveHeartFailure));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ChronicRenalFailure", A.ChronicRenalFailure));
                          Sqlcmd.Parameters.Add(new OdbcParameter("ChronicLiverDisease", A.ChronicLiverDisease));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Diabetes", A.Diabetes));
                          Sqlcmd.Parameters.Add(new OdbcParameter("OrganTransplant", A.OrganTransplant));
                          Sqlcmd.Parameters.Add(new OdbcParameter("InitialHypotensionDatetime", A.InitialHypotensionDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("elevatedlactatereason", A.ElevatedLactateReason));
                          Sqlcmd.Parameters.Add(new OdbcParameter("sepsisidentificationplace", A.SepsisIdentificationPlace));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Repeat_Volume_Status_and_Tissue_Perfusion_Assessment_Performed", A.RepeatVolumeStatusandTissuePerfusionAssessmentPerformed));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Repeat_Volume_Status_and_Tissue_Perfusion_Assessment_Performed_Datetime", A.RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Version", A.Version));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Year", A.Year));
                          Sqlcmd.Parameters.Add(new OdbcParameter("Quarter", A.Quarter));
                          Sqlcmd.Parameters.Add(new OdbcParameter("RecordCompleted", A.RecordCompleted));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CSVGenerated", A.CSVGenerated));
                          Sqlcmd.Parameters.Add(new OdbcParameter("CSVGeneratedDatetime", A.CSVGeneratedDatetime));

                          Sqlcmd.ExecuteNonQuery();

                      
                              if (A.RecordCompleted == 0)
                          {

                              MessageBox.Show("Record updated successfully and marked as incomplete because all Mandatory fields are not completed.", "Sepsis Data Entry");

                          }
                          else
                          {

                              MessageBox.Show("Record updated successfully and marked as complete.", "Sepsis Data Entry");
                          }

                        
                              Conn.Close();
                          sm.LoadGrid();
                          this.Close();
                          sm.Show();


                      }
                  }
              }

          

                  }
            catch (Exception ex)
            {
                int line = 0;

                StackTrace st = new StackTrace(true);
                for (int i = 0; i < st.FrameCount; i++)
                {
                    // Note that high up the call stack, there is only
                    // one stack frame.
                    StackFrame sf = st.GetFrame(i);
                    //Console.WriteLine();
                   // Console.WriteLine("High up the call stack, Method: {0}",
                      var frame =  sf.GetMethod();

                   // Console.WriteLine("High up the call stack, Line Number: {0}",
                      line =  sf.GetFileLineNumber();

                      if (line > 0)
                          break;

                }


                //var st = new StackTrace(ex, true);
                //// Get the top stack frame
                //var frame = st.GetFrame(0);
                //// Get the line number from the stack frame
                //var line = frame.GetFileLineNumber();

                using (Conn = new OdbcConnection(ConnectionString))
                {
                    Conn.Open();

                    query = "{call Sepsis_ErrorLog(?,?,?,?)}";

                    //using (SqlCommand Sqlcmd = new SqlCommand())
                    using (OdbcCommand Sqlcmd = new OdbcCommand())
                    {

                        Sqlcmd.CommandText = query;
                        Sqlcmd.CommandType = CommandType.StoredProcedure;
                        Sqlcmd.Connection = Conn;

                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Line",line));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Desc", ex.Message));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Form", "SepsisCaseDetails_5.cs"));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Datetime", DateTime.Now));
                 

                        Sqlcmd.ExecuteNonQuery();

        

                      
                        Conn.Close();
                  


                    }
                }



               //MessageBox.Show(ex.Message);
            }
          }


        
          public bool validateDatetime(string inputString)
          
            {
              
              
              DateTime dDate;
          

              if (inputString == "/  /       :")
              {
                  return true;
              }
              if (DateTime.TryParseExact(inputString, format1, CultureInfo.InvariantCulture,
        System.Globalization.DateTimeStyles.None, out dDate))
              //if (DateTime.TryParse(inputString, out dDate))
              {


                  //int result = DateTime.Compare(dDate, dDateStart);

                  //if (result < 0)
                  //    return false;
                  //else
                      return true;

                 // String.Format("{MM/dd/yyyy HH:mm}", dDate);
                  
              }
              else
              {
                  return false;
              }

             
          }



          public bool validateDate(string inputString)
          {


              DateTime dDate;


              if (inputString == "/  /")
              {
                  return true;
              }
              if (DateTime.TryParseExact(inputString, format2, CultureInfo.InvariantCulture,
        System.Globalization.DateTimeStyles.None, out dDate))
          
              {
                  return true;

              }
              else
              {
                  return false;
              }


          }


          public bool validateDatetimeLimit(string inputString1 ,string inputString2)
            {

              DateTime dDate1;
              DateTime dDate2;
             // inputString = inputString.Substring(0, 10);

              if (inputString1 == "/  /       :")
              {
                  return true;
              }

              if (inputString2 == "/  /       :")
              {
                  return true;
              }
              if (DateTime.TryParse(inputString1, out dDate1))
              {
                  if (DateTime.TryParse(inputString2, out dDate2))
                  {


                      int result1 = DateTime.Compare(dDate1, dDate2);
                     //int result2 = DateTime.Compare(dDate, dDateEnd);

                      if (result1 < 0)
                          return false;
                      else
                          return true;
                  }
                  return true;
                  // String.Format("{MM/dd/yyyy HH:mm}", dDate);

              }
              else
              {
                  return false;
              }


          }

          public bool LactateCharcheckCheck(string inputString)
          {

              if (!inputString.All(Lactateallowedchar.Contains))
              {
                  return true;
                  // Not allowed char detected
              }
              else
              {
                  return false;
              }


           
          }




          public Color MandatoryColor(Color c)
          {
              Color light = ControlPaint.Light(c);

              light = ControlPaint.Light(light);
              light = ControlPaint.Light(light);
           
              return light;
          }


          public Color ErrorColor(Color c)
          {
              Color light = ControlPaint.Light(c);


              return light;
          }



          private void SepsisCaseDetails_5_Load(object sender, EventArgs e)
          {

           try
            {

              this.tabControl.SelectedIndex = 0;
           
              checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.Gray);
              textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.Gray);
              checkedListBox_ExcludedExplain.BackColor = MandatoryColor(Color.Gray);
              textbox_TriageDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_septicShockPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
             
              comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
              textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
           
              comboBox_RepeatLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
              comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
              comboBox_BloodCultureCollectionAcceptableDelay.BackColor = MandatoryColor(Color.Gray);
              textBox_BloodCultureCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
           
              comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);
              comboBox_ElevatedLactateReason.BackColor = MandatoryColor(Color.Gray);
              comboBox_AntibioticAdministrationSelection.BackColor = MandatoryColor(Color.Gray);
              textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
              textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray);
              comboBox_PersistentHypotension.BackColor = MandatoryColor(Color.Gray);
              comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
        
              comboBox_VasopressorAdministration.BackColor = MandatoryColor(Color.Gray);
              textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
          
              textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_ICUAdmissionDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_ICUDischargeDatetime.BackColor = MandatoryColor(Color.Gray);
             
              textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
              textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
              textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.Gray);




              foreach (Control control in tabPage1.Controls)
              {


                  if (control is ComboBox)
                  {
                      ComboBox box;

                      box = (ComboBox)control;
                      box.SetHorizontalExtent();

                  }
              }
          
              foreach (Control control in tabPage3.Controls)
              {


                  if (control is ComboBox)
                  {
                      ComboBox box;

                      box = (ComboBox)control;
                      box.SetHorizontalExtent();

                  }
              }


              txtId.Focus();


            }
            catch (Exception ex)
            {

            }

          }

        public void LoadCombobox()
        {
            try
            {
              


               ds = new DataSet();
           
               query = "{call Sepsis_SelectCombo (?)}";

           
              using (Conn = new OdbcConnection(ConnectionString))
              {
                  Conn.Open();


                  using (OdbcCommand Sqlcmd = new OdbcCommand())
                  {

                      Sqlcmd.CommandText = query;
                      Sqlcmd.CommandType = CommandType.StoredProcedure;

                      Sqlcmd.Connection = Conn;


                      Sqlcmd.Parameters.Add(new OdbcParameter("Version", "5.1"));

                      OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter(Sqlcmd);
                      dbDataAdapter.Fill(ds);
                  }


               


                  Conn.Close();
              }

              ds.Tables[0].TableName = "Gender";
              ds.Tables[1].TableName = "Payor";
              ds.Tables[2].TableName = "Race";
              ds.Tables[3].TableName = "SepsisIdentificationPlace";

              ds.Tables[4].TableName = "Ethnicity";
              ds.Tables[5].TableName = "SourceOfAdmission";
              ds.Tables[6].TableName = "DischargedStatus";
              ds.Tables[7].TableName = "Transfer";
              ds.Tables[8].TableName = "ExcludedFromProtocol";
              ds.Tables[9].TableName = "ExcludedReason";
              ds.Tables[10].TableName = "ExcludedExplain";
              ds.Tables[11].TableName = "SevereSepsisPresent";
              ds.Tables[12].TableName = "SepticShockPresent";
              ds.Tables[13].TableName = "InitialLactateLevelCollection";
              ds.Tables[14].TableName = "ElevatedLactateReason";
              ds.Tables[15].TableName = "RepeatLactateLevelCollection";
              ds.Tables[16].TableName = "BloodCultureCollection";
              ds.Tables[17].TableName = "BloodCultureCollectionAcceptableDelay";
              ds.Tables[18].TableName = "AntibioticAdministration";
              ds.Tables[19].TableName = "AntibioticAdministrationSelection";
              ds.Tables[20].TableName = "AdultCrystalloidFluidAdministration";
              ds.Tables[21].TableName = "PediatricCrystalloidFluidAdministration";
              ds.Tables[22].TableName = "InitialHypotension";
              ds.Tables[23].TableName = "PersistentHypotension";
              ds.Tables[24].TableName = "VasopressorAdministration";
              ds.Tables[25].TableName = "RepeatVolumeStatusandTissuePerfusionAssessmentPerformed";
              ds.Tables[26].TableName = "PlateletCount";
              ds.Tables[27].TableName = "LowerRespiratoryInfection";
              ds.Tables[28].TableName = "AlteredMentalStatus";
              ds.Tables[29].TableName = "InfectionEtiology";
              ds.Tables[30].TableName = "SiteofInfection";
              ds.Tables[31].TableName = "MechanicalVentilation";
              ds.Tables[32].TableName = "ICU";
              ds.Tables[33].TableName = "ChronicRespiratoryFailure";
              ds.Tables[34].TableName = "AIDSDisease";
              ds.Tables[35].TableName = "MetastaticCancer";
              ds.Tables[36].TableName = "MultipleMyeloma";
              ds.Tables[37].TableName = "ImmuneModifyingMedications";
              ds.Tables[38].TableName = "CongestiveHeartFailure";
              ds.Tables[39].TableName = "ChronicRenalFailure";
              ds.Tables[40].TableName = "ChronicLiverDisease";
              ds.Tables[41].TableName = "Diabetes";
              ds.Tables[42].TableName = "OrganTransplant";
              ds.Tables[43].TableName = "Bandemia";


              Combobox_Gender.DataSource = ds.Tables["Gender"];
              Combobox_Gender.ValueMember = "ComboBox_Key";
              Combobox_Gender.DisplayMember = "ComboBox_Value";
              Combobox_Gender.SelectedIndex = 0;


              comboBox_Payor.DataSource = ds.Tables["Payor"];
              comboBox_Payor.ValueMember = "ComboBox_Key";
              comboBox_Payor.DisplayMember = "ComboBox_Value";
              comboBox_Payor.SelectedIndex = 0;


              checkedListBox_Race.DataSource = ds.Tables["Race"];
              checkedListBox_Race.ValueMember = "ComboBox_Key";
              checkedListBox_Race.DisplayMember = "ComboBox_Value";
              checkedListBox_Race.SelectedIndex = 0;


              Combobox_SepsisIdentificationPlace.DataSource = ds.Tables["SepsisIdentificationPlace"];
              Combobox_SepsisIdentificationPlace.ValueMember = "ComboBox_Key";
              Combobox_SepsisIdentificationPlace.DisplayMember = "ComboBox_Value";
              Combobox_SepsisIdentificationPlace.SelectedIndex = 0;

              
              Combobox_Ethnicity.DataSource = ds.Tables["Ethnicity"];
              Combobox_Ethnicity.ValueMember = "ComboBox_Key";
              Combobox_Ethnicity.DisplayMember = "ComboBox_Value";
              Combobox_Ethnicity.SelectedIndex = 0;

              comboBox_SourceofAdmission.DataSource = ds.Tables["SourceOfAdmission"];
              comboBox_SourceofAdmission.ValueMember = "ComboBox_Key";
              comboBox_SourceofAdmission.DisplayMember = "ComboBox_Value";
              comboBox_SourceofAdmission.SelectedIndex = 0;


              comboBox_DischargeStatus.DataSource = ds.Tables["DischargedStatus"];
              comboBox_DischargeStatus.ValueMember = "ComboBox_Key";
              comboBox_DischargeStatus.DisplayMember = "ComboBox_Value";
              comboBox_DischargeStatus.SelectedIndex = 0;

      

             
               comboBox_TransferStatus.DataSource = ds.Tables["Transfer"];
               comboBox_TransferStatus.ValueMember = "ComboBox_Key";
               comboBox_TransferStatus.DisplayMember = "ComboBox_Value";
               comboBox_TransferStatus.SelectedIndex = 0;

              
                 comboBox_ExcludedFromProtocol.DataSource = ds.Tables["ExcludedFromProtocol"];
                 comboBox_ExcludedFromProtocol.ValueMember = "ComboBox_Key";
                 comboBox_ExcludedFromProtocol.DisplayMember = "ComboBox_Value";
                 comboBox_ExcludedFromProtocol.SelectedIndex = 0;

              
                 checkedListBox_ExcludedReason.DataSource = ds.Tables["ExcludedReason"];
                 checkedListBox_ExcludedReason.ValueMember = "ComboBox_Key";
                 checkedListBox_ExcludedReason.DisplayMember = "ComboBox_Value";
                 checkedListBox_ExcludedReason.SelectedIndex = 0;

              
                 checkedListBox_ExcludedExplain.DataSource = ds.Tables["ExcludedExplain"];
                 checkedListBox_ExcludedExplain.ValueMember = "ComboBox_Key";
                 checkedListBox_ExcludedExplain.DisplayMember = "ComboBox_Value";
                 checkedListBox_ExcludedExplain.SelectedIndex = 0;

              
                 comboBox_SevereSepsisPresent.DataSource = ds.Tables["SevereSepsisPresent"];
                 comboBox_SevereSepsisPresent.ValueMember = "ComboBox_Key";
                 comboBox_SevereSepsisPresent.DisplayMember = "ComboBox_Value";
                 comboBox_SevereSepsisPresent.SelectedIndex = 0;

              
                 comboBox_SepticShockPresent.DataSource = ds.Tables["SepticShockPresent"];
                 comboBox_SepticShockPresent.ValueMember = "ComboBox_Key";
                 comboBox_SepticShockPresent.DisplayMember = "ComboBox_Value";
                 comboBox_SepticShockPresent.SelectedIndex = 0;

              
                 comboBox_InitialLactateLevelCollection.DataSource = ds.Tables["InitialLactateLevelCollection"];
                 comboBox_InitialLactateLevelCollection.ValueMember = "ComboBox_Key";
                 comboBox_InitialLactateLevelCollection.DisplayMember = "ComboBox_Value";
                 comboBox_InitialLactateLevelCollection.SelectedIndex = 0;



                 comboBox_ElevatedLactateReason.DataSource = ds.Tables["ElevatedLactateReason"];
                 comboBox_ElevatedLactateReason.ValueMember = "ComboBox_Key";
                 comboBox_ElevatedLactateReason.DisplayMember = "ComboBox_Value";
                 comboBox_ElevatedLactateReason.SelectedIndex = 0;


              
                 comboBox_RepeatLactateLevelCollection.DataSource = ds.Tables["RepeatLactateLevelCollection"];
                 comboBox_RepeatLactateLevelCollection.ValueMember = "ComboBox_Key";
                 comboBox_RepeatLactateLevelCollection.DisplayMember = "ComboBox_Value";
                 comboBox_RepeatLactateLevelCollection.SelectedIndex = 0;

              
                 comboBox_BloodCultureCollection.DataSource = ds.Tables["BloodCultureCollection"];
                 comboBox_BloodCultureCollection.ValueMember = "ComboBox_Key";
                 comboBox_BloodCultureCollection.DisplayMember = "ComboBox_Value";
                 comboBox_BloodCultureCollection.SelectedIndex = 0;

              
                 comboBox_BloodCultureCollectionAcceptableDelay.DataSource = ds.Tables["BloodCultureCollectionAcceptableDelay"];
                 comboBox_BloodCultureCollectionAcceptableDelay.ValueMember = "ComboBox_Key";
                 comboBox_BloodCultureCollectionAcceptableDelay.DisplayMember = "ComboBox_Value";
                 comboBox_BloodCultureCollectionAcceptableDelay.SelectedIndex = 0;


              
                 comboBox_AntibioticAdministration.DataSource = ds.Tables["AntibioticAdministration"];
                 comboBox_AntibioticAdministration.ValueMember = "ComboBox_Key";
                 comboBox_AntibioticAdministration.DisplayMember = "ComboBox_Value";
                 comboBox_AntibioticAdministration.SelectedIndex = 0;

              
                 comboBox_AntibioticAdministrationSelection.DataSource = ds.Tables["AntibioticAdministrationSelection"];
                 comboBox_AntibioticAdministrationSelection.ValueMember = "ComboBox_Key";
                 comboBox_AntibioticAdministrationSelection.DisplayMember = "ComboBox_Value";
                 comboBox_AntibioticAdministrationSelection.SelectedIndex = 0;

              
                 comboBox_AdultCrystalloidFluidAdministration.DataSource = ds.Tables["AdultCrystalloidFluidAdministration"];
                 comboBox_AdultCrystalloidFluidAdministration.ValueMember = "ComboBox_Key";
                 comboBox_AdultCrystalloidFluidAdministration.DisplayMember = "ComboBox_Value";
                 comboBox_AdultCrystalloidFluidAdministration.SelectedIndex = 0;


              
                 comboBox_PediatricCrystalloidFluidAdministration.DataSource = ds.Tables["PediatricCrystalloidFluidAdministration"];
                 comboBox_PediatricCrystalloidFluidAdministration.ValueMember = "ComboBox_Key";
                 comboBox_PediatricCrystalloidFluidAdministration.DisplayMember = "ComboBox_Value";
                 comboBox_PediatricCrystalloidFluidAdministration.SelectedIndex = 0;

              
                 comboBox_InitialHypotension.DataSource = ds.Tables["InitialHypotension"];
                 comboBox_InitialHypotension.ValueMember = "ComboBox_Key";
                 comboBox_InitialHypotension.DisplayMember = "ComboBox_Value";
                 comboBox_InitialHypotension.SelectedIndex = 0;

              
                 comboBox_PersistentHypotension.DataSource = ds.Tables["PersistentHypotension"];
                 comboBox_PersistentHypotension.ValueMember = "ComboBox_Key";
                 comboBox_PersistentHypotension.DisplayMember = "ComboBox_Value";
                 comboBox_PersistentHypotension.SelectedIndex = 0;

              
                 comboBox_VasopressorAdministration.DataSource = ds.Tables["VasopressorAdministration"];
                 comboBox_VasopressorAdministration.ValueMember = "ComboBox_Key";
                 comboBox_VasopressorAdministration.DisplayMember = "ComboBox_Value";
                 comboBox_VasopressorAdministration.SelectedIndex = 0;


                 comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.DataSource = ds.Tables["RepeatVolumeStatusandTissuePerfusionAssessmentPerformed"];
                 comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.ValueMember = "ComboBox_Key";
                 comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.DisplayMember = "ComboBox_Value";
                 comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.SelectedIndex = 0;


              
                 comboBox_PlateletCount.DataSource = ds.Tables["PlateletCount"];
                 comboBox_PlateletCount.ValueMember = "ComboBox_Key";
                 comboBox_PlateletCount.DisplayMember = "ComboBox_Value";
                 comboBox_PlateletCount.SelectedIndex = 0;

              
                 comboBox_LowerRespiratoryInfection.DataSource = ds.Tables["LowerRespiratoryInfection"];
                 comboBox_LowerRespiratoryInfection.ValueMember = "ComboBox_Key";
                 comboBox_LowerRespiratoryInfection.DisplayMember = "ComboBox_Value";
                 comboBox_LowerRespiratoryInfection.SelectedIndex = 0;

              
                 comboBox_AlteredMentalStatus.DataSource = ds.Tables["AlteredMentalStatus"];
                 comboBox_AlteredMentalStatus.ValueMember = "ComboBox_Key";
                 comboBox_AlteredMentalStatus.DisplayMember = "ComboBox_Value";
                 comboBox_AlteredMentalStatus.SelectedIndex = 0;

              
                 comboBox_InfectionEtiology.DataSource = ds.Tables["InfectionEtiology"];
                 comboBox_InfectionEtiology.ValueMember = "ComboBox_Key";
                 comboBox_InfectionEtiology.DisplayMember = "ComboBox_Value";
                 comboBox_InfectionEtiology.SelectedIndex = 0;

              
                 comboBox_SiteofInfection.DataSource = ds.Tables["SiteofInfection"];
                 comboBox_SiteofInfection.ValueMember = "ComboBox_Key";
                 comboBox_SiteofInfection.DisplayMember = "ComboBox_Value";
                 comboBox_SiteofInfection.SelectedIndex = 0;


              
                 comboBox_MechanicalVentilation.DataSource = ds.Tables["MechanicalVentilation"];
                 comboBox_MechanicalVentilation.ValueMember = "ComboBox_Key";
                 comboBox_MechanicalVentilation.DisplayMember = "ComboBox_Value";
                 comboBox_MechanicalVentilation.SelectedIndex = 0;


              
                 comboBox_ICU.DataSource = ds.Tables["ICU"];
                 comboBox_ICU.ValueMember = "ComboBox_Key";
                 comboBox_ICU.DisplayMember = "ComboBox_Value";
                 comboBox_ICU.SelectedIndex = 0;

              
                 comboBox_ChronicRespiratoryFailure.DataSource = ds.Tables["ChronicRespiratoryFailure"];
                 comboBox_ChronicRespiratoryFailure.ValueMember = "ComboBox_Key";
                 comboBox_ChronicRespiratoryFailure.DisplayMember = "ComboBox_Value";
                 comboBox_ChronicRespiratoryFailure.SelectedIndex = 0;

              
                 comboBox_AIDSDisease.DataSource = ds.Tables["AIDSDisease"];
                 comboBox_AIDSDisease.ValueMember = "ComboBox_Key";
                 comboBox_AIDSDisease.DisplayMember = "ComboBox_Value";
                 comboBox_AIDSDisease.SelectedIndex = 0;

            
                 comboBox_MetastaticCancer.DataSource = ds.Tables["MetastaticCancer"];
                 comboBox_MetastaticCancer.ValueMember = "ComboBox_Key";
                 comboBox_MetastaticCancer.DisplayMember = "ComboBox_Value";
                 comboBox_MetastaticCancer.SelectedIndex = 0;


             
                 comboBox_Lymphoma.DataSource = ds.Tables["MultipleMyeloma"];
                 comboBox_Lymphoma.ValueMember = "ComboBox_Key";
                 comboBox_Lymphoma.DisplayMember = "ComboBox_Value";
                 comboBox_Lymphoma.SelectedIndex = 0;


              
                 comboBox_ImmuneModifyingMedications.DataSource = ds.Tables["ImmuneModifyingMedications"];
                 comboBox_ImmuneModifyingMedications.ValueMember = "ComboBox_Key";
                 comboBox_ImmuneModifyingMedications.DisplayMember = "ComboBox_Value";
                 comboBox_ImmuneModifyingMedications.SelectedIndex = 0;


              
                 comboBox_CongestiveHeartFailure.DataSource = ds.Tables["CongestiveHeartFailure"];
                 comboBox_CongestiveHeartFailure.ValueMember = "ComboBox_Key";
                 comboBox_CongestiveHeartFailure.DisplayMember = "ComboBox_Value";
                 comboBox_CongestiveHeartFailure.SelectedIndex = 0;


              
                 comboBox_ChronicRenalFailure.DataSource = ds.Tables["ChronicRenalFailure"];
                 comboBox_ChronicRenalFailure.ValueMember = "ComboBox_Key";
                 comboBox_ChronicRenalFailure.DisplayMember = "ComboBox_Value";
                 comboBox_ChronicRenalFailure.SelectedIndex = 0;

              
                 comboBox_ChronicLiverDisease.DataSource = ds.Tables["ChronicLiverDisease"];
                 comboBox_ChronicLiverDisease.ValueMember = "ComboBox_Key";
                 comboBox_ChronicLiverDisease.DisplayMember = "ComboBox_Value";
                 comboBox_ChronicLiverDisease.SelectedIndex = 0;


              
                 comboBox_Diabetes.DataSource = ds.Tables["Diabetes"];
                 comboBox_Diabetes.ValueMember = "ComboBox_Key";
                 comboBox_Diabetes.DisplayMember = "ComboBox_Value";
                 comboBox_Diabetes.SelectedIndex = 0;

              
                 comboBox_OrganTransplant.DataSource = ds.Tables["OrganTransplant"];
                 comboBox_OrganTransplant.ValueMember = "ComboBox_Key";
                 comboBox_OrganTransplant.DisplayMember = "ComboBox_Value";
                 comboBox_OrganTransplant.SelectedIndex = 0;



                 comboBox_Bandemia.DataSource = ds.Tables["Bandemia"];
                 comboBox_Bandemia.ValueMember = "ComboBox_Key";
                 comboBox_Bandemia.DisplayMember = "ComboBox_Value";
                 comboBox_Bandemia.SelectedIndex = 0;
            


                   }
            catch (Exception ex)
            {

            }

        }

          private void textBox_AdmissionDateTime_Leave(object sender, EventArgs e)
                    {
                      try
                      {
                          if (validateDatetime(textBox_AdmissionDateTime.Text.ToString().Trim()) == false)
                          {
                             
                              textBox_AdmissionDateTime.BackColor = ErrorColor(Color.Red);
                              MessageBox.Show("Admission Datetime should be in format MM/DD/YYYY hh:mm", "Admission Datetime Error");
                              textBox_AdmissionDateTime.Focus();

                          }
                          else if (validateDatetimeLimit(textBox_AdmissionDateTime.Text.ToString().Trim(), txtDOB.Text.ToString().Trim()) == false)
                          {
                              textBox_AdmissionDateTime.BackColor = ErrorColor(Color.Red);
                              MessageBox.Show("Date of Birth cannot have been after Admission Datetime.", "Admission Datetime Error");
                              textBox_AdmissionDateTime.Focus();
                          }
                          else
                          {

                              textBox_AdmissionDateTime.BackColor = result;
                          }



                     }
            catch (Exception ex)
            {

            }
              
              
          }

          private void textBox_DischargedDatetime_Leave(object sender, EventArgs e)
          {
              try 
              {
              if (validateDatetime(textBox_DischargedDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_DischargedDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Discharge Datetime should be in format MM/DD/YYYY hh:mm", "Discharge Date/Time Error");
                  textBox_DischargedDatetime.Focus();
              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_AdmissionDateTime.Text.ToString().Trim()) == false)
              {
                  textBox_DischargedDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Discharge Datetime should be after Admission Datetime", "Discharge Date/Time Error");
                  textBox_DischargedDatetime.Focus();
              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), "12/31/2017 11:59:59 PM") == false)
              {
                  textBox_DischargedDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Discharge Datetime should be after 12/31/2017 for Sepsis reporting version 5.1", "Discharge Date/Time Error");
                  textBox_DischargedDatetime.Focus();
              }
              else
              {

                  textBox_DischargedDatetime.BackColor = result;
              }
              }
            catch (Exception ex)
            {

            }
          }

          private void textBox_ExcludedDatetime_Leave(object sender, EventArgs e)
          {
              try
              {
              if (validateDatetime(textBox_ExcludedDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ExcludedDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Excluded Datetime should be in format MM/DD/YYYY hh:mm", "Excluded Date/Time Error");
                  textBox_ExcludedDatetime.Focus();
                  
              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_ExcludedDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ExcludedDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Excluded Datetime cannot have been after Discharge Datetime.", "Excluded Date/Time Error");
                  textBox_ExcludedDatetime.Focus();
              }
              else
              {

                  if (lbl_ExcludedDatetime.Visible == true)
                      textBox_ExcludedDatetime.BackColor = result;
                  else
                      textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.Gray);
          
              }



             }
            catch (Exception ex)
            {

            }

          }

          private void textBox_EarliestDatetime_Leave(object sender, EventArgs e)
          {
              try
              {
              
              if (validateDatetime(textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ArrivalDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Arrival Datetime should be in format MM/DD/YYYY hh:mm", "Arrival Date/Time Error");
                  textBox_ArrivalDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ArrivalDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Arrival Datetime cannot have been after Discharge Datetime.", "Arrival Date/Time Error");
                  textBox_ArrivalDatetime.Focus();
              }
              else
              {
                  textBox_ArrivalDatetime.BackColor = result;
              }


              comboBox_SevereSepsisPresent.Focus();



             }
            catch (Exception ex)
            {

            }
          }

          private void textbox_TriageDatetime_Leave(object sender, EventArgs e)
          {
              try 
              {

              if (validateDatetime(textbox_TriageDatetime.Text.ToString().Trim()) == false)
              {
                  textbox_TriageDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Triage Datetime should be in format MM/DD/YYYY hh:mm", "Triage Date/Time Error");
                  textbox_TriageDatetime.Focus();
                  
              }
              else if (validateDatetimeLimit(textbox_TriageDatetime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
              {
                  textbox_TriageDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Triage Datetime cannot have been before Arrival Datetime.", "Triage Date/Time Error");
                  textbox_TriageDatetime.Focus();
              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textbox_TriageDatetime.Text.ToString().Trim()) == false)
              {
                  textbox_TriageDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Triage Datetime cannot have been after Discharge Datetime.", "Triage Datetime Error");
                  textbox_TriageDatetime.Focus();
              }
              else
              {
                  textbox_TriageDatetime.BackColor = MandatoryColor(Color.Gray);
              }

                  }
            catch (Exception ex)
            {

            }
            
          }

          private void textBox_SevereSepsisPresentationDatetime_Leave(object sender, EventArgs e)
          {
              try
              {
              if (validateDatetime(textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_SevereSepsisPresentationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Severe Sepsis Presentation Datetime should be in format MM/DD/YYYY hh:mm", "Severe Sepsis Presentation Date/Time Error");
                  textBox_SevereSepsisPresentationDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_SevereSepsisPresentationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Severe Sepsis Presentation Datetime cannot have been after Discharge Datetime.", "Severe Sepsis Presentation Date/Time Error");
                  textBox_SevereSepsisPresentationDatetime.Focus();
              }

              else if (validateDatetimeLimit(textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_SevereSepsisPresentationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Severe Sepsis Presentation Datetime cannot be before Arrival Datetime.", "Severe Sepsis Presentation Date/Time Error");
                  textBox_SevereSepsisPresentationDatetime.Focus();
              }
      
              else
              {
                  if (lbl_SevereSepsisPresentationDatetime.Visible == true)
                      textBox_SevereSepsisPresentationDatetime.BackColor = result;
                  else
                      textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.Gray);

              }



              if (validateDatetime(textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim()) == true)
              {


                  if (validateDatetime(textBox_septicShockPresentationDatetime.Text.ToString().Trim()) == true)
                  {

                      if (validateDatetimeLimit(textBox_septicShockPresentationDatetime.Text.ToString().Trim(), textBox_septicShockPresentationDatetime.Text.ToString().Trim()) == false)
                      {
                          textBox_SevereSepsisPresentationDatetime.BackColor = ErrorColor(Color.Red);
                          MessageBox.Show("Severe Sepsis Presentation Datetime cannot be after Septic Shock Presentation Datetime.", "Severe Sepsis Presentation Date/Time Error");
                          textBox_SevereSepsisPresentationDatetime.Focus();
                      }

                  }


              }

              


            }
            catch (Exception ex)
            {

            }
          }

          private void textBox_septicShockPresentationDatetime_Leave(object sender, EventArgs e)
          {
              try
              {
              if (validateDatetime(textBox_septicShockPresentationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_septicShockPresentationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Septic Shock Presentation Datetime should be in format MM/DD/YYYY hh:mm", "Septic Shock Presentation Date/Time Error");
                  textBox_septicShockPresentationDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_septicShockPresentationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_septicShockPresentationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Septic Shock Presentation Datetime cannot have been after Discharge Datetime.", "Septic Shock Presentation Date/Time Error");
                  textBox_septicShockPresentationDatetime.Focus();
              }
              else if (validateDatetimeLimit(textBox_septicShockPresentationDatetime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_septicShockPresentationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Septic Shock Presentation Datetime cannot have been before Arrival Datetime.", "Septic Shock Presentation Date/Time Error");
                  textBox_septicShockPresentationDatetime.Focus();
              }
              else
              {
                  if (lbl_SepticShockPresentationDatetime.Visible == true)
                      textBox_septicShockPresentationDatetime.BackColor = result;
                  else
                      textBox_septicShockPresentationDatetime.BackColor = MandatoryColor(Color.Gray);

                  
              }

            




             }
            catch (Exception ex)
            {

            }
          }


          private void textBox_InitialLactateLevelCollectionDatetime_Leave(object sender, EventArgs e)
          {
              try
              {


              if (validateDatetime(textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Initial Lactate Level Collection Datetime should be in format MM/DD/YYYY hh:mm", "Initial Lactate Level Collection Date/Time Error");
                  textBox_InitialLactateLevelCollectionDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Initial Lactate Level Collection Datetime cannot have been after Discharge Datetime.", "Initial Lactate Level Collection Date/Time Error");
                  textBox_InitialLactateLevelCollectionDatetime.Focus();
              }
              else if (validateDatetimeLimit(textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Initial Lactate Level Collection Datetime cannot have been before Arrival Datetime.", "Initial Lactate Level Collection Date/Time Error");
                  textBox_InitialLactateLevelCollectionDatetime.Focus();
              }
              else
              {
                  if (lbl_InitialLactateLevelCollectionDatetime.Visible == true)
                      textBox_InitialLactateLevelCollectionDatetime.BackColor = result;
                  else
                      textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);

              }

             }
            catch (Exception ex)
            {

            }
          }

          private void textbox_RepeatLactateLevelCollectionDatetime_Leave(object sender, EventArgs e)
          {

              try
              {


              if (validateDatetime(textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim()) == false)
              {
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Repeat Lactate Level Collection Datetime should be in format MM/DD/YYYY hh:mm", "Repeat Lactate Level Collection Date/Time Error");
                  textbox_RepeatLactateLevelCollectionDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim()) == false)
              {
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Repeat Lactate Level Collection Datetime cannot have been after Discharge Datetime.", "Repeat Lactate Level Collection Date/Time Error");
                  textbox_RepeatLactateLevelCollectionDatetime.Focus();
              }

              else if (validateDatetimeLimit(textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
              {
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Repeat Lactate Level Collection Datetime cannot have been before Arrival Datetime.", "Repeat Lactate Level Collection Date/Time Error");
                  textbox_RepeatLactateLevelCollectionDatetime.Focus();
              }
              else
              {
                  if (lbl_RepeatLactateLevelCollectionDatetime.Visible == true)
                      textbox_RepeatLactateLevelCollectionDatetime.BackColor = result;
                  else
                      textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
                  
              }
             }
            catch (Exception ex)
            {

            }
          }

          private void textBox_BloodCultureCollectionDatetime_Leave(object sender, EventArgs e)
          {
              try
              {


              if (validateDatetime(textBox_BloodCultureCollectionDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_BloodCultureCollectionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Blood Culture Collection Datetime should be in format MM/DD/YYYY hh:mm", "Blood Culture Collection Date/Time Error");
                  textBox_BloodCultureCollectionDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_BloodCultureCollectionDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_BloodCultureCollectionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Blood Culture Collection Datetime cannot have been after Discharge Datetime.", "Blood Culture Collection Date/Time Error");
                  textBox_BloodCultureCollectionDatetime.Focus();
              }
              else if (validateDatetimeLimit(textBox_BloodCultureCollectionDatetime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_BloodCultureCollectionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Blood Culture Collection Datetime cannot have been before Arrival Datetime.", "Blood Culture Collection Date/Time Error");
                  textBox_BloodCultureCollectionDatetime.Focus();
              }
              else
              {
                  if (lbl_BloodCultureCollectionDatetime.Visible == true)
                      textBox_BloodCultureCollectionDatetime.BackColor = result;
                  else
                      textBox_BloodCultureCollectionDatetime.BackColor = MandatoryColor(Color.Gray);

                  
              }
             }
            catch (Exception ex)
            {

            }
          }

          private void textBox_AntibioticAdministrationDatetime_Leave(object sender, EventArgs e)
          {
              try
              {
    

              if (validateDatetime(textBox_AntibioticAdministrationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_AntibioticAdministrationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Antibiotic Administration Datetime should be in format MM/DD/YYYY hh:mm", "Antibiotic Administration Date/Time Error");
                  textBox_AntibioticAdministrationDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_AntibioticAdministrationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_AntibioticAdministrationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Antibiotic Administration Datetime cannot have been after Discharge Datetime.", "Antibiotic Administration Date/Time Error");
                  textBox_AntibioticAdministrationDatetime.Focus();
              }
              else if (validateDatetimeLimit(textBox_AntibioticAdministrationDatetime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_AntibioticAdministrationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Antibiotic Administration Datetime cannot have been before Arrival Datetime.", "Antibiotic Administration Date/Time Error");
                  textBox_AntibioticAdministrationDatetime.Focus();
              }
              else
              {
                  if (lbl_AntibioticAdministrationDatetime.Visible == true)
                      textBox_AntibioticAdministrationDatetime.BackColor = result;
                  else
                      textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);

                  
              }

                  }
            catch (Exception ex)
            {

            }
          }

          private void textBox_CrystalloidFluidAdministrationDatetime_Leave(object sender, EventArgs e)
          {
              try
              {

          

              if (validateDatetime(textBox_CrystalloidFluidAdministrationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_CrystalloidFluidAdministrationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Crystalloid Fluid Administration Datetime should be in format MM/DD/YYYY hh:mm", "Crystalloid Fluid Administration Date/Time Error");
                  textBox_CrystalloidFluidAdministrationDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_CrystalloidFluidAdministrationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_CrystalloidFluidAdministrationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Crystalloid Fluid Administration Datetime cannot have been after Discharge Datetime.", "Crystalloid Fluid Administration Date/Time Error");
                  textBox_CrystalloidFluidAdministrationDatetime.Focus();
              }
              else
              {

                  if (lbl_CrystalloidFluidAdministrationDatetime.Visible == true)
                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = result;
                  else
                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                
              }

                  }
            catch (Exception ex)
            {

            }
          }

         

          private void textBox_VasopressorAdministrationDatetime_Leave(object sender, EventArgs e)
          {

              try
              {
      

                if (validateDatetime(textBox_VasopressorAdministrationDatetime.Text.ToString().Trim()) == false)
                  {
                      textBox_VasopressorAdministrationDatetime.BackColor = ErrorColor(Color.Red);
                      MessageBox.Show("Vasopressor Administration Datetime should be in format MM/DD/YYYY hh:mm", "Vasopressor Administration Date/Time Error");
                      textBox_VasopressorAdministrationDatetime.Focus();

                  }
                else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_VasopressorAdministrationDatetime.Text.ToString().Trim()) == false)
                {
                    textBox_VasopressorAdministrationDatetime.BackColor = ErrorColor(Color.Red);
                    MessageBox.Show("Vasopressor Administration Datetime cannot have been after Discharge Datetime.", "Vasopressor Administration Date/Time Error");
                    textBox_VasopressorAdministrationDatetime.Focus();
                }

                else if (validateDatetimeLimit(textBox_VasopressorAdministrationDatetime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
                {
                    textBox_VasopressorAdministrationDatetime.BackColor = ErrorColor(Color.Red);
                    MessageBox.Show("Vasopressor Administration Datetime cannot have been before Arrival Datetime.", "Vasopressor Administration Date/Time Error");
                    textBox_VasopressorAdministrationDatetime.Focus();
                }
              else
              {

                  if (lbl_VasopressorAdministrationDateTime.Visible == true)
                      textBox_VasopressorAdministrationDatetime.BackColor = result;
                  else
                      textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                
              }
              }
            catch (Exception ex)
            {

            }
          }

      

          private void textBox_MechanicalVentilationDatetime_Leave(object sender, EventArgs e)
          {
              try
              {

  
              if (validateDatetime(textBox_MechanicalVentilationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_MechanicalVentilationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Mechanical Ventilation Datetime should be in format MM/DD/YYYY hh:mm", "Mechanical Ventilation Date/Time Error");
                  textBox_MechanicalVentilationDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_MechanicalVentilationDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_MechanicalVentilationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Mechanical Ventilation Datetime should be before Discharge Datetime", "Mechanical Ventilation Date/Time Error");
                 
                  textBox_MechanicalVentilationDatetime.Focus();
              }
              else if (validateDatetimeLimit(textBox_MechanicalVentilationDatetime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_MechanicalVentilationDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Mechanical Ventilation Datetime cannot have been before Arrival Datetime.", "Mechanical Ventilation Date/Time Error");
                  textBox_MechanicalVentilationDatetime.Focus();
              }
              else
              {
                  if (lbl_MechanicalVentilationDatetime.Visible == true)
                      textBox_MechanicalVentilationDatetime.BackColor = result;
                  else
                      textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.Gray);
               
              }

           }
            catch (Exception ex)
            {

            }
          }

          private void textBox_ICUAdmissionDatetime_Leave(object sender, EventArgs e)
          {
             try
             {

              if (validateDatetime(textBox_ICUAdmissionDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ICUAdmissionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("ICU Admission Datetime should be in format MM/DD/YYYY hh:mm", "ICU Admission Date/Time Error");
                  textBox_ICUAdmissionDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_ICUAdmissionDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ICUAdmissionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("ICU Admission Datetime should be before Discharge Datetime", "ICU Admission Date/Time Error");
                
                  textBox_ICUAdmissionDatetime.Focus();
              }
              else if (validateDatetimeLimit(textBox_ICUAdmissionDatetime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ICUAdmissionDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("ICU Admission Datetime cannot have been before Arrival Datetime.", "ICU Admission Date/Time Error");
                  textBox_ICUAdmissionDatetime.Focus();
              }
              else
              {
                  if (lbl_ICUAdmissionDatetime.Visible == true)
                      textBox_ICUAdmissionDatetime.BackColor = result;
                  else
                      textBox_ICUAdmissionDatetime.BackColor = MandatoryColor(Color.Gray);
                  
              }
                   }
            catch (Exception ex)
            {

            }
          }

          private void textBox_ICUDischargeDatetime_Leave(object sender, EventArgs e)
          {
              try
              {
        

              if (validateDatetime(textBox_ICUDischargeDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ICUDischargeDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("ICU Discharge Datetime should be in format MM/DD/YYYY hh:mm", "ICU Discharge Date/Time Error");
                  textBox_ICUDischargeDatetime.Focus();

              }
              else if (validateDatetimeLimit(textBox_ICUDischargeDatetime.Text.ToString().Trim(), textBox_ICUAdmissionDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ICUDischargeDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("ICU Discharge Datetime should be after ICU Admission Datetime", "ICU Discharge Date/Time Error");
                
                  textBox_ICUDischargeDatetime.Focus();
              }
              else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_ICUDischargeDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ICUDischargeDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("ICU Discharge Datetime should be before Discharge Datetime", "ICU Discharge Date/Time Error");
                  
                  textBox_ICUDischargeDatetime.Focus();
              }
              else if (validateDatetimeLimit(textBox_ICUDischargeDatetime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
              {
                  textBox_ICUDischargeDatetime.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("ICU Discharge Datetime cannot have been before Arrival Datetime.", "ICU Discharge Date/Time Error");
                  textBox_ICUDischargeDatetime.Focus();
              }
              else
              {
                  if (lbl_ICUDischargeDatetime.Visible == true)
                      textBox_ICUDischargeDatetime.BackColor = result;
                  else
                      textBox_ICUDischargeDatetime.BackColor = MandatoryColor(Color.Gray);
                
              }
                   }
            catch (Exception ex)
            {

            }
          }

          private void TextBox_PatientCtrlNum_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
          {
              try
              {
              System.Text.StringBuilder messageBoxCS = new System.Text.StringBuilder();

              messageBoxCS.AppendFormat("{0} : {1}", "Patient Control Number Error", e.RejectionHint);
              messageBoxCS.AppendLine();
              MessageBox.Show(messageBoxCS.ToString(), "Patient Control Number Error");
               }
            catch (Exception ex)
            {

            }
          }

          private void TextBox_InsuranceNumber_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
          {
              try
              {
              System.Text.StringBuilder messageBoxCS = new System.Text.StringBuilder();

              messageBoxCS.AppendFormat("{0} : {1}", "Insurance Number Error", e.RejectionHint);
              messageBoxCS.AppendLine();
              MessageBox.Show(messageBoxCS.ToString(), "Insurance Number Error");
              }
            catch (Exception ex)
            {

            }
          }

       

          public bool MandatoryFieldCheck()
          {
              try
              {

         
              if (txtId.Text.ToString().Trim() == "")
              {
                  return false;
              }



              if (TextBox_PatientCtrlNum.Text.ToString().Trim() == "")
              {
                  return false;
              }


              if (txtDOB.Text.ToString().Trim() == "/  /")
              {
                  return false;
              }


              if (Combobox_Gender.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (checkedListBox_Race.CheckedItems.Count == 0)
              {
                  return false;
              }




              if (Combobox_Ethnicity.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_Payor.SelectedValue.ToString() == "Select")
              {
                  return false;
              }




              if (txtMRN.Text.ToString().Trim() == "")
              {
                  return false;
              }


              if (TextBox_FacilityIdentifier.Text.ToString().Trim() == "")
              {
                  return false;
              }




              if (textBox_AdmissionDateTime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }

              if (textBox_DischargedDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }

              if (comboBox_SourceofAdmission.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_DischargeStatus.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_TransferStatus.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

          

              if (Combobox_SepsisIdentificationPlace.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (textBox_ArrivalDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }

              if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "Select")
              {
                  return false;
              }




              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_PlateletCount.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_AlteredMentalStatus.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_InfectionEtiology.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_LowerRespiratoryInfection.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_Bandemia.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_SiteofInfection.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (comboBox_ICU.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_ChronicRespiratoryFailure.SelectedValue.ToString() == "Select")
              {
                  return false;
              }



              if (comboBox_AIDSDisease.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_MetastaticCancer.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_Lymphoma.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_ImmuneModifyingMedications.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_CongestiveHeartFailure.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_ChronicRenalFailure.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_ChronicLiverDisease.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

              if (comboBox_Diabetes.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_OrganTransplant.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

           
              
              // Dependency validations
              if ((comboBox_Payor.SelectedValue.ToString() == "C" || comboBox_Payor.SelectedValue.ToString() == "D" || comboBox_Payor.SelectedValue.ToString() == "F" || comboBox_Payor.SelectedValue.ToString() == "G") && TextBox_InsuranceNumber.Text.ToString().Trim()=="")
              {

                  return false;

              }

              if ((comboBox_TransferStatus.SelectedValue.ToString() == "3" || comboBox_TransferStatus.SelectedValue.ToString() == "4" || comboBox_TransferStatus.SelectedValue.ToString() == "5") && textBox_TransferFacilityIdentifier.Text.Trim() == "")
              {
                  return false;
              }

              if (comboBox_ICU.SelectedValue.ToString() == "1" && textBox_ICUAdmissionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_ICU.SelectedValue.ToString() == "1" && textBox_ICUDischargeDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "1" && textBox_MechanicalVentilationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }







              if (comboBox_VasopressorAdministration.SelectedValue.ToString() == "1" && textBox_VasopressorAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }
              


              if (comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.SelectedValue.ToString() == "1" && textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_AntibioticAdministration.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_InitialHypotension.SelectedValue.ToString() == "Select")
              {
                  return false;
              }

 

              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && textBox_CrystalloidFluidAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }

         

              if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1" && textBox_AntibioticAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1" && comboBox_AntibioticAdministrationSelection.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


        

              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && textBox_BloodCultureCollectionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && comboBox_BloodCultureCollectionAcceptableDelay.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_BloodCultureCollection.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


              if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1" && textBox_InitialLactateLevel.Text.ToString().Trim() == "")
              {
                  return false;
              }


              if (comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "1" && textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1" && textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }




              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1" && checkedListBox_ExcludedReason.CheckedItems.Count == 0)
              {
                  return false;
              }



              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1" && textBox_ExcludedDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_InitialHypotension.SelectedValue.ToString() == "1" && textbox_InitialHypotensionDateTime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }


              if (comboBox_InitialHypotension.SelectedValue.ToString() == "1" && comboBox_PersistentHypotension.SelectedValue.ToString() == "Select")
              {
                  return false;
              }


     
              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && textBox_septicShockPresentationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }

              if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "1" && textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  return false;
              }




              for (int i = 0; i < checkedListBox_ExcludedReason.Items.Count; i++)
              {
                  if (checkedListBox_ExcludedReason.GetItemChecked(i) == true)
                  {
                      DataRowView castedItem = checkedListBox_ExcludedReason.Items[i] as DataRowView;
                      if (castedItem["ComboBox_Key"].ToString() == "1")
                      {
                          ExcludedResonChecked = 1;
                          break;
                      }
                  }

              }


              if (ExcludedResonChecked == 1 && checkedListBox_ExcludedExplain.CheckedItems.Count <= 0)
              {
                  ExcludedResonChecked = 0;
                  return false;

              }



           

              if (textBox_InitialLactateLevel.Text.Length >= 1)
              {
                  DateTime dDate;
                  decimal j = 0;

                  j = decimal.Parse(textBox_InitialLactateLevel.Text);

                  if (validateDate(txtDOB.Text.ToString().Trim()) == true)
                  {

                      if (DateTime.TryParseExact(txtDOB.Text.ToString().Trim(), format2, CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out dDate))

                          
                          if (((comboBox_InitialHypotension.SelectedValue.ToString() == "1" || comboBox_SepticShockPresent.SelectedValue.ToString() == "1" || j >= 4) && DateTime.Compare(DateTime.Today.AddYears(-18), dDate) >= 0) && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
                          {

                              return false;
                          }


                      if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate) < 0 && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
                      {

                          return false;
                      }
                 

                  }

                  if (j > 2 && comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "Select")
                  {
                      return false;
                  }


                  if (j > 2 && comboBox_ElevatedLactateReason.SelectedValue.ToString() == "Select")
                  {
                      return false;
                  }
                  



              }


              DateTime dDate1;

              if (DateTime.TryParseExact(txtDOB.Text.ToString().Trim(), format2, CultureInfo.InvariantCulture,
        System.Globalization.DateTimeStyles.None, out dDate1))

              if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate1) < 0 && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
              {

                  return false;
              }

              if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate1) >= 0 && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
              {

                  return false;
              }
                 







              if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" && comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.SelectedValue.ToString() == "Select")
                return false;




              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" && comboBox_PersistentHypotension.SelectedValue.ToString() == "1" && comboBox_VasopressorAdministration.SelectedValue.ToString() == "Select")
                  return false;



              return true;


             }
            catch (Exception ex)
            {
                return false;

            }
}

    
      



          public void LoadEditData(int id)
          {
              try
              {
            
              DateTime dt;

              ds = new DataSet();

              //using (SqlConnection Conn = new SqlConnection(ConnectionString))
              using (Conn = new OdbcConnection(ConnectionString))
              {
                  Conn.Open();

                  //query = "select UniqueId, unique_personal_identifier, patient_control_number, date_of_birth, medical_record_number,Date_Created, Record_Completed, CSVGenerated from sepsis_collab ";
                  //query = query + "where Version = " + comboBox_Version.Text.ToString().Trim();
                  //query = "Sepsis_SelectEdit";
                  query = "{call Sepsis_SelectEdit (?,?)}";

                 
                  using (OdbcCommand Sqlcmd = new OdbcCommand())
                  {


                      Sqlcmd.CommandText = query;
                      Sqlcmd.CommandType = CommandType.StoredProcedure;

                      Sqlcmd.Connection = Conn;


                      Sqlcmd.Parameters.Add(new OdbcParameter("UniqueId", id));
                      Sqlcmd.Parameters.Add(new OdbcParameter("Version", "5.1"));

                      OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter(Sqlcmd);

                      dbDataAdapter.Fill(ds, "Edit");


                      if(ds.Tables["Edit"].Rows.Count  >= 1)
                      {
                          

                          txtId.Text = ds.Tables["Edit"].Rows[0]["unique_personal_identifier"].ToString().Trim();
                          TextBox_PatientCtrlNum.Text = ds.Tables["Edit"].Rows[0]["patient_control_number"].ToString().Trim();

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["date_of_birth"].ToString().Trim()) != true)
                          {
                                 dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["date_of_birth"].ToString().Trim());
                          txtDOB.Text = dt.ToString("MM/dd/yyyy");
                          }
                       
                       
                          Combobox_Gender.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Gender"].ToString().Trim());

                         
                          if (IsnullString(ds.Tables["Edit"].Rows[0]["Race"].ToString().Trim()) != null)
                          {


                              ProgramNames = ds.Tables["Edit"].Rows[0]["Race"].ToString().Trim().Split(':');
                              foreach (string Program in ProgramNames)
                              {


                                  foreach (object itemChecked in checkedListBox_Race.Items)
                                  {

                                      DataRowView castedItem = itemChecked as DataRowView;

                                      if (castedItem["ComboBox_Key"].ToString() == Program)
                                      {
                                          list.Add(temp);
                                          break;
                                      }
                                      temp++;
                                  }
                                  temp = 0;
                              }


                              for (int i = 0; i <= list.Count-1; i++)
                              {
                                  checkedListBox_Race.SetItemChecked(int.Parse(list[i].ToString()), true);
                              }
                              list.Clear();
            
                          }
                         
                  


                          
                          Combobox_Ethnicity.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Ethnicity"].ToString().Trim());
                          comboBox_Payor.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Payer"].ToString().Trim());
                          TextBox_InsuranceNumber.Text = ds.Tables["Edit"].Rows[0]["insurance_number"].ToString().Trim();
                          txtMRN.Text = ds.Tables["Edit"].Rows[0]["medical_record_number"].ToString().Trim();
                          TextBox_FacilityIdentifier.Text = ds.Tables["Edit"].Rows[0]["facility_identifier"].ToString().Trim();


                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["admission_datetime"].ToString().Trim()) != true)
                          {

                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["admission_datetime"].ToString().Trim(), new CultureInfo("en-US"));
                            textBox_AdmissionDateTime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                       


                          comboBox_SourceofAdmission.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["source_of_admission"].ToString().Trim());


                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["discharge_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["discharge_datetime"].ToString().Trim());
                            textBox_DischargedDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          

                          comboBox_DischargeStatus.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["discharge_status"].ToString().Trim());
                          comboBox_TransferStatus.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["transfer_status"].ToString().Trim());
                          textBox_TransferFacilityIdentifier.Text = ds.Tables["Edit"].Rows[0]["transfer_facility_identifier"].ToString().Trim();
                          comboBox_ExcludedFromProtocol.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["excluded_from_protocol"].ToString().Trim());

                          if (IsnullString(ds.Tables["Edit"].Rows[0]["excluded_reason"].ToString().Trim()) != null)
                          {


                            ProgramNames = ds.Tables["Edit"].Rows[0]["excluded_reason"].ToString().Trim().Split(':');
                              foreach (string Program in ProgramNames)
                              {


                                  foreach (object itemChecked in checkedListBox_ExcludedReason.Items)
                                  {

                                      DataRowView castedItem = itemChecked as DataRowView;

                                      if (castedItem["ComboBox_Key"].ToString() == Program)
                                      {
                                          list.Add(temp);
                                          break;
                                      }
                                      temp++;
                                  }
                                  temp = 0;
                              }


                              for (int i = 0; i <= list.Count - 1; i++)
                              {
                                  checkedListBox_ExcludedReason.SetItemChecked(int.Parse(list[i].ToString()), true);
                              }
                              list.Clear();

                          }



                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["Excluded_Datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["Excluded_Datetime"].ToString().Trim());
                              textBox_ExcludedDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }





                          if (IsnullString(ds.Tables["Edit"].Rows[0]["Excluded_Explain"].ToString().Trim()) != null)
                          {


                            ProgramNames = ds.Tables["Edit"].Rows[0]["Excluded_Explain"].ToString().Trim().Split(':');
                              foreach (string Program in ProgramNames)
                              {


                                  foreach (object itemChecked in checkedListBox_ExcludedExplain.Items)
                                  {

                                      DataRowView castedItem = itemChecked as DataRowView;

                                      if (castedItem["ComboBox_Key"].ToString() == Program)
                                      {
                                          list.Add(temp);
                                          break;
                                      }
                                      temp++;
                                  }
                                  temp = 0;
                              }


                              for (int i = 0; i <= list.Count - 1; i++)
                              {
                                  checkedListBox_ExcludedExplain.SetItemChecked(int.Parse(list[i].ToString()), true);
                              }
                              list.Clear();

                          }


                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["Earliest_DateTime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["Earliest_DateTime"].ToString().Trim());
                              textBox_ArrivalDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["Triage_Datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["Triage_Datetime"].ToString().Trim());
                              textbox_TriageDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                      

                        
                          comboBox_SevereSepsisPresent.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Severe_Sepsis_Present"].ToString().Trim());



                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["severe_sepsis_present_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["severe_sepsis_present_datetime"].ToString().Trim());
                              textBox_SevereSepsisPresentationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }


                          comboBox_SepticShockPresent.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Septic_Shock_Present"].ToString().Trim());


                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["septic_shock_present_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["septic_shock_present_datetime"].ToString().Trim());
                              textBox_septicShockPresentationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                        comboBox_InitialLactateLevelCollection.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["initial_lactate_level_collection"].ToString().Trim());


                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["initial_lactate_level_collection_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["initial_lactate_level_collection_datetime"].ToString().Trim());
                              textBox_InitialLactateLevelCollectionDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }

                          textBox_InitialLactateLevel.Text = ds.Tables["Edit"].Rows[0]["initial_lactate_level"].ToString().Trim();

                          textBox_InitialLactateLevel.Text.PadLeft(4);


                          comboBox_RepeatLactateLevelCollection.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["repeat_lactate_level_collection"].ToString().Trim());


                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["repeat_lactate_level_collection_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["repeat_lactate_level_collection_datetime"].ToString().Trim());
                              textbox_RepeatLactateLevelCollectionDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          

                          comboBox_BloodCultureCollection.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["blood_culture_collection"].ToString().Trim());
                          comboBox_BloodCultureCollectionAcceptableDelay.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["blood_culture_collection_acceptable_delay"].ToString().Trim());



                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["blood_culture_collection_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["blood_culture_collection_datetime"].ToString().Trim());
                              textBox_BloodCultureCollectionDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          

                          comboBox_AntibioticAdministration.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["antibiotic_administration"].ToString().Trim());
                          comboBox_AntibioticAdministrationSelection.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["antibiotic_administration_selection"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["antibiotic_administration_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["antibiotic_administration_datetime"].ToString().Trim());
                              textBox_AntibioticAdministrationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
  
                          comboBox_AdultCrystalloidFluidAdministration.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["adult_crystalloid_fluid_administration"].ToString().Trim());
                          comboBox_PediatricCrystalloidFluidAdministration.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["pediatric_crystalloid_fluid_administration"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["crystalloid_fluid_administration_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["crystalloid_fluid_administration_datetime"].ToString().Trim());
                              textBox_CrystalloidFluidAdministrationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
  
                          comboBox_InitialHypotension.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["initial_hypotension"].ToString().Trim());
                          comboBox_PersistentHypotension.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["persistent_hypotension"].ToString().Trim());
                          comboBox_VasopressorAdministration.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["vasopressor_administration"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["vasopressor_administration_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["vasopressor_administration_datetime"].ToString().Trim());
                              textBox_VasopressorAdministrationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
   
                          comboBox_PlateletCount.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["platelet_count"].ToString().Trim());
                          comboBox_Bandemia.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Bandemia"].ToString().Trim());
                          comboBox_LowerRespiratoryInfection.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["lower_respiratory_infection"].ToString().Trim());
                          comboBox_AlteredMentalStatus.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["altered_mental_status"].ToString().Trim());
                          comboBox_InfectionEtiology.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["infection_etiology"].ToString().Trim());
                          comboBox_SiteofInfection.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["site_of_infection"].ToString().Trim());
                          comboBox_MechanicalVentilation.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["mechanical_ventilation"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["mechanical_ventilation_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["mechanical_ventilation_datetime"].ToString().Trim());
                              textBox_MechanicalVentilationDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
             
                          comboBox_ICU.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["ICU"].ToString().Trim());

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["icu_admission_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["icu_admission_datetime"].ToString().Trim());
                              textBox_ICUAdmissionDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                     

                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["icu_discharge_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["icu_discharge_datetime"].ToString().Trim());
                              textBox_ICUDischargeDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                     
                          comboBox_ChronicRespiratoryFailure.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["chronic_respiratory_failure"].ToString().Trim());
                          comboBox_AIDSDisease.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["aids_hiv_disease"].ToString().Trim());
                          comboBox_MetastaticCancer.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["metastatic_cancer"].ToString().Trim());
                          comboBox_Lymphoma.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["lymphoma_leukemia_multiple_myeloma"].ToString().Trim());
                          comboBox_ImmuneModifyingMedications.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["immune_modifying_medications"].ToString().Trim());
                          comboBox_CongestiveHeartFailure.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["congestive_heart_failure"].ToString().Trim());
                          comboBox_ChronicRenalFailure.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["chronic_renal_failure"].ToString().Trim());
                          comboBox_ChronicLiverDisease.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["chronic_liver_disease"].ToString().Trim());
                          comboBox_Diabetes.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["Diabetes"].ToString().Trim());
                          comboBox_OrganTransplant.SelectedValue =  BlankComboEdit(ds.Tables["Edit"].Rows[0]["organ_transplant"].ToString().Trim());
                          
                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["initial_hypotension_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["initial_hypotension_datetime"].ToString().Trim());

                              textbox_InitialHypotensionDateTime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                          
                          comboBox_ElevatedLactateReason.SelectedValue = BlankComboEdit(ds.Tables["Edit"].Rows[0]["elevated_lactate_reason"].ToString().Trim());
                          Combobox_SepsisIdentificationPlace.SelectedValue = BlankComboEdit(ds.Tables["Edit"].Rows[0]["sepsis_identification_place"].ToString().Trim());


                          comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.SelectedValue = BlankComboEdit(ds.Tables["Edit"].Rows[0]["repeat_volume_status_and_tissue_perfusion_assessment_performed"].ToString().Trim());


                          if (IsnullDate(ds.Tables["Edit"].Rows[0]["repeat_volume_status_and_tissue_perfusion_assessment_performed_datetime"].ToString().Trim()) != true)
                          {
                              dt = DateTime.Parse(ds.Tables["Edit"].Rows[0]["repeat_volume_status_and_tissue_perfusion_assessment_performed_datetime"].ToString().Trim());

                              textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Text = dt.ToString("MM/dd/yyyy HH:mm");
                          }
                   



                      }


              


                  }


                  Conn.Close();
              }

            }
            catch (Exception ex)
            {
                int line = 0;

                StackTrace st = new StackTrace(true);
                for (int i = 0; i < st.FrameCount; i++)
                {
               
                    StackFrame sf = st.GetFrame(i);
                      var frame =  sf.GetMethod();
                      line =  sf.GetFileLineNumber();

                      if (line > 0)
                          break;

                }


                using (Conn = new OdbcConnection(ConnectionString))
                {
                    Conn.Open();

                    query = "{call Sepsis_ErrorLog(?,?,?,?)}";

                    //using (SqlCommand Sqlcmd = new SqlCommand())
                    using (OdbcCommand Sqlcmd = new OdbcCommand())
                    {

                        Sqlcmd.CommandText = query;
                        Sqlcmd.CommandType = CommandType.StoredProcedure;
                        Sqlcmd.Connection = Conn;

                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Line",line));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Desc", ex.Message));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Form", "SepsisCaseDetails_5.cs"));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Datetime", DateTime.Now));
                 

                        Sqlcmd.ExecuteNonQuery();

        

                      
                        Conn.Close();
                  


                    }
                }



            
            }
             
          }

          public void HideDependentFields()
          {
              lbl_ExcludedReason.Hide();
              lbl_ExcludedExplain.Hide();
              lbl_ExcludedDatetime.Hide();
              lbl_InitialLactateLevelCollectionDatetime.Hide();
              lbl_BloodCultureCollection.Hide();
              lbl_InitialLactateLevelCollection.Hide();
              lbl_RepeatLactateLevelCollectionDatetime.Hide();
              lbl_BloodCultureCollectionDatetime.Hide();
              lbl_BloodCultureCollectionAcceptableDelay.Hide();
              lbl_ElevatedLactateReason.Hide();
              lbl_AntibioticAdministration.Hide();
              lbl_AntibioticAdministrationSelection.Hide();
              lbl_AntibioticAdministrationDatetime.Hide();
              lbl_AdultCrystalloidFluidAdministration.Hide();
              lbl_PediatricCrystalloidFluidAdministration.Hide();
              lbl_CrystalloidFluidAdministrationDatetime.Hide();
              lbl_InitialHypotension.Hide();
              lbl_PersistentHypotension.Hide();
              lbl_VasopressorAdministration.Hide();
              lbl_VasopressorAdministrationDateTime.Hide();
              lbl_MechanicalVentilationDatetime.Hide();
              lbl_ICUAdmissionDatetime.Hide();
              lbl_ICUDischargeDatetime.Hide();
              lbl_ExcludedExplain.Hide();
              lbl_TransferFacilityIdentifier.Hide();
              lbl_InsuranceNumber.Hide();
              lbl_InitialHypotensionDateTime.Hide();
              lbl_ElevatedLactateReason.Hide();
              lbl_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.Hide();
              lbl_RepeatVolumeStatusandTissuePerfusionAssessmentPerformeddatetime.Hide();


              textBox_ICUAdmissionDatetime.Enabled = false;
              textBox_ICUDischargeDatetime.Enabled = false;
              textBox_MechanicalVentilationDatetime.Enabled = false;
              textBox_VasopressorAdministrationDatetime.Enabled = false;
              textBox_CrystalloidFluidAdministrationDatetime.Enabled = false;
              //comboBox_InitialHypotension.Enabled = false;
              textBox_ExcludedDatetime.Enabled = false;
              checkedListBox_ExcludedReason.Enabled = false;
              checkedListBox_ExcludedExplain.Enabled = false;
              textBox_AntibioticAdministrationDatetime.Enabled = false;
              comboBox_AntibioticAdministrationSelection.Enabled = false;
              textBox_BloodCultureCollectionDatetime.Enabled = false;
              comboBox_BloodCultureCollectionAcceptableDelay.Enabled = false;
              textbox_RepeatLactateLevelCollectionDatetime.Enabled = false;
              textBox_InitialLactateLevelCollectionDatetime.Enabled = false;
              comboBox_RepeatLactateLevelCollection.Enabled = false;
              checkedListBox_ExcludedExplain.Enabled = false;
              textbox_InitialHypotensionDateTime.Enabled = false;
              textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Enabled = false;


          }

          private void comboBox_ICU_SelectedIndexChanged(object sender, EventArgs e)
          {

              if (comboBox_ICU.SelectedValue.ToString() == "1")
              {
                  lbl_ICUAdmissionDatetime.Show();
                  lbl_ICUDischargeDatetime.Show();
                  textBox_ICUAdmissionDatetime.Enabled = true;
                  textBox_ICUDischargeDatetime.Enabled = true;
                  textBox_ICUAdmissionDatetime.BackColor = result;
                  textBox_ICUDischargeDatetime.BackColor = result;
              }
              else
              {
                  lbl_ICUAdmissionDatetime.Hide();
                  lbl_ICUDischargeDatetime.Hide();
                  textBox_ICUAdmissionDatetime.Enabled = false;
                  textBox_ICUDischargeDatetime.Enabled = false;

                  textBox_ICUAdmissionDatetime.BackColor = MandatoryColor(Color.Gray);
                  textBox_ICUDischargeDatetime.BackColor = MandatoryColor(Color.Gray);
                  textBox_ICUAdmissionDatetime.Text = "";
                  textBox_ICUDischargeDatetime.Text = "";
              }



          }

          private void comboBox_MechanicalVentilation_SelectedIndexChanged(object sender, EventArgs e)
          {
              try
              {
                  if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "1")
                  {
                      lbl_MechanicalVentilationDatetime.Show();
                      textBox_MechanicalVentilationDatetime.Enabled = true;
                      textBox_MechanicalVentilationDatetime.BackColor = result;
                  }
                  else
                  {
                      lbl_MechanicalVentilationDatetime.Hide();
                      textBox_MechanicalVentilationDatetime.Enabled = false;
                      textBox_MechanicalVentilationDatetime.Text = "";
                      textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
              }
              catch (Exception ex)
              {
              }

          }



          private void comboBox_VasopressorAdministration_SelectedIndexChanged(object sender, EventArgs e)
          {
              
              try
              {
              if (comboBox_VasopressorAdministration.SelectedValue.ToString() == "1")
              {
                  lbl_VasopressorAdministrationDateTime.Show();
                  textBox_VasopressorAdministrationDatetime.Enabled = true;
                  textBox_VasopressorAdministrationDatetime.BackColor = result;
              }
              else
              {
                  lbl_VasopressorAdministrationDateTime.Hide();
                  textBox_VasopressorAdministrationDatetime.Enabled = false;
                  textBox_VasopressorAdministrationDatetime.Text = "";

                  textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              }

               }
              catch (Exception ex)
              {
              }
          }






          private void comboBox_PediatricCrystalloidFluidAdministration_SelectedIndexChanged(object sender, EventArgs e)
          {
              try
              {
                  if (comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1")
                  {

                      lbl_CrystalloidFluidAdministrationDatetime.Show();

                      textBox_CrystalloidFluidAdministrationDatetime.Enabled = true;


                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = result;

                  }
                  else
                  {
                      lbl_CrystalloidFluidAdministrationDatetime.Hide();


                      textBox_CrystalloidFluidAdministrationDatetime.Enabled = false;


                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);


                      textBox_CrystalloidFluidAdministrationDatetime.Text = "";

                  }
               }
              catch (Exception ex)
              {
              }
         
          }

          private void comboBox_ExcludedFromProtocol_SelectedIndexChanged(object sender, EventArgs e)
          {
              try
              {
             
              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0")
              {
                  lbl_InitialHypotension.Show();
                  lbl_BloodCultureCollection.Show();
                  lbl_AntibioticAdministration.Show();
                  lbl_InitialLactateLevelCollection.Show();

                  //comboBox_InitialHypotension.Enabled = true;
                  comboBox_InitialHypotension.BackColor = result;
                  comboBox_BloodCultureCollection.BackColor = result;
                  comboBox_InitialLactateLevelCollection.BackColor = result;
                  comboBox_AntibioticAdministration.BackColor = result;

              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1")
              {
                  lbl_BloodCultureCollection.Hide();
                  lbl_InitialHypotension.Hide();
                  lbl_InitialLactateLevelCollection.Hide();
                  lbl_AntibioticAdministration.Hide();
                  //comboBox_InitialHypotension.Enabled = false;
                  comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray);
                  comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);
                  //comboBox_InitialHypotension.SelectedValue = "Select";
                  //comboBox_BloodCultureCollection.SelectedValue = "Select";
                  //comboBox_InitialLactateLevelCollection.SelectedValue = "Select";

              }
              else
              {
                  lbl_InitialLactateLevelCollection.Hide();
                  lbl_BloodCultureCollection.Hide();
                  lbl_InitialHypotension.Hide();
                  lbl_AntibioticAdministration.Hide();


                  //comboBox_InitialHypotension.Enabled = false;



                  comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray);

                  comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);

                  //comboBox_InitialHypotension.SelectedValue = "Select";

              }



              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1")
              {

                  lbl_ExcludedDatetime.Show();
                  lbl_ExcludedReason.Show();
                 

                  textBox_ExcludedDatetime.Enabled = true;
                  checkedListBox_ExcludedReason.Enabled = true;
                  //checkedListBox_ExcludedExplain.Enabled = true;

                  textBox_ExcludedDatetime.BackColor = result;
                  checkedListBox_ExcludedReason.BackColor = result;

              }
              else
              {
                  lbl_ExcludedDatetime.Hide();
                  lbl_ExcludedReason.Hide();
                  lbl_ExcludedExplain.Hide();
                  textBox_ExcludedDatetime.Enabled = false;
                  checkedListBox_ExcludedReason.Enabled = false;
                  checkedListBox_ExcludedExplain.Enabled = false;

                  textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.Gray);
                  checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.Gray);

                  textBox_ExcludedDatetime.Text = "";
                  foreach (int i in checkedListBox_ExcludedReason.CheckedIndices)
                  {
                      checkedListBox_ExcludedReason.SetItemCheckState(i, CheckState.Unchecked);
                  }

                  foreach (int i in checkedListBox_ExcludedExplain.CheckedIndices)
                  {
                      checkedListBox_ExcludedExplain.SetItemCheckState(i, CheckState.Unchecked);
                  }


              }

               }
              catch (Exception ex)
              {
              }
          }

          private void comboBox_AntibioticAdministration_SelectedIndexChanged(object sender, EventArgs e)
          {

            try
            {

              if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1")
              {

                  lbl_AntibioticAdministrationDatetime.Show();
                  lbl_AntibioticAdministrationSelection.Show();

                  textBox_AntibioticAdministrationDatetime.Enabled = true;
                  comboBox_AntibioticAdministrationSelection.Enabled = true;
                  textBox_AntibioticAdministrationDatetime.BackColor = result;
                  comboBox_AntibioticAdministrationSelection.BackColor = result;

              }
              else
              {

                  lbl_AntibioticAdministrationDatetime.Hide();
                  lbl_AntibioticAdministrationSelection.Hide();

                  textBox_AntibioticAdministrationDatetime.Enabled = false;
                  comboBox_AntibioticAdministrationSelection.Enabled = false;

                  textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                  comboBox_AntibioticAdministrationSelection.BackColor = MandatoryColor(Color.Gray);

                  textBox_AntibioticAdministrationDatetime.Text = "";
                  comboBox_AntibioticAdministrationSelection.SelectedValue = "Select";
                 
              }
               }
              catch (Exception ex)
              {
              }
          }

          private void comboBox_BloodCultureCollection_SelectedIndexChanged(object sender, EventArgs e)
          {
              try
              {
              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1")
              {
                 
                 
                  lbl_BloodCultureCollectionDatetime.Show();
                  lbl_ElevatedLactateReason.Show();
                  lbl_BloodCultureCollectionAcceptableDelay.Show();

                  textBox_BloodCultureCollectionDatetime.Enabled = true;
                  comboBox_BloodCultureCollectionAcceptableDelay.Enabled = true;

                  textBox_BloodCultureCollectionDatetime.BackColor =  result;
                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = result;
                
              }
              else
              {
                  lbl_BloodCultureCollectionAcceptableDelay.Hide();
                  lbl_BloodCultureCollectionDatetime.Hide();
                  lbl_ElevatedLactateReason.Hide();
          

                  textBox_BloodCultureCollectionDatetime.Enabled = false;

                  comboBox_BloodCultureCollectionAcceptableDelay.Enabled = false;
                  textBox_BloodCultureCollectionDatetime.Text = "";

                  comboBox_BloodCultureCollectionAcceptableDelay.SelectedValue = "Select";


                  textBox_BloodCultureCollectionDatetime.BackColor = MandatoryColor(Color.Gray);

                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = MandatoryColor(Color.Gray);
              }
               }
              catch (Exception ex)
              {
              }
          }

          private void comboBox_RepeatLactateLevelCollection_SelectedIndexChanged(object sender, EventArgs e)
          {
              try
              {
              if (comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "1")
              {

                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = true;
                  lbl_RepeatLactateLevelCollectionDatetime.Show();
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = result;
               
              }
              else
              {
                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = false;
                  lbl_RepeatLactateLevelCollectionDatetime.Hide();
                  textbox_RepeatLactateLevelCollectionDatetime.Text = "";
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
               
              }
               }
              catch (Exception ex)
              {
              }
          }

          private void comboBox_InitialLactateLevelCollection_SelectedIndexChanged(object sender, EventArgs e)
          {
              try
              {
              if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1")
              {


                  lbl_InitialLactateLevelCollectionDatetime.Show();
                  lbl_InitialLactateLevel.Show();


                  textBox_InitialLactateLevel.Enabled = true;
                  textBox_InitialLactateLevelCollectionDatetime.Enabled = true;

                  comboBox_RepeatLactateLevelCollection.Enabled = true;


                  textBox_InitialLactateLevel.BackColor = result;
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = result;



              }
              else 
              {

                  lbl_InitialLactateLevelCollectionDatetime.Hide();
  
                  lbl_InitialLactateLevel.Hide();
                  lbl_RepeatLactateLevelCollection.Hide();
                  lbl_RepeatLactateLevelCollectionDatetime.Hide();
                  textBox_InitialLactateLevel.Enabled = false;
                  textBox_InitialLactateLevelCollectionDatetime.Enabled = false;

                  comboBox_RepeatLactateLevelCollection.Enabled = false;
                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = false;
                  textBox_InitialLactateLevelCollectionDatetime.Text = "";

                  textBox_InitialLactateLevel.Text = "";
                  comboBox_RepeatLactateLevelCollection.SelectedValue = "Select";
                  textbox_RepeatLactateLevelCollectionDatetime.Text = "";

                  lbl_ElevatedLactateReason.Hide();

                  textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);

                  comboBox_RepeatLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
              }
               }
              catch (Exception ex)
              {
              }
          }

        

        

          private void comboBox_Payor_SelectedIndexChanged(object sender, EventArgs e)
          {
              try
              {
              if (comboBox_Payor.SelectedValue.ToString() == "C" || comboBox_Payor.SelectedValue.ToString() == "D" || comboBox_Payor.SelectedValue.ToString() == "F" || comboBox_Payor.SelectedValue.ToString() == "G")
              {

                  lbl_InsuranceNumber.Show();
                  TextBox_InsuranceNumber.BackColor = result;

              }
              else
              {

                  lbl_InsuranceNumber.Hide();
                  TextBox_InsuranceNumber.BackColor = MandatoryColor(Color.Gray);

              }
               }
              catch (Exception ex)
              {
              }
          }



          public void Dropdowncolor()
          {

          

              Combobox_Gender.BackColor = result;
              Combobox_Ethnicity.BackColor = result;
              comboBox_Payor.BackColor = result;
              comboBox_SourceofAdmission.BackColor = result;
              comboBox_DischargeStatus.BackColor = result;
              comboBox_TransferStatus.BackColor = result;
              Combobox_SepsisIdentificationPlace.BackColor = result;
              comboBox_ExcludedFromProtocol.BackColor = result;
              comboBox_SevereSepsisPresent.BackColor = result;
              comboBox_SepticShockPresent.BackColor = result;
              comboBox_InitialLactateLevelCollection.BackColor = result;
              comboBox_RepeatLactateLevelCollection.BackColor = result;
              comboBox_BloodCultureCollection.BackColor = result;
              comboBox_BloodCultureCollectionAcceptableDelay.BackColor = result;
              comboBox_AntibioticAdministration.BackColor = result;
              comboBox_AntibioticAdministrationSelection.BackColor = result;
              comboBox_AdultCrystalloidFluidAdministration.BackColor = result;
              comboBox_InitialHypotension.BackColor = result;
              comboBox_PersistentHypotension.BackColor = result;
              comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;
              comboBox_VasopressorAdministration.BackColor = result;
              comboBox_PlateletCount.BackColor = result;
              comboBox_AlteredMentalStatus.BackColor = result;
              comboBox_Bandemia.BackColor = result;
              comboBox_InfectionEtiology.BackColor = result;
              comboBox_LowerRespiratoryInfection.BackColor = result;
              comboBox_SiteofInfection.BackColor = result;
              comboBox_MechanicalVentilation.BackColor = result;
              comboBox_ICU.BackColor = result;
              comboBox_ChronicRespiratoryFailure.BackColor = result;
              comboBox_AIDSDisease.BackColor = result;
              comboBox_MetastaticCancer.BackColor = result;
              comboBox_Lymphoma.BackColor = result;
              comboBox_ImmuneModifyingMedications.BackColor = result;
              comboBox_CongestiveHeartFailure.BackColor = result;
              comboBox_ChronicRenalFailure.BackColor = result;
              comboBox_ChronicLiverDisease.BackColor = result;
              comboBox_Diabetes.BackColor = result;
              comboBox_OrganTransplant.BackColor = result;


          }


          public void MandatoryColorChange()
          {
              try
              {


              Color temp = System.Drawing.ColorTranslator.FromHtml("#FFF7D1");
              Color Mandatoryresult = Color.FromArgb(temp.R, temp.G, temp.B);
              // Actual Mandatory Fields
              if (txtId.Text.ToString().Trim() == "")
              {
                  txtId.BackColor = Mandatoryresult;
              }
              else
                  txtId.BackColor = result;



              if (TextBox_PatientCtrlNum.Text.ToString().Trim() == "")
              {
                  TextBox_PatientCtrlNum.BackColor = Mandatoryresult;
              }
              else
                  TextBox_PatientCtrlNum.BackColor = result;


              if (txtDOB.Text.ToString().Trim() == "/  /")
              {
                  txtDOB.BackColor = Mandatoryresult;
              }
              else
                  txtDOB.BackColor = result;


              if (Combobox_Gender.SelectedValue.ToString() == "Select")
              {
                  Combobox_Gender.BackColor = Mandatoryresult;
              }
              else
                  Combobox_Gender.BackColor = result;



              if (checkedListBox_Race.CheckedItems.Count == 0)
              {
                checkedListBox_Race.BackColor = Mandatoryresult;
              }
              else
                  checkedListBox_Race.BackColor = result;




              if (Combobox_Ethnicity.SelectedValue.ToString() == "Select")
              {
                  Combobox_Ethnicity.BackColor = Mandatoryresult;
              }
              else
                  Combobox_Ethnicity.BackColor = result;


              if (comboBox_Payor.SelectedValue.ToString() == "Select")
              {
                  comboBox_Payor.BackColor = Mandatoryresult;
              }

              else
                  comboBox_Payor.BackColor = result;


              if (txtMRN.Text.ToString().Trim() == "")
              {
                  txtMRN.BackColor = Mandatoryresult;
              }
              else
                  txtMRN.BackColor = result;


              if (TextBox_FacilityIdentifier.Text.ToString().Trim() == "")
              {
                  TextBox_FacilityIdentifier.BackColor = Mandatoryresult;
              }
              else
                  TextBox_FacilityIdentifier.BackColor = result;




              if (textBox_AdmissionDateTime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_AdmissionDateTime.BackColor = Mandatoryresult;
              }
              else
                  textBox_AdmissionDateTime.BackColor = result;

              if (textBox_DischargedDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_DischargedDatetime.BackColor = Mandatoryresult;
              }
              else
                  textBox_DischargedDatetime.BackColor = result;

              if (comboBox_SourceofAdmission.SelectedValue.ToString() == "Select")
              {
                  comboBox_SourceofAdmission.BackColor = Mandatoryresult;
              }
              else
                  comboBox_SourceofAdmission.BackColor = result;

              if (comboBox_DischargeStatus.SelectedValue.ToString() == "Select")
              {
                  comboBox_DischargeStatus.BackColor = Mandatoryresult;
              }
              else
                  comboBox_DischargeStatus.BackColor = result;


              if (comboBox_TransferStatus.SelectedValue.ToString() == "Select")
              {
                  comboBox_TransferStatus.BackColor = Mandatoryresult;
              }
              else
                  comboBox_TransferStatus.BackColor = result;


          


              if (Combobox_SepsisIdentificationPlace.SelectedValue.ToString() == "Select")
              {
                  Combobox_SepsisIdentificationPlace.BackColor = Mandatoryresult;
              }
              else
                  Combobox_SepsisIdentificationPlace.BackColor = result;




              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "Select")
              {
                  comboBox_ExcludedFromProtocol.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ExcludedFromProtocol.BackColor = result;


              if (textBox_ArrivalDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_ArrivalDatetime.BackColor = Mandatoryresult;
              }
              else
                  textBox_ArrivalDatetime.BackColor = result;

              if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "Select")
              {
                  comboBox_SevereSepsisPresent.BackColor = Mandatoryresult;
              }
              else
                  comboBox_SevereSepsisPresent.BackColor = result;



              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "Select")
              {
                  comboBox_SepticShockPresent.BackColor = Mandatoryresult;
              }
              else
                  comboBox_SepticShockPresent.BackColor = result;

              if (comboBox_PlateletCount.SelectedValue.ToString() == "Select")
              {
                  comboBox_PlateletCount.BackColor = Mandatoryresult;
              }
              else
                  comboBox_PlateletCount.BackColor = result;


              if (comboBox_AlteredMentalStatus.SelectedValue.ToString() == "Select")
              {
                  comboBox_AlteredMentalStatus.BackColor = Mandatoryresult;
              }
              else
                  comboBox_AlteredMentalStatus.BackColor = result;

              if (comboBox_InfectionEtiology.SelectedValue.ToString() == "Select")
              {
                  comboBox_InfectionEtiology.BackColor = Mandatoryresult;
              }
              else
                  comboBox_InfectionEtiology.BackColor = result;


              if (comboBox_LowerRespiratoryInfection.SelectedValue.ToString() == "Select")
              {
                  comboBox_LowerRespiratoryInfection.BackColor = Mandatoryresult;
              }
              else
                  comboBox_LowerRespiratoryInfection.BackColor = result;

              if (comboBox_Bandemia.SelectedValue.ToString() == "Select")
              {
               
                  comboBox_Bandemia.BackColor = Mandatoryresult;
              }
              else
                  comboBox_Bandemia.BackColor = result;


              if (comboBox_SiteofInfection.SelectedValue.ToString() == "Select")
              {
                  comboBox_SiteofInfection.BackColor = Mandatoryresult;
              }
              else
                  comboBox_SiteofInfection.BackColor = result;

              if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "Select")
              {
                  comboBox_MechanicalVentilation.BackColor = Mandatoryresult;
              }
              else
                  comboBox_MechanicalVentilation.BackColor = result;



              if (comboBox_ICU.SelectedValue.ToString() == "Select")
              {
                  comboBox_ICU.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ICU.BackColor = result;

              if (comboBox_ChronicRespiratoryFailure.SelectedValue.ToString() == "Select")
              {
                  comboBox_ChronicRespiratoryFailure.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ChronicRespiratoryFailure.BackColor = result;



              if (comboBox_AIDSDisease.SelectedValue.ToString() == "Select")
              {
                  comboBox_AIDSDisease.BackColor = Mandatoryresult;
              }
              else
                  comboBox_AIDSDisease.BackColor = result;


              if (comboBox_MetastaticCancer.SelectedValue.ToString() == "Select")
              {
                  comboBox_MetastaticCancer.BackColor = Mandatoryresult;
              }
              else
                  comboBox_MetastaticCancer.BackColor = result;


              if (comboBox_Lymphoma.SelectedValue.ToString() == "Select")
              {
                  comboBox_Lymphoma.BackColor = Mandatoryresult;
              }
              else
                  comboBox_Lymphoma.BackColor = result;

              if (comboBox_ImmuneModifyingMedications.SelectedValue.ToString() == "Select")
              {
                  comboBox_ImmuneModifyingMedications.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ImmuneModifyingMedications.BackColor = result;


              if (comboBox_CongestiveHeartFailure.SelectedValue.ToString() == "Select")
              {
                  comboBox_CongestiveHeartFailure.BackColor = Mandatoryresult;
              }
              else
                  comboBox_CongestiveHeartFailure.BackColor = result;

              if (comboBox_ChronicRenalFailure.SelectedValue.ToString() == "Select")
              {
                  comboBox_ChronicRenalFailure.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ChronicRenalFailure.BackColor = result;


              if (comboBox_ChronicLiverDisease.SelectedValue.ToString() == "Select")
              {
                  comboBox_ChronicLiverDisease.BackColor = Mandatoryresult;
              }
              else
                  comboBox_ChronicLiverDisease.BackColor = result;

              if (comboBox_Diabetes.SelectedValue.ToString() == "Select")
              {
                  comboBox_Diabetes.BackColor = Mandatoryresult;
              }
              else
                  comboBox_Diabetes.BackColor = result;


              if (comboBox_OrganTransplant.SelectedValue.ToString() == "Select")
              {
                  comboBox_OrganTransplant.BackColor = Mandatoryresult;
              }
              else
                  comboBox_OrganTransplant.BackColor = result;


              if (Combobox_SepsisIdentificationPlace.SelectedValue.ToString() == "Select")
              {
                  Combobox_SepsisIdentificationPlace.BackColor = Mandatoryresult;
              }
              else
                  Combobox_SepsisIdentificationPlace.BackColor = result;




              // Dependency validations
              if ((comboBox_Payor.SelectedValue.ToString() == "C" || comboBox_Payor.SelectedValue.ToString() == "D" || comboBox_Payor.SelectedValue.ToString() == "F" || comboBox_Payor.SelectedValue.ToString() == "G") && TextBox_InsuranceNumber.Text.ToString().Trim() == "")
              {

                  TextBox_InsuranceNumber.BackColor = Mandatoryresult;

              }
              else  if ((comboBox_Payor.SelectedValue.ToString() == "A" || comboBox_Payor.SelectedValue.ToString() == "B" || comboBox_Payor.SelectedValue.ToString() == "E" || comboBox_Payor.SelectedValue.ToString() == "H" || comboBox_Payor.SelectedValue.ToString() == "I"))
              {
                  TextBox_InsuranceNumber.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  TextBox_InsuranceNumber.BackColor = result;


              if ((comboBox_TransferStatus.SelectedValue.ToString() == "3" || comboBox_TransferStatus.SelectedValue.ToString() == "4" || comboBox_TransferStatus.SelectedValue.ToString() == "5") && textBox_TransferFacilityIdentifier.Text.Trim() == "")
              {
                  textBox_TransferFacilityIdentifier.BackColor = Mandatoryresult;
              }
              else if (comboBox_TransferStatus.SelectedValue.ToString() == "1" || comboBox_TransferStatus.SelectedValue.ToString() == "2")
              {
                  textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_TransferFacilityIdentifier.BackColor = result;


              if (comboBox_ICU.SelectedValue.ToString() == "1" && textBox_ICUAdmissionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_ICUAdmissionDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_ICU.SelectedValue.ToString() != "1")
              {
                  textBox_ICUAdmissionDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_ICUAdmissionDatetime.BackColor = result;


              if (comboBox_ICU.SelectedValue.ToString() == "1" && textBox_ICUDischargeDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_ICUDischargeDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_ICU.SelectedValue.ToString() != "1")
              {
                  textBox_ICUDischargeDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_ICUDischargeDatetime.BackColor = result;


              if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "1" && textBox_MechanicalVentilationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_MechanicalVentilationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_MechanicalVentilation.SelectedValue.ToString() != "1")
              {
                  textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_MechanicalVentilationDatetime.BackColor = result;



              if (comboBox_VasopressorAdministration.SelectedValue.ToString() == "1" && textBox_VasopressorAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_VasopressorAdministrationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_VasopressorAdministration.SelectedValue.ToString() != "1")
              {
                  textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_VasopressorAdministrationDatetime.BackColor = result;



              if (comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.SelectedValue.ToString() == "1" && textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.SelectedValue.ToString() != "1")
              {
                  textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.BackColor = result;





              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_AntibioticAdministration.SelectedValue.ToString() == "Select")
              {
                   comboBox_AntibioticAdministration.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
              {
                  comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_AntibioticAdministration.BackColor = result;


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_InitialHypotension.SelectedValue.ToString() == "Select")
              {
                   comboBox_InitialHypotension.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
              {
                  comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_InitialHypotension.BackColor = result;



              if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && textBox_CrystalloidFluidAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_CrystalloidFluidAdministrationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "Select" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
              {
                  textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_CrystalloidFluidAdministrationDatetime.BackColor = result;

           

              if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1" && textBox_AntibioticAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_AntibioticAdministrationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_AntibioticAdministration.SelectedValue.ToString() != "1")
              {
                  textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_AntibioticAdministrationDatetime.BackColor = result;


              if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1" && comboBox_AntibioticAdministrationSelection.SelectedValue.ToString() == "Select")
              {
                   comboBox_AntibioticAdministrationSelection.BackColor = Mandatoryresult;
              }
              else if (comboBox_AntibioticAdministration.SelectedValue.ToString() != "1")
              {
                  comboBox_AntibioticAdministrationSelection.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_AntibioticAdministrationSelection.BackColor = result;





              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && textBox_BloodCultureCollectionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_BloodCultureCollectionDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_BloodCultureCollection.SelectedValue.ToString() != "1")
              {
                  textBox_BloodCultureCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_BloodCultureCollectionDatetime.BackColor = result;


              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && comboBox_BloodCultureCollectionAcceptableDelay.SelectedValue.ToString() == "Select")
              {
                   comboBox_BloodCultureCollectionAcceptableDelay.BackColor = Mandatoryresult;
              }
              else if (comboBox_BloodCultureCollection.SelectedValue.ToString() != "1")
              {
                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = result;


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_BloodCultureCollection.SelectedValue.ToString() == "Select")
              {
                   comboBox_BloodCultureCollection.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
              {
                  comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_BloodCultureCollection.BackColor = result;


              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "Select")
              {
                  comboBox_InitialLactateLevelCollection.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
              {
                  comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_InitialLactateLevelCollection.BackColor = result;


              if (comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "1" && textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textbox_RepeatLactateLevelCollectionDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() != "1")
                  {
                      textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
              else
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = result;


              if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1" && textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_InitialLactateLevelCollectionDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() != "1")
              {
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = result;


              if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1" && textBox_InitialLactateLevel.Text.ToString().Trim() == "")
              {
                  textBox_InitialLactateLevel.BackColor = Mandatoryresult;
              }
              else if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() != "1")
              {
                  textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_InitialLactateLevel.BackColor = result;



              if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1" && comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "Select")
              {
                  comboBox_RepeatLactateLevelCollection.BackColor = Mandatoryresult;
              }
              else if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() != "1")
              {
                  comboBox_RepeatLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_RepeatLactateLevelCollection.BackColor = result;



              if (comboBox_InitialHypotension.SelectedValue.ToString() == "1" && textbox_InitialHypotensionDateTime.Text.ToString().Trim() == "/  /       :")
              {
                  textbox_InitialHypotensionDateTime.BackColor = Mandatoryresult;
              }
              else if (comboBox_InitialHypotension.SelectedValue.ToString() != "1")
              {
                  textbox_InitialHypotensionDateTime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textbox_InitialHypotensionDateTime.BackColor = result;


              if (comboBox_InitialHypotension.SelectedValue.ToString() == "1" && comboBox_PersistentHypotension.SelectedValue.ToString() == "Select")
              {
                  comboBox_PersistentHypotension.BackColor = Mandatoryresult;
              }
              else if (comboBox_InitialHypotension.SelectedValue.ToString() != "1")
              {
                  comboBox_PersistentHypotension.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  comboBox_PersistentHypotension.BackColor = result;





              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1" && checkedListBox_ExcludedReason.CheckedItems.Count == 0)
              {
                   checkedListBox_ExcludedReason.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "1")
              {
                  checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  checkedListBox_ExcludedReason.BackColor = result;



              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1" && textBox_ExcludedDatetime.Text.ToString().Trim() == "/  /       :")
              {
                   textBox_ExcludedDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "1")
              {
                  textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_ExcludedDatetime.BackColor = result;




              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && textBox_septicShockPresentationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_septicShockPresentationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_SepticShockPresent.SelectedValue.ToString() != "1")
              {
                  textBox_septicShockPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_septicShockPresentationDatetime.BackColor = result;


              if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "1" && textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim() == "/  /       :")
              {
                  textBox_SevereSepsisPresentationDatetime.BackColor = Mandatoryresult;
              }
              else if (comboBox_SevereSepsisPresent.SelectedValue.ToString() != "1")
              {
                  textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  textBox_SevereSepsisPresentationDatetime.BackColor = result;



              for (int i = 0; i < checkedListBox_ExcludedReason.Items.Count; i++)
              {
                  if (checkedListBox_ExcludedReason.GetItemChecked(i) == true)
                  {
                      DataRowView castedItem = checkedListBox_ExcludedReason.Items[i] as DataRowView;
                      if (castedItem["ComboBox_Key"].ToString() == "1")
                      {
                          ExcludedResonChecked = 1;
                          break;
                      }
                  }

              }


              if (ExcludedResonChecked == 1 && checkedListBox_ExcludedExplain.CheckedItems.Count <= 0)
              {
                  ExcludedResonChecked = 0;
                  checkedListBox_ExcludedExplain.BackColor = Mandatoryresult;
              }
              else if (ExcludedResonChecked  != 1)
              {
                  checkedListBox_ExcludedExplain.BackColor = MandatoryColor(Color.Gray);
              }
              else
                  checkedListBox_ExcludedExplain.BackColor = result;


              DateTime dDate;
              decimal j = 0;
              if (textBox_InitialLactateLevel.Text.Length >= 1)
              {


                  j = decimal.Parse(textBox_InitialLactateLevel.Text);
              }

                  if (validateDate(txtDOB.Text.ToString().Trim()) == true)
                  {

                      if (DateTime.TryParseExact(txtDOB.Text.ToString().Trim(), format2, CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out dDate))


                          if (((comboBox_InitialHypotension.SelectedValue.ToString() == "1" || comboBox_SepticShockPresent.SelectedValue.ToString() == "1" || j >= 4) && DateTime.Compare(DateTime.Today.AddYears(-18), dDate) >= 0) && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
                          {
                              comboBox_AdultCrystalloidFluidAdministration.BackColor = Mandatoryresult;
                          }
                          else if ((comboBox_InitialHypotension.SelectedValue.ToString() == "1" || comboBox_SepticShockPresent.SelectedValue.ToString() == "1" || j >= 4) && DateTime.Compare(DateTime.Today.AddYears(-18), dDate) >= 0)
                          {
                              comboBox_AdultCrystalloidFluidAdministration.BackColor = result;
                          }
                          else
                              comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);


                      if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate) < 0 && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
                      {
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = Mandatoryresult;
                      }
                      else if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate) < 0)
                      {
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;
                      }
                      else
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);


                  }

                  if (j > 2 && comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "Select")

                   comboBox_RepeatLactateLevelCollection.BackColor = Mandatoryresult;

                  else if (j > 2)
                  {
                      comboBox_RepeatLactateLevelCollection.BackColor = result;
                  }
                  else
                      comboBox_RepeatLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);



                  if (j > 2 && comboBox_ElevatedLactateReason.SelectedValue.ToString() == "Select")

                      comboBox_ElevatedLactateReason.BackColor = Mandatoryresult;
                  else if (j > 2)
                      comboBox_ElevatedLactateReason.BackColor = result;
                  else
                      comboBox_ElevatedLactateReason.BackColor = MandatoryColor(Color.Gray);





                  DateTime dDate1;

                  if (DateTime.TryParseExact(txtDOB.Text.ToString().Trim(), format2, CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None, out dDate1))

                      if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate1) < 0 && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = Mandatoryresult;
                      else if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate1) < 0)
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;
                      else
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);



                  if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate1) >= 0 && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = Mandatoryresult;
                  else if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate1) >= 0)
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = result;
                  else
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                 




              



              if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" && comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.SelectedValue.ToString() == "Select")

                  comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.BackColor = Mandatoryresult;
              else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" && comboBox_SepticShockPresent.SelectedValue.ToString() == "1")
                  comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.BackColor = result;
              else
                  comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.BackColor = MandatoryColor(Color.Gray);




              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" && comboBox_PersistentHypotension.SelectedValue.ToString() == "1" && comboBox_VasopressorAdministration.SelectedValue.ToString() == "Select")
                  comboBox_VasopressorAdministration.BackColor = Mandatoryresult;
              else if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" && comboBox_PersistentHypotension.SelectedValue.ToString() == "1")
                  comboBox_VasopressorAdministration.BackColor = result;
              else
                  comboBox_VasopressorAdministration.BackColor = MandatoryColor(Color.Gray);
       

               }
              catch (Exception ex)
              {
              }
         

          }













          public void MandatoryColorChange_NewCase()
          {
              try
              {


                  Color temp = System.Drawing.ColorTranslator.FromHtml("#E8E8E8");
                  Color Mandatoryresult = Color.FromArgb(temp.R, temp.G, temp.B);
                  // Actual Mandatory Fields
                  if (txtId.Text.ToString().Trim() == "")
                  {
                      txtId.BackColor = Mandatoryresult;
                  }
                  else
                      txtId.BackColor = MandatoryColor(Color.Gray);



                  if (TextBox_PatientCtrlNum.Text.ToString().Trim() == "")
                  {
                      TextBox_PatientCtrlNum.BackColor = Mandatoryresult;
                  }
                  else
                      TextBox_PatientCtrlNum.BackColor = MandatoryColor(Color.Gray);


                  if (txtDOB.Text.ToString().Trim() == "/  /")
                  {
                      txtDOB.BackColor = Mandatoryresult;
                  }
                  else
                      txtDOB.BackColor = MandatoryColor(Color.Gray);


                  if (Combobox_Gender.SelectedValue.ToString() == "Select")
                  {
                      Combobox_Gender.BackColor = Mandatoryresult;
                  }
                  else
                      Combobox_Gender.BackColor = MandatoryColor(Color.Gray);



                  if (checkedListBox_Race.CheckedItems.Count == 0)
                  {
                      checkedListBox_Race.BackColor = Mandatoryresult;
                  }
                  else
                      checkedListBox_Race.BackColor = MandatoryColor(Color.Gray);




                  if (Combobox_Ethnicity.SelectedValue.ToString() == "Select")
                  {
                      Combobox_Ethnicity.BackColor = Mandatoryresult;
                  }
                  else
                      Combobox_Ethnicity.BackColor = MandatoryColor(Color.Gray);


                  if (comboBox_Payor.SelectedValue.ToString() == "Select")
                  {
                      comboBox_Payor.BackColor = Mandatoryresult;
                  }

                  else
                      comboBox_Payor.BackColor = MandatoryColor(Color.Gray);


                  if (txtMRN.Text.ToString().Trim() == "")
                  {
                      txtMRN.BackColor = Mandatoryresult;
                  }
                  else
                      txtMRN.BackColor = MandatoryColor(Color.Gray);


                  if (TextBox_FacilityIdentifier.Text.ToString().Trim() == "")
                  {
                      TextBox_FacilityIdentifier.BackColor = Mandatoryresult;
                  }
                  else
                      TextBox_FacilityIdentifier.BackColor = MandatoryColor(Color.Gray);




                  if (textBox_AdmissionDateTime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_AdmissionDateTime.BackColor = Mandatoryresult;
                  }
                  else
                      textBox_AdmissionDateTime.BackColor = MandatoryColor(Color.Gray);

                  if (textBox_DischargedDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_DischargedDatetime.BackColor = Mandatoryresult;
                  }
                  else
                      textBox_DischargedDatetime.BackColor = MandatoryColor(Color.Gray);

                  if (comboBox_SourceofAdmission.SelectedValue.ToString() == "Select")
                  {
                      comboBox_SourceofAdmission.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_SourceofAdmission.BackColor = MandatoryColor(Color.Gray);

                  if (comboBox_DischargeStatus.SelectedValue.ToString() == "Select")
                  {
                      comboBox_DischargeStatus.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_DischargeStatus.BackColor = MandatoryColor(Color.Gray);


                  if (comboBox_TransferStatus.SelectedValue.ToString() == "Select")
                  {
                      comboBox_TransferStatus.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_TransferStatus.BackColor = MandatoryColor(Color.Gray);





                  if (Combobox_SepsisIdentificationPlace.SelectedValue.ToString() == "Select")
                  {
                      Combobox_SepsisIdentificationPlace.BackColor = Mandatoryresult;
                  }
                  else
                      Combobox_SepsisIdentificationPlace.BackColor = MandatoryColor(Color.Gray);




                  if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "Select")
                  {
                      comboBox_ExcludedFromProtocol.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_ExcludedFromProtocol.BackColor = MandatoryColor(Color.Gray);


                  if (textBox_ArrivalDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_ArrivalDatetime.BackColor = Mandatoryresult;
                  }
                  else
                      textBox_ArrivalDatetime.BackColor = MandatoryColor(Color.Gray);

                  if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "Select")
                  {
                      comboBox_SevereSepsisPresent.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_SevereSepsisPresent.BackColor = MandatoryColor(Color.Gray);



                  if (comboBox_SepticShockPresent.SelectedValue.ToString() == "Select")
                  {
                      comboBox_SepticShockPresent.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_SepticShockPresent.BackColor = MandatoryColor(Color.Gray);

                  if (comboBox_PlateletCount.SelectedValue.ToString() == "Select")
                  {
                      comboBox_PlateletCount.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_PlateletCount.BackColor = MandatoryColor(Color.Gray);


                  if (comboBox_AlteredMentalStatus.SelectedValue.ToString() == "Select")
                  {
                      comboBox_AlteredMentalStatus.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_AlteredMentalStatus.BackColor = MandatoryColor(Color.Gray);

                  if (comboBox_InfectionEtiology.SelectedValue.ToString() == "Select")
                  {
                      comboBox_InfectionEtiology.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_InfectionEtiology.BackColor = MandatoryColor(Color.Gray);


                  if (comboBox_LowerRespiratoryInfection.SelectedValue.ToString() == "Select")
                  {
                      comboBox_LowerRespiratoryInfection.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_LowerRespiratoryInfection.BackColor = MandatoryColor(Color.Gray);

                  if (comboBox_Bandemia.SelectedValue.ToString() == "Select")
                  {

                      comboBox_Bandemia.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_Bandemia.BackColor = MandatoryColor(Color.Gray);


                  if (comboBox_SiteofInfection.SelectedValue.ToString() == "Select")
                  {
                      comboBox_SiteofInfection.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_SiteofInfection.BackColor = MandatoryColor(Color.Gray);

                  if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "Select")
                  {
                      comboBox_MechanicalVentilation.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_MechanicalVentilation.BackColor = MandatoryColor(Color.Gray);



                  if (comboBox_ICU.SelectedValue.ToString() == "Select")
                  {
                      comboBox_ICU.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_ICU.BackColor = MandatoryColor(Color.Gray);

                  if (comboBox_ChronicRespiratoryFailure.SelectedValue.ToString() == "Select")
                  {
                      comboBox_ChronicRespiratoryFailure.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_ChronicRespiratoryFailure.BackColor = MandatoryColor(Color.Gray);



                  if (comboBox_AIDSDisease.SelectedValue.ToString() == "Select")
                  {
                      comboBox_AIDSDisease.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_AIDSDisease.BackColor = MandatoryColor(Color.Gray);


                  if (comboBox_MetastaticCancer.SelectedValue.ToString() == "Select")
                  {
                      comboBox_MetastaticCancer.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_MetastaticCancer.BackColor = MandatoryColor(Color.Gray);


                  if (comboBox_Lymphoma.SelectedValue.ToString() == "Select")
                  {
                      comboBox_Lymphoma.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_Lymphoma.BackColor = MandatoryColor(Color.Gray);

                  if (comboBox_ImmuneModifyingMedications.SelectedValue.ToString() == "Select")
                  {
                      comboBox_ImmuneModifyingMedications.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_ImmuneModifyingMedications.BackColor = MandatoryColor(Color.Gray);


                  if (comboBox_CongestiveHeartFailure.SelectedValue.ToString() == "Select")
                  {
                      comboBox_CongestiveHeartFailure.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_CongestiveHeartFailure.BackColor = MandatoryColor(Color.Gray);

                  if (comboBox_ChronicRenalFailure.SelectedValue.ToString() == "Select")
                  {
                      comboBox_ChronicRenalFailure.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_ChronicRenalFailure.BackColor = MandatoryColor(Color.Gray);


                  if (comboBox_ChronicLiverDisease.SelectedValue.ToString() == "Select")
                  {
                      comboBox_ChronicLiverDisease.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_ChronicLiverDisease.BackColor = MandatoryColor(Color.Gray);

                  if (comboBox_Diabetes.SelectedValue.ToString() == "Select")
                  {
                      comboBox_Diabetes.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_Diabetes.BackColor = MandatoryColor(Color.Gray);


                  if (comboBox_OrganTransplant.SelectedValue.ToString() == "Select")
                  {
                      comboBox_OrganTransplant.BackColor = Mandatoryresult;
                  }
                  else
                      comboBox_OrganTransplant.BackColor = MandatoryColor(Color.Gray);


                  if (Combobox_SepsisIdentificationPlace.SelectedValue.ToString() == "Select")
                  {
                      Combobox_SepsisIdentificationPlace.BackColor = Mandatoryresult;
                  }
                  else
                      Combobox_SepsisIdentificationPlace.BackColor = MandatoryColor(Color.Gray);




                  // Dependency validations
                  if ((comboBox_Payor.SelectedValue.ToString() == "C" || comboBox_Payor.SelectedValue.ToString() == "D" || comboBox_Payor.SelectedValue.ToString() == "F" || comboBox_Payor.SelectedValue.ToString() == "G") && TextBox_InsuranceNumber.Text.ToString().Trim() == "")
                  {

                      TextBox_InsuranceNumber.BackColor = Mandatoryresult;

                  }
                  else if ((comboBox_Payor.SelectedValue.ToString() == "A" || comboBox_Payor.SelectedValue.ToString() == "B" || comboBox_Payor.SelectedValue.ToString() == "E" || comboBox_Payor.SelectedValue.ToString() == "H" || comboBox_Payor.SelectedValue.ToString() == "I"))
                  {
                      TextBox_InsuranceNumber.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      TextBox_InsuranceNumber.BackColor = result;


                  if ((comboBox_TransferStatus.SelectedValue.ToString() == "3" || comboBox_TransferStatus.SelectedValue.ToString() == "4" || comboBox_TransferStatus.SelectedValue.ToString() == "5") && textBox_TransferFacilityIdentifier.Text.Trim() == "")
                  {
                      textBox_TransferFacilityIdentifier.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_TransferStatus.SelectedValue.ToString() == "1" || comboBox_TransferStatus.SelectedValue.ToString() == "2")
                  {
                      textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_TransferFacilityIdentifier.BackColor = result;


                  if (comboBox_ICU.SelectedValue.ToString() == "1" && textBox_ICUAdmissionDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_ICUAdmissionDatetime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_ICU.SelectedValue.ToString() != "1")
                  {
                      textBox_ICUAdmissionDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_ICUAdmissionDatetime.BackColor = result;


                  if (comboBox_ICU.SelectedValue.ToString() == "1" && textBox_ICUDischargeDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_ICUDischargeDatetime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_ICU.SelectedValue.ToString() != "1")
                  {
                      textBox_ICUDischargeDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_ICUDischargeDatetime.BackColor = result;


                  if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "1" && textBox_MechanicalVentilationDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_MechanicalVentilationDatetime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_MechanicalVentilation.SelectedValue.ToString() != "1")
                  {
                      textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_MechanicalVentilationDatetime.BackColor = result;



                  if (comboBox_VasopressorAdministration.SelectedValue.ToString() == "1" && textBox_VasopressorAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_VasopressorAdministrationDatetime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_VasopressorAdministration.SelectedValue.ToString() != "1")
                  {
                      textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_VasopressorAdministrationDatetime.BackColor = result;



                  if (comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.SelectedValue.ToString() == "1" && textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.SelectedValue.ToString() != "1")
                  {
                      textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.BackColor = result;





                  if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_AntibioticAdministration.SelectedValue.ToString() == "Select")
                  {
                      comboBox_AntibioticAdministration.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
                  {
                      comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      comboBox_AntibioticAdministration.BackColor = result;


                  if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_InitialHypotension.SelectedValue.ToString() == "Select")
                  {
                      comboBox_InitialHypotension.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
                  {
                      comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      comboBox_InitialHypotension.BackColor = result;



                  if ((comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1") && textBox_CrystalloidFluidAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "Select" && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
                  {
                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_CrystalloidFluidAdministrationDatetime.BackColor = result;



                  if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1" && textBox_AntibioticAdministrationDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_AntibioticAdministrationDatetime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_AntibioticAdministration.SelectedValue.ToString() != "1")
                  {
                      textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_AntibioticAdministrationDatetime.BackColor = result;


                  if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1" && comboBox_AntibioticAdministrationSelection.SelectedValue.ToString() == "Select")
                  {
                      comboBox_AntibioticAdministrationSelection.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_AntibioticAdministration.SelectedValue.ToString() != "1")
                  {
                      comboBox_AntibioticAdministrationSelection.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      comboBox_AntibioticAdministrationSelection.BackColor = result;





                  if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && textBox_BloodCultureCollectionDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_BloodCultureCollectionDatetime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_BloodCultureCollection.SelectedValue.ToString() != "1")
                  {
                      textBox_BloodCultureCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_BloodCultureCollectionDatetime.BackColor = result;


                  if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1" && comboBox_BloodCultureCollectionAcceptableDelay.SelectedValue.ToString() == "Select")
                  {
                      comboBox_BloodCultureCollectionAcceptableDelay.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_BloodCultureCollection.SelectedValue.ToString() != "1")
                  {
                      comboBox_BloodCultureCollectionAcceptableDelay.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      comboBox_BloodCultureCollectionAcceptableDelay.BackColor = result;


                  if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_BloodCultureCollection.SelectedValue.ToString() == "Select")
                  {
                      comboBox_BloodCultureCollection.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
                  {
                      comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      comboBox_BloodCultureCollection.BackColor = result;


                  if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0" && comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "Select")
                  {
                      comboBox_InitialLactateLevelCollection.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "0")
                  {
                      comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      comboBox_InitialLactateLevelCollection.BackColor = result;


                  if (comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "1" && textbox_RepeatLactateLevelCollectionDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textbox_RepeatLactateLevelCollectionDatetime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() != "1")
                  {
                      textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textbox_RepeatLactateLevelCollectionDatetime.BackColor = result;


                  if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1" && textBox_InitialLactateLevelCollectionDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_InitialLactateLevelCollectionDatetime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() != "1")
                  {
                      textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_InitialLactateLevelCollectionDatetime.BackColor = result;


                  if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1" && textBox_InitialLactateLevel.Text.ToString().Trim() == "")
                  {
                      textBox_InitialLactateLevel.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() != "1")
                  {
                      textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_InitialLactateLevel.BackColor = result;



                  if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1" && comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "Select")
                  {
                      comboBox_RepeatLactateLevelCollection.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() != "1")
                  {
                      comboBox_RepeatLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      comboBox_RepeatLactateLevelCollection.BackColor = result;



                  if (comboBox_InitialHypotension.SelectedValue.ToString() == "1" && textbox_InitialHypotensionDateTime.Text.ToString().Trim() == "/  /       :")
                  {
                      textbox_InitialHypotensionDateTime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_InitialHypotension.SelectedValue.ToString() != "1")
                  {
                      textbox_InitialHypotensionDateTime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textbox_InitialHypotensionDateTime.BackColor = result;


                  if (comboBox_InitialHypotension.SelectedValue.ToString() == "1" && comboBox_PersistentHypotension.SelectedValue.ToString() == "Select")
                  {
                      comboBox_PersistentHypotension.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_InitialHypotension.SelectedValue.ToString() != "1")
                  {
                      comboBox_PersistentHypotension.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      comboBox_PersistentHypotension.BackColor = result;





                  if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1" && checkedListBox_ExcludedReason.CheckedItems.Count == 0)
                  {
                      checkedListBox_ExcludedReason.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "1")
                  {
                      checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      checkedListBox_ExcludedReason.BackColor = result;



                  if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1" && textBox_ExcludedDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_ExcludedDatetime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() != "1")
                  {
                      textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_ExcludedDatetime.BackColor = result;




                  if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && textBox_septicShockPresentationDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_septicShockPresentationDatetime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_SepticShockPresent.SelectedValue.ToString() != "1")
                  {
                      textBox_septicShockPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_septicShockPresentationDatetime.BackColor = result;


                  if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "1" && textBox_SevereSepsisPresentationDatetime.Text.ToString().Trim() == "/  /       :")
                  {
                      textBox_SevereSepsisPresentationDatetime.BackColor = Mandatoryresult;
                  }
                  else if (comboBox_SevereSepsisPresent.SelectedValue.ToString() != "1")
                  {
                      textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      textBox_SevereSepsisPresentationDatetime.BackColor = result;



                  for (int i = 0; i < checkedListBox_ExcludedReason.Items.Count; i++)
                  {
                      if (checkedListBox_ExcludedReason.GetItemChecked(i) == true)
                      {
                          DataRowView castedItem = checkedListBox_ExcludedReason.Items[i] as DataRowView;
                          if (castedItem["ComboBox_Key"].ToString() == "1")
                          {
                              ExcludedResonChecked = 1;
                              break;
                          }
                      }

                  }


                  if (ExcludedResonChecked == 1 && checkedListBox_ExcludedExplain.CheckedItems.Count <= 0)
                  {
                      ExcludedResonChecked = 0;
                      checkedListBox_ExcludedExplain.BackColor = Mandatoryresult;
                  }
                  else if (ExcludedResonChecked != 1)
                  {
                      checkedListBox_ExcludedExplain.BackColor = MandatoryColor(Color.Gray);
                  }
                  else
                      checkedListBox_ExcludedExplain.BackColor = result;


                  DateTime dDate;
                  decimal j = 0;
                  if (textBox_InitialLactateLevel.Text.Length >= 1)
                  {


                      j = decimal.Parse(textBox_InitialLactateLevel.Text);
                  }

                  if (validateDate(txtDOB.Text.ToString().Trim()) == true)
                  {

                      if (DateTime.TryParseExact(txtDOB.Text.ToString().Trim(), format2, CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out dDate))


                          if (((comboBox_InitialHypotension.SelectedValue.ToString() == "1" || comboBox_SepticShockPresent.SelectedValue.ToString() == "1" || j >= 4) && DateTime.Compare(DateTime.Today.AddYears(-18), dDate) >= 0) && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
                              comboBox_AdultCrystalloidFluidAdministration.BackColor = Mandatoryresult;
                          else
                              comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);


                      if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate) < 0 && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = Mandatoryresult;
                      else
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);


                  }

                  if (j > 2 && comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "Select")

                      comboBox_RepeatLactateLevelCollection.BackColor = Mandatoryresult;
                  else
                      comboBox_RepeatLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);



                  if (j > 2 && comboBox_ElevatedLactateReason.SelectedValue.ToString() == "Select")

                      comboBox_ElevatedLactateReason.BackColor = Mandatoryresult;
                  else
                      comboBox_ElevatedLactateReason.BackColor = MandatoryColor(Color.Gray);






                  DateTime dDate1;

                  if (DateTime.TryParseExact(txtDOB.Text.ToString().Trim(), format2, CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None, out dDate1))

                      if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate1) < 0 && comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = Mandatoryresult;

                      else
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);



                  if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate1) >= 0 && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "Select")
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = Mandatoryresult;

                  else
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);









                  if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" && comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.SelectedValue.ToString() == "Select")

                      comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.BackColor = Mandatoryresult;
                  else
                      comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.BackColor = MandatoryColor(Color.Gray);




                  if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" && comboBox_PersistentHypotension.SelectedValue.ToString() == "1" && comboBox_VasopressorAdministration.SelectedValue.ToString() == "Select")
                      comboBox_VasopressorAdministration.BackColor = Mandatoryresult;
                  else
                      comboBox_VasopressorAdministration.BackColor = MandatoryColor(Color.Gray);


              }
              catch (Exception ex)
              {
              }


          }





          public void SituationalDisplayforEdit()
          {
              try
              {
              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1")
              {

                  lbl_SepticShockPresentationDatetime.Show();
                  textBox_septicShockPresentationDatetime.Enabled = true;
              }
              else
              {
                  lbl_SepticShockPresentationDatetime.Hide();
                  textBox_septicShockPresentationDatetime.Enabled = false;
                  textBox_septicShockPresentationDatetime.Text = "";
              }


              if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "1")
              {

                  lbl_SevereSepsisPresentationDatetime.Show();
                  textBox_SevereSepsisPresentationDatetime.Enabled = true;
              }
              else
              {
                  lbl_SevereSepsisPresentationDatetime.Hide();
                  textBox_SevereSepsisPresentationDatetime.Enabled = false;
                  textBox_SevereSepsisPresentationDatetime.Text = "";
              }


              DateTime dDate;
              decimal j = 0;

                  if (validateDate(txtDOB.Text.ToString().Trim()) == true)
                  {


                    

                      if (textBox_InitialLactateLevel.Text != "")
                          j = decimal.Parse(textBox_InitialLactateLevel.Text);

                      if (DateTime.TryParseExact(txtDOB.Text.ToString().Trim(), format2, CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out dDate))


                          if ((comboBox_InitialHypotension.SelectedValue.ToString() == "1" || comboBox_SepticShockPresent.SelectedValue.ToString() == "1" || j >= 4) && DateTime.Compare(DateTime.Today.AddYears(-18), dDate) >= 0)
                          {


                              lbl_AdultCrystalloidFluidAdministration.Show();
                              comboBox_AdultCrystalloidFluidAdministration.BackColor = result;

                          }
                          else
                          {

                              lbl_AdultCrystalloidFluidAdministration.Hide();
                              comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                
                          }


                      if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate) < 0)
                      {

                          lbl_PediatricCrystalloidFluidAdministration.Show();
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;
                      }
                      else
                      {
                          lbl_PediatricCrystalloidFluidAdministration.Hide();
                         
                          comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

                      }




                  }
               


                  j = 0;
                  if (textBox_InitialLactateLevel.Text != "")
                      j = decimal.Parse(textBox_InitialLactateLevel.Text);

                  if (j > 2)
                  {

                      lbl_RepeatLactateLevelCollection.Show();
                      lbl_ElevatedLactateReason.Show();
                      comboBox_RepeatLactateLevelCollection.BackColor = result;
                      comboBox_ElevatedLactateReason.BackColor = result;
           
                  }

                  else
                  {
                      lbl_RepeatLactateLevelCollection.Hide();
                      comboBox_RepeatLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
                      lbl_ElevatedLactateReason.Hide();
                      comboBox_ElevatedLactateReason.BackColor = MandatoryColor(Color.Gray);
                  }




                  if (comboBox_InitialHypotension.SelectedValue.ToString() == "1")
                  {

                      lbl_PersistentHypotension.Show();
                      comboBox_PersistentHypotension.BackColor = result;
                  }
                  else
                  {

                      lbl_PersistentHypotension.Hide();
                      comboBox_PersistentHypotension.BackColor = MandatoryColor(Color.Gray);
                  }



                  if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" && comboBox_SepticShockPresent.SelectedValue.ToString() == "1")
                     {
                          lbl_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.Show();
                          comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.BackColor = result;
                      }
                      else
                      {
                          lbl_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.Hide();
                          comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.BackColor = MandatoryColor(Color.Gray);
                      }


                  if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" && comboBox_PersistentHypotension.SelectedValue.ToString() == "1")
                  {


                      lbl_VasopressorAdministration.Show();
                 
                      comboBox_VasopressorAdministration.BackColor = result;
                  }
                  else
                  {
                      lbl_VasopressorAdministration.Hide();
            

                      comboBox_VasopressorAdministration.BackColor = MandatoryColor(Color.Gray);
                  }






              if (comboBox_Payor.SelectedValue.ToString() == "C" || comboBox_Payor.SelectedValue.ToString() == "D" || comboBox_Payor.SelectedValue.ToString() == "F" || comboBox_Payor.SelectedValue.ToString() == "G")
              {

                  lbl_InsuranceNumber.Show();
                  TextBox_InsuranceNumber.BackColor = result;

              }
              else
              {

                  lbl_InsuranceNumber.Hide();
                  TextBox_InsuranceNumber.BackColor = MandatoryColor(Color.Gray);

              }


              if ((comboBox_TransferStatus.SelectedValue.ToString() == "3" || comboBox_TransferStatus.SelectedValue.ToString() == "4" || comboBox_TransferStatus.SelectedValue.ToString() == "5") && textBox_TransferFacilityIdentifier.Text.Trim() == "")
              {

                  lbl_TransferFacilityIdentifier.Show();
                  TextBox_FacilityIdentifier.BackColor = result;
                  textBox_TransferFacilityIdentifier.Enabled = true;


              }
              else if (comboBox_TransferStatus.SelectedValue.ToString() == "1")
              {

                  lbl_TransferFacilityIdentifier.Hide();
                  textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.Gray);
                  textBox_TransferFacilityIdentifier.Enabled = false;
                  textBox_TransferFacilityIdentifier.Text = "";
              }
         
        

              if (comboBox_InitialLactateLevelCollection.SelectedValue.ToString() == "1")
              {


                  lbl_InitialLactateLevelCollectionDatetime.Show();
                
                  lbl_InitialLactateLevel.Show();
             

                  textBox_InitialLactateLevel.Enabled = true;
                  textBox_InitialLactateLevelCollectionDatetime.Enabled = true;
           
                  comboBox_RepeatLactateLevelCollection.Enabled = true;
          
                  textBox_InitialLactateLevel.BackColor = result;
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = result;
                  comboBox_RepeatLactateLevelCollection.BackColor = result;
                

              }
              else 
              {

                  lbl_InitialLactateLevelCollectionDatetime.Hide();
                 
                  lbl_InitialLactateLevel.Hide();
                  lbl_RepeatLactateLevelCollection.Hide();
                  lbl_RepeatLactateLevelCollectionDatetime.Hide();
                  textBox_InitialLactateLevel.Enabled = false;
                  textBox_InitialLactateLevelCollectionDatetime.Enabled = false;
          
                  comboBox_RepeatLactateLevelCollection.Enabled = false;
                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = false;
                  textBox_InitialLactateLevelCollectionDatetime.Text = "";
             
                  textBox_InitialLactateLevel.Text = "";
                  comboBox_RepeatLactateLevelCollection.SelectedValue = "Select";
                  textbox_RepeatLactateLevelCollectionDatetime.Text = "";

                  textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
                  textBox_InitialLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
                  comboBox_RepeatLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
              }


              if (comboBox_RepeatLactateLevelCollection.SelectedValue.ToString() == "1")
              {

                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = true;
                  lbl_RepeatLactateLevelCollectionDatetime.Show();
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = result;

              }
              else
              {
                  textbox_RepeatLactateLevelCollectionDatetime.Enabled = false;
                  lbl_RepeatLactateLevelCollectionDatetime.Hide();
                  textbox_RepeatLactateLevelCollectionDatetime.Text = "";
                  textbox_RepeatLactateLevelCollectionDatetime.BackColor = MandatoryColor(Color.Gray);

              }


              if (comboBox_BloodCultureCollection.SelectedValue.ToString() == "1")
              {


                  lbl_BloodCultureCollectionDatetime.Show();
                  //lbl_ElevatedLactateReason.Show();
                 
                  lbl_BloodCultureCollectionAcceptableDelay.Show();

                  textBox_BloodCultureCollectionDatetime.Enabled = true;
                  comboBox_BloodCultureCollectionAcceptableDelay.Enabled = true;

                  textBox_BloodCultureCollectionDatetime.BackColor = result;
                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = result;
                

              }
              else
              {
                  lbl_BloodCultureCollectionAcceptableDelay.Hide();
                  lbl_BloodCultureCollectionDatetime.Hide();
                  //lbl_ElevatedLactateReason.Hide();
              

                  textBox_BloodCultureCollectionDatetime.Enabled = false;             
                  textBox_BloodCultureCollectionDatetime.Text = "";
                  textBox_BloodCultureCollectionDatetime.BackColor = MandatoryColor(Color.Gray);
                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = MandatoryColor(Color.Gray);
              }



              if (comboBox_AntibioticAdministration.SelectedValue.ToString() == "1")
              {

                  lbl_AntibioticAdministrationDatetime.Show();
                  lbl_AntibioticAdministrationSelection.Show();

                  textBox_AntibioticAdministrationDatetime.Enabled = true;
                  comboBox_AntibioticAdministrationSelection.Enabled = true;

                  textBox_AntibioticAdministrationDatetime.BackColor = result;
                  comboBox_AntibioticAdministrationSelection.BackColor = result;
                
              }
              else
              {

                  lbl_AntibioticAdministrationDatetime.Hide();
                  lbl_AntibioticAdministrationSelection.Hide();

                  textBox_AntibioticAdministrationDatetime.Enabled = false;
                  comboBox_AntibioticAdministrationSelection.Enabled = false;

                  textBox_AntibioticAdministrationDatetime.Text = "";
                  comboBox_AntibioticAdministrationSelection.SelectedValue = "Select";

                  textBox_AntibioticAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                  comboBox_AntibioticAdministrationSelection.BackColor = MandatoryColor(Color.Gray);
              }



              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1")
              {

                  lbl_ExcludedDatetime.Show();
                  lbl_ExcludedReason.Show();

                  textBox_ExcludedDatetime.Enabled = true;
                  checkedListBox_ExcludedReason.Enabled = true;


                  textBox_ExcludedDatetime.BackColor = result;
                  checkedListBox_ExcludedReason.BackColor = result;
              }
              else
              {
                  lbl_ExcludedDatetime.Hide();
                  lbl_ExcludedReason.Hide();
                  textBox_ExcludedDatetime.Enabled = false;
                  checkedListBox_ExcludedReason.Enabled = false;
                  textBox_ExcludedDatetime.Text = "";
                  foreach (int i in checkedListBox_ExcludedReason.CheckedIndices)
                  {
                      checkedListBox_ExcludedReason.SetItemCheckState(i, CheckState.Unchecked);
                  }

                  textBox_ExcludedDatetime.BackColor = MandatoryColor(Color.Gray);
                  checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.Gray);
              }



              if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "0")
              {
                  lbl_InitialHypotension.Show();
                

                  lbl_InitialLactateLevelCollection.Show();
                  lbl_BloodCultureCollection.Show();
                  lbl_AntibioticAdministration.Show();


                  comboBox_BloodCultureCollection.BackColor = result;
                  comboBox_AntibioticAdministration.BackColor = result;
                  comboBox_InitialHypotension.BackColor = result;
                  comboBox_InitialLactateLevelCollection.BackColor = result;



              }
              else if (comboBox_ExcludedFromProtocol.SelectedValue.ToString() == "1")
              {

                  lbl_BloodCultureCollection.Hide();
                  lbl_InitialLactateLevelCollection.Hide();
                  lbl_InitialHypotension.Hide();
                  lbl_AntibioticAdministration.Hide();

                  comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray); 
                  comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);
          

              }

              else
              {
                  lbl_InitialLactateLevelCollection.Hide();
                  lbl_BloodCultureCollection.Hide();
                  lbl_InitialHypotension.Hide();
                  lbl_AntibioticAdministration.Hide();


                  comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray);
                  comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
                  comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);
          
              }


              if (comboBox_PediatricCrystalloidFluidAdministration.SelectedValue.ToString() == "1" || comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1")
              {

                  lbl_CrystalloidFluidAdministrationDatetime.Show();
         

                  textBox_CrystalloidFluidAdministrationDatetime.Enabled = true;
               


                  textBox_CrystalloidFluidAdministrationDatetime.BackColor = result;
                 
              }
              else
              {
                  lbl_CrystalloidFluidAdministrationDatetime.Hide();
             

                  textBox_CrystalloidFluidAdministrationDatetime.Enabled = false;
              

                  textBox_CrystalloidFluidAdministrationDatetime.Text = "";


                  textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);
                 
              }




              if (comboBox_VasopressorAdministration.SelectedValue.ToString() == "1")
              {
                  lbl_VasopressorAdministrationDateTime.Show();
                  textBox_VasopressorAdministrationDatetime.Enabled = true;

                  textBox_VasopressorAdministrationDatetime.BackColor = result;
              }
              else
              {
                  lbl_VasopressorAdministrationDateTime.Hide();
                  textBox_VasopressorAdministrationDatetime.Enabled = false;
                  textBox_VasopressorAdministrationDatetime.Text = "";
                  textBox_VasopressorAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);

              }





              if (comboBox_MechanicalVentilation.SelectedValue.ToString() == "1")
              {
                  lbl_MechanicalVentilationDatetime.Show();
                  textBox_MechanicalVentilationDatetime.Enabled = true;
                  textBox_MechanicalVentilationDatetime.BackColor = result;
              }
              else
              {
                  lbl_MechanicalVentilationDatetime.Hide();
                  textBox_MechanicalVentilationDatetime.Enabled = false;
                  textBox_MechanicalVentilationDatetime.Text = "";

                  textBox_MechanicalVentilationDatetime.BackColor = MandatoryColor(Color.Gray);
              }

              if (comboBox_ICU.SelectedValue.ToString() == "1")
              {
                  lbl_ICUAdmissionDatetime.Show();
                  lbl_ICUDischargeDatetime.Show();
                  textBox_ICUAdmissionDatetime.Enabled = true;
                  textBox_ICUDischargeDatetime.Enabled = true;


                  textBox_ICUAdmissionDatetime.BackColor = result;
                  textBox_ICUDischargeDatetime.BackColor = result;
              }
              else
              {
                  lbl_ICUAdmissionDatetime.Hide();
                  lbl_ICUDischargeDatetime.Hide();
                  textBox_ICUAdmissionDatetime.Enabled = false;
                  textBox_ICUDischargeDatetime.Enabled = false;
                  textBox_ICUAdmissionDatetime.Text = "";
                  textBox_ICUDischargeDatetime.Text = "";


                  textBox_ICUAdmissionDatetime.BackColor = result;
                  textBox_ICUDischargeDatetime.BackColor = result;
              }




              if (DateTime.TryParseExact(txtDOB.Text.ToString().Trim(), format2, CultureInfo.InvariantCulture,
        System.Globalization.DateTimeStyles.None, out dDate))


                  if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate) < 0)
                  {

                      lbl_PediatricCrystalloidFluidAdministration.Show();
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;

                      lbl_AdultCrystalloidFluidAdministration.Hide();
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                      comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";

                  }
                  else
                  {
                      lbl_PediatricCrystalloidFluidAdministration.Hide();
                      comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                      comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                      comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";

                      lbl_AdultCrystalloidFluidAdministration.Show();
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = result;
                      comboBox_AdultCrystalloidFluidAdministration.Enabled = true;





                  }


              for (int i = 0; i < checkedListBox_ExcludedReason.Items.Count; i++)
              {
                  if (checkedListBox_ExcludedReason.GetItemChecked(i) == true)
                  {
                      DataRowView castedItem = checkedListBox_ExcludedReason.Items[i] as DataRowView;
                      if (castedItem["ComboBox_Key"].ToString() == "1")
                      {
                          ExcludedResonChecked = 1;
                          break;
                      }
                  }

              }


              if (ExcludedResonChecked == 1)
              {
                  ExcludedResonChecked = 0;
                  lbl_ExcludedExplain.Show();
                  checkedListBox_ExcludedExplain.Enabled = true;

                  checkedListBox_ExcludedExplain.BackColor = result;
              }
              else
              {
                  lbl_ExcludedExplain.Hide();
                  checkedListBox_ExcludedExplain.Enabled = false;
                  checkedListBox_ExcludedExplain.BackColor = MandatoryColor(Color.Gray);
                  for (int i = 0; i <= checkedListBox_ExcludedExplain.Items.Count - 1; i++)
                  {
                      checkedListBox_ExcludedExplain.SetItemChecked(i, false);
                  }

              }

                   }
              catch (Exception ex)
              {
              }

          }

          private void comboBox_SepticShockPresent_SelectedIndexChanged(object sender, EventArgs e)
          {
              try
              {
              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1")
              {
                  
                  lbl_SepticShockPresentationDatetime.Show();
                  textBox_septicShockPresentationDatetime.Enabled = true;
                  textBox_septicShockPresentationDatetime.BackColor = result;

                  lbl_AdultCrystalloidFluidAdministration.Show();
                  
                
                     comboBox_AdultCrystalloidFluidAdministration.BackColor = result;
              }
              else
              {
                  lbl_SepticShockPresentationDatetime.Hide();
                  textBox_septicShockPresentationDatetime.Enabled = false;
                  textBox_septicShockPresentationDatetime.Text = "";
                  textBox_septicShockPresentationDatetime.BackColor = MandatoryColor(Color.Gray);

              }



              if (validateDate(txtDOB.Text.ToString().Trim()) == true)
              {


                  DateTime dDate;
                 decimal j = 0;

                 if (textBox_InitialLactateLevel.Text != "")
                     j = decimal.Parse(textBox_InitialLactateLevel.Text);

                  if (DateTime.TryParseExact(txtDOB.Text.ToString().Trim(), format2, CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None, out dDate))



                      if ((comboBox_InitialHypotension.SelectedValue.ToString() == "1" || comboBox_SepticShockPresent.SelectedValue.ToString() == "1" || j >= 4) && DateTime.Compare(DateTime.Today.AddYears(-18), dDate) >= 0)
                      {


                          lbl_AdultCrystalloidFluidAdministration.Show();
                          comboBox_AdultCrystalloidFluidAdministration.BackColor = result;
                        
                      }
                      else
                      {

                          lbl_AdultCrystalloidFluidAdministration.Hide();
                          comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                         
                      }




              }
              }
              catch (Exception ex)
              {
              }


          }

          private void txtDOB_Leave(object sender, EventArgs e)
          {
              try
              {
              if (txtDOB.Text.ToString().Trim() != "/  /")
              {



                  if (validateDate(txtDOB.Text.ToString().Trim()) == false)
                  {


                      // textBox_AdmissionDateTime.BackColor = Color.White;
                      txtDOB.BackColor = ErrorColor(Color.Red);
                      MessageBox.Show("Date of Birth should be in format MM/DD/YYYY", "Date of Birth Error");
                      txtDOB.Focus();

                  }
                  else if (validateDatetimeLimit(DateTime.Now.ToString(), txtDOB.Text.ToString().Trim()) == false)
                  {
                      txtDOB.BackColor = ErrorColor(Color.Red);
                      MessageBox.Show("Date of Birth should not be future date", "Date of Birth Error");
                      txtDOB.Focus();
                  }
                  else if (validateDatetimeLimit(txtDOB.Text.ToString().Trim(), "12/31/1899 11:59:59 PM") == false)
                  {
                      txtDOB.BackColor = ErrorColor(Color.Red);
                      MessageBox.Show("Date of Birth should not be before 19th Century", "Date of Birth Error");
                      txtDOB.Focus();
                  }
                  else
                  {





                      DateTime dDate;

                      if (DateTime.TryParseExact(txtDOB.Text.ToString().Trim(), format2, CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out dDate))


                          if (DateTime.Compare(DateTime.Today.AddYears(-18), dDate) < 0)
                          {

                              lbl_PediatricCrystalloidFluidAdministration.Show();
                              comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;
                              comboBox_PediatricCrystalloidFluidAdministration.Enabled = true;

                              lbl_AdultCrystalloidFluidAdministration.Hide();
                              comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                              comboBox_AdultCrystalloidFluidAdministration.Enabled = false;
                              comboBox_AdultCrystalloidFluidAdministration.SelectedValue = "Select";

                          }
                          else
                          {
                              lbl_PediatricCrystalloidFluidAdministration.Hide();
                              comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                              comboBox_PediatricCrystalloidFluidAdministration.Enabled = false;
                              comboBox_PediatricCrystalloidFluidAdministration.SelectedValue = "Select";

                              lbl_AdultCrystalloidFluidAdministration.Show();
                              comboBox_AdultCrystalloidFluidAdministration.BackColor = result;
                              comboBox_AdultCrystalloidFluidAdministration.Enabled = true;





                          }

                      txtDOB.BackColor = result;
                  }


              }
              else
              {
                  txtDOB.BackColor = result;
              }

              }
              catch (Exception ex)
              {
              }
          }

          private void SepsisCaseDetails_5_FormClosing(object sender, FormClosingEventArgs e)
          {
              sm.Show();
          }

          private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
          {
              try
              {

              if (this.tabControl.SelectedIndex == 0)
              {
                  txtId.Focus();
              }
           
              else if (this.tabControl.SelectedIndex == 1)
              {
                  textBox_ArrivalDatetime.Focus();
              }
              else if (this.tabControl.SelectedIndex == 2)
              {
                  comboBox_PlateletCount.Focus();
              }

                   }
              catch (Exception ex)
              {
              }

          }


          public string checkdecimalpoint (string S)
          {
                  if (S.Length >= 1)
              {

                  for (int i = 0; i <= S.Length - 1; i++ )
                  {
                      if ( S[i] == '.')
                      {
                          d = S[i];
                          positionCount = S.Length - 1 - i;
                          break;
                      }


                  }
                


                  if (d=='.')
                  {
                      d=' ';
                      templactate = decimal.Parse(S);
                      if (positionCount >= 2)
                      {
                         
                          templactate = decimal.Round(templactate, 1,MidpointRounding.AwayFromZero);
                       

                      }

                      if ((templactate % 1) == 0)
                      {
                          lactatelevel = (int)templactate;
                          return lactatelevel.ToString();
                      }
                      else
                          {
                                 return templactate.ToString();
                          }






                  }

                     
              }

                  return S;
          }


          private void textBox_InitialLactateLevel_Leave(object sender, EventArgs e)
          {
              try
              {
                  if (textBox_InitialLactateLevel.Text.Length >= 1)
                  {
                      if (LactateCharcheckCheck(textBox_InitialLactateLevel.Text.ToString().Trim()) == true)
                      {
                          textBox_InitialLactateLevel.BackColor = ErrorColor(Color.Red);
                          MessageBox.Show("Initial Lactate Level only accept Numeric or Decimal Values.", "Initial Lactate Level Error");
                          textBox_InitialLactateLevel.Focus();
                          return;

                      }
                      else
                      {
                          if (lbl_InitialLactateLevel.Visible == true)
                              textBox_InitialLactateLevel.BackColor = result;
                          else
                              textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
                         
                      }


                      Decimaloccurance = textBox_InitialLactateLevel.Text.Count(x => x == '.');
                      if (Decimaloccurance > 1)
                      {
                          textBox_InitialLactateLevel.BackColor = ErrorColor(Color.Red);
                          MessageBox.Show("Initial Lactate Level have invalid input.", "Initial Lactate Level Error");
                          textBox_InitialLactateLevel.Focus();
                          return;
                      }
                      else if (Decimaloccurance == textBox_InitialLactateLevel.Text.ToString().Trim().Length)
                      {
                          textBox_InitialLactateLevel.BackColor = ErrorColor(Color.Red);
                          MessageBox.Show("Initial Lactate Level have invalid input.", "Initial Lactate Level Error");
                          textBox_InitialLactateLevel.Focus();
                          return;
                      }
                      else
                      {
                          if (lbl_InitialLactateLevel.Visible == true)
                              textBox_InitialLactateLevel.BackColor = result;
                          else
                              textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
                          
                      }


                      textBox_InitialLactateLevel.Text = checkdecimalpoint(textBox_InitialLactateLevel.Text.ToString().Trim());

                      if (decimal.Parse(textBox_InitialLactateLevel.Text) > 2)
                      {
                          lbl_ElevatedLactateReason.Show();
                          comboBox_ElevatedLactateReason.BackColor = result;
                          lbl_RepeatLactateLevelCollection.Show();
                          comboBox_RepeatLactateLevelCollection.BackColor = result;
                         
                      }
                      else
                      {
                          lbl_RepeatLactateLevelCollection.Hide();
                          comboBox_RepeatLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
                          lbl_ElevatedLactateReason.Hide();
                          comboBox_ElevatedLactateReason.BackColor = MandatoryColor(Color.Gray);
                      }



                              if (validateDate(txtDOB.Text.ToString().Trim()) == true)
                              {


                             DateTime dDate;
                                  if (DateTime.TryParseExact(txtDOB.Text.ToString().Trim(), format2, CultureInfo.InvariantCulture,
                            System.Globalization.DateTimeStyles.None, out dDate))

                                      if ((comboBox_InitialHypotension.SelectedValue.ToString() == "1" || comboBox_SepticShockPresent.SelectedValue.ToString() == "1" || decimal.Parse(textBox_InitialLactateLevel.Text) >= 4) && DateTime.Compare(DateTime.Today.AddYears(-18), dDate) >= 0)
                                      {


                                          lbl_AdultCrystalloidFluidAdministration.Show();
                                          comboBox_AdultCrystalloidFluidAdministration.BackColor = result;
                                      }
                                      else
                                      {

                                          lbl_AdultCrystalloidFluidAdministration.Hide();
                                          comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                                      }

                          
                                        
                                }


                  }
                  else
                  {
                      if (lbl_InitialLactateLevel.Visible == true)
                          textBox_InitialLactateLevel.BackColor = result;
                      else
                          textBox_InitialLactateLevel.BackColor = MandatoryColor(Color.Gray);
                    
                  }

                

              }
              catch (Exception ex)
              {

              }
          }

      

          private void txtId_Leave(object sender, EventArgs e)
          {
              try
              {
              if (txtId.Text.ToString().Trim().Length >= 1 && txtId.Text.ToString().Trim().Length < 10)
              {
                  txtId.BackColor = ErrorColor(Color.Red);
                  MessageBox.Show("Unique Personal Identifier should have a length of 10.", "Unique Personal Identifier Error");
                      txtId.Focus();
                      return;
                  }
                  else
                  {
                      txtId.BackColor = result;
                  }

              txtId.Text = txtId.Text.ToUpper();

                    }
            catch (Exception ex)
            {

            }
          }

          

          private void checkedListBox_ExcludedReason_MouseUp(object sender, MouseEventArgs e)
          {
              try
              {
              if (checkedListBox_ExcludedReason.Items.Count > 0)
              {
                  for (int i = 0; i < checkedListBox_ExcludedReason.Items.Count; i++)
                  {
                      if (checkedListBox_ExcludedReason.GetItemChecked(i) == true)
                      {
                          DataRowView castedItem = checkedListBox_ExcludedReason.Items[i] as DataRowView;
                          if (castedItem["ComboBox_Key"].ToString() == "1")
                          {
                              ExcludedResonChecked = 1;
                              break;
                          }
                      }

                  }


                  if (ExcludedResonChecked == 1)
                  {
                      ExcludedResonChecked = 0;
                      lbl_ExcludedExplain.Show();
                      checkedListBox_ExcludedExplain.Enabled = true;

                      checkedListBox_ExcludedExplain.BackColor = result;
                  }
                  else
                  {
                      lbl_ExcludedExplain.Hide();
                      checkedListBox_ExcludedExplain.Enabled = false;
                      checkedListBox_ExcludedExplain.BackColor = MandatoryColor(Color.Gray);
                      for (int i = 0; i <= checkedListBox_ExcludedExplain.Items.Count - 1; i++)
                      {
                          checkedListBox_ExcludedExplain.SetItemChecked(i, false);
                      }

                  }



              }

                   }
              catch (Exception ex)
              {
              }
          }

          private void comboBox_SevereSepsisPresent_SelectedIndexChanged(object sender, EventArgs e)
          {
              try
              {
              if (comboBox_SevereSepsisPresent.SelectedValue.ToString() == "1")
              {

                  lbl_SevereSepsisPresentationDatetime.Show();
                  textBox_SevereSepsisPresentationDatetime.Enabled = true;
                  textBox_SevereSepsisPresentationDatetime.BackColor = result;
              }
              else
              {
                  lbl_SevereSepsisPresentationDatetime.Hide();
                  textBox_SevereSepsisPresentationDatetime.Enabled = false;
                  textBox_SevereSepsisPresentationDatetime.Text = "";
                  textBox_SevereSepsisPresentationDatetime.BackColor = MandatoryColor(Color.Gray);
              }
              }
              catch (Exception ex)
              {
              }
          }

          private void txtId_Enter(object sender, EventArgs e)
          {

              this.BeginInvoke((MethodInvoker)delegate()
              {
                  txtId.Select(0, 0);
              });      
          
             
          }

          private void TextBox_PatientCtrlNum_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  TextBox_PatientCtrlNum.Select(0, 0);
              });      
          
          }

          private void txtDOB_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  txtDOB.Select(0, 0);
              });      
          }

          private void TextBox_InsuranceNumber_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  TextBox_InsuranceNumber.Select(0, 0);
              });      
          }

          private void txtMRN_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  txtMRN.Select(0, 0);
              });      
          }

          private void TextBox_FacilityIdentifier_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  TextBox_FacilityIdentifier.Select(0, 0);
              });      
          }

          private void textBox_AdmissionDateTime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_AdmissionDateTime.Select(0, 0);
              });      
          }

          private void textBox_DischargedDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_DischargedDatetime.Select(0, 0);
              });      
          }

          private void textBox_TransferFacilityIdentifier_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_TransferFacilityIdentifier.Select(0, 0);
              });      
          }

         

          private void textBox_ExcludedDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_ExcludedDatetime.Select(0, 0);
              });      
          }

          private void textBox_EarliestDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_ArrivalDatetime.Select(0, 0);
              });      
          }

          private void textbox_TriageDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textbox_TriageDatetime.Select(0, 0);
              });      
          }

          private void textBox_SevereSepsisPresentationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_SevereSepsisPresentationDatetime.Select(0, 0);
              });      
          }

          private void textBox_septicShockPresentationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_septicShockPresentationDatetime.Select(0, 0);
              });      
          }

        

          private void textBox_InitialLactateLevelCollectionDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_InitialLactateLevelCollectionDatetime.Select(0, 0);
              });      
          }

          private void textBox_InitialLactateLevel_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_InitialLactateLevel.Select(0, 0);
              });      
          }

          private void textbox_RepeatLactateLevelCollectionDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textbox_RepeatLactateLevelCollectionDatetime.Select(0, 0);
              });      
          }

          private void textBox_BloodCultureCollectionDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_BloodCultureCollectionDatetime.Select(0, 0);
              });      
          }

          private void textBox_AntibioticAdministrationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_AntibioticAdministrationDatetime.Select(0, 0);
              });      
          }

          private void textBox_CrystalloidFluidAdministrationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_CrystalloidFluidAdministrationDatetime.Select(0, 0);
              });      
          }

       

          private void textBox_VasopressorAdministrationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_VasopressorAdministrationDatetime.Select(0, 0);
              });      
          }


          private void textBox_MechanicalVentilationDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_MechanicalVentilationDatetime.Select(0, 0);
              });      
          }

          private void textBox_ICUAdmissionDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_ICUAdmissionDatetime.Select(0, 0);
              });      
          }

          private void textBox_ICUDischargeDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_ICUDischargeDatetime.Select(0, 0);
              });      
          }

          private void TextBox_InsuranceNumber_Leave(object sender, EventArgs e)
          {
              try
              {

              if (lbl_InsuranceNumber.Visible == true)
                  TextBox_InsuranceNumber.BackColor = result;
              else
                   TextBox_InsuranceNumber.BackColor = MandatoryColor(Color.Gray);

                   }
              catch (Exception ex)
              {
              }
            
          }

          private void textBox_TransferFacilityIdentifier_Leave(object sender, EventArgs e)
          {
              if (lbl_TransferFacilityIdentifier.Visible == true)
                  textBox_TransferFacilityIdentifier.BackColor = result;
              else
                  textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.Gray);
          }


          private void checkedListBox_ExcludedReason_Leave(object sender, EventArgs e)
          {
              if (lbl_ExcludedReason.Visible == true)
                  checkedListBox_ExcludedReason.BackColor = result;
              else
                  checkedListBox_ExcludedReason.BackColor = MandatoryColor(Color.Gray);
          }

     

          private void comboBox_RepeatLactateLevelCollection_Leave(object sender, EventArgs e)
          {
              if (lbl_RepeatLactateLevelCollection.Visible == true)
                  comboBox_RepeatLactateLevelCollection.BackColor = result;
              else
                  comboBox_RepeatLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_BloodCultureCollection_Leave(object sender, EventArgs e)
          {
              if (lbl_BloodCultureCollection.Visible == true)
                  comboBox_BloodCultureCollection.BackColor = result;
              else
                  comboBox_BloodCultureCollection.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_BloodCultureCollectionAcceptableDelay_Leave(object sender, EventArgs e)
          {
              if (lbl_BloodCultureCollectionAcceptableDelay.Visible == true)
                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = result;
              else
                  comboBox_BloodCultureCollectionAcceptableDelay.BackColor = MandatoryColor(Color.Gray);
          }

         

          private void comboBox_AntibioticAdministration_Leave(object sender, EventArgs e)
          {
              if (lbl_AntibioticAdministration.Visible == true)
                  comboBox_AntibioticAdministration.BackColor = result;
              else
                  comboBox_AntibioticAdministration.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_AntibioticAdministrationSelection_Leave(object sender, EventArgs e)
          {
              if (lbl_AntibioticAdministrationSelection.Visible == true)
                  comboBox_AntibioticAdministrationSelection.BackColor = result;
              else
                  comboBox_AntibioticAdministrationSelection.BackColor = MandatoryColor(Color.Gray);
          }

       

          private void comboBox_InitialHypotension_Leave(object sender, EventArgs e)
          {
              if (lbl_InitialHypotension.Visible == true)
                  comboBox_InitialHypotension.BackColor = result;
              else
                  comboBox_InitialHypotension.BackColor = MandatoryColor(Color.Gray);
          }

     

          private void comboBox_PediatricCrystalloidFluidAdministration_Leave(object sender, EventArgs e)
          {

              if (lbl_PediatricCrystalloidFluidAdministration.Visible == true)
                  comboBox_PediatricCrystalloidFluidAdministration.BackColor = result;
              else
                  comboBox_PediatricCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);

          }

     
          private void comboBox_VasopressorAdministration_Leave(object sender, EventArgs e)
          {
              if (lbl_VasopressorAdministration.Visible == true)
                  comboBox_VasopressorAdministration.BackColor = result;
              else
                  comboBox_VasopressorAdministration.BackColor = MandatoryColor(Color.Gray);
          }

    


          private void Label_ClickHere_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
          {

              Help hp = new Help();
              hp.Show();

          }

          private void comboBox_InitialLactateLevelCollection_Leave(object sender, EventArgs e)
          {

              if (lbl_InitialLactateLevelCollection.Visible == true)
                  comboBox_InitialLactateLevelCollection.BackColor = result;
              else
                  comboBox_InitialLactateLevelCollection.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed_Leave(object sender, EventArgs e)
          {

              if (lbl_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.Visible == true)
                  comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.BackColor = result;
              else
                  comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.BackColor = MandatoryColor(Color.Gray);


          }

          private void textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime_Leave(object sender, EventArgs e)
          {
              try
              {
                  if (validateDatetime(textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Text.ToString().Trim()) == false)
                  {
                      textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.BackColor = ErrorColor(Color.Red);
                      MessageBox.Show("Repeat Volume Status and Tissue Perfusion Assessment Performed Datetime should be in format MM/DD/YYYY hh:mm", "Repeat Volume Status Date/Time Error");
                      textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Focus();
                  }
                  else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Text.ToString().Trim()) == false)
                  {
                      textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.BackColor = ErrorColor(Color.Red);
                      MessageBox.Show("Repeat Volume Status and Tissue Perfusion Assessment Performed Datetime should be before Discharge Datetime", "Repeat Volume Status Date/Time Error");
                      textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Focus();
                  }
                  else if (validateDatetimeLimit(textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
                  {
                      textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.BackColor = ErrorColor(Color.Red);
                      MessageBox.Show("Repeat Volume Status and Tissue Perfusion Assessment Performed Datetime cannot have been before Arrival Datetime.", "Repeat Volume Status Date/Time Error");
                      textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Focus();
                  }
                  else
                  {

                      textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.BackColor = result;
                  }
              }
              catch (Exception ex)
              {

              }
          }

          private void comboBox_InitialHypotension_SelectedIndexChanged(object sender, EventArgs e)
          {
              try
              {
              if (comboBox_InitialHypotension.SelectedValue.ToString() == "1")
              {

                  lbl_InitialHypotensionDateTime.Show();
                  textbox_InitialHypotensionDateTime.Enabled = true;
                  textbox_InitialHypotensionDateTime.BackColor = result;

                  lbl_AdultCrystalloidFluidAdministration.Show();
                  comboBox_AdultCrystalloidFluidAdministration.BackColor = result;


                  
                  lbl_PersistentHypotension.Show();
                  comboBox_PersistentHypotension.BackColor = result;
              }
              else
              {
                  lbl_InitialHypotensionDateTime.Hide();
                  textbox_InitialHypotensionDateTime.Enabled = false;
                  textbox_InitialHypotensionDateTime.Text = "";
                  textbox_InitialHypotensionDateTime.BackColor = MandatoryColor(Color.Gray);


                  lbl_PersistentHypotension.Hide();
                  comboBox_PersistentHypotension.BackColor = MandatoryColor(Color.Gray);

                  lbl_AdultCrystalloidFluidAdministration.Hide();
                  comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
              }




              if (validateDate(txtDOB.Text.ToString().Trim()) == true)
              {


                  DateTime dDate;
                  decimal j = 0;

                  if (textBox_InitialLactateLevel.Text != "")
                      j = decimal.Parse(textBox_InitialLactateLevel.Text);

                  if (DateTime.TryParseExact(txtDOB.Text.ToString().Trim(), format2, CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None, out dDate))

                      if ((comboBox_InitialHypotension.SelectedValue.ToString() == "1" || comboBox_SepticShockPresent.SelectedValue.ToString() == "1" || j >= 4) && DateTime.Compare(DateTime.Today.AddYears(-18), dDate) >= 0)
                  {


                      lbl_AdultCrystalloidFluidAdministration.Show();
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = result;
                  }
                  else
                  {

                      lbl_AdultCrystalloidFluidAdministration.Hide();
                      comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);
                  }




              }
                }
              catch (Exception ex)
              {
              }


          }

          private void textbox_InitialHypotensionDateTime_Leave(object sender, EventArgs e)
          {
              try
              {
                  if (validateDatetime(textbox_InitialHypotensionDateTime.Text.ToString().Trim()) == false)
                  {
                      textbox_InitialHypotensionDateTime.BackColor = ErrorColor(Color.Red);
                      MessageBox.Show("Initial Hypotension Datetime should be in format MM/DD/YYYY hh:mm", "Initial Hypotension Date/Time Error");
                      textbox_InitialHypotensionDateTime.Focus();

                  }
                  else if (validateDatetimeLimit(textBox_DischargedDatetime.Text.ToString().Trim(), textbox_InitialHypotensionDateTime.Text.ToString().Trim()) == false)
                  {
                      textbox_InitialHypotensionDateTime.BackColor = ErrorColor(Color.Red);
                      MessageBox.Show("Initial Hypotension Datetime cannot have been after Discharge Datetime.", "Initial Hypotension Date/Time Error");
                      textbox_InitialHypotensionDateTime.Focus();
                  }

                  else if (validateDatetimeLimit(textbox_InitialHypotensionDateTime.Text.ToString().Trim(), textBox_ArrivalDatetime.Text.ToString().Trim()) == false)
                  {
                      textbox_InitialHypotensionDateTime.BackColor = ErrorColor(Color.Red);
                      MessageBox.Show("Initial Hypotension Datetime cannot have been before Arrival Datetime.", "Initial Hypotension Date/Time Error");
                      textbox_InitialHypotensionDateTime.Focus();
                  }
                  else
                  {

                      if (lbl_InitialHypotensionDateTime.Visible == true)
                          textbox_InitialHypotensionDateTime.BackColor = result;
                      else
                          textbox_InitialHypotensionDateTime.BackColor = MandatoryColor(Color.Gray);

                      
                  }
              }
              catch (Exception ex)
              {

              }
          }

          private void comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.SelectedValue.ToString() == "1")
              {
                  
                  lbl_RepeatVolumeStatusandTissuePerfusionAssessmentPerformeddatetime.Show();
                  textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Enabled = true;
                  textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.BackColor = result;
              }
              else
              {
                  lbl_RepeatVolumeStatusandTissuePerfusionAssessmentPerformeddatetime.Hide();
                  textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Enabled = false;
                  textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Text = "";
                  textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.BackColor = MandatoryColor(Color.Gray);
              }
          }

        

          private void textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime.Select(0, 0);
              });      
          }

          private void textbox_InitialHypotensionDateTime_Enter(object sender, EventArgs e)
          {
              this.BeginInvoke((MethodInvoker)delegate()
              {
                  textbox_InitialHypotensionDateTime.Select(0, 0);
              });      
          }

          private void comboBox_TransferStatus_SelectedIndexChanged(object sender, EventArgs e)
          {
              try
              {

              if (comboBox_TransferStatus.SelectedValue.ToString() == "3" || comboBox_TransferStatus.SelectedValue.ToString() == "4" || comboBox_TransferStatus.SelectedValue.ToString() == "5")
              {
                  textBox_TransferFacilityIdentifier.Enabled = true;
                  textBox_TransferFacilityIdentifier.Text = "";
                  lbl_TransferFacilityIdentifier.Show();
                  textBox_TransferFacilityIdentifier.BackColor = result;

              }
              else if (comboBox_TransferStatus.SelectedValue.ToString() == "1")
              {

                  lbl_TransferFacilityIdentifier.Hide();
                  textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.Gray);
                  textBox_TransferFacilityIdentifier.Enabled = false;
                  textBox_TransferFacilityIdentifier.Text = "";
              }
              else
              {
                  lbl_TransferFacilityIdentifier.Hide();
                  textBox_TransferFacilityIdentifier.BackColor = MandatoryColor(Color.Gray);
                  textBox_TransferFacilityIdentifier.Enabled = true;
                  textBox_TransferFacilityIdentifier.Text = "";

              }
                   }
              catch (Exception ex)
              {
              }
          }

          private void comboBox_AdultCrystalloidFluidAdministration_Leave(object sender, EventArgs e)
          {

              if (lbl_AdultCrystalloidFluidAdministration.Visible == true)
                  comboBox_AdultCrystalloidFluidAdministration.BackColor = result;
              else
                  comboBox_AdultCrystalloidFluidAdministration.BackColor = MandatoryColor(Color.Gray);


          }

          private void comboBox_AdultCrystalloidFluidAdministration_SelectedIndexChanged(object sender, EventArgs e)
          {

              try
              {
              if (comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1")
              {


                  if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1")
                  {
                      lbl_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.Show();
                      comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.BackColor = result;

                  }
                  else
                  {
                      lbl_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.Hide();
                      comboBox_RepeatVolumeStatusandTissuePerfusionAssessmentPerformed.BackColor = MandatoryColor(Color.Gray);


                  }

                  lbl_CrystalloidFluidAdministrationDatetime.Show();


                  textBox_CrystalloidFluidAdministrationDatetime.Enabled = true;



                  textBox_CrystalloidFluidAdministrationDatetime.BackColor = result;



              }
              else
              {
                  lbl_CrystalloidFluidAdministrationDatetime.Hide();


                  textBox_CrystalloidFluidAdministrationDatetime.Enabled = false;


                  textBox_CrystalloidFluidAdministrationDatetime.BackColor = MandatoryColor(Color.Gray);


                  textBox_CrystalloidFluidAdministrationDatetime.Text = "";


              }

                   }
              catch (Exception ex)
              {
              }
          }

          private void comboBox_PersistentHypotension_Leave(object sender, EventArgs e)
          {
              if (lbl_PersistentHypotension.Visible == true)
                  comboBox_PersistentHypotension.BackColor = result;
              else
                  comboBox_PersistentHypotension.BackColor = MandatoryColor(Color.Gray);
          }

          private void comboBox_PersistentHypotension_SelectedIndexChanged(object sender, EventArgs e)
          {

              try
              {
              if (comboBox_SepticShockPresent.SelectedValue.ToString() == "1" && comboBox_AdultCrystalloidFluidAdministration.SelectedValue.ToString() == "1" && comboBox_PersistentHypotension.SelectedValue.ToString() == "1")
              {


                  lbl_VasopressorAdministration.Show();
               
                  comboBox_VasopressorAdministration.BackColor = result;
              }
              else
              {
                  lbl_VasopressorAdministration.Hide();
              

                  comboBox_VasopressorAdministration.BackColor = MandatoryColor(Color.Gray);
              }

                   }
              catch (Exception ex)
              {
              }
          }

          //private void comboBox_Payor_Leave(object sender, EventArgs e)
          //{
          //    if (lbl_InsuranceNumber.Visible == true)
          //        TextBox_InsuranceNumber.Focus();
          //    else
          //        txtMRN.Focus();
            
           
          //}

          //private void comboBox_TransferStatus_Leave(object sender, EventArgs e)
          //{

          //    if (lbl_TransferFacilityIdentifier.Visible == true)
          //        textBox_TransferFacilityIdentifier.Focus();
          //    else

          //        Combobox_SepsisIdentificationPlace.Focus();
          //}

          //private void comboBox_SepticShockPresent_Leave(object sender, EventArgs e)
          //{
              

          //    if (lbl_SepticShockPresentationDatetime.Visible != true)
          //    {


          //        if (lbl_InitialLactateLevelCollection.Visible == true)
          //            comboBox_InitialLactateLevelCollection.Focus();
          //        else if (lbl_InitialLactateLevelCollectionDatetime.Visible == true)
          //            textBox_InitialLactateLevelCollectionDatetime.Focus();

          //        else if (lbl_InitialLactateLevelCollectionDatetime.Visible != true)
          //        {

          //            if (lbl_BloodCultureCollection.Visible == true)
          //                comboBox_BloodCultureCollection.Focus();
          //            else if (lbl_BloodCultureCollectionAcceptableDelay.Visible == true)
          //                comboBox_BloodCultureCollectionAcceptableDelay.Focus();
          //            else if (lbl_AntibioticAdministration.Visible == true)
          //                comboBox_AntibioticAdministration.Focus();
          //            else if (lbl_AntibioticAdministrationDatetime.Visible != true)
          //            {
          //                if (lbl_AdultCrystalloidFluidAdministration.Visible == true)
          //                    comboBox_AdultCrystalloidFluidAdministration.Focus();
          //                else
          //                    comboBox_PediatricCrystalloidFluidAdministration.Focus();
          //            }





          //        }
          //    }
                
                

          //}

       

       

    
      
    }
}
