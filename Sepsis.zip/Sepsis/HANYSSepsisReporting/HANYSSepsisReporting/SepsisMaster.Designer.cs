﻿namespace WindowsFormsApplication1
{
    partial class SepsisMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SepsisMaster));
            this.dataGridView_DisplayData = new System.Windows.Forms.DataGridView();
            this.button_AddNewCase = new System.Windows.Forms.Button();
            this.button_ExportData = new System.Windows.Forms.Button();
            this.comboBox_Version = new System.Windows.Forms.ComboBox();
            this.label_Version = new System.Windows.Forms.Label();
            this.label_DateCreatedFrom = new System.Windows.Forms.Label();
            this.label_DateCreatedTo = new System.Windows.Forms.Label();
            this.radioButton_RecordCompleteYes = new System.Windows.Forms.RadioButton();
            this.radioButton_RecordCompleteNo = new System.Windows.Forms.RadioButton();
            this.radioButton_CSVGeneratedNo = new System.Windows.Forms.RadioButton();
            this.radioButton_CSVGeneratedYes = new System.Windows.Forms.RadioButton();
            this.groupBox_RecordComplete = new System.Windows.Forms.GroupBox();
            this.radioButton_RecordCompleteBoth = new System.Windows.Forms.RadioButton();
            this._CSVGenerated = new System.Windows.Forms.GroupBox();
            this.radioButton_CSVGeneratedBoth = new System.Windows.Forms.RadioButton();
            this.button_Search = new System.Windows.Forms.Button();
            this.textbox_DataCreatedFrom = new System.Windows.Forms.MaskedTextBox();
            this.textBox_DateCreatedTo = new System.Windows.Forms.MaskedTextBox();
            this.lbl_Note = new System.Windows.Forms.Label();
            this.TextBox_PatientCtrlNum = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMRN = new System.Windows.Forms.MaskedTextBox();
            this.Label_MRN = new System.Windows.Forms.Label();
            this.label_PFI = new System.Windows.Forms.Label();
            this.comboBox_PFI = new System.Windows.Forms.ComboBox();
            this.label_Copyright = new System.Windows.Forms.Label();
            this.comboBox_CSVGeneratedDate = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Label_ClickHere = new System.Windows.Forms.LinkLabel();
            this.Label_Contact = new System.Windows.Forms.Label();
            this.button_ClearCSVChecks = new System.Windows.Forms.Button();
            this.button_ExportSampling = new System.Windows.Forms.Button();
            this.button_Reports = new System.Windows.Forms.Button();
            this.groupBox_DictionaryType = new System.Windows.Forms.GroupBox();
            this.radioButton_Adult = new System.Windows.Forms.RadioButton();
            this.radioButton_Pediatric = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_AddDemoGraphics = new System.Windows.Forms.Button();
            this.button_Subscribe = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DisplayData)).BeginInit();
            this.groupBox_RecordComplete.SuspendLayout();
            this._CSVGenerated.SuspendLayout();
            this.groupBox_DictionaryType.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_DisplayData
            // 
            this.dataGridView_DisplayData.AllowUserToAddRows = false;
            this.dataGridView_DisplayData.AllowUserToDeleteRows = false;
            this.dataGridView_DisplayData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle31.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_DisplayData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle31;
            this.dataGridView_DisplayData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_DisplayData.DefaultCellStyle = dataGridViewCellStyle32;
            this.dataGridView_DisplayData.Location = new System.Drawing.Point(55, 136);
            this.dataGridView_DisplayData.Name = "dataGridView_DisplayData";
            this.dataGridView_DisplayData.Size = new System.Drawing.Size(1132, 242);
            this.dataGridView_DisplayData.TabIndex = 0;
            this.dataGridView_DisplayData.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_DisplayData_CellClick);
            this.dataGridView_DisplayData.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_DisplayData_CellContentClick);
            this.dataGridView_DisplayData.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_DisplayData_CellDoubleClick);
            this.dataGridView_DisplayData.Sorted += new System.EventHandler(this.dataGridView_DisplayData_Sorted);
            // 
            // button_AddNewCase
            // 
            this.button_AddNewCase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_AddNewCase.Location = new System.Drawing.Point(589, 400);
            this.button_AddNewCase.Name = "button_AddNewCase";
            this.button_AddNewCase.Size = new System.Drawing.Size(113, 38);
            this.button_AddNewCase.TabIndex = 1;
            this.button_AddNewCase.Text = "Add New Case";
            this.button_AddNewCase.UseVisualStyleBackColor = true;
            this.button_AddNewCase.Click += new System.EventHandler(this.button_AddNewCase_Click);
            // 
            // button_ExportData
            // 
            this.button_ExportData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ExportData.Location = new System.Drawing.Point(737, 400);
            this.button_ExportData.Name = "button_ExportData";
            this.button_ExportData.Size = new System.Drawing.Size(113, 38);
            this.button_ExportData.TabIndex = 2;
            this.button_ExportData.Text = "Export Data";
            this.button_ExportData.UseVisualStyleBackColor = true;
            this.button_ExportData.Click += new System.EventHandler(this.button_ExportData_Click);
            // 
            // comboBox_Version
            // 
            this.comboBox_Version.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Version.Location = new System.Drawing.Point(87, 90);
            this.comboBox_Version.Name = "comboBox_Version";
            this.comboBox_Version.Size = new System.Drawing.Size(58, 21);
            this.comboBox_Version.TabIndex = 3;
            this.comboBox_Version.SelectedIndexChanged += new System.EventHandler(this.comboBox_Version_SelectedIndexChanged);
            // 
            // label_Version
            // 
            this.label_Version.AutoSize = true;
            this.label_Version.Location = new System.Drawing.Point(33, 92);
            this.label_Version.Name = "label_Version";
            this.label_Version.Size = new System.Drawing.Size(48, 13);
            this.label_Version.TabIndex = 4;
            this.label_Version.Text = "Version :";
            // 
            // label_DateCreatedFrom
            // 
            this.label_DateCreatedFrom.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label_DateCreatedFrom.AutoSize = true;
            this.label_DateCreatedFrom.Location = new System.Drawing.Point(238, 46);
            this.label_DateCreatedFrom.Name = "label_DateCreatedFrom";
            this.label_DateCreatedFrom.Size = new System.Drawing.Size(110, 13);
            this.label_DateCreatedFrom.TabIndex = 5;
            this.label_DateCreatedFrom.Text = "Discharge Date From:";
            // 
            // label_DateCreatedTo
            // 
            this.label_DateCreatedTo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label_DateCreatedTo.AutoSize = true;
            this.label_DateCreatedTo.Location = new System.Drawing.Point(437, 46);
            this.label_DateCreatedTo.Name = "label_DateCreatedTo";
            this.label_DateCreatedTo.Size = new System.Drawing.Size(103, 13);
            this.label_DateCreatedTo.TabIndex = 7;
            this.label_DateCreatedTo.Text = "Discharge Date  To:";
            // 
            // radioButton_RecordCompleteYes
            // 
            this.radioButton_RecordCompleteYes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton_RecordCompleteYes.AutoSize = true;
            this.radioButton_RecordCompleteYes.Location = new System.Drawing.Point(16, 21);
            this.radioButton_RecordCompleteYes.Name = "radioButton_RecordCompleteYes";
            this.radioButton_RecordCompleteYes.Size = new System.Drawing.Size(43, 17);
            this.radioButton_RecordCompleteYes.TabIndex = 10;
            this.radioButton_RecordCompleteYes.TabStop = true;
            this.radioButton_RecordCompleteYes.Text = "Yes";
            this.radioButton_RecordCompleteYes.UseVisualStyleBackColor = true;
            // 
            // radioButton_RecordCompleteNo
            // 
            this.radioButton_RecordCompleteNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton_RecordCompleteNo.AutoSize = true;
            this.radioButton_RecordCompleteNo.Location = new System.Drawing.Point(79, 21);
            this.radioButton_RecordCompleteNo.Name = "radioButton_RecordCompleteNo";
            this.radioButton_RecordCompleteNo.Size = new System.Drawing.Size(39, 17);
            this.radioButton_RecordCompleteNo.TabIndex = 11;
            this.radioButton_RecordCompleteNo.TabStop = true;
            this.radioButton_RecordCompleteNo.Text = "No";
            this.radioButton_RecordCompleteNo.UseVisualStyleBackColor = true;
            // 
            // radioButton_CSVGeneratedNo
            // 
            this.radioButton_CSVGeneratedNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton_CSVGeneratedNo.AutoSize = true;
            this.radioButton_CSVGeneratedNo.Location = new System.Drawing.Point(85, 21);
            this.radioButton_CSVGeneratedNo.Name = "radioButton_CSVGeneratedNo";
            this.radioButton_CSVGeneratedNo.Size = new System.Drawing.Size(39, 17);
            this.radioButton_CSVGeneratedNo.TabIndex = 14;
            this.radioButton_CSVGeneratedNo.TabStop = true;
            this.radioButton_CSVGeneratedNo.Text = "No";
            this.radioButton_CSVGeneratedNo.UseVisualStyleBackColor = true;
            // 
            // radioButton_CSVGeneratedYes
            // 
            this.radioButton_CSVGeneratedYes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton_CSVGeneratedYes.AutoSize = true;
            this.radioButton_CSVGeneratedYes.Location = new System.Drawing.Point(17, 21);
            this.radioButton_CSVGeneratedYes.Name = "radioButton_CSVGeneratedYes";
            this.radioButton_CSVGeneratedYes.Size = new System.Drawing.Size(43, 17);
            this.radioButton_CSVGeneratedYes.TabIndex = 13;
            this.radioButton_CSVGeneratedYes.TabStop = true;
            this.radioButton_CSVGeneratedYes.Text = "Yes";
            this.radioButton_CSVGeneratedYes.UseVisualStyleBackColor = true;
            // 
            // groupBox_RecordComplete
            // 
            this.groupBox_RecordComplete.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox_RecordComplete.Controls.Add(this.radioButton_RecordCompleteBoth);
            this.groupBox_RecordComplete.Controls.Add(this.radioButton_RecordCompleteYes);
            this.groupBox_RecordComplete.Controls.Add(this.radioButton_RecordCompleteNo);
            this.groupBox_RecordComplete.Location = new System.Drawing.Point(658, 23);
            this.groupBox_RecordComplete.Name = "groupBox_RecordComplete";
            this.groupBox_RecordComplete.Size = new System.Drawing.Size(225, 53);
            this.groupBox_RecordComplete.TabIndex = 15;
            this.groupBox_RecordComplete.TabStop = false;
            this.groupBox_RecordComplete.Text = "Record Complete";
            // 
            // radioButton_RecordCompleteBoth
            // 
            this.radioButton_RecordCompleteBoth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton_RecordCompleteBoth.AutoSize = true;
            this.radioButton_RecordCompleteBoth.Location = new System.Drawing.Point(145, 21);
            this.radioButton_RecordCompleteBoth.Name = "radioButton_RecordCompleteBoth";
            this.radioButton_RecordCompleteBoth.Size = new System.Drawing.Size(47, 17);
            this.radioButton_RecordCompleteBoth.TabIndex = 12;
            this.radioButton_RecordCompleteBoth.TabStop = true;
            this.radioButton_RecordCompleteBoth.Text = "Both";
            this.radioButton_RecordCompleteBoth.UseVisualStyleBackColor = true;
            // 
            // _CSVGenerated
            // 
            this._CSVGenerated.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._CSVGenerated.Controls.Add(this.radioButton_CSVGeneratedBoth);
            this._CSVGenerated.Controls.Add(this.radioButton_CSVGeneratedYes);
            this._CSVGenerated.Controls.Add(this.radioButton_CSVGeneratedNo);
            this._CSVGenerated.Location = new System.Drawing.Point(894, 23);
            this._CSVGenerated.Name = "_CSVGenerated";
            this._CSVGenerated.Size = new System.Drawing.Size(225, 53);
            this._CSVGenerated.TabIndex = 16;
            this._CSVGenerated.TabStop = false;
            this._CSVGenerated.Text = "CSV Generated :";
            // 
            // radioButton_CSVGeneratedBoth
            // 
            this.radioButton_CSVGeneratedBoth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton_CSVGeneratedBoth.AutoSize = true;
            this.radioButton_CSVGeneratedBoth.Location = new System.Drawing.Point(145, 21);
            this.radioButton_CSVGeneratedBoth.Name = "radioButton_CSVGeneratedBoth";
            this.radioButton_CSVGeneratedBoth.Size = new System.Drawing.Size(47, 17);
            this.radioButton_CSVGeneratedBoth.TabIndex = 15;
            this.radioButton_CSVGeneratedBoth.TabStop = true;
            this.radioButton_CSVGeneratedBoth.Text = "Both";
            this.radioButton_CSVGeneratedBoth.UseVisualStyleBackColor = true;
            // 
            // button_Search
            // 
            this.button_Search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Search.Location = new System.Drawing.Point(1131, 23);
            this.button_Search.Name = "button_Search";
            this.button_Search.Size = new System.Drawing.Size(113, 53);
            this.button_Search.TabIndex = 19;
            this.button_Search.Text = "Search";
            this.button_Search.UseVisualStyleBackColor = true;
            this.button_Search.Click += new System.EventHandler(this.button_Search_Click);
            // 
            // textbox_DataCreatedFrom
            // 
            this.textbox_DataCreatedFrom.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textbox_DataCreatedFrom.Location = new System.Drawing.Point(349, 43);
            this.textbox_DataCreatedFrom.Mask = "00/00/0000";
            this.textbox_DataCreatedFrom.Name = "textbox_DataCreatedFrom";
            this.textbox_DataCreatedFrom.Size = new System.Drawing.Size(71, 20);
            this.textbox_DataCreatedFrom.TabIndex = 39;
            this.textbox_DataCreatedFrom.ValidatingType = typeof(System.DateTime);
            // 
            // textBox_DateCreatedTo
            // 
            this.textBox_DateCreatedTo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox_DateCreatedTo.Location = new System.Drawing.Point(545, 42);
            this.textBox_DateCreatedTo.Mask = "00/00/0000";
            this.textBox_DateCreatedTo.Name = "textBox_DateCreatedTo";
            this.textBox_DateCreatedTo.Size = new System.Drawing.Size(74, 20);
            this.textBox_DateCreatedTo.TabIndex = 40;
            this.textBox_DateCreatedTo.ValidatingType = typeof(System.DateTime);
            // 
            // lbl_Note
            // 
            this.lbl_Note.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbl_Note.AutoSize = true;
            this.lbl_Note.Location = new System.Drawing.Point(52, 381);
            this.lbl_Note.Name = "lbl_Note";
            this.lbl_Note.Size = new System.Drawing.Size(229, 13);
            this.lbl_Note.TabIndex = 41;
            this.lbl_Note.Text = "PleaseNote:- Records in yellow are incomplete.";
            // 
            // TextBox_PatientCtrlNum
            // 
            this.TextBox_PatientCtrlNum.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.TextBox_PatientCtrlNum.Location = new System.Drawing.Point(467, 91);
            this.TextBox_PatientCtrlNum.Mask = "AAAAAAAAAAAAAAAAAAAA";
            this.TextBox_PatientCtrlNum.Name = "TextBox_PatientCtrlNum";
            this.TextBox_PatientCtrlNum.Size = new System.Drawing.Size(107, 20);
            this.TextBox_PatientCtrlNum.TabIndex = 42;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(346, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 13);
            this.label1.TabIndex = 43;
            this.label1.Text = "Patient Control Number:";
            // 
            // txtMRN
            // 
            this.txtMRN.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtMRN.Location = new System.Drawing.Point(694, 92);
            this.txtMRN.Mask = "AAAAAAAAAAAAAAAAA";
            this.txtMRN.Name = "txtMRN";
            this.txtMRN.Size = new System.Drawing.Size(92, 20);
            this.txtMRN.TabIndex = 45;
            // 
            // Label_MRN
            // 
            this.Label_MRN.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label_MRN.AutoSize = true;
            this.Label_MRN.Location = new System.Drawing.Point(586, 93);
            this.Label_MRN.Name = "Label_MRN";
            this.Label_MRN.Size = new System.Drawing.Size(102, 13);
            this.Label_MRN.TabIndex = 44;
            this.Label_MRN.Text = "Medical Record No:";
            // 
            // label_PFI
            // 
            this.label_PFI.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label_PFI.Location = new System.Drawing.Point(180, 90);
            this.label_PFI.Name = "label_PFI";
            this.label_PFI.Size = new System.Drawing.Size(90, 29);
            this.label_PFI.TabIndex = 46;
            this.label_PFI.Text = "Facility Identifier :";
            this.label_PFI.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // comboBox_PFI
            // 
            this.comboBox_PFI.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.comboBox_PFI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_PFI.FormattingEnabled = true;
            this.comboBox_PFI.Location = new System.Drawing.Point(271, 91);
            this.comboBox_PFI.Name = "comboBox_PFI";
            this.comboBox_PFI.Size = new System.Drawing.Size(58, 21);
            this.comboBox_PFI.TabIndex = 47;
            // 
            // label_Copyright
            // 
            this.label_Copyright.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Copyright.AutoSize = true;
            this.label_Copyright.Location = new System.Drawing.Point(582, 471);
            this.label_Copyright.Name = "label_Copyright";
            this.label_Copyright.Size = new System.Drawing.Size(86, 13);
            this.label_Copyright.TabIndex = 49;
            this.label_Copyright.Text = "© HANYS 2020.";
            // 
            // comboBox_CSVGeneratedDate
            // 
            this.comboBox_CSVGeneratedDate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.comboBox_CSVGeneratedDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_CSVGeneratedDate.FormattingEnabled = true;
            this.comboBox_CSVGeneratedDate.Location = new System.Drawing.Point(939, 94);
            this.comboBox_CSVGeneratedDate.Name = "comboBox_CSVGeneratedDate";
            this.comboBox_CSVGeneratedDate.Size = new System.Drawing.Size(129, 21);
            this.comboBox_CSVGeneratedDate.TabIndex = 51;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.Location = new System.Drawing.Point(798, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 21);
            this.label2.TabIndex = 50;
            this.label2.Text = "CSV Generated Date :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Label_ClickHere
            // 
            this.Label_ClickHere.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_ClickHere.AutoSize = true;
            this.Label_ClickHere.Location = new System.Drawing.Point(1188, 471);
            this.Label_ClickHere.Name = "Label_ClickHere";
            this.Label_ClickHere.Size = new System.Drawing.Size(56, 13);
            this.Label_ClickHere.TabIndex = 53;
            this.Label_ClickHere.TabStop = true;
            this.Label_ClickHere.Text = "Click Here";
            this.Label_ClickHere.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Label_ClickHere_LinkClicked);
            // 
            // Label_Contact
            // 
            this.Label_Contact.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Contact.AutoSize = true;
            this.Label_Contact.Location = new System.Drawing.Point(1068, 471);
            this.Label_Contact.Name = "Label_Contact";
            this.Label_Contact.Size = new System.Drawing.Size(122, 13);
            this.Label_Contact.TabIndex = 54;
            this.Label_Contact.Text = "Contact Sepsis support:-";
            // 
            // button_ClearCSVChecks
            // 
            this.button_ClearCSVChecks.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ClearCSVChecks.AutoSize = true;
            this.button_ClearCSVChecks.Location = new System.Drawing.Point(1101, 87);
            this.button_ClearCSVChecks.Name = "button_ClearCSVChecks";
            this.button_ClearCSVChecks.Size = new System.Drawing.Size(140, 38);
            this.button_ClearCSVChecks.TabIndex = 55;
            this.button_ClearCSVChecks.Text = "Select/Unselect all Export";
            this.button_ClearCSVChecks.UseVisualStyleBackColor = true;
            this.button_ClearCSVChecks.Click += new System.EventHandler(this.button_ClearCSVChecks_Click);
            // 
            // button_ExportSampling
            // 
            this.button_ExportSampling.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ExportSampling.AutoSize = true;
            this.button_ExportSampling.Location = new System.Drawing.Point(884, 400);
            this.button_ExportSampling.Name = "button_ExportSampling";
            this.button_ExportSampling.Size = new System.Drawing.Size(113, 38);
            this.button_ExportSampling.TabIndex = 56;
            this.button_ExportSampling.Text = "Export Sampling";
            this.button_ExportSampling.UseVisualStyleBackColor = true;
            this.button_ExportSampling.Click += new System.EventHandler(this.button_ExportSampling_Click);
            // 
            // button_Reports
            // 
            this.button_Reports.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Reports.AutoSize = true;
            this.button_Reports.Location = new System.Drawing.Point(1020, 400);
            this.button_Reports.Name = "button_Reports";
            this.button_Reports.Size = new System.Drawing.Size(113, 38);
            this.button_Reports.TabIndex = 57;
            this.button_Reports.Text = "Reports";
            this.button_Reports.UseVisualStyleBackColor = true;
            this.button_Reports.Click += new System.EventHandler(this.button_Reports_Click);
            // 
            // groupBox_DictionaryType
            // 
            this.groupBox_DictionaryType.AutoSize = true;
            this.groupBox_DictionaryType.Controls.Add(this.radioButton_Adult);
            this.groupBox_DictionaryType.Controls.Add(this.radioButton_Pediatric);
            this.groupBox_DictionaryType.Location = new System.Drawing.Point(36, 23);
            this.groupBox_DictionaryType.Name = "groupBox_DictionaryType";
            this.groupBox_DictionaryType.Size = new System.Drawing.Size(168, 59);
            this.groupBox_DictionaryType.TabIndex = 16;
            this.groupBox_DictionaryType.TabStop = false;
            // 
            // radioButton_Adult
            // 
            this.radioButton_Adult.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton_Adult.AutoSize = true;
            this.radioButton_Adult.Location = new System.Drawing.Point(19, 23);
            this.radioButton_Adult.Name = "radioButton_Adult";
            this.radioButton_Adult.Size = new System.Drawing.Size(49, 17);
            this.radioButton_Adult.TabIndex = 10;
            this.radioButton_Adult.TabStop = true;
            this.radioButton_Adult.Text = "Adult";
            this.radioButton_Adult.UseVisualStyleBackColor = true;
            this.radioButton_Adult.CheckedChanged += new System.EventHandler(this.radioButton_Adult_CheckedChanged);
            // 
            // radioButton_Pediatric
            // 
            this.radioButton_Pediatric.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton_Pediatric.AutoSize = true;
            this.radioButton_Pediatric.Location = new System.Drawing.Point(86, 23);
            this.radioButton_Pediatric.Name = "radioButton_Pediatric";
            this.radioButton_Pediatric.Size = new System.Drawing.Size(66, 17);
            this.radioButton_Pediatric.TabIndex = 11;
            this.radioButton_Pediatric.TabStop = true;
            this.radioButton_Pediatric.Text = "Pediatric";
            this.radioButton_Pediatric.UseVisualStyleBackColor = true;
            this.radioButton_Pediatric.CheckedChanged += new System.EventHandler(this.radioButton_Pediatric_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(9, 434);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(160, 43);
            this.pictureBox1.TabIndex = 48;
            this.pictureBox1.TabStop = false;
            // 
            // button_AddDemoGraphics
            // 
            this.button_AddDemoGraphics.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_AddDemoGraphics.AutoSize = true;
            this.button_AddDemoGraphics.Location = new System.Drawing.Point(398, 400);
            this.button_AddDemoGraphics.Name = "button_AddDemoGraphics";
            this.button_AddDemoGraphics.Size = new System.Drawing.Size(142, 38);
            this.button_AddDemoGraphics.TabIndex = 58;
            this.button_AddDemoGraphics.Text = "Demographics Upload";
            this.button_AddDemoGraphics.UseVisualStyleBackColor = true;
            this.button_AddDemoGraphics.Click += new System.EventHandler(this.button_AddDemoGraphics_Click);
            // 
            // button_Subscribe
            // 
            this.button_Subscribe.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_Subscribe.AutoSize = true;
            this.button_Subscribe.BackColor = System.Drawing.SystemColors.Info;
            this.button_Subscribe.Location = new System.Drawing.Point(55, 397);
            this.button_Subscribe.Name = "button_Subscribe";
            this.button_Subscribe.Size = new System.Drawing.Size(90, 31);
            this.button_Subscribe.TabIndex = 58;
            this.button_Subscribe.Text = "Subscribe";
            this.button_Subscribe.UseVisualStyleBackColor = false;
            this.button_Subscribe.Click += new System.EventHandler(this.button_Subscribe_Click);
            // 
            // SepsisMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1267, 489);
            this.Controls.Add(this.button_AddDemoGraphics);
            this.Controls.Add(this.button_Subscribe);
            this.Controls.Add(this.groupBox_DictionaryType);
            this.Controls.Add(this.button_Reports);
            this.Controls.Add(this.button_ExportSampling);
            this.Controls.Add(this.button_ClearCSVChecks);
            this.Controls.Add(this.Label_Contact);
            this.Controls.Add(this.Label_ClickHere);
            this.Controls.Add(this.comboBox_CSVGeneratedDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_Copyright);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.comboBox_PFI);
            this.Controls.Add(this.label_PFI);
            this.Controls.Add(this.txtMRN);
            this.Controls.Add(this.Label_MRN);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TextBox_PatientCtrlNum);
            this.Controls.Add(this.lbl_Note);
            this.Controls.Add(this.textBox_DateCreatedTo);
            this.Controls.Add(this.textbox_DataCreatedFrom);
            this.Controls.Add(this.button_Search);
            this.Controls.Add(this._CSVGenerated);
            this.Controls.Add(this.groupBox_RecordComplete);
            this.Controls.Add(this.label_DateCreatedTo);
            this.Controls.Add(this.label_DateCreatedFrom);
            this.Controls.Add(this.label_Version);
            this.Controls.Add(this.comboBox_Version);
            this.Controls.Add(this.button_ExportData);
            this.Controls.Add(this.button_AddNewCase);
            this.Controls.Add(this.dataGridView_DisplayData);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SepsisMaster";
            this.Text = "Master";
            this.HelpButtonClicked += new System.ComponentModel.CancelEventHandler(this.SepsisMaster_HelpButtonClicked);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SepsisMaster_FormClosing);
            this.Load += new System.EventHandler(this.SepsisMaster_Load);
            this.Shown += new System.EventHandler(this.SepsisMaster_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DisplayData)).EndInit();
            this.groupBox_RecordComplete.ResumeLayout(false);
            this.groupBox_RecordComplete.PerformLayout();
            this._CSVGenerated.ResumeLayout(false);
            this._CSVGenerated.PerformLayout();
            this.groupBox_DictionaryType.ResumeLayout(false);
            this.groupBox_DictionaryType.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_DisplayData;
        private System.Windows.Forms.Button button_AddNewCase;
        private System.Windows.Forms.Button button_ExportData;
        private System.Windows.Forms.ComboBox comboBox_Version;
        private System.Windows.Forms.Label label_Version;
        private System.Windows.Forms.Label label_DateCreatedFrom;
        private System.Windows.Forms.Label label_DateCreatedTo;
        private System.Windows.Forms.RadioButton radioButton_RecordCompleteYes;
        private System.Windows.Forms.RadioButton radioButton_RecordCompleteNo;
        private System.Windows.Forms.RadioButton radioButton_CSVGeneratedNo;
        private System.Windows.Forms.RadioButton radioButton_CSVGeneratedYes;
        private System.Windows.Forms.GroupBox groupBox_RecordComplete;
        private System.Windows.Forms.GroupBox _CSVGenerated;
        private System.Windows.Forms.Button button_Search;
        private System.Windows.Forms.MaskedTextBox textbox_DataCreatedFrom;
        private System.Windows.Forms.MaskedTextBox textBox_DateCreatedTo;
        private System.Windows.Forms.Label lbl_Note;
        private System.Windows.Forms.RadioButton radioButton_CSVGeneratedBoth;
        private System.Windows.Forms.RadioButton radioButton_RecordCompleteBoth;
        private System.Windows.Forms.MaskedTextBox TextBox_PatientCtrlNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox txtMRN;
        private System.Windows.Forms.Label Label_MRN;
        private System.Windows.Forms.Label label_PFI;
        private System.Windows.Forms.ComboBox comboBox_PFI;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label_Copyright;
        private System.Windows.Forms.ComboBox comboBox_CSVGeneratedDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel Label_ClickHere;
        private System.Windows.Forms.Label Label_Contact;
        private System.Windows.Forms.Button button_ClearCSVChecks;
        private System.Windows.Forms.Button button_ExportSampling;
        private System.Windows.Forms.Button button_Reports;
        private System.Windows.Forms.GroupBox groupBox_DictionaryType;
        private System.Windows.Forms.RadioButton radioButton_Adult;
        private System.Windows.Forms.RadioButton radioButton_Pediatric;
        private System.Windows.Forms.Button button_Subscribe;
        private System.Windows.Forms.Button button_AddDemoGraphics;
    }
}

