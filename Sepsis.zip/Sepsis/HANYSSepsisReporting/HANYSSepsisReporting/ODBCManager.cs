﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.Odbc;
using Dapper;
using LicenseValidator;
using System.Diagnostics;

namespace HANYSSepsisReporting
{
    public static class ODBCManager
    {

        private const string ODBC_INI_REG_PATH = "SOFTWARE\\ODBC\\ODBC.INI\\";
        private const string ODBCINST_INI_REG_PATH = "SOFTWARE\\ODBC\\ODBCINST.INI\\";
        ///
        /// Creates a new DSN entry with the specified values. If the DSN exists, the values are updated.
        ///
        /// Name of the DSN for use by client applications
        /// Description of the DSN that appears in the ODBC control panel applet
        /// Network name or IP address of database server
        /// Name of the driver to use
        /// True to use NT authentication, false to require applications to supply username/password in the connection string
        /// Name of the datbase to connect to


        public static void CreateSystemDSN(string dsnName, string description, string server, string driverName, bool trustedConnection, string database, string User, string Password)
        {

            // Lookup driver path from driver name
            RegistryKey driverKey = Registry.LocalMachine.CreateSubKey(ODBCINST_INI_REG_PATH + driverName);
            if (driverKey == null) throw new Exception(string.Format("ODBC Registry key for driver '{0}' does not exist", driverName));
            string driverPath = driverKey.GetValue("Driver").ToString();

            // Add value to odbc data sources
            RegistryKey datasourcesKey = Registry.LocalMachine.CreateSubKey(ODBC_INI_REG_PATH + "ODBC Data Sources");
            if (datasourcesKey == null) throw new Exception("ODBC Registry key for datasources does not exist");
            datasourcesKey.SetValue(dsnName, driverName);

            // Create new key in odbc.ini with dsn name and add values
            RegistryKey dsnKey = Registry.LocalMachine.CreateSubKey(ODBC_INI_REG_PATH + dsnName);
            if (dsnKey == null) throw new Exception("ODBC Registry key for DSN was not created");
            dsnKey.SetValue("Database", database);
            dsnKey.SetValue("Description", description);
            dsnKey.SetValue("Driver", driverPath);
            dsnKey.SetValue("LastUser", User);
            dsnKey.SetValue("Server", server);
            dsnKey.SetValue("Database", database);
            dsnKey.SetValue("User", User);
            dsnKey.SetValue("Password", Password);

            dsnKey.SetValue("Trusted_Connection", trustedConnection ? "Yes" : "No");

            if (!ConnectionCheck())
            {
                RemoveDSN(dsnName);
            }
        }


        public static void CreateUSERDSN(string dsnName, string description, string server, string driverName, bool trustedConnection, string database, string User, string Password)
        {

            // Lookup driver path from driver name for HKEY_CURRENT_USER
            RegistryKey driverKey = Registry.LocalMachine.CreateSubKey(ODBCINST_INI_REG_PATH + driverName);

            if (driverKey == null) throw new Exception(string.Format("ODBC Registry key for driver '{0}' does not exist", driverName));
            string driverPath = driverKey.GetValue("Driver").ToString();

            // Add value to odbc data sources
            RegistryKey datasourcesKey = Registry.CurrentUser.CreateSubKey(ODBC_INI_REG_PATH + "ODBC Data Sources");
            if (datasourcesKey == null) throw new Exception("ODBC Registry key for datasources does not exist");
            datasourcesKey.SetValue(dsnName, driverName);

            // Create new key in odbc.ini with dsn name and add values
            RegistryKey dsnKey = Registry.CurrentUser.CreateSubKey(ODBC_INI_REG_PATH + dsnName);
            if (dsnKey == null) throw new Exception("ODBC Registry key for DSN was not created");
            dsnKey.SetValue("Database", database);
            dsnKey.SetValue("Description", description);
            dsnKey.SetValue("Driver", driverPath);
            dsnKey.SetValue("LastUser", User);
            dsnKey.SetValue("Server", server);
            dsnKey.SetValue("Database", database);
            dsnKey.SetValue("User", User);
            dsnKey.SetValue("Password", Password);

            dsnKey.SetValue("Trusted_Connection", trustedConnection ? "Yes" : "No");

            if (!ConnectionCheck())
            {
                MessageBox.Show("DataBase connection was not successfull, Please remove ODBC Driver manaually by accessing ODBC Configuaration Manager before opening the tool and Create again  (or) Contact Hanys Support!");
                Kill();
            }
        }

        private static void Kill()
        {
            foreach (var process in Process.GetProcessesByName("HANYSSepsisReporting"))
            {
                process.Kill();
            }
        }

        ///
        /// Removes a DSN entry
        ///
        /// Name of the DSN to remove.
        public static void RemoveDSN(string dsnName)
        {

            // Remove DSN key
            Registry.LocalMachine.DeleteSubKeyTree(ODBC_INI_REG_PATH + dsnName);

            // Remove DSN name from values list in ODBC Data Sources key
            RegistryKey datasourcesKey = Registry.LocalMachine.CreateSubKey(ODBC_INI_REG_PATH + "ODBC Data Sources");
            if (datasourcesKey == null) throw new Exception("ODBC Registry key for datasources does not exist");
            datasourcesKey.DeleteValue(dsnName);

        }

        ///
        /// Checks the registry to see if a DSN exists with the specified name
        ///
        public static bool DSNExists(string dsnName)
        {

            bool retval = false;
            string DSNPath = "";
            try
            {
                RegistryKey dsnKey = Registry.CurrentUser.CreateSubKey(ODBC_INI_REG_PATH, RegistryKeyPermissionCheck.ReadSubTree);
                if (dsnKey.OpenSubKey(dsnName) != null)
                {
                    DSNPath = dsnKey.OpenSubKey(dsnName).Name;
                    if (DSNPath.Equals(dsnKey.Name + @"\" + dsnName))
                    {
                        retval = true;
                    }
                }

                 dsnKey = Registry.LocalMachine.CreateSubKey(ODBC_INI_REG_PATH, RegistryKeyPermissionCheck.ReadSubTree);

                if (dsnKey.OpenSubKey(dsnName) != null)
                {
                    DSNPath = dsnKey.OpenSubKey(dsnName).Name;
                    if (DSNPath.Equals(dsnKey.Name + @"\" + dsnName))
                    {
                        retval = true;
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return retval;

        }

        ///
        /// Returns an array of driver names installed on the system
        ///

        public static string[] GetInstalledDrivers()
        {

            RegistryKey driversKey = Registry.LocalMachine.CreateSubKey(ODBCINST_INI_REG_PATH + "ODBC Drivers");
            if (driversKey == null) throw new Exception("ODBC Registry key for drivers does not exist");

            string[] driverNames = driversKey.GetValueNames();

            List<string> ret = new List<string>();

            foreach (string driverName in driverNames)
            {
                if (driverName != "(Default)")
                {
                    ret.Add(driverName);
                }
            }

            return ret.ToArray();

        }
        public static bool ConnectionCheck()
        {
            DataBaseConnection Db = new DataBaseConnection();
            string ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;

            OdbcConnection Conn = new OdbcConnection(ConnectionString);
            try
            {
                Conn.Open();
                Conn.Query<MetaData>("Select * from Metadata");
                Conn.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}