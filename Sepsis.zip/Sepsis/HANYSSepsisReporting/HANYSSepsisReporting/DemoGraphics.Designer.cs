﻿namespace HANYSSepsisReporting
{
    partial class Demographics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Demographics));
            this.label_Copyright = new System.Windows.Forms.Label();
            this.Label_Contact = new System.Windows.Forms.Label();
            this.Label_ClickHere = new System.Windows.Forms.LinkLabel();
            this.dgColumnMapping = new System.Windows.Forms.DataGridView();
            this.lblDemoGraphic = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.uploadCsvColumns = new System.Windows.Forms.ComboBox();
            this.gbColumns = new System.Windows.Forms.GroupBox();
            this.btnUploadCSVColumns = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ddlDemoGraphics = new System.Windows.Forms.ComboBox();
            this.btnAddMappingColumn = new System.Windows.Forms.Button();
            this.btnPreviewDemoGraphics = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgColumnMapping)).BeginInit();
            this.gbColumns.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label_Copyright
            // 
            this.label_Copyright.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Copyright.AutoSize = true;
            this.label_Copyright.Location = new System.Drawing.Point(490, 563);
            this.label_Copyright.Name = "label_Copyright";
            this.label_Copyright.Size = new System.Drawing.Size(86, 13);
            this.label_Copyright.TabIndex = 503;
            this.label_Copyright.Text = "© HANYS 2020.";
            // 
            // Label_Contact
            // 
            this.Label_Contact.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Contact.AutoSize = true;
            this.Label_Contact.Location = new System.Drawing.Point(879, 568);
            this.Label_Contact.Name = "Label_Contact";
            this.Label_Contact.Size = new System.Drawing.Size(122, 13);
            this.Label_Contact.TabIndex = 505;
            this.Label_Contact.Text = "Contact Sepsis support:-";
            // 
            // Label_ClickHere
            // 
            this.Label_ClickHere.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_ClickHere.AutoSize = true;
            this.Label_ClickHere.Location = new System.Drawing.Point(1007, 568);
            this.Label_ClickHere.Name = "Label_ClickHere";
            this.Label_ClickHere.Size = new System.Drawing.Size(56, 13);
            this.Label_ClickHere.TabIndex = 506;
            this.Label_ClickHere.TabStop = true;
            this.Label_ClickHere.Text = "Click Here";
            this.Label_ClickHere.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Label_ClickHere_LinkClicked);
            // 
            // dgColumnMapping
            // 
            this.dgColumnMapping.AllowUserToAddRows = false;
            this.dgColumnMapping.AllowUserToDeleteRows = false;
            this.dgColumnMapping.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgColumnMapping.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgColumnMapping.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgColumnMapping.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgColumnMapping.Location = new System.Drawing.Point(78, 130);
            this.dgColumnMapping.Name = "dgColumnMapping";
            this.dgColumnMapping.Size = new System.Drawing.Size(957, 345);
            this.dgColumnMapping.TabIndex = 509;
            this.dgColumnMapping.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgColumnMapping_CellClick);
            this.dgColumnMapping.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgColumnMapping_CellContentClick);
            // 
            // lblDemoGraphic
            // 
            this.lblDemoGraphic.AutoSize = true;
            this.lblDemoGraphic.Location = new System.Drawing.Point(6, 31);
            this.lblDemoGraphic.Name = "lblDemoGraphic";
            this.lblDemoGraphic.Size = new System.Drawing.Size(70, 13);
            this.lblDemoGraphic.TabIndex = 511;
            this.lblDemoGraphic.Text = "Demographic";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 513;
            this.label2.Text = "Csv Columns";
            // 
            // uploadCsvColumns
            // 
            this.uploadCsvColumns.FormattingEnabled = true;
            this.uploadCsvColumns.Location = new System.Drawing.Point(80, 28);
            this.uploadCsvColumns.Name = "uploadCsvColumns";
            this.uploadCsvColumns.Size = new System.Drawing.Size(267, 21);
            this.uploadCsvColumns.TabIndex = 514;
            this.uploadCsvColumns.Text = "Select Matching Column";
            // 
            // gbColumns
            // 
            this.gbColumns.Controls.Add(this.label2);
            this.gbColumns.Controls.Add(this.uploadCsvColumns);
            this.gbColumns.Controls.Add(this.btnUploadCSVColumns);
            this.gbColumns.Location = new System.Drawing.Point(490, 35);
            this.gbColumns.Name = "gbColumns";
            this.gbColumns.Size = new System.Drawing.Size(452, 71);
            this.gbColumns.TabIndex = 515;
            this.gbColumns.TabStop = false;
            this.gbColumns.Text = "File Columns";
            // 
            // btnUploadCSVColumns
            // 
            this.btnUploadCSVColumns.Location = new System.Drawing.Point(353, 27);
            this.btnUploadCSVColumns.Name = "btnUploadCSVColumns";
            this.btnUploadCSVColumns.Size = new System.Drawing.Size(84, 24);
            this.btnUploadCSVColumns.TabIndex = 510;
            this.btnUploadCSVColumns.Text = "Get Columns";
            this.btnUploadCSVColumns.UseVisualStyleBackColor = true;
            this.btnUploadCSVColumns.Click += new System.EventHandler(this.btnUploadCSVColumns_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ddlDemoGraphics);
            this.groupBox1.Controls.Add(this.lblDemoGraphic);
            this.groupBox1.Location = new System.Drawing.Point(78, 35);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(401, 71);
            this.groupBox1.TabIndex = 516;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Demographics Columns";
            // 
            // ddlDemoGraphics
            // 
            this.ddlDemoGraphics.FormattingEnabled = true;
            this.ddlDemoGraphics.Location = new System.Drawing.Point(82, 31);
            this.ddlDemoGraphics.Name = "ddlDemoGraphics";
            this.ddlDemoGraphics.Size = new System.Drawing.Size(296, 21);
            this.ddlDemoGraphics.TabIndex = 512;
            // 
            // btnAddMappingColumn
            // 
            this.btnAddMappingColumn.BackColor = System.Drawing.SystemColors.Control;
            this.btnAddMappingColumn.Location = new System.Drawing.Point(951, 52);
            this.btnAddMappingColumn.Name = "btnAddMappingColumn";
            this.btnAddMappingColumn.Size = new System.Drawing.Size(84, 44);
            this.btnAddMappingColumn.TabIndex = 517;
            this.btnAddMappingColumn.Text = "Add ";
            this.btnAddMappingColumn.UseVisualStyleBackColor = false;
            this.btnAddMappingColumn.Click += new System.EventHandler(this.btnAddMappingColumn_Click);
            // 
            // btnPreviewDemoGraphics
            // 
            this.btnPreviewDemoGraphics.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreviewDemoGraphics.Location = new System.Drawing.Point(895, 498);
            this.btnPreviewDemoGraphics.Name = "btnPreviewDemoGraphics";
            this.btnPreviewDemoGraphics.Size = new System.Drawing.Size(139, 39);
            this.btnPreviewDemoGraphics.TabIndex = 519;
            this.btnPreviewDemoGraphics.Text = "Preview Mapping";
            this.btnPreviewDemoGraphics.UseVisualStyleBackColor = true;
            this.btnPreviewDemoGraphics.Click += new System.EventHandler(this.btnPreviewDemoGraphics_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.InitialImage")));
            this.pictureBox2.Location = new System.Drawing.Point(33, 533);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(160, 43);
            this.pictureBox2.TabIndex = 520;
            this.pictureBox2.TabStop = false;
            // 
            // Demographics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1145, 590);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnPreviewDemoGraphics);
            this.Controls.Add(this.btnAddMappingColumn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbColumns);
            this.Controls.Add(this.dgColumnMapping);
            this.Controls.Add(this.Label_ClickHere);
            this.Controls.Add(this.Label_Contact);
            this.Controls.Add(this.label_Copyright);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Demographics";
            this.Text = "Demographics Upload";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DemoGraphics_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dgColumnMapping)).EndInit();
            this.gbColumns.ResumeLayout(false);
            this.gbColumns.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_Copyright;
        private System.Windows.Forms.Label Label_Contact;
        private System.Windows.Forms.LinkLabel Label_ClickHere;
        private System.Windows.Forms.DataGridView dgColumnMapping;
        private System.Windows.Forms.Label lblDemoGraphic;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox uploadCsvColumns;
        private System.Windows.Forms.GroupBox gbColumns;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAddMappingColumn;
        private System.Windows.Forms.Button btnUploadCSVColumns;
        private System.Windows.Forms.ComboBox ddlDemoGraphics;
        private System.Windows.Forms.Button btnPreviewDemoGraphics;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}