﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1;

namespace HANYSSepsisReporting
{
    public partial class ODBC : Form
    {
        SepsisMaster sm;
        public ODBC(SepsisMaster master)
        {
            InitializeComponent();
            sm = master;

            //sm.Hide();

            Label mylab = new Label();
            mylab.Text = "HANYS Sepsis Data Tool is not connected to DataBase please provide following details to establish a connection.";
            mylab.Location = new Point(3, 20);
            mylab.AutoSize = true;
            mylab.Font = new Font("Calibri", 10);
            mylab.BorderStyle = BorderStyle.Fixed3D;
            mylab.ForeColor = Color.IndianRed;
            mylab.Margin = new Padding(3, 0, 3, 0);
            mylab.Size = new Size(656, 13);
            //mylab.Padding = new Padding(6);

            this.Controls.Add(mylab);
        }
        public string IsnullString(string inputString)
        {
            if (inputString == "" || inputString == "Select" || inputString == null)
            {
                inputString = null;
                return inputString;
            }
            return inputString;

        }

        DataBaseConnection Db = new DataBaseConnection();

        private void button_Submit_Click(object sender, EventArgs e)
        {
            string serverName = "";
            string userName = "";
            string password = "";
            if (IsnullString(textBox_ServerName.Text.ToString().Trim()) == null)
            {
                MessageBox.Show("Please Give Server Name:");
                textBox_ServerName.Focus();
                return;
            }
            else
                serverName = textBox_ServerName.Text.ToString();
            if (IsnullString(textBox_UserName.Text.ToString().Trim()) == null)
            {
                MessageBox.Show("Please Give User Name:");
                textBox_UserName.Focus();
                return;
            }
            else if(textBox_UserName.Text.ToString().ToLower() != Db.UserName.ToLower())
            {
                MessageBox.Show("Please enter valid UserName !");
                textBox_UserName.Focus();
                return;
            }
            else
                userName = textBox_UserName.Text.ToString();
            if (IsnullString(textBox_Password.Text.ToString().Trim()) == null)
            {
                MessageBox.Show("Please Give Password:");
                textBox_Password.Focus();
                return;
            }
            else if (textBox_Password.Text.ToString() != Db.Password)
            {
                MessageBox.Show("Please enter valid Password !");
                textBox_Password.Focus();
                return;
            }
            else
                password = textBox_Password.Text.ToString();
            if (serverName != null && userName != null && password != null && serverName != "" && userName != "" && password !="")
            {

                //UpdateDsnServer("HANYS_Sepsis", serverName);
                //ODBCManager create = new ODBCManager();
                //create.CreateDSN(serverName, userName, password);
                // CreateDSN();
                string driverName = "SQL Server";
                string dsnName = "Hanys_sepsis";
                string database = "Sepsis";
                string description = "This DSN was created from Sepsis tool";

                if (comboBox_DSNType.Text == "System DSN")
                {
                    ODBCManager.CreateSystemDSN(dsnName, description, serverName, driverName, false, database, userName, password);

                    if (ODBCManager.DSNExists("Hanys_sepsis") == false)
                    {
                        MessageBox.Show("Error While Establishing DataBase Connection! Please provide values again.");
                        ClearTextBoxes(this);
                        return;
                    }
                    else
                    {
                        MessageBox.Show("Connection Succesfully Established !");
                        //sm.Load_Data();
                        this.Hide();
                        //sm.Show();
                        SepsisMaster SM1 = new SepsisMaster();
                        SM1.Show();
                    }

                }
                else if (comboBox_DSNType.Text == "User DSN")
                {
                    ODBCManager.CreateUSERDSN(dsnName, description, serverName, driverName, false, database, userName, password);

                    if (ODBCManager.DSNExists("Hanys_sepsis") == false)
                    {
                        MessageBox.Show("Error While Establishing DataBase Connection! Please provide values again.");
                        ClearTextBoxes(this);
                        return;
                    }
                    else
                    {
                        MessageBox.Show("Connection Succesfully Established !");
                        //sm.Load_Data();
                        this.Hide();
                        //sm.Show();
                        SepsisMaster SM1 = new SepsisMaster();
                        SM1.Show();
                    }

                    ////sm.Load_Data();
                    //this.Close();
                    ////sm.Show();
                    //SepsisMaster SM1 = new SepsisMaster();
                    //SM1.Show();
                    ////sm.Show();
                    ////sm.Load_Data();
                }
                else
                {
                    MessageBox.Show("Please Select DSN Type.");
                    return;
                }
            }
        }

        public void ClearTextBoxes(Control form)
        {
            foreach (Control control in form.Controls)
            {
                if (control is TextBox)
                {
                    ((TextBox)control).Clear();
                }

                if (control.HasChildren)
                {
                    ClearTextBoxes(control);
                }
                if (control.GetType() == typeof(TextBox))
                {
                    control.Text = "";
                }
            }
        }

        private void ODBC_FormClosing(object sender, FormClosingEventArgs e)
        {
            foreach (var process in Process.GetProcessesByName("HANYSSepsisReporting"))
            {
                process.Kill();
            }
        }


        //void  CreateDSN()
        // {
        //     string ODBC_PATH = "SOFTWARE\\ODBC\\ODBC.INI\\";
        //     string driverName = "SQL Server";
        //     string dsnName = "Hanys_sepsis";
        //     string database = "Sepsis";
        //     string description = "This DSN was created from code!";
        //     string server = "ALB-SQLHNS01D\\DEVSQLINST,2050";
        //     bool trustedConnection = false;

        //     // Lookup driver path from driver name         
        //     string driverPath = "C:\\WINDOWS\\System32\\sqlsrv32.dll";

        //     var datasourcesKey = Registry.LocalMachine.CreateSubKey(ODBC_PATH + "ODBC Data Sources");
        //     if (datasourcesKey == null)
        //     {
        //         throw new Exception("ODBC Registry key does not exist");
        //     }
        //     datasourcesKey.SetValue(dsnName, driverName);
        //     //var j = datasourcesKey.GetSubKeyNames();

        //     // UpdateDsnServer("HANYS_Sepsis", server);

        //     // Create new key in odbc.ini with dsn name and add values        
        //     var dsnKey = Registry.LocalMachine.CreateSubKey(ODBC_PATH + dsnName);
        //     //var k = dsnKey.GetType();
        //     if (dsnKey == null)
        //     {
        //         throw new Exception("ODBC Registry key for DSN was not created");
        //     }

        //     dsnKey.SetValue("Database", database);
        //     dsnKey.SetValue("Description", description);
        //     dsnKey.SetValue("Driver", driverPath);
        //     dsnKey.SetValue("LastUser", "Hanys_Sepsis_Application");
        //     dsnKey.SetValue("Server", server);
        //     dsnKey.SetValue("Database", database);
        //     dsnKey.SetValue("username", "Hanys_Sepsis_Application");
        //     dsnKey.SetValue("password", "Myr@str@st87");
        //     dsnKey.SetValue("Trusted_Connection", trustedConnection ? "Yes" : "No");





        // }













        //[DllImport("ODBCCP32.DLL", CharSet = CharSet.Unicode, SetLastError = true)]
        //static extern bool SQLConfigDataSourceW(UInt32 hwndParent, RequestFlags fRequest, string lpszDriver, string lpszAttributes);

        //enum RequestFlags : int
        //{
        //    ODBC_ADD_DSN = 1,
        //    ODBC_CONFIG_DSN = 2,
        //    ODBC_REMOVE_DSN = 3,
        //    ODBC_ADD_SYS_DSN = 4,
        //    ODBC_CONFIG_SYS_DSN = 5,
        //    ODBC_REMOVE_SYS_DSN = 6,
        //    ODBC_REMOVE_DEFAULT_DSN = 7
        //}

        //bool UpdateDsnServer(string name, string server)
        //{
        //    var flag = RequestFlags.ODBC_ADD_DSN;
        //    string dsnNameLine = "DSN=" + name;
        //    string serverLine = "Server=" + server;

        //    string configString = new[] { dsnNameLine, serverLine }.Aggregate("", (str, line) => str + line + "\0");

        //    return SQLConfigDataSourceW(0, flag, "SQL Server", configString);
        //}



        //public class ODBCManager
        //{
        //    private const string ODBC_INI_REG_PATH = "SOFTWARE\\ODBC\\ODBC.INI\\";
        //    private const string ODBCINST_INI_REG_PATH = "SOFTWARE\\ODBC\\ODBCINST.INI\\";

        //    /// <summary>
        //    /// Creates a new DSN entry with the specified values. If the DSN exists, the values are updated.
        //    /// </summary>
        //    /// <param name="dsnName">Name of the DSN for use by client applications</param>
        //    /// <param name="description">Description of the DSN that appears in the ODBC control panel applet</param>
        //    /// <param name="server">Network name or IP address of database server</param>
        //    /// <param name="driverName">Name of the driver to use</param>
        //    /// <param name="trustedConnection">True to use NT authentication, false to require applications to supply username/password in the connection string</param>
        //    /// <param name="database">Name of the datbase to connect to</param>
        //    public void CreateDSN(string server,string username,string password)
        //    {
        //        try
        //        {
        //            string dsnName = "HANYS_SEPSIS";
        //            string driverName = "";
        //            string database = "sepsis";
        //            string description = "";
        //            bool trustedConnection = false;
        //            // Lookup driver path from driver name
        //            var driverKey = Registry.LocalMachine.CreateSubKey(ODBCINST_INI_REG_PATH + driverName);
        //            if (driverKey == null) throw new Exception(string.Format("ODBC Registry key for driver '{0}' does not exist", driverName));
        //            string driverPath = driverKey.GetValue("Driver").ToString();

        //            // Add value to odbc data sources
        //            var datasourcesKey = Registry.LocalMachine.CreateSubKey(ODBC_INI_REG_PATH + "ODBC Data Sources");
        //            if (datasourcesKey == null) throw new Exception("ODBC Registry key for datasources does not exist");
        //            datasourcesKey.SetValue(dsnName, driverName);

        //            // Create new key in odbc.ini with dsn name and add values
        //            var dsnKey = Registry.LocalMachine.CreateSubKey(ODBC_INI_REG_PATH + dsnName);
        //            if (dsnKey == null) throw new Exception("ODBC Registry key for DSN was not created");
        //            dsnKey.SetValue("Database", database);
        //            dsnKey.SetValue("Description", description);
        //            dsnKey.SetValue("Driver", driverPath);
        //            dsnKey.SetValue("Server", server);
        //            dsnKey.SetValue("User", username);
        //            dsnKey.SetValue("Password", password);
        //            dsnKey.SetValue("Trusted_Connection", trustedConnection ? "Yes" : "No");
        //        }
        //        catch(Exception ex)
        //        {

        //        }              
        //    }

        //    /// <summary>
        //    /// Removes a DSN entry
        //    /// </summary>
        //    /// <param name="dsnName">Name of the DSN to remove.</param>
        //    //public static void RemoveDSN(string dsnName)
        //    //{
        //    //    // Remove DSN key
        //    //    Registry.LocalMachine.DeleteSubKeyTree(ODBC_INI_REG_PATH + dsnName);

        //    //    // Remove DSN name from values list in ODBC Data Sources key
        //    //    var datasourcesKey = Registry.LocalMachine.CreateSubKey(ODBC_INI_REG_PATH + "ODBC Data Sources");
        //    //    if (datasourcesKey == null) throw new Exception("ODBC Registry key for datasources does not exist");
        //    //    datasourcesKey.DeleteValue(dsnName);
        //    //}

        //    ///<summary>
        //    /// Checks the registry to see if a DSN exists with the specified name
        //    ///</summary>
        //    ///<param name="dsnName"></param>
        //    ///<returns></returns>
        //    //public bool DSNExists(string dsnName)
        //    //{
        //    //    var driversKey = Registry.LocalMachine.CreateSubKey(ODBCINST_INI_REG_PATH + "ODBC Drivers");
        //    //    if (driversKey == null) throw new Exception("ODBC Registry key for drivers does not exist");

        //    //    return driversKey.GetValue(dsnName) != null;
        //    //}

        //    ///<summary>
        //    /// Returns an array of driver names installed on the system
        //    ///</summary>
        //    ///<returns></returns>
        //    //public static string[] GetInstalledDrivers()
        //    //{
        //    //    var driversKey = Registry.LocalMachine.CreateSubKey(ODBCINST_INI_REG_PATH + "ODBC Drivers");
        //    //    if (driversKey == null) throw new Exception("ODBC Registry key for drivers does not exist");

        //    //    var driverNames = driversKey.GetValueNames();

        //    //    var ret = new List<string>();

        //    //    foreach (var driverName in driverNames)
        //    //    {
        //    //        if (driverName != "(Default)")
        //    //        {
        //    //            ret.Add(driverName);
        //    //        }
        //    //    }

        //    //    return ret.ToArray();
        //    //}
        //}
    }
}
