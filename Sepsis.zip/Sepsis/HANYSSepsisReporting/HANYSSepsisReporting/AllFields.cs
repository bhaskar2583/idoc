﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
   public class AllFields
   {
        public int UniqueId { get; set; }
        public string UniquePersonalIdentifier  { get; set; }
        public string PatientControlNumber { get; set; }
        public DateTime? DateofBirth { get; set; }
        public string Gender { get; set; }
        public string Race { get; set; }
        public string Ethnicity { get; set; }
        public string Payor { get; set; }
        public string InsuranceNumber { get; set; }
        public string MedicalRecordNumber { get; set; }
        public string FacilityIdentifier { get; set; }
        public DateTime? AdmissionDatetime { get; set; }
        public string SourceofAdmission { get; set; }
        public DateTime? DischargeDatetime { get; set; }
        public string DischargedStatus { get; set; }
        public string TransferStatus { get; set; }
        public string TransferFacilityIdentifier { get; set; }
        public string ProtocolInitiated { get; set; }
        public string ProtocolNotInitiatedReason { get; set; }
        public string ProtocolNotInitiatedAdditionalDetail { get; set; }
        public string ProtocolInitiatedPlace { get; set; }
        public string ProtocolType { get; set; }
        public string ExcludedFromProtocol { get; set; }
        public string ExcludedReason { get; set; }
        public DateTime? ExcludedDatetime { get; set; }
        public string ExcludedExplain { get; set; }
        public DateTime? EarliestDateTime { get; set; }
        public DateTime? TriageDatetime { get; set; }
        public string SevereSepsisPresent { get; set; }
        public DateTime? SevereSepsisPresentationDatetime { get; set; }
        public string SepticShockPresent { get; set; }
        public DateTime? SepticShockPresentDatetime { get; set; }
        public DateTime? LeftEDDatetime { get; set; }
        public string DestinationAfterED { get; set; }
        public string InitialLactateLevelCollection { get; set; }
        public DateTime? InitialLactateLevelCollectionDatetime { get; set; }
        public string InitialLactateLevel { get; set; }
        public string InitialLactateLevelUnit { get; set; }
        public string RepeatLactateLevelCollection { get; set; }
        public DateTime? RepeatLactateLevelCollectionDatetime { get; set; }
        public string BloodCultureCollection { get; set; }
        public string BloodCultureCollectionAcceptableDelay { get; set; }
        public DateTime? BloodCultureCollectionDatetime { get; set; }
        public string BloodCultureResult { get; set; }
        public string BloodCulturePathogen { get; set; }
        public string AntibioticAdministration { get; set; }
        public string AntibioticAdministrationSelection { get; set; }
        public DateTime? AntibioticAdministrationDatetime { get; set; }
        public string AdultCrystalloidFluidAdministration { get; set; }
        public string PediatricCrystalloidFluidAdministration { get; set; }
        public DateTime? CrystalloidFluidAdministrationDatetime { get; set; }
        public string InitialHypotension { get; set; }
        public string PersistentHypotension { get; set; }
        public string VasopressorAdministration { get; set; }
        public DateTime? VasopressorAdministrationDatetime { get; set; }
        public string BesideCardiovascularUltrasound { get; set; }
        public DateTime? BesideCardiovascularUltrasoundDatetime { get; set; }
        public string CapillaryRefillExamination { get; set; }
        public DateTime? CapillaryRefillExaminationDatetime { get; set; }
        public string CardiopulmonaryEvaluation { get; set; }
        public DateTime? CardiopulmonaryEvaluationDatetime { get; set; }
        public string PassiveLegRaiseExamination { get; set; }
        public DateTime? PassiveLegRaiseExaminationDatetime { get; set; }
        public string PeripheralPulseEvaluation { get; set; }
        public DateTime? PeripheralPulseEvaluationDatetime { get; set; }
        public string SkinExamination { get; set; }
        public DateTime? SkinExaminationDatetime { get; set; }
        public string CentralVenousOxygenMeasurement { get; set; }
        public DateTime? CentralVenousOxygenMeasurementDatetime { get; set; }
        public string CentralVenousPressureMeasurement { get; set; }
        public DateTime? CentralVenousPressureMeasurementDatetime { get; set; }
        public string FluidChallengePerformed { get; set; }
        public DateTime? FluidChallengePerformedDatetime { get; set; }
        public string VitalSignsReview { get; set; }
        public DateTime? VitalSignsReviewDatetime { get; set; }
        public string PlateletCount { get; set; }
        public string Bandemia { get; set; }
        public string LoweRespiratoryInfection { get; set; }
        public string AlteredMentalStatus { get; set; }
        public string InfectionEtiology { get; set; }
        public string SiteofInfection { get; set; }
        public string MechanicalVentilation { get; set; }
        public DateTime? MechanicalVentilationDatetime { get; set; }
        public string ICU { get; set; }
        public DateTime? ICUAdmissionDatetime { get; set; }
        public DateTime? ICUDischargeDatetime { get; set; }
        public string ChronicRespiratoryFailure { get; set; }
        public string AIDS { get; set; }
        public string MetastaticCancer { get; set; }
        public string Lymphoma { get; set; }
        public string ImmuneModifyingMedications { get; set; }
        public string CongestiveHeartFailure { get; set; }
        public string ChronicRenalFailure { get; set; }
        public string ChronicLiverDisease { get; set; }
        public string Diabetes { get; set; }
        public string OrganTransplant { get; set; }
        public DateTime? InitialHypotensionDatetime { get; set; }
        public string ElevatedLactateReason { get; set; }
        public string SepsisIdentificationPlace { get; set; }
        public string RepeatVolumeStatusandTissuePerfusionAssessmentPerformed { get; set; }
        public DateTime? RepeatVolumeStatusandTissuePerfusionAssessmentPerformedDatetime { get; set; }
        public string pregnancystatus { get; set; }

        public DateTime? vasopressor_administration_end_datetime { get; set; }
        public string vasopressor_administration_transfer { get; set; }
        public DateTime? mechanical_ventilation_end_datetime { get; set; }
        public string mechanical_ventilation_transfer { get; set; }

        public string Version { get; set; }
        public string Year { get; set; }
        public string Quarter { get; set; }
        public DateTime? DateCreated { get; set; }
        //public bool RecordCompleted { get; set; }
        //public bool CSVGenerated { get; set; }
        public int RecordCompleted { get; set; }
        public int CSVGenerated { get; set; }
        public DateTime? CSVGeneratedDatetime { get; set; }
        public string InitialLactateLevelSource { get; set; }
        public int AutoUploadCase { get; set; }
    }
}
