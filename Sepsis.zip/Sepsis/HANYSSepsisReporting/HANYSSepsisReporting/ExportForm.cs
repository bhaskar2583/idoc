﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.Odbc;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;

namespace WindowsFormsApplication1
{
    public partial class ExportForm : Form
    {
        SepsisMaster sm;
        string ConnectionString;
        string strHeader = "";
        string strData = "";
        int count = 0;
        //string sDSN = "Sepsis";
        DataSet ds;
        string query = "";
        string SelectData = "";
        string FileName = "";
        string CurrentDate = "";
        string Currenttime = "";
        string Version { get; set; }
        string DateCreatedFrom { get; set; }
        string DateCreatedTo { get; set; }
        string txtPCN { get; set; }
        string txtMRN1 { get; set; }
        int? RecordComplete { get; set; }
        int? CSVGenerated { get; set; }
        string _querystring = "";
        string _version = "";
        int _sampling = 0;
        TextWriter sw;

        DateTime dDate;

        //int recordcompletecount = 0;
        ArrayList recordcompleteUniqueID = new ArrayList();
        StringBuilder querystring = new StringBuilder();
        int DataSetfillflag = 0;
        DataBaseConnection Db = new DataBaseConnection();
        OdbcConnection Conn;

        public ExportForm(string Query, string Version, SepsisMaster master)
        {
            sm = master;
            InitializeComponent();
            _querystring = Query;
            _version = Version;
        }

        public ExportForm(string Query, string Version, SepsisMaster master, int Sampling)
        {
            _sampling = Sampling;
            sm = master;
            InitializeComponent();
            _querystring = Query;
            _version = Version;
        }


        private void button_Export_Click(object sender, EventArgs e)
        {
            try
            {

                if (textBox_Path.Text.ToString().Trim() == "")
                {
                    MessageBox.Show("Please select folder to export file", "Export Details");
                    textBox_Path.Focus();
                    return;
                }


                if (!Directory.Exists(textBox_Path.Text.ToString().Trim()))
                {
                    MessageBox.Show("Please select a valid path!", "Export Details");
                    textBox_Path.Focus();
                    return;
                }

                //DataBaseConnection Db = new DataBaseConnection();
                //ConnectionString = @"Server=HANYS-APPS-DB-D\DEVNETFORUMDB;Database=Sepsis;User Id=sa;Password=password;";
                //ConnectionString = @"Server=JITU-PC\JITU;Database=Sepsis;User Id=sa;Password=jitu123;";


                // ConnectionString = "FIL=Sql server;DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;

                SelectData = "";



                if (_version == "4.1")
                {

                    SelectData = SelectData + "Select unique_personal_identifier, patient_control_number, date_of_birth, gender, race, ethnicity, payer, insurance_number, medical_record_number, facility_identifier, admission_datetime, source_of_admission,";
                    SelectData = SelectData + "discharge_datetime, discharge_status, transfer_status, transfer_facility_identifier, protocol_initiated, protocol_not_initiated_reason, protocol_ni_initiated_reason_additional_detail, protocol_initiated_place,";
                    SelectData = SelectData + "protocol_type, excluded_from_protocol, excluded_reason, excluded_datetime, excluded_explain, earliest_datetime, triage_datetime, severe_sepsis_present, severe_sepsis_present_datetime, septic_shock_present,";
                    SelectData = SelectData + "septic_shock_present_datetime, left_ed_datetime, destination_after_ed, initial_lactate_level_collection, initial_lactate_level_collection_datetime, initial_lactate_level, initial_lactate_level_unit,";
                    SelectData = SelectData + "repeat_lactate_level_collection, repeat_lactate_level_collection_datetime, blood_culture_collection, blood_culture_collection_acceptable_delay, blood_culture_collection_datetime, blood_culture_result,";
                    SelectData = SelectData + "blood_culture_pathogen, antibiotic_administration, antibiotic_administration_selection, antibiotic_administration_datetime, adult_crystalloid_fluid_administration, pediatric_crystalloid_fluid_administration,";
                    SelectData = SelectData + "crystalloid_fluid_administration_datetime, initial_hypotension, persistent_hypotension, vasopressor_administration, vasopressor_administration_datetime, bedside_cardiovascular_ultrasound, bedside_cardiovascular_ultrasound_datetime,";
                    SelectData = SelectData + "capillary_refill_examination, capillary_refill_examination_datetime, cardiopulmonary_evaluation, cardiopulmonary_evaluation_datetime, passive_leg_raise_examination, passive_leg_raise_examination_datetime,";
                    SelectData = SelectData + "peripheral_pulse_evaluation, peripheral_pulse_evaluation_datetime, skin_examination, skin_examination_datetime, central_venous_oxygen_measurement, central_venous_oxygen_measurement_datetime,";
                    SelectData = SelectData + "central_venous_pressure_measurement, central_venous_pressure_measurement_datetime, fluid_challenge_performed, fluid_challenge_performed_datetime, vital_signs_review, vital_signs_review_datetime, platelet_count,";
                    SelectData = SelectData + "bandemia, lower_respiratory_infection, altered_mental_status, infection_etiology, site_of_infection, mechanical_ventilation, mechanical_ventilation_datetime, icu, icu_admission_datetime, icu_discharge_datetime,";
                    SelectData = SelectData + "chronic_respiratory_failure, aids_hiv_disease, metastatic_cancer, lymphoma_leukemia_multiple_myeloma, immune_modifying_medications, congestive_heart_failure, chronic_renal_failure, chronic_liver_disease,";
                    SelectData = SelectData + "diabetes, organ_transplant From sepsis_Collab where UniqueId in (" + _querystring + ")";





                    ds = new DataSet();


                    //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                    using (Conn = new OdbcConnection(ConnectionString))
                    {
                        if (DataSetfillflag == 1)
                        {
                            DataSetfillflag = 0;
                            ds.Tables["sepsis_collab"].Clear();
                            ds.Tables["CSV_MAPPING"].Clear();
                        }

                        Conn.Open();



                        //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                        using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("Select * from CSV_MAPPING where version = '" + _version + "' order by order_no", Conn))
                        {

                            dbDataAdapter.Fill(ds, "CSV_MAPPING");
                            dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                            dbDataAdapter.Fill(ds, "sepsis_collab");

                        }


                        Conn.Close();
                    }

                    CurrentDate = DateTime.Now.ToString("yyyy-MM-dd");
                    Currenttime = DateTime.Now.ToString("HHmmss");


                    if (ds.Tables["sepsis_collab"].Rows.Count >= 1)
                    {
                        DataSetfillflag = 1;
                        FileName = "\\sdc_" + ds.Tables["sepsis_collab"].Rows[0]["facility_identifier"].ToString() + "_" + CurrentDate + "_" + Currenttime + ".csv";
                    }
                    else
                    {
                        MessageBox.Show("Nothing to Export.", "Export Message");
                    }



                    //TextWriter sw = new StreamWriter("C:\\All Sepsis\\New Sepsis\\Data.csv");
                    //TextWriter sw = new StreamWriter("G:\\All Sepsis\\New Sepsis\\Data.csv");

                    //TextWriter sw = new StreamWriter(Application.StartupPath + FileName);
                    sw = new StreamWriter(textBox_Path.Text.ToString().Trim() + FileName);

                    for (int i = 0; i <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; i++)
                    {

                        strHeader = "\"" + ds.Tables["CSV_MAPPING"].Rows[i]["Column"] + "\"";

                        if (i != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                        {
                            sw.Write("{0};", strHeader);
                        }
                        else
                        {
                            sw.WriteLine("{0}", strHeader);
                        }
                    }

                    for (int j = 0; j <= ds.Tables["sepsis_collab"].Rows.Count - 1; j++)
                    {

                        for (int k = 0; k <= ds.Tables["sepsis_collab"].Columns.Count - 1; k++)
                        {

                            for (int p = 0; p <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; p++)
                            {



                                if (ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim() == ds.Tables["sepsis_collab"].Columns[k].ToString().Trim())
                                {
                                    CurrentDate = ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim();

                                    count++;

                                    //Console.WriteLine(ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString());

                                    if (ds.Tables["sepsis_collab"].Columns[k].DataType.ToString() == "System.DateTime")
                                    {

                                        if (ds.Tables["sepsis_collab"].Rows[j][k].ToString() != "")
                                        {

                                            if (ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString() == "date_of_birth")
                                            {
                                                dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                strData = "\"" + dDate.ToString("yyyyMMdd") + "\"";

                                            }
                                            else
                                            {
                                                dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                strData = "\"" + dDate.ToString("yyyy-MM-dd HH:mm") + "\"";
                                            }




                                        }
                                        else
                                        {
                                            strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                        }



                                    }
                                    else
                                    {
                                        strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                    }







                                    if (k != ds.Tables["CSV_MAPPING"].Rows.Count)
                                    {
                                        sw.Write("{0};", strData);

                                    }
                                    else
                                    {
                                        sw.WriteLine("{0}", strData);
                                    }

                                    break;
                                }




                            }
                        }

                        count = 0;
                    }

                    sw.Close();
                    recordcompleteUniqueID.Clear();



                }
                else if (_version == "5.1")
                {
                    ds = new DataSet();

                    if (_sampling == 1)
                    {
                        _version = "5.11";

                        SelectData = SelectData + "Select admission_datetime, date_of_birth, discharge_datetime, discharge_status, facility_identifier, gender, medical_record_number, patient_control_number, source_of_admission, unique_personal_identifier";
                        SelectData = SelectData + " from sepsis_collab where UniqueId in (" + _querystring + ")";



                     

                        //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                        using (Conn = new OdbcConnection(ConnectionString))
                        {
                            if (DataSetfillflag == 1)
                            {
                                DataSetfillflag = 0;
                                ds.Tables["sepsis_collab"].Clear();
                                ds.Tables["CSV_MAPPING"].Clear();
                            }

                            Conn.Open();



                            //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                            using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("Select * from CSV_MAPPING where version = '" + _version + "' order by order_no", Conn))
                            {

                                dbDataAdapter.Fill(ds, "CSV_MAPPING");
                                //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                                dbDataAdapter.SelectCommand.CommandText = SelectData;
                                dbDataAdapter.Fill(ds, "sepsis_collab");

                            }


                            Conn.Close();
                        }

                        CurrentDate = DateTime.Now.ToString("yyyy-MM-dd");
                        Currenttime = DateTime.Now.ToString("HHmmss");


                        if (ds.Tables["sepsis_collab"].Rows.Count >= 1)
                        {
                            DataSetfillflag = 1;
                            FileName = "\\sdc_" + ds.Tables["sepsis_collab"].Rows[0]["facility_identifier"].ToString() + "_" + CurrentDate + "_" + Currenttime + ".csv";
                        }
                        else
                        {
                            MessageBox.Show("Nothing to Export.", "Export Message");
                        }




                        sw = new StreamWriter(textBox_Path.Text.ToString().Trim() + FileName);

                        for (int i = 0; i <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; i++)
                        {

                            strHeader = "\"" + ds.Tables["CSV_MAPPING"].Rows[i]["Column"] + "\"";

                            if (i != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                            {
                                sw.Write("{0};", strHeader);
                            }
                            else
                            {
                                sw.WriteLine("{0}", strHeader);
                            }
                        }

                        string test;
                        for (int j = 0; j <= ds.Tables["sepsis_collab"].Rows.Count - 1; j++)
                        {

                            for (int k = 0; k <= ds.Tables["sepsis_collab"].Columns.Count - 1; k++)
                            {

                                for (int p = 0; p <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; p++)
                                {



                                    if (ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim() == ds.Tables["sepsis_collab"].Columns[k].ToString().Trim())
                                    {
                                        test = ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString();

                                        CurrentDate = ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim();

                                        count++;

                                        //Console.WriteLine(ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString());

                                        if (ds.Tables["sepsis_collab"].Columns[k].DataType.ToString() == "System.DateTime")
                                        {

                                            if (ds.Tables["sepsis_collab"].Rows[j][k].ToString() != "")
                                            {

                                                if (ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString() == "date_of_birth")
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyyMMdd") + "\"";

                                                }
                                                else
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd HH:mm") + "\"";
                                                }




                                            }
                                            else
                                            {
                                                strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                            }



                                        }
                                        else
                                        {
                                            strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                        }







                                        if (k != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                                        {
                                            sw.Write("{0};", strData);

                                        }
                                        else
                                        {
                                            sw.WriteLine("{0}", strData);
                                        }

                                        break;
                                    }





                                }
                            }

                            count = 0;
                        }

                        sw.Close();
                        recordcompleteUniqueID.Clear();

                    }
                    else
                    { 

                        




                    SelectData = SelectData + "Select admission_datetime, date_of_birth, discharge_datetime, discharge_status, ethnicity, excluded_datetime, excluded_explain, excluded_from_protocol, excluded_reason, facility_identifier,";
                    SelectData = SelectData + "gender, insurance_number, medical_record_number, patient_control_number, payer, race, sepsis_identification_place, source_of_admission, transfer_facility_identifier, transfer_status,";
                    SelectData = SelectData + "unique_personal_identifier, adult_crystalloid_fluid_administration, antibiotic_administration, antibiotic_administration_datetime, antibiotic_administration_selection, earliest_datetime as 'arrival_datetime',";
                    SelectData = SelectData + "blood_culture_collection, blood_culture_collection_acceptable_delay, blood_culture_collection_datetime,";
                    SelectData = SelectData + "crystalloid_fluid_administration_datetime, initial_hypotension, initial_hypotension_datetime, initial_lactate_level, elevated_lactate_reason, initial_lactate_level_collection, initial_lactate_level_collection_datetime,";
                    SelectData = SelectData + "pediatric_crystalloid_fluid_administration, persistent_hypotension, repeat_lactate_level_collection, repeat_lactate_level_collection_datetime,";
                    SelectData = SelectData + "repeat_volume_status_and_tissue_perfusion_assessment_performed, repeat_volume_status_and_tissue_perfusion_assessment_performed_datetime, septic_shock_present, septic_shock_present_datetime, severe_sepsis_present, severe_sepsis_present_datetime,";
                    SelectData = SelectData + "triage_datetime, vasopressor_administration, vasopressor_administration_datetime, altered_mental_status, bandemia, lower_respiratory_infection,";
                    SelectData = SelectData + "platelet_count, aids_hiv_disease, chronic_liver_disease, chronic_renal_failure, chronic_respiratory_failure, congestive_heart_failure, diabetes, icu, icu_admission_datetime, icu_discharge_datetime,";
                    SelectData = SelectData + "immune_modifying_medications, infection_etiology, lymphoma_leukemia_multiple_myeloma, mechanical_ventilation, mechanical_ventilation_datetime, metastatic_cancer, organ_transplant, site_of_infection";
                    SelectData = SelectData + " from sepsis_collab where UniqueId in (" + _querystring + ")";

                    ds = new DataSet();


                    //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                    using (Conn = new OdbcConnection(ConnectionString))
                    {
                        if (DataSetfillflag == 1)
                        {
                            DataSetfillflag = 0;
                            ds.Tables["sepsis_collab"].Clear();
                            ds.Tables["CSV_MAPPING"].Clear();
                        }

                        Conn.Open();



                        //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                        using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("Select * from CSV_MAPPING where version = '" + _version + "' order by order_no", Conn))
                        {

                            dbDataAdapter.Fill(ds, "CSV_MAPPING");
                            //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                            dbDataAdapter.SelectCommand.CommandText = SelectData;
                            dbDataAdapter.Fill(ds, "sepsis_collab");

                        }


                        Conn.Close();
                    }

                    CurrentDate = DateTime.Now.ToString("yyyy-MM-dd");
                    Currenttime = DateTime.Now.ToString("HHmmss");


                    if (ds.Tables["sepsis_collab"].Rows.Count >= 1)
                    {
                        DataSetfillflag = 1;
                        FileName = "\\sdc_" + ds.Tables["sepsis_collab"].Rows[0]["facility_identifier"].ToString() + "_" + CurrentDate + "_" + Currenttime + ".csv";
                    }
                    else
                    {
                        MessageBox.Show("Nothing to Export.", "Export Message");
                    }



                    //TextWriter sw = new StreamWriter("C:\\All Sepsis\\New Sepsis\\Data.csv");
                    //TextWriter sw = new StreamWriter("G:\\All Sepsis\\New Sepsis\\Data.csv");

                    //TextWriter sw = new StreamWriter(Application.StartupPath + FileName);
                    sw = new StreamWriter(textBox_Path.Text.ToString().Trim() + FileName);

                    for (int i = 0; i <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; i++)
                    {

                        strHeader = "\"" + ds.Tables["CSV_MAPPING"].Rows[i]["Column"] + "\"";

                        if (i != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                        {
                            sw.Write("{0};", strHeader);
                        }
                        else
                        {
                            sw.WriteLine("{0}", strHeader);
                        }
                    }

                    string test;
                    for (int j = 0; j <= ds.Tables["sepsis_collab"].Rows.Count - 1; j++)
                    {

                        for (int k = 0; k <= ds.Tables["sepsis_collab"].Columns.Count - 1; k++)
                        {

                            for (int p = 0; p <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; p++)
                            {



                                if (ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim() == ds.Tables["sepsis_collab"].Columns[k].ToString().Trim())
                                {
                                    test = ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString();

                                    CurrentDate = ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim();

                                    count++;

                                    //Console.WriteLine(ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString());

                                    if (ds.Tables["sepsis_collab"].Columns[k].DataType.ToString() == "System.DateTime")
                                    {

                                        if (ds.Tables["sepsis_collab"].Rows[j][k].ToString() != "")
                                        {

                                            if (ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString() == "date_of_birth")
                                            {
                                                dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                strData = "\"" + dDate.ToString("yyyyMMdd") + "\"";

                                            }
                                            else
                                            {
                                                dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                strData = "\"" + dDate.ToString("yyyy-MM-dd HH:mm") + "\"";
                                            }




                                        }
                                        else
                                        {
                                            strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                        }



                                    }
                                    else
                                    {
                                        strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                    }







                                    if (k != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                                    {
                                        sw.Write("{0};", strData);

                                    }
                                    else
                                    {
                                        sw.WriteLine("{0}", strData);
                                    }

                                    break;
                                }





                            }
                        }

                        count = 0;
                    }

                    sw.Close();
                    recordcompleteUniqueID.Clear();
                }
                    



                    }

                else if (_version == "6.2")
                {
                    ds = new DataSet();

                    if (_sampling == 1)
                    {
                        _version = "5.11";

                        SelectData = SelectData + "Select admission_datetime, date_of_birth, discharge_datetime, discharge_status, facility_identifier, gender, medical_record_number, patient_control_number, source_of_admission, unique_personal_identifier";
                        SelectData = SelectData + " from sepsis_collab where UniqueId in (" + _querystring + ")";





                        //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                        using (Conn = new OdbcConnection(ConnectionString))
                        {
                            if (DataSetfillflag == 1)
                            {
                                DataSetfillflag = 0;
                                ds.Tables["sepsis_collab"].Clear();
                                ds.Tables["CSV_MAPPING"].Clear();
                            }

                            Conn.Open();



                            //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                            using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("Select * from CSV_MAPPING where version = '" + _version + "' order by order_no", Conn))
                            {

                                dbDataAdapter.Fill(ds, "CSV_MAPPING");
                                //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                                dbDataAdapter.SelectCommand.CommandText = SelectData;
                                dbDataAdapter.Fill(ds, "sepsis_collab");

                            }


                            Conn.Close();
                        }

                        CurrentDate = DateTime.Now.ToString("yyyy-MM-dd");
                        Currenttime = DateTime.Now.ToString("HHmmss");


                        if (ds.Tables["sepsis_collab"].Rows.Count >= 1)
                        {
                            DataSetfillflag = 1;
                            FileName = "\\sdc_" + ds.Tables["sepsis_collab"].Rows[0]["facility_identifier"].ToString() + "_" + CurrentDate + "_" + Currenttime + ".csv";
                        }
                        else
                        {
                            MessageBox.Show("Nothing to Export.", "Export Message");
                        }




                        sw = new StreamWriter(textBox_Path.Text.ToString().Trim() + FileName);

                        for (int i = 0; i <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; i++)
                        {

                            strHeader = "\"" + ds.Tables["CSV_MAPPING"].Rows[i]["Column"] + "\"";

                            if (i != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                            {
                                sw.Write("{0};", strHeader);
                            }
                            else
                            {
                                sw.WriteLine("{0}", strHeader);
                            }
                        }

                        string test;
                        for (int j = 0; j <= ds.Tables["sepsis_collab"].Rows.Count - 1; j++)
                        {

                            for (int k = 0; k <= ds.Tables["sepsis_collab"].Columns.Count - 1; k++)
                            {

                                for (int p = 0; p <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; p++)
                                {



                                    if (ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim() == ds.Tables["sepsis_collab"].Columns[k].ToString().Trim())
                                    {
                                        test = ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString();

                                        CurrentDate = ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim();

                                        count++;

                                        //Console.WriteLine(ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString());

                                        if (ds.Tables["sepsis_collab"].Columns[k].DataType.ToString() == "System.DateTime")
                                        {

                                            if (ds.Tables["sepsis_collab"].Rows[j][k].ToString() != "")
                                            {

                                                if (ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString() == "date_of_birth")
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd") + "\"";

                                                }
                                                else
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd HH:mm") + "\"";
                                                }




                                            }
                                            else
                                            {
                                                strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                            }



                                        }
                                        else
                                        {
                                            strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                        }







                                        if (k != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                                        {
                                            sw.Write("{0};", strData);

                                        }
                                        else
                                        {
                                            sw.WriteLine("{0}", strData);
                                        }

                                        break;
                                    }





                                }
                            }

                            count = 0;
                        }

                        sw.Close();
                        recordcompleteUniqueID.Clear();

                    }
                    else
                    {
               
                        SelectData = SelectData + "Select admission_datetime, date_of_birth, discharge_datetime, discharge_status, ethnicity, excluded_datetime, excluded_explain, excluded_from_protocol, excluded_reason, facility_identifier,";
                        SelectData = SelectData + "gender, insurance_number, medical_record_number, patient_control_number, payer, pregnancy_status, race, sepsis_identification_place, source_of_admission, transfer_facility_identifier, transfer_status,";
                        SelectData = SelectData + "unique_personal_identifier, adult_crystalloid_fluid_administration, antibiotic_administration, antibiotic_administration_datetime, antibiotic_administration_selection, earliest_datetime as 'arrival_datetime',";
                        SelectData = SelectData + "blood_culture_collection, blood_culture_collection_acceptable_delay, blood_culture_collection_datetime,";
                        SelectData = SelectData + "crystalloid_fluid_administration_datetime, initial_hypotension, initial_hypotension_datetime, initial_lactate_level, elevated_lactate_reason, initial_lactate_level_collection, initial_lactate_level_collection_datetime,";
                        SelectData = SelectData + "persistent_hypotension, repeat_lactate_level_collection, repeat_lactate_level_collection_datetime,";
                        SelectData = SelectData + "repeat_volume_status_and_tissue_perfusion_assessment_performed, repeat_volume_status_and_tissue_perfusion_assessment_performed_datetime, septic_shock_present, septic_shock_present_datetime as septic_shock_presentation_datetime, severe_sepsis_present, severe_sepsis_present_datetime as severe_sepsis_presentation_datetime,";
                        SelectData = SelectData + "triage_datetime, vasopressor_administration, vasopressor_administration_datetime, altered_mental_status, bandemia, lower_respiratory_infection,";
                        SelectData = SelectData + "platelet_count, aids_hiv_disease, chronic_liver_disease, chronic_renal_failure, chronic_respiratory_failure, congestive_heart_failure, diabetes, icu, icu_admission_datetime, icu_discharge_datetime,";
                        SelectData = SelectData + "immune_modifying_medications, infection_etiology, lymphoma_leukemia_multiple_myeloma, mechanical_ventilation, mechanical_ventilation_datetime, metastatic_cancer, organ_transplant, site_of_infection";
                        SelectData = SelectData + " from sepsis_collab where UniqueId in (" + _querystring + ")";

                        ds = new DataSet();


                        //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                        using (Conn = new OdbcConnection(ConnectionString))
                        {
                            if (DataSetfillflag == 1)
                            {
                                DataSetfillflag = 0;
                                ds.Tables["sepsis_collab"].Clear();
                                ds.Tables["CSV_MAPPING"].Clear();
                            }

                            Conn.Open();



                            //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                            using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("Select * from CSV_MAPPING where version = '" + _version + "' order by order_no", Conn))
                            {

                                dbDataAdapter.Fill(ds, "CSV_MAPPING");
                                //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                                dbDataAdapter.SelectCommand.CommandText = SelectData;
                                dbDataAdapter.Fill(ds, "sepsis_collab");

                            }


                            Conn.Close();
                        }

                        CurrentDate = DateTime.Now.ToString("yyyy-MM-dd");
                        Currenttime = DateTime.Now.ToString("HHmmss");


                        if (ds.Tables["sepsis_collab"].Rows.Count >= 1)
                        {
                            DataSetfillflag = 1;
                            FileName = "\\sdc_" + ds.Tables["sepsis_collab"].Rows[0]["facility_identifier"].ToString() + "_" + CurrentDate + "_" + Currenttime + ".csv";
                        }
                        else
                        {
                            MessageBox.Show("Nothing to Export.", "Export Message");
                        }



                        //TextWriter sw = new StreamWriter("C:\\All Sepsis\\New Sepsis\\Data.csv");
                        //TextWriter sw = new StreamWriter("G:\\All Sepsis\\New Sepsis\\Data.csv");

                        //TextWriter sw = new StreamWriter(Application.StartupPath + FileName);
                        sw = new StreamWriter(textBox_Path.Text.ToString().Trim() + FileName);

                        for (int i = 0; i <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; i++)
                        {

                            strHeader = "\"" + ds.Tables["CSV_MAPPING"].Rows[i]["Column"] + "\"";

                            if (i != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                            {
                                sw.Write("{0};", strHeader);
                            }
                            else
                            {
                                sw.WriteLine("{0}", strHeader);
                            }
                        }

                        string test;
                        for (int j = 0; j <= ds.Tables["sepsis_collab"].Rows.Count - 1; j++)
                        {

                            for (int k = 0; k <= ds.Tables["sepsis_collab"].Columns.Count - 1; k++)
                            {

                                for (int p = 0; p <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; p++)
                                {



                                    if (ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim() == ds.Tables["sepsis_collab"].Columns[k].ToString().Trim())
                                    {
                                        test = ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString();

                                        CurrentDate = ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim();

                                        count++;

                                        //Console.WriteLine(ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString());

                                        if (ds.Tables["sepsis_collab"].Columns[k].DataType.ToString() == "System.DateTime")
                                        {

                                            if (ds.Tables["sepsis_collab"].Rows[j][k].ToString() != "")
                                            {

                                                if (ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString() == "date_of_birth")
                                                {

                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd") + "\"";

                                                }
                                                else
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd HH:mm") + "\"";
                                                }




                                            }
                                            else
                                            {
                                                strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                            }



                                        }
                                        else
                                        {
                                            strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                        }







                                        if (k != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                                        {
                                            sw.Write("{0};", strData);

                                        }
                                        else
                                        {
                                            sw.WriteLine("{0}", strData);
                                        }

                                        break;
                                    }





                                }
                            }

                            count = 0;
                        }

                        sw.Close();
                        recordcompleteUniqueID.Clear();
                    }




                }

                else if (_version == "7.1")
                {
                    ds = new DataSet();

                    if (_sampling == 1)
                    {
                        _version = "5.11";

                        SelectData = SelectData + "Select admission_datetime, date_of_birth, discharge_datetime, discharge_status, facility_identifier, gender, medical_record_number, patient_control_number, source_of_admission, unique_personal_identifier";
                        SelectData = SelectData + " from sepsis_collab where UniqueId in (" + _querystring + ")";





                        //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                        using (Conn = new OdbcConnection(ConnectionString))
                        {
                            if (DataSetfillflag == 1)
                            {
                                DataSetfillflag = 0;
                                ds.Tables["sepsis_collab"].Clear();
                                ds.Tables["CSV_MAPPING"].Clear();
                            }

                            Conn.Open();



                            //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                            using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("Select * from CSV_MAPPING where version = '" + _version + "' order by order_no", Conn))
                            {

                                dbDataAdapter.Fill(ds, "CSV_MAPPING");
                                //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                                dbDataAdapter.SelectCommand.CommandText = SelectData;
                                dbDataAdapter.Fill(ds, "sepsis_collab");

                            }


                            Conn.Close();
                        }

                        CurrentDate = DateTime.Now.ToString("yyyy-MM-dd");
                        Currenttime = DateTime.Now.ToString("HHmmss");


                        if (ds.Tables["sepsis_collab"].Rows.Count >= 1)
                        {
                            DataSetfillflag = 1;
                            FileName = "\\sdc_" + ds.Tables["sepsis_collab"].Rows[0]["facility_identifier"].ToString() + "_" + CurrentDate + "_" + Currenttime + ".csv";
                        }
                        else
                        {
                            MessageBox.Show("Nothing to Export.", "Export Message");
                        }




                        sw = new StreamWriter(textBox_Path.Text.ToString().Trim() + FileName);

                        for (int i = 0; i <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; i++)
                        {

                            strHeader = "\"" + ds.Tables["CSV_MAPPING"].Rows[i]["Column"] + "\"";

                            if (i != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                            {
                                sw.Write("{0};", strHeader);
                            }
                            else
                            {
                                sw.WriteLine("{0}", strHeader);
                            }
                        }

                        string test;
                        for (int j = 0; j <= ds.Tables["sepsis_collab"].Rows.Count - 1; j++)
                        {

                            for (int k = 0; k <= ds.Tables["sepsis_collab"].Columns.Count - 1; k++)
                            {

                                for (int p = 0; p <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; p++)
                                {



                                    if (ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim() == ds.Tables["sepsis_collab"].Columns[k].ToString().Trim())
                                    {
                                        test = ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString();

                                        CurrentDate = ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim();

                                        count++;

                                        //Console.WriteLine(ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString());

                                        if (ds.Tables["sepsis_collab"].Columns[k].DataType.ToString() == "System.DateTime")
                                        {

                                            if (ds.Tables["sepsis_collab"].Rows[j][k].ToString() != "")
                                            {

                                                if (ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString() == "date_of_birth")
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd") + "\"";

                                                }
                                                else
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd HH:mm") + "\"";
                                                }




                                            }
                                            else
                                            {
                                                strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                            }



                                        }
                                        else
                                        {
                                            strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                        }







                                        if (k != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                                        {
                                            sw.Write("{0};", strData);

                                        }
                                        else
                                        {
                                            sw.WriteLine("{0}", strData);
                                        }

                                        break;
                                    }





                                }
                            }

                            count = 0;
                        }

                        sw.Close();
                        recordcompleteUniqueID.Clear();

                    }
                    else
                    {
                       
                        SelectData = SelectData + "Select admission_datetime, date_of_birth, discharge_datetime, discharge_status, ethnicity, excluded_datetime, excluded_explain, excluded_from_protocol, excluded_reason, facility_identifier,";
                        SelectData = SelectData + "gender, insurance_number, medical_record_number, patient_control_number, payer, pregnancy_status, race, sepsis_identification_place, source_of_admission, transfer_facility_identifier, transfer_status,";
                        SelectData = SelectData + "unique_personal_identifier, adult_crystalloid_fluid_administration, antibiotic_administration, antibiotic_administration_datetime, antibiotic_administration_selection, earliest_datetime as 'arrival_datetime',";
                        SelectData = SelectData + "blood_culture_collection, blood_culture_collection_acceptable_delay, blood_culture_collection_datetime,";
                        SelectData = SelectData + "crystalloid_fluid_administration_datetime, initial_hypotension, initial_hypotension_datetime, initial_lactate_level, elevated_lactate_reason, initial_lactate_level_collection, initial_lactate_level_collection_datetime,";
                        SelectData = SelectData + "persistent_hypotension, repeat_lactate_level_collection, repeat_lactate_level_collection_datetime,";
                        SelectData = SelectData + "repeat_volume_status_and_tissue_perfusion_assessment_performed, repeat_volume_status_and_tissue_perfusion_assessment_performed_datetime, septic_shock_present, septic_shock_present_datetime as septic_shock_presentation_datetime, severe_sepsis_present, severe_sepsis_present_datetime as severe_sepsis_presentation_datetime,";
                        SelectData = SelectData + "triage_datetime, vasopressor_administration, vasopressor_administration_datetime, altered_mental_status, bandemia, lower_respiratory_infection,";
                        SelectData = SelectData + "platelet_count, aids_hiv_disease, chronic_liver_disease, chronic_renal_failure, chronic_respiratory_failure, congestive_heart_failure, diabetes, icu, icu_admission_datetime, icu_discharge_datetime,";
                        SelectData = SelectData + "immune_modifying_medications, infection_etiology, lymphoma_leukemia_multiple_myeloma, mechanical_ventilation, mechanical_ventilation_datetime, metastatic_cancer, organ_transplant, site_of_infection";
                        SelectData = SelectData + " from sepsis_collab where UniqueId in (" + _querystring + ")";

                        ds = new DataSet();


                        //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                        using (Conn = new OdbcConnection(ConnectionString))
                        {
                            if (DataSetfillflag == 1)
                            {
                                DataSetfillflag = 0;
                                ds.Tables["sepsis_collab"].Clear();
                                ds.Tables["CSV_MAPPING"].Clear();
                            }

                            Conn.Open();



                            //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                            using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("Select * from CSV_MAPPING where version = '" + _version + "' order by order_no", Conn))
                            {

                                dbDataAdapter.Fill(ds, "CSV_MAPPING");
                                //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                                dbDataAdapter.SelectCommand.CommandText = SelectData;
                                dbDataAdapter.Fill(ds, "sepsis_collab");

                            }


                            Conn.Close();
                        }

                        CurrentDate = DateTime.Now.ToString("yyyy-MM-dd");
                        Currenttime = DateTime.Now.ToString("HHmmss");


                        if (ds.Tables["sepsis_collab"].Rows.Count >= 1)
                        {
                            DataSetfillflag = 1;
                            FileName = "\\sdc_" + ds.Tables["sepsis_collab"].Rows[0]["facility_identifier"].ToString() + "_" + CurrentDate + "_" + Currenttime + ".csv";
                        }
                        else
                        {
                            MessageBox.Show("Nothing to Export.", "Export Message");
                        }



                        //TextWriter sw = new StreamWriter("C:\\All Sepsis\\New Sepsis\\Data.csv");
                        //TextWriter sw = new StreamWriter("G:\\All Sepsis\\New Sepsis\\Data.csv");

                        //TextWriter sw = new StreamWriter(Application.StartupPath + FileName);
                        sw = new StreamWriter(textBox_Path.Text.ToString().Trim() + FileName);

                        for (int i = 0; i <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; i++)
                        {

                            strHeader = "\"" + ds.Tables["CSV_MAPPING"].Rows[i]["Column"] + "\"";

                            if (i != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                            {
                                sw.Write("{0};", strHeader);
                            }
                            else
                            {
                                sw.WriteLine("{0}", strHeader);
                            }
                        }

                        string test;
                        for (int j = 0; j <= ds.Tables["sepsis_collab"].Rows.Count - 1; j++)
                        {

                            for (int k = 0; k <= ds.Tables["sepsis_collab"].Columns.Count - 1; k++)
                            {

                                for (int p = 0; p <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; p++)
                                {



                                    if (ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim() == ds.Tables["sepsis_collab"].Columns[k].ToString().Trim())
                                    {
                                        test = ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString();

                                        CurrentDate = ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim();

                                        count++;

                                        //Console.WriteLine(ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString());

                                        if (ds.Tables["sepsis_collab"].Columns[k].DataType.ToString() == "System.DateTime")
                                        {

                                            if (ds.Tables["sepsis_collab"].Rows[j][k].ToString() != "")
                                            {

                                                if (ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString() == "date_of_birth")
                                                {

                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd") + "\"";

                                                }
                                                else
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd HH:mm") + "\"";
                                                }




                                            }
                                            else
                                            {
                                                strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                            }



                                        }
                                        else
                                        {
                                            strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                        }







                                        if (k != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                                        {
                                            sw.Write("{0};", strData);

                                        }
                                        else
                                        {
                                            sw.WriteLine("{0}", strData);
                                        }

                                        break;
                                    }





                                }
                            }

                            count = 0;
                        }

                        sw.Close();
                        recordcompleteUniqueID.Clear();
                    }




                }

                else if (_version == "1.1")
                {
                    ds = new DataSet();

                    if (_sampling == 1)
                    {
                        _version = "5.11";

                        SelectData = SelectData + "Select admission_datetime, date_of_birth, discharge_datetime, discharge_status, facility_identifier, gender, medical_record_number, patient_control_number, source_of_admission, unique_personal_identifier";
                        SelectData = SelectData + " from sepsis_collab where UniqueId in (" + _querystring + ")";





                        //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                        using (Conn = new OdbcConnection(ConnectionString))
                        {
                            if (DataSetfillflag == 1)
                            {
                                DataSetfillflag = 0;
                                ds.Tables["sepsis_collab"].Clear();
                                ds.Tables["CSV_MAPPING"].Clear();
                            }

                            Conn.Open();



                            //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                            using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("Select * from CSV_MAPPING where version = '" + _version + "' order by order_no", Conn))
                            {

                                dbDataAdapter.Fill(ds, "CSV_MAPPING");
                                //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                                dbDataAdapter.SelectCommand.CommandText = SelectData;
                                dbDataAdapter.Fill(ds, "sepsis_collab");

                            }


                            Conn.Close();
                        }

                        CurrentDate = DateTime.Now.ToString("yyyy-MM-dd");
                        Currenttime = DateTime.Now.ToString("HHmmss");


                        if (ds.Tables["sepsis_collab"].Rows.Count >= 1)
                        {
                            DataSetfillflag = 1;
                            FileName = "\\sdc_" + ds.Tables["sepsis_collab"].Rows[0]["facility_identifier"].ToString() + "_" + CurrentDate + "_" + Currenttime + ".csv";
                        }
                        else
                        {
                            MessageBox.Show("Nothing to Export.", "Export Message");
                        }




                        sw = new StreamWriter(textBox_Path.Text.ToString().Trim() + FileName);

                        for (int i = 0; i <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; i++)
                        {

                            strHeader = "\"" + ds.Tables["CSV_MAPPING"].Rows[i]["Column"] + "\"";

                            if (i != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                            {
                                sw.Write("{0};", strHeader);
                            }
                            else
                            {
                                sw.WriteLine("{0}", strHeader);
                            }
                        }

                        string test;
                        for (int j = 0; j <= ds.Tables["sepsis_collab"].Rows.Count - 1; j++)
                        {

                            for (int k = 0; k <= ds.Tables["sepsis_collab"].Columns.Count - 1; k++)
                            {

                                for (int p = 0; p <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; p++)
                                {



                                    if (ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim() == ds.Tables["sepsis_collab"].Columns[k].ToString().Trim())
                                    {
                                        test = ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString();

                                        CurrentDate = ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim();

                                        count++;

                                        //Console.WriteLine(ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString());

                                        if (ds.Tables["sepsis_collab"].Columns[k].DataType.ToString() == "System.DateTime")
                                        {

                                            if (ds.Tables["sepsis_collab"].Rows[j][k].ToString() != "")
                                            {

                                                if (ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString() == "date_of_birth")
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd") + "\"";

                                                }
                                                else
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd HH:mm") + "\"";
                                                }




                                            }
                                            else
                                            {
                                                strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                            }



                                        }
                                        else
                                        {
                                            strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                        }







                                        if (k != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                                        {
                                            sw.Write("{0};", strData);

                                        }
                                        else
                                        {
                                            sw.WriteLine("{0}", strData);
                                        }

                                        break;
                                    }





                                }
                            }

                            count = 0;
                        }

                        sw.Close();
                        recordcompleteUniqueID.Clear();

                    }
                    else
                    {

                        SelectData = SelectData + "Select admission_datetime, Earliest_datetime as arrival_datetime, date_of_birth, discharge_datetime, discharge_status, ethnicity,";
                        SelectData = SelectData + "excluded_datetime, excluded_explain, excluded_from_protocol, excluded_reason, facility_identifier, gender, insurance_number, medical_record_number,";
                        SelectData = SelectData + "patient_control_number, payer, race, sepsis_identification_place, source_of_admission, transfer_facility_identifier, transfer_status, triage_datetime, unique_personal_identifier,";
                        SelectData = SelectData + "antibiotic_administration, antibiotic_administration_datetime, blood_culture_collection, blood_culture_collection_datetime, blood_culture_collection_acceptable_delay,";
                        SelectData = SelectData + "pediatric_crystalloid_fluid_administration as  crystalloid_fluid_administration, crystalloid_fluid_administration_datetime, elevated_lactate_reason, initial_lactate_level,";
                        SelectData = SelectData + "initial_lactate_level_collection, initial_lactate_level_collection_datetime, septic_shock_present, septic_shock_present_datetime as septic_shock_presentation_datetime,";
                        SelectData = SelectData + "severe_sepsis_present, severe_sepsis_present_datetime as severe_sepsis_presentation_datetime, vasopressor_administration,";
                        SelectData = SelectData + "vasopressor_administration_datetime as vasopressor_administration_start_datetime, vasopressor_administration_end_datetime, vasopressor_administration_transfer, altered_mental_status,";
                        SelectData = SelectData + "bandemia, lower_respiratory_infection, platelet_count, aids_hiv_disease, chronic_liver_disease, chronic_renal_failure, chronic_respiratory_failure, congestive_heart_failure, diabetes,";
                        SelectData = SelectData + "icu, icu_admission_datetime, icu_discharge_datetime, immune_modifying_medications, infection_etiology, lymphoma_leukemia_multiple_myeloma, mechanical_ventilation,";
                        SelectData = SelectData + "mechanical_ventilation_datetime as mechanical_ventilation_start_datetime, mechanical_ventilation_end_datetime, mechanical_ventilation_transfer, metastatic_cancer, organ_transplant, site_of_infection";
                        SelectData = SelectData + " from sepsis_collab where UniqueId in (" + _querystring + ")";

                        ds = new DataSet();


                        //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                        using (Conn = new OdbcConnection(ConnectionString))
                        {
                            if (DataSetfillflag == 1)
                            {
                                DataSetfillflag = 0;
                                ds.Tables["sepsis_collab"].Clear();
                                ds.Tables["CSV_MAPPING"].Clear();
                            }

                            Conn.Open();



                            //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                            using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("Select * from CSV_MAPPING where version = '" + _version + "' order by order_no", Conn))
                            {

                                dbDataAdapter.Fill(ds, "CSV_MAPPING");
                                //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                                dbDataAdapter.SelectCommand.CommandText = SelectData;
                                dbDataAdapter.Fill(ds, "sepsis_collab");

                            }


                            Conn.Close();
                        }

                        CurrentDate = DateTime.Now.ToString("yyyy-MM-dd");
                        Currenttime = DateTime.Now.ToString("HHmmss");


                        if (ds.Tables["sepsis_collab"].Rows.Count >= 1)
                        {
                            DataSetfillflag = 1;
                            FileName = "\\sdc_" + ds.Tables["sepsis_collab"].Rows[0]["facility_identifier"].ToString() + "_" + CurrentDate + "_" + Currenttime + ".csv";
                        }
                        else
                        {
                            MessageBox.Show("Nothing to Export.", "Export Message");
                        }



                        //TextWriter sw = new StreamWriter("C:\\All Sepsis\\New Sepsis\\Data.csv");
                        //TextWriter sw = new StreamWriter("G:\\All Sepsis\\New Sepsis\\Data.csv");

                        //TextWriter sw = new StreamWriter(Application.StartupPath + FileName);
                        sw = new StreamWriter(textBox_Path.Text.ToString().Trim() + FileName);

                        for (int i = 0; i <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; i++)
                        {

                            strHeader = "\"" + ds.Tables["CSV_MAPPING"].Rows[i]["Column"] + "\"";

                            if (i != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                            {
                                sw.Write("{0};", strHeader);
                            }
                            else
                            {
                                sw.WriteLine("{0}", strHeader);
                            }
                        }

                        string test;
                        for (int j = 0; j <= ds.Tables["sepsis_collab"].Rows.Count - 1; j++)
                        {

                            for (int k = 0; k <= ds.Tables["sepsis_collab"].Columns.Count - 1; k++)
                            {

                                for (int p = 0; p <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; p++)
                                {



                                    if (ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim() == ds.Tables["sepsis_collab"].Columns[k].ToString().Trim())
                                    {
                                        test = ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString();

                                        CurrentDate = ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim();

                                        count++;

                                        //Console.WriteLine(ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString());

                                        if (ds.Tables["sepsis_collab"].Columns[k].DataType.ToString() == "System.DateTime")
                                        {

                                            if (ds.Tables["sepsis_collab"].Rows[j][k].ToString() != "")
                                            {

                                                if (ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString() == "date_of_birth")
                                                {

                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd") + "\"";

                                                }
                                                else
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd HH:mm") + "\"";
                                                }




                                            }
                                            else
                                            {
                                                strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                            }



                                        }
                                        else
                                        {
                                            strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                        }







                                        if (k != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                                        {
                                            sw.Write("{0};", strData);

                                        }
                                        else
                                        {
                                            sw.WriteLine("{0}", strData);
                                        }

                                        break;
                                    }





                                }
                            }

                            count = 0;
                        }

                        sw.Close();
                        recordcompleteUniqueID.Clear();
                    }




                }



                else if (_version == "2.0")
                {
                    ds = new DataSet();

                    if (_sampling == 1)
                    {
                        _version = "5.11";

                        SelectData = SelectData + "Select admission_datetime, date_of_birth, discharge_datetime, discharge_status, facility_identifier, gender, medical_record_number, patient_control_number, source_of_admission, unique_personal_identifier";
                        SelectData = SelectData + " from sepsis_collab where UniqueId in (" + _querystring + ")";





                        //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                        using (Conn = new OdbcConnection(ConnectionString))
                        {
                            if (DataSetfillflag == 1)
                            {
                                DataSetfillflag = 0;
                                ds.Tables["sepsis_collab"].Clear();
                                ds.Tables["CSV_MAPPING"].Clear();
                            }

                            Conn.Open();



                            //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                            using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("Select * from CSV_MAPPING where version = '" + 2 + "' order by order_no", Conn))
                            {

                                dbDataAdapter.Fill(ds, "CSV_MAPPING");
                                //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                                dbDataAdapter.SelectCommand.CommandText = SelectData;
                                dbDataAdapter.Fill(ds, "sepsis_collab");

                            }


                            Conn.Close();
                        }

                        CurrentDate = DateTime.Now.ToString("yyyy-MM-dd");
                        Currenttime = DateTime.Now.ToString("HHmmss");


                        if (ds.Tables["sepsis_collab"].Rows.Count >= 1)
                        {
                            DataSetfillflag = 1;
                            FileName = "\\sdc_" + ds.Tables["sepsis_collab"].Rows[0]["facility_identifier"].ToString() + "_" + CurrentDate + "_" + Currenttime + ".csv";
                        }
                        else
                        {
                            MessageBox.Show("Nothing to Export.", "Export Message");
                        }




                        sw = new StreamWriter(textBox_Path.Text.ToString().Trim() + FileName);

                        for (int i = 0; i <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; i++)
                        {

                            strHeader = "\"" + ds.Tables["CSV_MAPPING"].Rows[i]["Column"] + "\"";

                            if (i != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                            {
                                sw.Write("{0};", strHeader);
                            }
                            else
                            {
                                sw.WriteLine("{0}", strHeader);
                            }
                        }

                        string test;
                        for (int j = 0; j <= ds.Tables["sepsis_collab"].Rows.Count - 1; j++)
                        {

                            for (int k = 0; k <= ds.Tables["sepsis_collab"].Columns.Count - 1; k++)
                            {

                                for (int p = 0; p <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; p++)
                                {



                                    if (ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim() == ds.Tables["sepsis_collab"].Columns[k].ToString().Trim())
                                    {
                                        test = ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString();

                                        CurrentDate = ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim();

                                        count++;

                                        //Console.WriteLine(ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString());

                                        if (ds.Tables["sepsis_collab"].Columns[k].DataType.ToString() == "System.DateTime")
                                        {

                                            if (ds.Tables["sepsis_collab"].Rows[j][k].ToString() != "")
                                            {

                                                if (ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString() == "date_of_birth")
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd") + "\"";

                                                }
                                                else
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd HH:mm") + "\"";
                                                }




                                            }
                                            else
                                            {
                                                strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                            }



                                        }
                                        else
                                        {
                                            strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                        }







                                        if (k != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                                        {
                                            sw.Write("{0};", strData);

                                        }
                                        else
                                        {
                                            sw.WriteLine("{0}", strData);
                                        }

                                        break;
                                    }





                                }
                            }

                            count = 0;
                        }

                        sw.Close();
                        recordcompleteUniqueID.Clear();

                    }
                    else
                    {
                       
                        SelectData = SelectData + "Select admission_datetime, Earliest_datetime as arrival_datetime, date_of_birth, discharge_datetime, discharge_status, ethnicity,";
                        SelectData = SelectData + "excluded_datetime, excluded_explain, excluded_from_protocol, excluded_reason, facility_identifier, gender, insurance_number, medical_record_number,";
                        SelectData = SelectData + "patient_control_number, pregnancy_status, payer, race, sepsis_identification_place, source_of_admission, transfer_facility_identifier, transfer_status, triage_datetime, unique_personal_identifier,";
                        SelectData = SelectData + "antibiotic_administration, antibiotic_administration_datetime, blood_culture_collection, blood_culture_collection_datetime, blood_culture_collection_acceptable_delay,";
                        SelectData = SelectData + "pediatric_crystalloid_fluid_administration as  crystalloid_fluid_administration, crystalloid_fluid_administration_datetime, elevated_lactate_reason, initial_lactate_level,";
                        SelectData = SelectData + "initial_lactate_level_collection, initial_lactate_level_collection_datetime, initial_lactate_level_source, septic_shock_present, septic_shock_present_datetime as septic_shock_presentation_datetime,";
                        SelectData = SelectData + "severe_sepsis_present, severe_sepsis_present_datetime as severe_sepsis_presentation_datetime, vasopressor_administration,";
                        SelectData = SelectData + "vasopressor_administration_datetime as vasopressor_administration_start_datetime, vasopressor_administration_end_datetime, vasopressor_administration_transfer, altered_mental_status,";
                        SelectData = SelectData + "bandemia, lower_respiratory_infection, platelet_count, aids_hiv_disease, chronic_liver_disease, chronic_renal_failure, chronic_respiratory_failure, congestive_heart_failure, diabetes,";
                        SelectData = SelectData + "icu, icu_admission_datetime, icu_discharge_datetime, immune_modifying_medications, infection_etiology, lymphoma_leukemia_multiple_myeloma, mechanical_ventilation,";
                        SelectData = SelectData + "mechanical_ventilation_datetime as mechanical_ventilation_start_datetime, mechanical_ventilation_end_datetime, mechanical_ventilation_transfer, metastatic_cancer, organ_transplant, site_of_infection";
                        SelectData = SelectData + " from sepsis_collab where UniqueId in (" + _querystring + ")";

                        ds = new DataSet();


                        //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                        using (Conn = new OdbcConnection(ConnectionString))
                        {
                            if (DataSetfillflag == 1)
                            {
                                DataSetfillflag = 0;
                                ds.Tables["sepsis_collab"].Clear();
                                ds.Tables["CSV_MAPPING"].Clear();
                            }

                            Conn.Open();



                            //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                            using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("Select * from CSV_MAPPING where version = '" + _version + "' order by order_no", Conn))
                            {

                                dbDataAdapter.Fill(ds, "CSV_MAPPING");
                                //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                                dbDataAdapter.SelectCommand.CommandText = SelectData;
                                dbDataAdapter.Fill(ds, "sepsis_collab");

                            }


                            Conn.Close();
                        }

                        CurrentDate = DateTime.Now.ToString("yyyy-MM-dd");
                        Currenttime = DateTime.Now.ToString("HHmmss");


                        if (ds.Tables["sepsis_collab"].Rows.Count >= 1)
                        {
                            DataSetfillflag = 1;
                            FileName = "\\sdc_" + ds.Tables["sepsis_collab"].Rows[0]["facility_identifier"].ToString() + "_" + CurrentDate + "_" + Currenttime + ".csv";
                        }
                        else
                        {
                            MessageBox.Show("Nothing to Export.", "Export Message");
                        }



                        //TextWriter sw = new StreamWriter("C:\\All Sepsis\\New Sepsis\\Data.csv");
                        //TextWriter sw = new StreamWriter("G:\\All Sepsis\\New Sepsis\\Data.csv");

                        //TextWriter sw = new StreamWriter(Application.StartupPath + FileName);
                        sw = new StreamWriter(textBox_Path.Text.ToString().Trim() + FileName);

                        for (int i = 0; i <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; i++)
                        {

                            strHeader = "\"" + ds.Tables["CSV_MAPPING"].Rows[i]["Column"] + "\"";

                            if (i != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                            {
                                sw.Write("{0};", strHeader);
                            }
                            else
                            {
                                sw.WriteLine("{0}", strHeader);
                            }
                        }

                        string test;
                        for (int j = 0; j <= ds.Tables["sepsis_collab"].Rows.Count - 1; j++)
                        {

                            for (int k = 0; k <= ds.Tables["sepsis_collab"].Columns.Count - 1; k++)
                            {

                                for (int p = 0; p <= ds.Tables["CSV_MAPPING"].Rows.Count - 1; p++)
                                {



                                    if (ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim() == ds.Tables["sepsis_collab"].Columns[k].ToString().Trim())
                                    {
                                        test = ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString();

                                        CurrentDate = ds.Tables["CSV_MAPPING"].Rows[p]["Column"].ToString().Trim();

                                        count++;

                                        //Console.WriteLine(ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString());

                                        if (ds.Tables["sepsis_collab"].Columns[k].DataType.ToString() == "System.DateTime")
                                        {

                                            if (ds.Tables["sepsis_collab"].Rows[j][k].ToString() != "")
                                            {

                                                if (ds.Tables["sepsis_collab"].Columns[k].ColumnName.ToString() == "date_of_birth")
                                                {

                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd") + "\"";

                                                }
                                                else
                                                {
                                                    dDate = DateTime.Parse(ds.Tables["sepsis_collab"].Rows[j][k].ToString());
                                                    strData = "\"" + dDate.ToString("yyyy-MM-dd HH:mm") + "\"";
                                                }




                                            }
                                            else
                                            {
                                                strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                            }



                                        }
                                        else
                                        {
                                            strData = "\"" + ds.Tables["sepsis_collab"].Rows[j][k] + "\"";
                                        }







                                        if (k != ds.Tables["CSV_MAPPING"].Rows.Count - 1)
                                        {
                                            sw.Write("{0};", strData);

                                        }
                                        else
                                        {
                                            sw.WriteLine("{0}", strData);
                                        }

                                        break;
                                    }





                                }
                            }

                            count = 0;
                        }

                        sw.Close();
                        recordcompleteUniqueID.Clear();
                    }




                }

                String updatequery = "";
                
                if (_sampling == 1)
                {
                    updatequery = "update [Sepsis_collab] set sampling = 1, sampling_Date = '" + DateTime.Now + "' where UniqueId in (" + _querystring + ")";

                }
                else
                {
                    updatequery = "update [Sepsis_collab] set CSVGenerated = 1, CSVGenerated_Date = '" + DateTime.Now + "' where UniqueId in (" + _querystring + ")";
                }

                    using (OdbcConnection Conn = new OdbcConnection(ConnectionString))
                    {
                        Conn.Open();

                        //using (SqlCommand cmd = new SqlCommand("update [Sepsis_Collab] set CSVGenerated = 1, CSVGenerated_Date = '" + DateTime.Now + "' where UniqueId in (" + querystring + ")", Conn))
                        using (OdbcCommand cmd = new OdbcCommand())
                        {

                            cmd.Connection = Conn;
                            cmd.CommandText = updatequery;
                            cmd.ExecuteNonQuery();

                        }


                        Conn.Close();
                    }
                



                if (_sampling == 0)
                MessageBox.Show("Records marked as complete have been successfully uploaded to CSV.", "Export Details");
                else
                    MessageBox.Show("Sampling data have been successfully uploaded to CSV.", "Export Details");
                //MessageBox.Show("All Records have been successfully uploaded to CSV.", "Export Details");
                //sm.LoadGrid();
                this.Close();
                sm.Show();

            }
            catch (Exception ex)
            {
                int line = 0;

                StackTrace st = new StackTrace(true);
                for (int i = 0; i < st.FrameCount; i++)
                {

                    StackFrame sf = st.GetFrame(i);
                    var frame = sf.GetMethod();
                    line = sf.GetFileLineNumber();

                    if (line > 0)
                        break;

                }


                using (Conn = new OdbcConnection(ConnectionString))
                {
                    Conn.Open();

                    query = "{call Sepsis_ErrorLog(?,?,?,?)}";

                    //using (SqlCommand Sqlcmd = new SqlCommand())
                    using (OdbcCommand Sqlcmd = new OdbcCommand())
                    {

                        Sqlcmd.CommandText = query;
                        Sqlcmd.CommandType = CommandType.StoredProcedure;
                        Sqlcmd.Connection = Conn;

                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Line", line));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Desc", ex.Message));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Form", "SepsisCaseDetails.cs"));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Datetime", DateTime.Now));


                        Sqlcmd.ExecuteNonQuery();




                        Conn.Close();



                    }
                }

            }
            finally
            {
                if (sw != null)
                {
                    sw.Close();
                }
               
            }

       
        }

        private void button_FolderBrowser_Click(object sender, EventArgs e)
        {

            try
            {
            DialogResult result = folderBrowserDialog_Export.ShowDialog();
            if (result == DialogResult.OK)
            {
                textBox_Path.Text = folderBrowserDialog_Export.SelectedPath;
  
            }
                }
            catch (Exception ex)
            {

            }
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
            try
            {

           // sm.LoadGrid();
            this.Close();
            sm.Show();

                }
            catch (Exception ex)
            {

            }

        }

        private void ExportForm_Load(object sender, EventArgs e)
        {
            try
            {
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;
            textBox_Path.Focus();

            }
            catch (Exception ex)
            {

            }
        }

        private void ExportForm_HelpButtonClicked(object sender, CancelEventArgs e)
        {
            Help hp = new Help();
            hp.Show();
            e.Cancel = true;
        }

        private void ExportForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            sm.Show();
        }

     

        private void Label_ClickHere_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Help hp = new Help();
            hp.Show();
        }
    }
}
