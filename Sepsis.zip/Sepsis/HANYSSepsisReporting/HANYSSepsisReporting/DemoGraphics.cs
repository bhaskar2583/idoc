﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Configuration;
using System.Data.Odbc;

namespace HANYSSepsisReporting
{

    public partial class Demographics : Form
    {
        SepsisMaster sm;
        DataTable mappingGrdDt = new DataTable();
        DataTable excelDt = new DataTable();
        DataTable previewDT = new DataTable();
        string uploadFileName;


        OdbcConnection Conn;
        DataBaseConnection Db = new DataBaseConnection();
        OpenFileDialog file = new OpenFileDialog();
        string ConnectionString;

        //string connectionString = ConfigurationManager.ConnectionStrings["DbContext"].ConnectionString;
        string _facilityidentifier;
        string _version;
        public Demographics(SepsisMaster master, string facilityidentifier,string version)
        {
            InitializeComponent();
            sm = master;
            _facilityidentifier = facilityidentifier;
            _version = version;
            LoadDemoGraphicsDropdown(_version);
            CoumnsMappingTable();
            bindGrid();
            LoadDemoGraphicsMappingGrd(_facilityidentifier,_version);
        }

        private void DemoGraphics_FormClosing(object sender, FormClosingEventArgs e)
        {
            sm.Show();
        }

        private void btnSaveMapping_Click(object sender, EventArgs e)
        {
        }

        private void btnUploadCSVColumns_Click(object sender, EventArgs e)
        {
            string filePath = string.Empty;
            string fileExt = string.Empty;
            //open dialog to choose file  
            if (file.ShowDialog() == System.Windows.Forms.DialogResult.OK) //if there is a file choosen by the user  
            {
                filePath = file.FileName; //get the path of the file  
                fileExt = Path.GetExtension(filePath); //get the file extension  
                uploadFileName = Path.GetFileNameWithoutExtension(filePath);
                //if (fileExt.CompareTo(".xls") == 0 || fileExt.CompareTo(".xlsx") == 0)
                DataTable dtCsv = new DataTable();
                if (fileExt.CompareTo(".csv") == 0)
                {
                    try
                    {

                        dtCsv = ReadCSVFile(filePath, fileExt); //read csv file  
                        uploadCsvColumns.DataSource = dtCsv;
                        uploadCsvColumns.ValueMember = "csv Columns";
                        uploadCsvColumns.DisplayMember = "csv Columns";
                        //comboBox_Payor.SelectedIndex = 0;

                        excelDt = ReadCSVFileWithData(filePath, fileExt);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Plese make sure to close the file before uploading.");
                    }

                }
                else
                {
                    uploadCsvColumns.DataSource = dtCsv;
                    MessageBox.Show("Please choose .csv file only.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error); //custom messageBox to show error  
                }
            }
        }

        #region CSV

        static DataTable ReadCSVFile(string filePath, string fileName)
        {
            DataTable dt = new DataTable();
            try
            {
                DataRow dr = null;
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line = string.Empty;
                    int count = 0;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] split = ReplaceComma(line);
                        dt.Columns.Add("csv Columns");
                        dr = dt.NewRow();
                        if (count == 0)
                        {
                            foreach (var column in split)
                            {
                                dt.Rows.Add(column.ToString());
                            }
                        }
                        //count++;
                    }
                }

            }
            catch (Exception ex)
            {

            }
            return dt;
        }

        static DataTable ReadCSVFileWithData(string filePath, string fileName)
        {
            DataTable dt = new DataTable();
            try
            {
                DataRow dr = null;
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line = string.Empty;
                    int count = 0;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] split = ReplaceComma(line);
                        if (count == 0)
                        {
                            foreach (var column in split)
                            {
                                dt.Columns.Add(column.ToString());
                            }
                        }
                        else
                        {
                            dr = dt.NewRow();
                            for (int i = 0; i < split.Length; i++)
                            {
                                // dr[i] = split[i].ToString();
                                double d = 0;
                                if (split[i].Contains("E") && double.TryParse(split[i], out d))
                                {
                                    //Your conversion
                                    dr[i] = decimal.Parse(split[i], NumberStyles.Float);
                                }
                                else
                                {
                                    dr[i] = split[i].ToString();
                                }
                            }
                            dt.Rows.Add(dr);
                        }

                        count++;
                    }
                }

            }
            catch (Exception ex)
            {
            }
            return dt;
        }

        private static string[] ReplaceComma(string line)
        {
            string[] fields = null;
            try
            {
                Regex CSVParser = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");
                fields = CSVParser.Split(line);
            }
            catch (Exception ex)
            {

            }
            return fields;
        }

        #endregion

        private void LoadDemoGraphicsMappingGrd(string facilityidentifier,string version)
        {
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;

            //var query = "[dbo].[Sepsis_GetDemoGraphicsColumns]";
            OdbcConnection con = new OdbcConnection(ConnectionString);
            OdbcCommand cmd = new OdbcCommand("{call Sepsis_GetDemographicsMappingColumns(?,?)}", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FacilityIdentifier", facilityidentifier);
            cmd.Parameters.AddWithValue("@Version", version);

            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);


            mappingGrdDt = ds.Tables[0];
            dgColumnMapping.DataSource = mappingGrdDt;
        }

        private void btnAddMappingColumn_Click(object sender, EventArgs e)
        {

            if (ddlDemoGraphics.SelectedIndex == -1 || uploadCsvColumns.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select a .CSV File to Add Mapping.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                var sourceColumn = ddlDemoGraphics.Text;
                var targetColumn = uploadCsvColumns.Text;

                bool IsSourceColumnExist = mappingGrdDt.AsEnumerable().Any(row => sourceColumn == row.Field<string>("Source Column"));
                bool IsTargetColumnExist = mappingGrdDt.AsEnumerable().Any(row => targetColumn == row.Field<string>("Target Column"));

                if (!IsSourceColumnExist && !IsTargetColumnExist)
                {
                    DataRow NewRow = mappingGrdDt.NewRow();
                    NewRow[0] = 0;
                    NewRow[1] = ddlDemoGraphics.SelectedValue;
                    NewRow[2] = sourceColumn;
                    NewRow[3] = targetColumn;
                    mappingGrdDt.Rows.Add(NewRow);
                    SaveColumns(NewRow);
                    dgColumnMapping.DataSource = mappingGrdDt;
                }
                else
                {
                    MessageBox.Show("Please map a different column! This Mapping already Exist.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void SaveColumns(DataRow NewRow)
        {
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;
            using (OdbcConnection con = new OdbcConnection(ConnectionString))
            {
                con.Open();
                string insertpolquery = "INSERT INTO [dbo].[Demographic_Mapping]([SoureFile_Name],[Demographic_Source_Name],[Target_Column],[Facility_Identifier],[Version])VALUES('" + uploadFileName + "','" + NewRow[2] + "','" + NewRow[3] + "','" + _facilityidentifier + "','" + _version + "')";
                OdbcCommand insertpolcmd = new OdbcCommand(insertpolquery, con);
                insertpolcmd.CommandType = CommandType.Text;
                insertpolcmd.ExecuteNonQuery();
            }
        }

        private void bindGrid()
        {
            dgColumnMapping.DataSource = mappingGrdDt;
            dgColumnMapping.Columns[0].Width = 10;
            dgColumnMapping.Columns[2].Width = 400;
            dgColumnMapping.Columns[3].Width = 400;

            DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            dgColumnMapping.Columns.Add(btn);
            btn.HeaderText = "Delete";
            btn.Text = "Delete";
            btn.Name = "btnMappingGrdDeleteButton";
            btn.UseColumnTextForButtonValue = true;

            dgColumnMapping.Columns[0].Visible = false;
            dgColumnMapping.Columns[1].Visible = false;
        }

        private void dgColumnMapping_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == dgColumnMapping.NewRowIndex || e.RowIndex < 0)
                return;

            //Check if click is on specific column 
            if (e.ColumnIndex == dgColumnMapping.Columns["btnMappingGrdDeleteButton"].Index)
            {
                var deleteRowId = 0;
                deleteRowId = Convert.ToInt32(dgColumnMapping.Rows[e.RowIndex].Cells["MappingId"].Value);

                if(deleteRowId > 0)
                {
                    DeleteRowMappingTable(deleteRowId);
                }
                dgColumnMapping.Rows.RemoveAt(e.RowIndex);

                mappingGrdDt.AcceptChanges();


            }
        }

        private void LoadDemoGraphicsDropdown(string version)
        {
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;

            var query = "[dbo].[Sepsis_GetDemographicsColumns]";
            OdbcConnection con = new OdbcConnection(ConnectionString);
            OdbcCommand cmd = new OdbcCommand("{call Sepsis_GetDemographicsColumns(?)}", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Version", version);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);


            ddlDemoGraphics.DataSource = ds.Tables[0];
            ddlDemoGraphics.ValueMember = "SourceCode";
            ddlDemoGraphics.DisplayMember = "SourceColumn";

        }

        private DataTable CoumnsMappingTable()
        {
            if (mappingGrdDt.Columns.Count == 0)
            {
                mappingGrdDt.Columns.Add("MappingId", typeof(int));
                mappingGrdDt.Columns.Add("SourceCodeColumn", typeof(string));
                mappingGrdDt.Columns.Add("Source Column", typeof(string));
                mappingGrdDt.Columns.Add("Target Column", typeof(string));
            }

            return mappingGrdDt;
        }

        private void DeleteRowMappingTable(int MappingId)
        {
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;

            OdbcConnection con = new OdbcConnection(ConnectionString);
            con.Open();
            var deletMappingColumnQuery = "DELETE FROM [dbo].[Demographic_Mapping] where Demographic_Mapping_Id=  " + MappingId + "";
            OdbcCommand invalidcmd = new OdbcCommand(deletMappingColumnQuery, con);
            invalidcmd.CommandType = CommandType.Text;
            invalidcmd.ExecuteNonQuery();
            con.Close();
        }

        private void Label_ClickHere_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            WindowsFormsApplication1.Help hp = new WindowsFormsApplication1.Help();
            hp.Show();
        }

        private void btnPreviewDemoGraphics_Click(object sender, EventArgs e)
        {
            //var x = 1;
            //var y = x.ToString("D2");
            //var z = 22;
            //var p = z.ToString("D2");
            //var temp = 222;
            //var ts = temp.ToString("D2");
            if (ddlDemoGraphics.SelectedIndex == -1 || uploadCsvColumns.SelectedIndex == -1)
            {
                MessageBox.Show("Please Upload a .CSV File before moving to Preview tab.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            else
            {
                if (dgColumnMapping.Rows.Count > 0)
                {
                    var validationMsg = ValdiationPreview(mappingGrdDt);
                    if (string.IsNullOrEmpty(validationMsg))
                    {
                        List<string> selectedColumns = new List<string>();

                        foreach (DataRow row in mappingGrdDt.Rows)
                        {
                            selectedColumns.Add(row.Field<string>("Target Column"));
                        }

                        if (IsAllColumnExist(excelDt, selectedColumns))
                        {
                            var FinalPreviewDt = excelDt.DefaultView.ToTable(false, selectedColumns.ToArray());

                            var dataValidationMsg = DatatValidationPreview(mappingGrdDt, FinalPreviewDt);

                            if (string.IsNullOrEmpty(dataValidationMsg))
                            {
                                DemographicsPreview dgp = new DemographicsPreview(this, sm, mappingGrdDt, FinalPreviewDt, uploadFileName, _facilityidentifier, _version);
                                //this.Hide();
                                dgp.Show();
                            }
                            else
                            {
                                MessageBox.Show(dataValidationMsg);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Mapping columns are not matched in upload file.");
                        }
                    }
                    else
                    {
                        MessageBox.Show(validationMsg);
                    }
                }
                else
                {
                    MessageBox.Show("Atleast one column should be Mapped to proceed to Preview.");
                }
            }
        }

        private bool IsAllColumnExist(DataTable tableNameToCheck, List<string> columnsNames)
        {
            bool iscolumnExist = true;
            try
            {
                if (null != tableNameToCheck && tableNameToCheck.Columns != null)
                {
                    foreach (string columnName in columnsNames)
                    {
                        if (!tableNameToCheck.Columns.Contains(columnName))
                        {
                            iscolumnExist = false;
                            break;
                        }
                    }
                }
                else
                {
                    iscolumnExist = false;
                }
            }
            catch (Exception ex)
            {

            }
            return iscolumnExist;
        }

        private string ValdiationPreview(DataTable dt)
        {
            var errorMsg = string.Empty;

            bool IsDischargeDateTime = dt.Select().ToList().Exists(row => row["SourceCodeColumn"].ToString() == "discharge_datetime");
            bool IsDischargeTime = dt.Select().ToList().Exists(row => row["SourceCodeColumn"].ToString() == "DischargeTime");
            bool Ismedicalrecordnumber = dt.Select().ToList().Exists(row => row["SourceCodeColumn"].ToString() == "medical_record_number");
            bool IsAdmissionDateTime = dt.Select().ToList().Exists(row => row["SourceCodeColumn"].ToString() == "admission_datetime");
            bool IsAdmissionTime = dt.Select().ToList().Exists(row => row["SourceCodeColumn"].ToString() == "AdmissionTime");
            bool IsArrivalDateTime = dt.Select().ToList().Exists(row => row["SourceCodeColumn"].ToString() == "earliest_datetime");
            bool IsArrivalTime = dt.Select().ToList().Exists(row => row["SourceCodeColumn"].ToString() == "ArrivalTime");
            bool IsTriageDateTime = dt.Select().ToList().Exists(row => row["SourceCodeColumn"].ToString() == "triage_datetime");
            bool IsTriageTime = dt.Select().ToList().Exists(row => row["SourceCodeColumn"].ToString() == "TriageTime");
            bool IsTransferStatus = dt.Select().ToList().Exists(row => row["SourceCodeColumn"].ToString() == "transfer_status");
            bool IsTransferFacilityIdentifier = dt.Select().ToList().Exists(row => row["SourceCodeColumn"].ToString() == "transfer_facility_identifier");
            bool IsPayer = dt.Select().ToList().Exists(row => row["SourceCodeColumn"].ToString() == "payer");
            bool IsInsuranceNumber = dt.Select().ToList().Exists(row => row["SourceCodeColumn"].ToString() == "insurance_number");

            if (!IsDischargeDateTime && IsDischargeTime)
            {
                errorMsg = "Discharge DateTime is mandatory! ( Discharge Time Depends on Discharge Date/Time .";
            }
            if (!IsAdmissionDateTime && IsAdmissionTime)
            {
                errorMsg = "Admission DateTime is mandatory! ( Admission Time Depends on Admission Date/Time .)";
            }

            if (!IsTransferStatus && IsTransferFacilityIdentifier)
            {
                errorMsg = "Transfer Status is mandatory! ( Transfer Facility Identifier Depends on Transfer Status .)";
            }

            if (!IsPayer && IsInsuranceNumber)
            {
                errorMsg = "Payer is mandatory! ( Insurance Number Depends on Payer .)";
            }

            if (!IsArrivalDateTime && IsArrivalTime)
            {
                errorMsg = "Arrival DateTime is mandatory! ( Arrival Time Depends on Arrival DateTime .)";
            }

            if (!IsTriageDateTime && IsTriageTime)
            {
                errorMsg = "Triage DateTime is mandatory! ( Triage Time Depends on Triage DateTime .)";
            }

            if (!Ismedicalrecordnumber)
            {
                errorMsg = "Medical Record Number is Mandatory for Mapping.";
            }

            if(!IsDischargeDateTime)
            {
                errorMsg = "Discharge Datetime is Mandatory for Mapping.";
            }

            return errorMsg;
        }

        private string DatatValidationPreview(DataTable MappingGrid, DataTable ExcelGrid)
        {
            var errorMsg = string.Empty;
            previewDT = new DataTable();

            foreach (DataRow sepHeader in MappingGrid.Rows)
            {
                previewDT.Columns.Add(sepHeader["SourceCodeColumn"].ToString(), typeof(string));
            }

            foreach (DataRow sepData in ExcelGrid.Rows)
            {
                previewDT.Rows.Add(sepData.ItemArray);
            }

            foreach (DataRow row in previewDT.Rows)
            {
                //if (previewDT.Columns.Contains("payer") && !previewDT.Columns.Contains("insurance_number"))
                //{
                //    var insuranceValue = string.Empty;
                //    var payerValue = Convert.ToString(row["payer"]);
                //    if (previewDT.Columns.Contains("insurance_number"))
                //    {
                //         insuranceValue = Convert.ToString(row["insurance_number"]);
                //    }
                //    if ((payerValue.ToString() == "C" || payerValue.ToString() == "D"
                //        || payerValue.ToString() == "F" || payerValue.ToString() == "G")
                //        && string.IsNullOrWhiteSpace(insuranceValue))
                //    {
                //        errorMsg = "If payer is 'Medicare,Medical,Insurance Company& Blue cross' then 'Insurance Number Mandatory'";
                //    }
                //}
         
                //if (previewDT.Columns.Contains("transfer_status") && !previewDT.Columns.Contains("transfer_facility_identifier"))
                //{
                //    var transerfaciValue = string.Empty;
                //    var transferValue = Convert.ToString(row["transfer_status"]);
                //    if (previewDT.Columns.Contains("transfer_facility_identifier"))
                //    {
                //        transerfaciValue = Convert.ToString(row["transfer_facility_identifier"]);
                //    }
                //    if ((transferValue.ToString() == "3" || transferValue.ToString() == "4"
                //        || transferValue.ToString() == "5")
                //        && string.IsNullOrWhiteSpace(transerfaciValue))
                //    {
                //        errorMsg = "If Transfer status is selected then 'Tranfer Faclity Idenfier Mandatory'";
                //    }
                //}
                
                //if (previewDT.Columns.Contains("date_of_birth"))
                //{
                //    var dob = Convert.ToString(row["date_of_birth"]);
                //    DateTime Test;
                //    if (DateTime.TryParseExact(dob, "MM/dd/yyyy", null, DateTimeStyles.None, out Test) == false)
                //    {
                //        return errorMsg = "Date of Birth should be in format MM/DD/YYYY";
                //    }
                // }

                //if (previewDT.Columns.Contains("admission_datetime"))
                //{
                //    var admindt = Convert.ToString(row["admission_datetime"]);
                //    DateTime Test;
                //    if (DateTime.TryParseExact(admindt, "MM/dd/yyyy", null, DateTimeStyles.None, out Test) == false)
                //    {
                //        return errorMsg = "Admission Date should be in format MM/DD/YYYY";
                //    }
                //}

                //if (previewDT.Columns.Contains("discharge_datetime"))
                //{
                //    var Dischargedt = Convert.ToString(row["discharge_datetime"]);
                //    DateTime Test;
                //    if (DateTime.TryParseExact(Dischargedt, "MM/dd/yyyy", null, DateTimeStyles.None, out Test) == false)
                //    {
                //        return errorMsg = "Discharge Date should be in format MM/DD/YYYY";
                //    }
                //}

                //if (previewDT.Columns.Contains("excluded_datetime"))
                //{
                //    var excludededt = Convert.ToString(row["excluded_datetime"]);
                //    DateTime Test;
                //    if (DateTime.TryParseExact(excludededt, "MM/dd/yyyy", null, DateTimeStyles.None, out Test) == false)
                //    {
                //        return errorMsg = "Excluded Date should be in format MM/DD/YYYY";
                //    }
                //}

                //if (previewDT.Columns.Contains("date_of_birth"))
                //{
                //    var dob = Convert.ToString(row["date_of_birth"]);
                //    DateTime dt = DateTime.ParseExact(dob, "MM/DD/YYYY", CultureInfo.InvariantCulture);
                //    if (dt > DateTime.Today)
                //    {
                //        return errorMsg = "Date of Birth should not be future date";
                //    }
                //}

            }

            return errorMsg;
        }

        private void dgColumnMapping_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }

    internal class DataControlRowType
    {
        public static object DataRow { get; internal set; }
    }
}
