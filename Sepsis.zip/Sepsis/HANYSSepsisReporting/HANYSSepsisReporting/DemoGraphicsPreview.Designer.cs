﻿namespace HANYSSepsisReporting
{
    partial class DemographicsPreview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DemographicsPreview));
            this.dgPreview = new System.Windows.Forms.DataGridView();
            this.Label_Contact = new System.Windows.Forms.Label();
            this.Label_ClickHere = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.dgprevMapping = new System.Windows.Forms.DataGridView();
            this.btnSaveMapping = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgPreview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgprevMapping)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgPreview
            // 
            this.dgPreview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPreview.Location = new System.Drawing.Point(33, 235);
            this.dgPreview.Name = "dgPreview";
            this.dgPreview.Size = new System.Drawing.Size(1088, 333);
            this.dgPreview.TabIndex = 0;
            this.dgPreview.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgPrievew_CellFormatting);
            // 
            // Label_Contact
            // 
            this.Label_Contact.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Contact.AutoSize = true;
            this.Label_Contact.Location = new System.Drawing.Point(937, 656);
            this.Label_Contact.Name = "Label_Contact";
            this.Label_Contact.Size = new System.Drawing.Size(122, 13);
            this.Label_Contact.TabIndex = 508;
            this.Label_Contact.Text = "Contact Sepsis support:-";
            // 
            // Label_ClickHere
            // 
            this.Label_ClickHere.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_ClickHere.AutoSize = true;
            this.Label_ClickHere.Location = new System.Drawing.Point(1065, 656);
            this.Label_ClickHere.Name = "Label_ClickHere";
            this.Label_ClickHere.Size = new System.Drawing.Size(56, 13);
            this.Label_ClickHere.TabIndex = 509;
            this.Label_ClickHere.TabStop = true;
            this.Label_ClickHere.Text = "Click Here";
            this.Label_ClickHere.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Label_ClickHere_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(490, 656);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 13);
            this.label1.TabIndex = 510;
            this.label1.Text = "© HANYS 2020.";
            // 
            // dgprevMapping
            // 
            this.dgprevMapping.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgprevMapping.Location = new System.Drawing.Point(33, 12);
            this.dgprevMapping.Name = "dgprevMapping";
            this.dgprevMapping.Size = new System.Drawing.Size(1088, 205);
            this.dgprevMapping.TabIndex = 511;
            // 
            // btnSaveMapping
            // 
            this.btnSaveMapping.Location = new System.Drawing.Point(982, 591);
            this.btnSaveMapping.Name = "btnSaveMapping";
            this.btnSaveMapping.Size = new System.Drawing.Size(139, 39);
            this.btnSaveMapping.TabIndex = 519;
            this.btnSaveMapping.Text = "Save";
            this.btnSaveMapping.UseVisualStyleBackColor = true;
            this.btnSaveMapping.Click += new System.EventHandler(this.btnSaveMapping_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 577);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(274, 13);
            this.label2.TabIndex = 520;
            this.label2.Text = "Note: Please check data in orange color cells are Invalid";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(33, 623);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(160, 43);
            this.pictureBox1.TabIndex = 521;
            this.pictureBox1.TabStop = false;
            // 
            // DemographicsPreview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1144, 678);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnSaveMapping);
            this.Controls.Add(this.dgprevMapping);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Label_ClickHere);
            this.Controls.Add(this.Label_Contact);
            this.Controls.Add(this.dgPreview);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DemographicsPreview";
            this.Text = "DemographicsPreview";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DemoGraphicsPreview_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dgPreview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgprevMapping)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgPreview;
        private System.Windows.Forms.Label Label_Contact;
        private System.Windows.Forms.LinkLabel Label_ClickHere;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgprevMapping;
        private System.Windows.Forms.Button btnSaveMapping;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}