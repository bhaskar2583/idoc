﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    class ComboBoxValues
    {

 
          public List<KeyValuePair<string, string>> Gender = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> Payor = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> Race = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> Ethnicity = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> SourceOfAdmission = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> DischargeStatus = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> TransferStatus = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> ProtocolInitiated = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> ProtocolNotInitiatedReason = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> ProtocolInitiatedPlace = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> ProtocolType = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> ExcludedFromProtocol = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> ExcludedReason = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> ExcludedExplain = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> SevereSepsisPresent = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> SepticShockPresent = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> DestinationAfterED = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> InitialLactactLevelCollection = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> InitialLactactLevelUnit = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> RepeatLactactLevelCollection = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> BloodCultureCollection = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> BloodCultureCollectionAcceptableDelay = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> BloodCultureResult = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> BloodCulturePathogen = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> AntibioticAdministration = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> AntibioticAdministrationSelection = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> AdultCrystallionAdultCrystalloidFluidAdministration = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> PediatricCrystalloidFluidAdministration = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> InitialHypotension = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> PersistentHypotension = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> VasopressorAdministration = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> BesideCardiovascularUltrasound = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> CapillaryRefillExamination = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> CardiopulmonaryEvaluation = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> PassiveLegRaiseExamination = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> PeripheralPulseEvaluation = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> SkinExamination = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> CentralVenousOxygenMeasurement = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> CentralVenousPressureMeasurement = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> FluidChallengePerformed = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> VitalSignsReview = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> PlateletCount = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> Bandemia = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> LoweRespiratoryInfection = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> AlteredMentalStatus = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> InfectionEtiology = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> SiteofInfection = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> MechanicalVentilation = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> ICU = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> ChronicRespiratoryFailure = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> AIDS = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> MetastaticCancer = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> Lymphoma = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> ImmuneModifyingMedications = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> CongestiveHeartFailure = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> ChronicRenalFailure = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> ChronicLiverDisease = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> Diabetes = new List<KeyValuePair<string, string>>();
         public List<KeyValuePair<string, string>> OrganTransplant = new List<KeyValuePair<string, string>>();
     
  



  
  
 

//employmentStatus.Add(new KeyValuePair<string, string>("0", "[Select Status]"));
//employmentStatus.Add(new KeyValuePair<string, string>("1", "Contract"));
//employmentStatus.Add(new KeyValuePair<string, string>("2", "Part Time"));
//employmentStatus.Add(new KeyValuePair<string, string>("3", "Permanent"));
//employmentStatus.Add(new KeyValuePair<string, string>("4", "Probation"));

//employmentStatus.Add(new KeyValuePair<string, string>("5", "Other"));
//cmbEmployeeStatus.DataSource = employmentStatus;
//cmbEmployeeStatus.ValueMember = "Key";
//cmbEmployeeStatus.DisplayMember = "Value";
//cmbEmployeeStatus.SelectedIndex = 0;
    }
}
