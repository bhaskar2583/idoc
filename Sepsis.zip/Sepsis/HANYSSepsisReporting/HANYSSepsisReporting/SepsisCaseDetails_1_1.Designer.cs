﻿namespace WindowsFormsApplication1
{
    partial class SepsisCaseDetails_1_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SepsisCaseDetails_1_1));
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.comboBox_TransferStatus = new WindowsFormsApplication1.ComboBox();
            this.comboBox_DischargeStatus = new WindowsFormsApplication1.ComboBox();
            this.comboBox_SourceofAdmission = new WindowsFormsApplication1.ComboBox();
            this.lbl_SepsisIdentificationPlace = new System.Windows.Forms.Label();
            this.Combobox_SepsisIdentificationPlace = new System.Windows.Forms.ComboBox();
            this.label_SepsisIdentificationPlace = new System.Windows.Forms.Label();
            this.lbl_ExcludedExplain = new System.Windows.Forms.Label();
            this.lbl_ExcludedDatetime = new System.Windows.Forms.Label();
            this.textBox_ExcludedDatetime = new System.Windows.Forms.MaskedTextBox();
            this.checkedListBox_ExcludedExplain = new System.Windows.Forms.CheckedListBox();
            this.Label_ExcludedDatetime = new System.Windows.Forms.Label();
            this.Label_ExcludedExplain = new System.Windows.Forms.Label();
            this.lbl_ExcludedReason = new System.Windows.Forms.Label();
            this.checkedListBox_ExcludedReason = new System.Windows.Forms.CheckedListBox();
            this.Label_ExcludedReason = new System.Windows.Forms.Label();
            this.lbl_ExcludedFromProtocol = new System.Windows.Forms.Label();
            this.comboBox_ExcludedFromProtocol = new System.Windows.Forms.ComboBox();
            this.Label_ExcludedFromProtocol = new System.Windows.Forms.Label();
            this.lbl_TransferFacilityIdentifier = new System.Windows.Forms.Label();
            this.lbl_TransferStatus = new System.Windows.Forms.Label();
            this.lbl_DischargedStatus = new System.Windows.Forms.Label();
            this.lbl_SourceofAdmission = new System.Windows.Forms.Label();
            this.lbl_DischargeDatetime = new System.Windows.Forms.Label();
            this.lbl_AdmissionDateTime = new System.Windows.Forms.Label();
            this.lbl_FacilityIdentifier = new System.Windows.Forms.Label();
            this.lbl_MRN = new System.Windows.Forms.Label();
            this.lbl_InsuranceNumber = new System.Windows.Forms.Label();
            this.lbl_Payor = new System.Windows.Forms.Label();
            this.lbl_Ethnicity = new System.Windows.Forms.Label();
            this.lbl_Race = new System.Windows.Forms.Label();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.lbl_DOB = new System.Windows.Forms.Label();
            this.lbl_PatientCtrlNum = new System.Windows.Forms.Label();
            this.lbl_txID = new System.Windows.Forms.Label();
            this.textBox_TransferFacilityIdentifier = new System.Windows.Forms.MaskedTextBox();
            this.TextBox_FacilityIdentifier = new System.Windows.Forms.MaskedTextBox();
            this.TextBox_InsuranceNumber = new System.Windows.Forms.MaskedTextBox();
            this.TextBox_PatientCtrlNum = new System.Windows.Forms.MaskedTextBox();
            this.txtId = new System.Windows.Forms.MaskedTextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.txtMRN = new System.Windows.Forms.MaskedTextBox();
            this.textBox_DischargedDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_AdmissionDateTime = new System.Windows.Forms.MaskedTextBox();
            this.txtDOB = new System.Windows.Forms.MaskedTextBox();
            this.Label_AdmissionDatetime = new System.Windows.Forms.Label();
            this.Label_SourceofAdmission = new System.Windows.Forms.Label();
            this.Label_DischargeDatetime = new System.Windows.Forms.Label();
            this.Label_DischargedStatus = new System.Windows.Forms.Label();
            this.Label_Transfer = new System.Windows.Forms.Label();
            this.checkedListBox_Race = new System.Windows.Forms.CheckedListBox();
            this.comboBox_Payor = new System.Windows.Forms.ComboBox();
            this.Combobox_Ethnicity = new System.Windows.Forms.ComboBox();
            this.Combobox_Gender = new System.Windows.Forms.ComboBox();
            this.Label_PatientCtrlNum = new System.Windows.Forms.Label();
            this.Label_Ethnicity = new System.Windows.Forms.Label();
            this.Label_InsuranceNumber = new System.Windows.Forms.Label();
            this.Label_Race = new System.Windows.Forms.Label();
            this.Label_Payor = new System.Windows.Forms.Label();
            this.Label_Gender = new System.Windows.Forms.Label();
            this.Label_FacilityIdentifier = new System.Windows.Forms.Label();
            this.Label_MRN = new System.Windows.Forms.Label();
            this.Label_DateofBirth = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.comboBox_VasopressorTransfer = new WindowsFormsApplication1.ComboBox();
            this.lbl_VasopressorTransfer = new System.Windows.Forms.Label();
            this.label_VasopressorTransfer = new System.Windows.Forms.Label();
            this.lbl_VasopressorAdministrationEndDateTime = new System.Windows.Forms.Label();
            this.textBox_VasopressorAdministrationEndDatetime = new System.Windows.Forms.MaskedTextBox();
            this.label_VasopressorAdministrationEndDateTime = new System.Windows.Forms.Label();
            this.lbl_InitialLactateLevelCollection = new System.Windows.Forms.Label();
            this.textBox_InitialLactateLevel = new System.Windows.Forms.TextBox();
            this.lbl_SepticShockPresentationDatetime = new System.Windows.Forms.Label();
            this.lbl_InitialLactateLevel = new System.Windows.Forms.Label();
            this.lbl_AntibioticAdministration = new System.Windows.Forms.Label();
            this.lbl_VasopressorAdministrationStartDateTime = new System.Windows.Forms.Label();
            this.lbl_VasopressorAdministration = new System.Windows.Forms.Label();
            this.lbl_CrystalloidFluidAdministrationDatetime = new System.Windows.Forms.Label();
            this.lbl_CrystalloidFluidAdministration = new System.Windows.Forms.Label();
            this.lbl_AntibioticAdministrationDatetime = new System.Windows.Forms.Label();
            this.lbl_ElevatedLactateReason = new System.Windows.Forms.Label();
            this.lbl_BloodCultureCollectionDatetime = new System.Windows.Forms.Label();
            this.lbl_BloodCultureCollectionAcceptableDelay = new System.Windows.Forms.Label();
            this.lbl_BloodCultureCollection = new System.Windows.Forms.Label();
            this.lbl_InitialLactateLevelCollectionDatetime = new System.Windows.Forms.Label();
            this.lbl_SepticShockPresent = new System.Windows.Forms.Label();
            this.lbl_SevereSepsisPresentationDatetime = new System.Windows.Forms.Label();
            this.lbl_SevereSepsisPresent = new System.Windows.Forms.Label();
            this.lbl_EarliestDatetime = new System.Windows.Forms.Label();
            this.textBox_AntibioticAdministrationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_BloodCultureCollectionDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_VasopressorAdministrationStartDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_CrystalloidFluidAdministrationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_InitialLactateLevelCollectionDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_septicShockPresentationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_SevereSepsisPresentationDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textbox_TriageDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_ArrivalDatetime = new System.Windows.Forms.MaskedTextBox();
            this.comboBox_VasopressorAdministration = new System.Windows.Forms.ComboBox();
            this.comboBox_BloodCultureCollection = new System.Windows.Forms.ComboBox();
            this.comboBox_BloodCultureCollectionAcceptableDelay = new System.Windows.Forms.ComboBox();
            this.comboBox_ElevatedLactateReason = new System.Windows.Forms.ComboBox();
            this.comboBox_AntibioticAdministration = new System.Windows.Forms.ComboBox();
            this.comboBox_SepticShockPresent = new System.Windows.Forms.ComboBox();
            this.comboBox_InitialLactateLevelCollection = new System.Windows.Forms.ComboBox();
            this.comboBox_SevereSepsisPresent = new System.Windows.Forms.ComboBox();
            this.label_VasopressorAdministration = new System.Windows.Forms.Label();
            this.label_VasopressorAdministrationStartDateTime = new System.Windows.Forms.Label();
            this.Label_CrystalloidFluidAdministrationDatetime = new System.Windows.Forms.Label();
            this.Label_CrystalloidFluidAdministration = new System.Windows.Forms.Label();
            this.Label_AntibioticAdministrationDatetime = new System.Windows.Forms.Label();
            this.Label_ElevatedLactateReason = new System.Windows.Forms.Label();
            this.Label_BloodCultureCollection = new System.Windows.Forms.Label();
            this.Label_InitialLactateLevel = new System.Windows.Forms.Label();
            this.Label_SevereSepsisPresent = new System.Windows.Forms.Label();
            this.Label_BloodCultureCollectionAcceptableDelay = new System.Windows.Forms.Label();
            this.Label_SevereSepsisPresentationDatetime = new System.Windows.Forms.Label();
            this.Label_AntibioticAdministration = new System.Windows.Forms.Label();
            this.Label_InitialLactateLevelCollectionDatetime = new System.Windows.Forms.Label();
            this.Label_SepticShockPresentationDatetime = new System.Windows.Forms.Label();
            this.Label_BloodCultureCollectionDatetime = new System.Windows.Forms.Label();
            this.Label_SepticShockPresent = new System.Windows.Forms.Label();
            this.Label_InitialLactateLevelCollection = new System.Windows.Forms.Label();
            this.Label_TriageDatetime = new System.Windows.Forms.Label();
            this.Label_ArrivalDatetime = new System.Windows.Forms.Label();
            this.comboBox_CrystalloidFluidAdministration = new WindowsFormsApplication1.ComboBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.comboBox_MechanicalVentilationTransfer = new WindowsFormsApplication1.ComboBox();
            this.lbl_MechanicalVentaltionTransfer = new System.Windows.Forms.Label();
            this.label_MechanicalVentaltionTransfer = new System.Windows.Forms.Label();
            this.lbl_MechanicalVentilationEndDateTime = new System.Windows.Forms.Label();
            this.textBox_MechanicalVentilationEndDatetime = new System.Windows.Forms.MaskedTextBox();
            this.label_MechanicalVentilationEndDateTime = new System.Windows.Forms.Label();
            this.lbl_ICUDischargeDatetime = new System.Windows.Forms.Label();
            this.lbl_ICUAdmissionDatetime = new System.Windows.Forms.Label();
            this.lbl_MechanicalVentilationStartDatetime = new System.Windows.Forms.Label();
            this.lbl_Diabetes = new System.Windows.Forms.Label();
            this.lbl_ChronicRenalFailure = new System.Windows.Forms.Label();
            this.lbl_OrganTransplant = new System.Windows.Forms.Label();
            this.lbl_ChronicLiverDisease = new System.Windows.Forms.Label();
            this.lbl_CongestiveHeartFailure = new System.Windows.Forms.Label();
            this.lbl_ImmuneModifyingMedications = new System.Windows.Forms.Label();
            this.lbl_Lymphoma = new System.Windows.Forms.Label();
            this.lbl_MetastaticCancer = new System.Windows.Forms.Label();
            this.lbl_AIDSDisease = new System.Windows.Forms.Label();
            this.lbl_ChronicRespiratoryFailure = new System.Windows.Forms.Label();
            this.lbl_ICU = new System.Windows.Forms.Label();
            this.lbl_MechanicalVentilation = new System.Windows.Forms.Label();
            this.lbl_SiteofInfection = new System.Windows.Forms.Label();
            this.lbl_LowerRespiratoryInfection = new System.Windows.Forms.Label();
            this.lbl_InfectionEtiology = new System.Windows.Forms.Label();
            this.lbl_Bandemia = new System.Windows.Forms.Label();
            this.lbl_AlteredMentalStatus = new System.Windows.Forms.Label();
            this.lbl_PlateletCount = new System.Windows.Forms.Label();
            this.textBox_ICUDischargeDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_ICUAdmissionDatetime = new System.Windows.Forms.MaskedTextBox();
            this.textBox_MechanicalVentilationStartDatetime = new System.Windows.Forms.MaskedTextBox();
            this.comboBox_ICU = new System.Windows.Forms.ComboBox();
            this.comboBox_AIDSDisease = new System.Windows.Forms.ComboBox();
            this.comboBox_ChronicRespiratoryFailure = new System.Windows.Forms.ComboBox();
            this.comboBox_MechanicalVentilation = new System.Windows.Forms.ComboBox();
            this.comboBox_InfectionEtiology = new System.Windows.Forms.ComboBox();
            this.comboBox_SiteofInfection = new System.Windows.Forms.ComboBox();
            this.comboBox_Lymphoma = new System.Windows.Forms.ComboBox();
            this.comboBox_AlteredMentalStatus = new System.Windows.Forms.ComboBox();
            this.comboBox_Diabetes = new System.Windows.Forms.ComboBox();
            this.comboBox_ChronicLiverDisease = new System.Windows.Forms.ComboBox();
            this.comboBox_OrganTransplant = new System.Windows.Forms.ComboBox();
            this.comboBox_ImmuneModifyingMedications = new System.Windows.Forms.ComboBox();
            this.comboBox_ChronicRenalFailure = new System.Windows.Forms.ComboBox();
            this.comboBox_CongestiveHeartFailure = new System.Windows.Forms.ComboBox();
            this.comboBox_PlateletCount = new System.Windows.Forms.ComboBox();
            this.comboBox_Bandemia = new System.Windows.Forms.ComboBox();
            this.comboBox_LowerRespiratoryInfection = new System.Windows.Forms.ComboBox();
            this.comboBox_MetastaticCancer = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label_MechanicalVentilationStartDateTime = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.button_SaveCase = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.lbl_nt = new System.Windows.Forms.Label();
            this.label_Copyright = new System.Windows.Forms.Label();
            this.Label_Contact = new System.Windows.Forms.Label();
            this.Label_ClickHere = new System.Windows.Forms.LinkLabel();
            this.button_Validate = new System.Windows.Forms.Button();
            this.label_Name = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Controls.Add(this.tabPage4);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1241, 577);
            this.tabControl.TabIndex = 300;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.comboBox_TransferStatus);
            this.tabPage1.Controls.Add(this.comboBox_DischargeStatus);
            this.tabPage1.Controls.Add(this.comboBox_SourceofAdmission);
            this.tabPage1.Controls.Add(this.lbl_SepsisIdentificationPlace);
            this.tabPage1.Controls.Add(this.Combobox_SepsisIdentificationPlace);
            this.tabPage1.Controls.Add(this.label_SepsisIdentificationPlace);
            this.tabPage1.Controls.Add(this.lbl_ExcludedExplain);
            this.tabPage1.Controls.Add(this.lbl_ExcludedDatetime);
            this.tabPage1.Controls.Add(this.textBox_ExcludedDatetime);
            this.tabPage1.Controls.Add(this.checkedListBox_ExcludedExplain);
            this.tabPage1.Controls.Add(this.Label_ExcludedDatetime);
            this.tabPage1.Controls.Add(this.Label_ExcludedExplain);
            this.tabPage1.Controls.Add(this.lbl_ExcludedReason);
            this.tabPage1.Controls.Add(this.checkedListBox_ExcludedReason);
            this.tabPage1.Controls.Add(this.Label_ExcludedReason);
            this.tabPage1.Controls.Add(this.lbl_ExcludedFromProtocol);
            this.tabPage1.Controls.Add(this.comboBox_ExcludedFromProtocol);
            this.tabPage1.Controls.Add(this.Label_ExcludedFromProtocol);
            this.tabPage1.Controls.Add(this.lbl_TransferFacilityIdentifier);
            this.tabPage1.Controls.Add(this.lbl_TransferStatus);
            this.tabPage1.Controls.Add(this.lbl_DischargedStatus);
            this.tabPage1.Controls.Add(this.lbl_SourceofAdmission);
            this.tabPage1.Controls.Add(this.lbl_DischargeDatetime);
            this.tabPage1.Controls.Add(this.lbl_AdmissionDateTime);
            this.tabPage1.Controls.Add(this.lbl_FacilityIdentifier);
            this.tabPage1.Controls.Add(this.lbl_MRN);
            this.tabPage1.Controls.Add(this.lbl_InsuranceNumber);
            this.tabPage1.Controls.Add(this.lbl_Payor);
            this.tabPage1.Controls.Add(this.lbl_Ethnicity);
            this.tabPage1.Controls.Add(this.lbl_Race);
            this.tabPage1.Controls.Add(this.lbl_Gender);
            this.tabPage1.Controls.Add(this.lbl_DOB);
            this.tabPage1.Controls.Add(this.lbl_PatientCtrlNum);
            this.tabPage1.Controls.Add(this.lbl_txID);
            this.tabPage1.Controls.Add(this.textBox_TransferFacilityIdentifier);
            this.tabPage1.Controls.Add(this.TextBox_FacilityIdentifier);
            this.tabPage1.Controls.Add(this.TextBox_InsuranceNumber);
            this.tabPage1.Controls.Add(this.TextBox_PatientCtrlNum);
            this.tabPage1.Controls.Add(this.txtId);
            this.tabPage1.Controls.Add(this.label38);
            this.tabPage1.Controls.Add(this.label32);
            this.tabPage1.Controls.Add(this.txtMRN);
            this.tabPage1.Controls.Add(this.textBox_DischargedDatetime);
            this.tabPage1.Controls.Add(this.textBox_AdmissionDateTime);
            this.tabPage1.Controls.Add(this.txtDOB);
            this.tabPage1.Controls.Add(this.Label_AdmissionDatetime);
            this.tabPage1.Controls.Add(this.Label_SourceofAdmission);
            this.tabPage1.Controls.Add(this.Label_DischargeDatetime);
            this.tabPage1.Controls.Add(this.Label_DischargedStatus);
            this.tabPage1.Controls.Add(this.Label_Transfer);
            this.tabPage1.Controls.Add(this.checkedListBox_Race);
            this.tabPage1.Controls.Add(this.comboBox_Payor);
            this.tabPage1.Controls.Add(this.Combobox_Ethnicity);
            this.tabPage1.Controls.Add(this.Combobox_Gender);
            this.tabPage1.Controls.Add(this.Label_PatientCtrlNum);
            this.tabPage1.Controls.Add(this.Label_Ethnicity);
            this.tabPage1.Controls.Add(this.Label_InsuranceNumber);
            this.tabPage1.Controls.Add(this.Label_Race);
            this.tabPage1.Controls.Add(this.Label_Payor);
            this.tabPage1.Controls.Add(this.Label_Gender);
            this.tabPage1.Controls.Add(this.Label_FacilityIdentifier);
            this.tabPage1.Controls.Add(this.Label_MRN);
            this.tabPage1.Controls.Add(this.Label_DateofBirth);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1233, 551);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Demographics";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // comboBox_TransferStatus
            // 
            this.comboBox_TransferStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_TransferStatus.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_TransferStatus.FormattingEnabled = true;
            this.comboBox_TransferStatus.Location = new System.Drawing.Point(25, 268);
            this.comboBox_TransferStatus.Name = "comboBox_TransferStatus";
            this.comboBox_TransferStatus.Size = new System.Drawing.Size(1196, 21);
            this.comboBox_TransferStatus.TabIndex = 14;
            this.comboBox_TransferStatus.SelectedIndexChanged += new System.EventHandler(this.comboBox_TransferStatus_SelectedIndexChanged);
            // 
            // comboBox_DischargeStatus
            // 
            this.comboBox_DischargeStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_DischargeStatus.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_DischargeStatus.FormattingEnabled = true;
            this.comboBox_DischargeStatus.Location = new System.Drawing.Point(25, 226);
            this.comboBox_DischargeStatus.Name = "comboBox_DischargeStatus";
            this.comboBox_DischargeStatus.Size = new System.Drawing.Size(1196, 21);
            this.comboBox_DischargeStatus.TabIndex = 13;
            // 
            // comboBox_SourceofAdmission
            // 
            this.comboBox_SourceofAdmission.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_SourceofAdmission.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_SourceofAdmission.FormattingEnabled = true;
            this.comboBox_SourceofAdmission.Location = new System.Drawing.Point(25, 180);
            this.comboBox_SourceofAdmission.Name = "comboBox_SourceofAdmission";
            this.comboBox_SourceofAdmission.Size = new System.Drawing.Size(1196, 21);
            this.comboBox_SourceofAdmission.TabIndex = 12;
            // 
            // lbl_SepsisIdentificationPlace
            // 
            this.lbl_SepsisIdentificationPlace.AutoSize = true;
            this.lbl_SepsisIdentificationPlace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SepsisIdentificationPlace.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SepsisIdentificationPlace.ForeColor = System.Drawing.Color.Black;
            this.lbl_SepsisIdentificationPlace.Location = new System.Drawing.Point(151, 314);
            this.lbl_SepsisIdentificationPlace.Name = "lbl_SepsisIdentificationPlace";
            this.lbl_SepsisIdentificationPlace.Size = new System.Drawing.Size(14, 16);
            this.lbl_SepsisIdentificationPlace.TabIndex = 78;
            this.lbl_SepsisIdentificationPlace.Text = "*";
            // 
            // Combobox_SepsisIdentificationPlace
            // 
            this.Combobox_SepsisIdentificationPlace.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Combobox_SepsisIdentificationPlace.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Combobox_SepsisIdentificationPlace.FormattingEnabled = true;
            this.Combobox_SepsisIdentificationPlace.Items.AddRange(new object[] {
            "Select",
            "Patient was not excluded from the protocol",
            "Patient was excluded from the protocol"});
            this.Combobox_SepsisIdentificationPlace.Location = new System.Drawing.Point(166, 314);
            this.Combobox_SepsisIdentificationPlace.Name = "Combobox_SepsisIdentificationPlace";
            this.Combobox_SepsisIdentificationPlace.Size = new System.Drawing.Size(630, 21);
            this.Combobox_SepsisIdentificationPlace.TabIndex = 16;
            // 
            // label_SepsisIdentificationPlace
            // 
            this.label_SepsisIdentificationPlace.AutoSize = true;
            this.label_SepsisIdentificationPlace.Location = new System.Drawing.Point(163, 298);
            this.label_SepsisIdentificationPlace.Name = "label_SepsisIdentificationPlace";
            this.label_SepsisIdentificationPlace.Size = new System.Drawing.Size(134, 13);
            this.label_SepsisIdentificationPlace.TabIndex = 77;
            this.label_SepsisIdentificationPlace.Text = "Sepsis Identification Place:";
            // 
            // lbl_ExcludedExplain
            // 
            this.lbl_ExcludedExplain.AutoSize = true;
            this.lbl_ExcludedExplain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ExcludedExplain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ExcludedExplain.ForeColor = System.Drawing.Color.Black;
            this.lbl_ExcludedExplain.Location = new System.Drawing.Point(284, 450);
            this.lbl_ExcludedExplain.Name = "lbl_ExcludedExplain";
            this.lbl_ExcludedExplain.Size = new System.Drawing.Size(14, 16);
            this.lbl_ExcludedExplain.TabIndex = 75;
            this.lbl_ExcludedExplain.Text = "*";
            // 
            // lbl_ExcludedDatetime
            // 
            this.lbl_ExcludedDatetime.AutoSize = true;
            this.lbl_ExcludedDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ExcludedDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ExcludedDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_ExcludedDatetime.Location = new System.Drawing.Point(5, 456);
            this.lbl_ExcludedDatetime.Name = "lbl_ExcludedDatetime";
            this.lbl_ExcludedDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_ExcludedDatetime.TabIndex = 74;
            this.lbl_ExcludedDatetime.Text = "*";
            // 
            // textBox_ExcludedDatetime
            // 
            this.textBox_ExcludedDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_ExcludedDatetime.Location = new System.Drawing.Point(20, 456);
            this.textBox_ExcludedDatetime.Mask = "00/00/0000 90:00";
            this.textBox_ExcludedDatetime.Name = "textBox_ExcludedDatetime";
            this.textBox_ExcludedDatetime.Size = new System.Drawing.Size(116, 20);
            this.textBox_ExcludedDatetime.TabIndex = 19;
            this.textBox_ExcludedDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_ExcludedDatetime.Enter += new System.EventHandler(this.textBox_ExcludedDatetime_Enter);
            this.textBox_ExcludedDatetime.Leave += new System.EventHandler(this.textBox_ExcludedDatetime_Leave);
            // 
            // checkedListBox_ExcludedExplain
            // 
            this.checkedListBox_ExcludedExplain.FormattingEnabled = true;
            this.checkedListBox_ExcludedExplain.Items.AddRange(new object[] {
            "IV or IO fluids (acute, decompensated congestive heart failure, pulmonary edema a" +
                "nd LVAD)",
            "IV or IO fluids (end stage renal disease with signs of fluid overload)",
            "Central Line (significant, uncorrectable coagulation abnormalities)",
            "Central Line (anatomic obstacles or limitations)",
            "Vasopressors or inotropes for refractory hypotension (significant, uncorrectable " +
                "coagulation abnormalities)",
            "Vasopressors or inotropes for refractory hypotension (anatomic obstacles or limit" +
                "ations)"});
            this.checkedListBox_ExcludedExplain.Location = new System.Drawing.Point(509, 450);
            this.checkedListBox_ExcludedExplain.Name = "checkedListBox_ExcludedExplain";
            this.checkedListBox_ExcludedExplain.Size = new System.Drawing.Size(543, 94);
            this.checkedListBox_ExcludedExplain.TabIndex = 20;
            // 
            // Label_ExcludedDatetime
            // 
            this.Label_ExcludedDatetime.AutoSize = true;
            this.Label_ExcludedDatetime.Location = new System.Drawing.Point(17, 430);
            this.Label_ExcludedDatetime.Name = "Label_ExcludedDatetime";
            this.Label_ExcludedDatetime.Size = new System.Drawing.Size(108, 13);
            this.Label_ExcludedDatetime.TabIndex = 73;
            this.Label_ExcludedDatetime.Text = "Excluded Date/Time:";
            // 
            // Label_ExcludedExplain
            // 
            this.Label_ExcludedExplain.AutoSize = true;
            this.Label_ExcludedExplain.Location = new System.Drawing.Point(295, 450);
            this.Label_ExcludedExplain.Name = "Label_ExcludedExplain";
            this.Label_ExcludedExplain.Size = new System.Drawing.Size(193, 13);
            this.Label_ExcludedExplain.TabIndex = 72;
            this.Label_ExcludedExplain.Text = "Excluded Explain: (Check all that apply)";
            // 
            // lbl_ExcludedReason
            // 
            this.lbl_ExcludedReason.AutoSize = true;
            this.lbl_ExcludedReason.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ExcludedReason.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ExcludedReason.ForeColor = System.Drawing.Color.Black;
            this.lbl_ExcludedReason.Location = new System.Drawing.Point(295, 365);
            this.lbl_ExcludedReason.Name = "lbl_ExcludedReason";
            this.lbl_ExcludedReason.Size = new System.Drawing.Size(14, 16);
            this.lbl_ExcludedReason.TabIndex = 69;
            this.lbl_ExcludedReason.Text = "*";
            // 
            // checkedListBox_ExcludedReason
            // 
            this.checkedListBox_ExcludedReason.FormattingEnabled = true;
            this.checkedListBox_ExcludedReason.Items.AddRange(new object[] {
            "Interventions were clinically contraindicated",
            "Patient had advanced directives in place that precluded one or more elements of t" +
                "he protocol",
            "Patient, or surrogate decision maker, declined interventions",
            "Patient was enrolled in an IRB approved trial that was inconsistent with the prot" +
                "ocol interventions"});
            this.checkedListBox_ExcludedReason.Location = new System.Drawing.Point(509, 363);
            this.checkedListBox_ExcludedReason.Name = "checkedListBox_ExcludedReason";
            this.checkedListBox_ExcludedReason.Size = new System.Drawing.Size(543, 64);
            this.checkedListBox_ExcludedReason.TabIndex = 18;
            this.checkedListBox_ExcludedReason.Leave += new System.EventHandler(this.checkedListBox_ExcludedReason_Leave);
            this.checkedListBox_ExcludedReason.MouseUp += new System.Windows.Forms.MouseEventHandler(this.checkedListBox_ExcludedReason_MouseUp);
            // 
            // Label_ExcludedReason
            // 
            this.Label_ExcludedReason.AutoSize = true;
            this.Label_ExcludedReason.Location = new System.Drawing.Point(304, 365);
            this.Label_ExcludedReason.Name = "Label_ExcludedReason";
            this.Label_ExcludedReason.Size = new System.Drawing.Size(199, 13);
            this.Label_ExcludedReason.TabIndex = 67;
            this.Label_ExcludedReason.Text = " Excluded Reason: (Check all that apply)";
            // 
            // lbl_ExcludedFromProtocol
            // 
            this.lbl_ExcludedFromProtocol.AutoSize = true;
            this.lbl_ExcludedFromProtocol.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ExcludedFromProtocol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ExcludedFromProtocol.ForeColor = System.Drawing.Color.Black;
            this.lbl_ExcludedFromProtocol.Location = new System.Drawing.Point(5, 379);
            this.lbl_ExcludedFromProtocol.Name = "lbl_ExcludedFromProtocol";
            this.lbl_ExcludedFromProtocol.Size = new System.Drawing.Size(14, 16);
            this.lbl_ExcludedFromProtocol.TabIndex = 66;
            this.lbl_ExcludedFromProtocol.Text = "*";
            // 
            // comboBox_ExcludedFromProtocol
            // 
            this.comboBox_ExcludedFromProtocol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ExcludedFromProtocol.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ExcludedFromProtocol.FormattingEnabled = true;
            this.comboBox_ExcludedFromProtocol.Items.AddRange(new object[] {
            "Select",
            "Patient was not excluded from the protocol",
            "Patient was excluded from the protocol"});
            this.comboBox_ExcludedFromProtocol.Location = new System.Drawing.Point(20, 379);
            this.comboBox_ExcludedFromProtocol.Name = "comboBox_ExcludedFromProtocol";
            this.comboBox_ExcludedFromProtocol.Size = new System.Drawing.Size(245, 21);
            this.comboBox_ExcludedFromProtocol.TabIndex = 17;
            this.comboBox_ExcludedFromProtocol.SelectedIndexChanged += new System.EventHandler(this.comboBox_ExcludedFromProtocol_SelectedIndexChanged);
            // 
            // Label_ExcludedFromProtocol
            // 
            this.Label_ExcludedFromProtocol.AutoSize = true;
            this.Label_ExcludedFromProtocol.Location = new System.Drawing.Point(17, 363);
            this.Label_ExcludedFromProtocol.Name = "Label_ExcludedFromProtocol";
            this.Label_ExcludedFromProtocol.Size = new System.Drawing.Size(122, 13);
            this.Label_ExcludedFromProtocol.TabIndex = 65;
            this.Label_ExcludedFromProtocol.Text = "Excluded From Protocol:";
            // 
            // lbl_TransferFacilityIdentifier
            // 
            this.lbl_TransferFacilityIdentifier.AutoSize = true;
            this.lbl_TransferFacilityIdentifier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_TransferFacilityIdentifier.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TransferFacilityIdentifier.ForeColor = System.Drawing.Color.Black;
            this.lbl_TransferFacilityIdentifier.Location = new System.Drawing.Point(1, 313);
            this.lbl_TransferFacilityIdentifier.Name = "lbl_TransferFacilityIdentifier";
            this.lbl_TransferFacilityIdentifier.Size = new System.Drawing.Size(14, 16);
            this.lbl_TransferFacilityIdentifier.TabIndex = 60;
            this.lbl_TransferFacilityIdentifier.Text = "*";
            // 
            // lbl_TransferStatus
            // 
            this.lbl_TransferStatus.AutoSize = true;
            this.lbl_TransferStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_TransferStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TransferStatus.ForeColor = System.Drawing.Color.Black;
            this.lbl_TransferStatus.Location = new System.Drawing.Point(9, 271);
            this.lbl_TransferStatus.Name = "lbl_TransferStatus";
            this.lbl_TransferStatus.Size = new System.Drawing.Size(14, 16);
            this.lbl_TransferStatus.TabIndex = 59;
            this.lbl_TransferStatus.Text = "*";
            // 
            // lbl_DischargedStatus
            // 
            this.lbl_DischargedStatus.AutoSize = true;
            this.lbl_DischargedStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_DischargedStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DischargedStatus.ForeColor = System.Drawing.Color.Black;
            this.lbl_DischargedStatus.Location = new System.Drawing.Point(9, 227);
            this.lbl_DischargedStatus.Name = "lbl_DischargedStatus";
            this.lbl_DischargedStatus.Size = new System.Drawing.Size(14, 16);
            this.lbl_DischargedStatus.TabIndex = 58;
            this.lbl_DischargedStatus.Text = "*";
            // 
            // lbl_SourceofAdmission
            // 
            this.lbl_SourceofAdmission.AutoSize = true;
            this.lbl_SourceofAdmission.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SourceofAdmission.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SourceofAdmission.ForeColor = System.Drawing.Color.Black;
            this.lbl_SourceofAdmission.Location = new System.Drawing.Point(8, 181);
            this.lbl_SourceofAdmission.Name = "lbl_SourceofAdmission";
            this.lbl_SourceofAdmission.Size = new System.Drawing.Size(14, 16);
            this.lbl_SourceofAdmission.TabIndex = 57;
            this.lbl_SourceofAdmission.Text = "*";
            // 
            // lbl_DischargeDatetime
            // 
            this.lbl_DischargeDatetime.AutoSize = true;
            this.lbl_DischargeDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_DischargeDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DischargeDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_DischargeDatetime.Location = new System.Drawing.Point(689, 132);
            this.lbl_DischargeDatetime.Name = "lbl_DischargeDatetime";
            this.lbl_DischargeDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_DischargeDatetime.TabIndex = 56;
            this.lbl_DischargeDatetime.Text = "*";
            // 
            // lbl_AdmissionDateTime
            // 
            this.lbl_AdmissionDateTime.AutoSize = true;
            this.lbl_AdmissionDateTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_AdmissionDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AdmissionDateTime.ForeColor = System.Drawing.Color.Black;
            this.lbl_AdmissionDateTime.Location = new System.Drawing.Point(496, 131);
            this.lbl_AdmissionDateTime.Name = "lbl_AdmissionDateTime";
            this.lbl_AdmissionDateTime.Size = new System.Drawing.Size(14, 16);
            this.lbl_AdmissionDateTime.TabIndex = 55;
            this.lbl_AdmissionDateTime.Text = "*";
            // 
            // lbl_FacilityIdentifier
            // 
            this.lbl_FacilityIdentifier.AutoSize = true;
            this.lbl_FacilityIdentifier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_FacilityIdentifier.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FacilityIdentifier.ForeColor = System.Drawing.Color.Black;
            this.lbl_FacilityIdentifier.Location = new System.Drawing.Point(263, 133);
            this.lbl_FacilityIdentifier.Name = "lbl_FacilityIdentifier";
            this.lbl_FacilityIdentifier.Size = new System.Drawing.Size(14, 16);
            this.lbl_FacilityIdentifier.TabIndex = 54;
            this.lbl_FacilityIdentifier.Text = "*";
            // 
            // lbl_MRN
            // 
            this.lbl_MRN.AutoSize = true;
            this.lbl_MRN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_MRN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MRN.ForeColor = System.Drawing.Color.Black;
            this.lbl_MRN.Location = new System.Drawing.Point(9, 133);
            this.lbl_MRN.Name = "lbl_MRN";
            this.lbl_MRN.Size = new System.Drawing.Size(14, 16);
            this.lbl_MRN.TabIndex = 53;
            this.lbl_MRN.Text = "*";
            // 
            // lbl_InsuranceNumber
            // 
            this.lbl_InsuranceNumber.AutoSize = true;
            this.lbl_InsuranceNumber.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_InsuranceNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_InsuranceNumber.ForeColor = System.Drawing.Color.Black;
            this.lbl_InsuranceNumber.Location = new System.Drawing.Point(486, 85);
            this.lbl_InsuranceNumber.Name = "lbl_InsuranceNumber";
            this.lbl_InsuranceNumber.Size = new System.Drawing.Size(14, 16);
            this.lbl_InsuranceNumber.TabIndex = 52;
            this.lbl_InsuranceNumber.Text = "*";
            // 
            // lbl_Payor
            // 
            this.lbl_Payor.AutoSize = true;
            this.lbl_Payor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Payor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Payor.ForeColor = System.Drawing.Color.Black;
            this.lbl_Payor.Location = new System.Drawing.Point(264, 84);
            this.lbl_Payor.Name = "lbl_Payor";
            this.lbl_Payor.Size = new System.Drawing.Size(14, 16);
            this.lbl_Payor.TabIndex = 51;
            this.lbl_Payor.Text = "*";
            // 
            // lbl_Ethnicity
            // 
            this.lbl_Ethnicity.AutoSize = true;
            this.lbl_Ethnicity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Ethnicity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ethnicity.ForeColor = System.Drawing.Color.Black;
            this.lbl_Ethnicity.Location = new System.Drawing.Point(10, 84);
            this.lbl_Ethnicity.Name = "lbl_Ethnicity";
            this.lbl_Ethnicity.Size = new System.Drawing.Size(14, 16);
            this.lbl_Ethnicity.TabIndex = 50;
            this.lbl_Ethnicity.Text = "*";
            // 
            // lbl_Race
            // 
            this.lbl_Race.AutoSize = true;
            this.lbl_Race.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Race.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Race.ForeColor = System.Drawing.Color.Black;
            this.lbl_Race.Location = new System.Drawing.Point(922, 25);
            this.lbl_Race.Name = "lbl_Race";
            this.lbl_Race.Size = new System.Drawing.Size(14, 16);
            this.lbl_Race.TabIndex = 49;
            this.lbl_Race.Text = "*";
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.ForeColor = System.Drawing.Color.Black;
            this.lbl_Gender.Location = new System.Drawing.Point(683, 34);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(14, 16);
            this.lbl_Gender.TabIndex = 48;
            this.lbl_Gender.Text = "*";
            // 
            // lbl_DOB
            // 
            this.lbl_DOB.AutoSize = true;
            this.lbl_DOB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_DOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DOB.ForeColor = System.Drawing.Color.Black;
            this.lbl_DOB.Location = new System.Drawing.Point(491, 35);
            this.lbl_DOB.Name = "lbl_DOB";
            this.lbl_DOB.Size = new System.Drawing.Size(14, 16);
            this.lbl_DOB.TabIndex = 47;
            this.lbl_DOB.Text = "*";
            // 
            // lbl_PatientCtrlNum
            // 
            this.lbl_PatientCtrlNum.AutoSize = true;
            this.lbl_PatientCtrlNum.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_PatientCtrlNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatientCtrlNum.ForeColor = System.Drawing.Color.Black;
            this.lbl_PatientCtrlNum.Location = new System.Drawing.Point(265, 34);
            this.lbl_PatientCtrlNum.Name = "lbl_PatientCtrlNum";
            this.lbl_PatientCtrlNum.Size = new System.Drawing.Size(14, 16);
            this.lbl_PatientCtrlNum.TabIndex = 46;
            this.lbl_PatientCtrlNum.Text = "*";
            // 
            // lbl_txID
            // 
            this.lbl_txID.AutoSize = true;
            this.lbl_txID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_txID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_txID.ForeColor = System.Drawing.Color.Black;
            this.lbl_txID.Location = new System.Drawing.Point(12, 33);
            this.lbl_txID.Name = "lbl_txID";
            this.lbl_txID.Size = new System.Drawing.Size(14, 16);
            this.lbl_txID.TabIndex = 45;
            this.lbl_txID.Text = "*";
            // 
            // textBox_TransferFacilityIdentifier
            // 
            this.textBox_TransferFacilityIdentifier.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_TransferFacilityIdentifier.Location = new System.Drawing.Point(15, 312);
            this.textBox_TransferFacilityIdentifier.Mask = "000000";
            this.textBox_TransferFacilityIdentifier.Name = "textBox_TransferFacilityIdentifier";
            this.textBox_TransferFacilityIdentifier.Size = new System.Drawing.Size(100, 20);
            this.textBox_TransferFacilityIdentifier.TabIndex = 15;
            this.textBox_TransferFacilityIdentifier.Enter += new System.EventHandler(this.textBox_TransferFacilityIdentifier_Enter);
            this.textBox_TransferFacilityIdentifier.Leave += new System.EventHandler(this.textBox_TransferFacilityIdentifier_Leave);
            // 
            // TextBox_FacilityIdentifier
            // 
            this.TextBox_FacilityIdentifier.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.TextBox_FacilityIdentifier.Location = new System.Drawing.Point(279, 133);
            this.TextBox_FacilityIdentifier.Mask = "AAAAAA";
            this.TextBox_FacilityIdentifier.Name = "TextBox_FacilityIdentifier";
            this.TextBox_FacilityIdentifier.Size = new System.Drawing.Size(150, 20);
            this.TextBox_FacilityIdentifier.TabIndex = 9;
            this.TextBox_FacilityIdentifier.Enter += new System.EventHandler(this.TextBox_FacilityIdentifier_Enter);
            // 
            // TextBox_InsuranceNumber
            // 
            this.TextBox_InsuranceNumber.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.TextBox_InsuranceNumber.Location = new System.Drawing.Point(506, 85);
            this.TextBox_InsuranceNumber.Mask = "AAAAAAAAAAAAAAAAAAA";
            this.TextBox_InsuranceNumber.Name = "TextBox_InsuranceNumber";
            this.TextBox_InsuranceNumber.Size = new System.Drawing.Size(126, 20);
            this.TextBox_InsuranceNumber.TabIndex = 7;
            this.TextBox_InsuranceNumber.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.TextBox_InsuranceNumber_MaskInputRejected);
            this.TextBox_InsuranceNumber.Enter += new System.EventHandler(this.TextBox_InsuranceNumber_Enter);
            this.TextBox_InsuranceNumber.Leave += new System.EventHandler(this.TextBox_InsuranceNumber_Leave);
            // 
            // TextBox_PatientCtrlNum
            // 
            this.TextBox_PatientCtrlNum.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.TextBox_PatientCtrlNum.Location = new System.Drawing.Point(279, 34);
            this.TextBox_PatientCtrlNum.Mask = "AAAAAAAAAAAAAAAAAAAA";
            this.TextBox_PatientCtrlNum.Name = "TextBox_PatientCtrlNum";
            this.TextBox_PatientCtrlNum.Size = new System.Drawing.Size(150, 20);
            this.TextBox_PatientCtrlNum.TabIndex = 1;
            this.TextBox_PatientCtrlNum.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.TextBox_PatientCtrlNum_MaskInputRejected);
            this.TextBox_PatientCtrlNum.Enter += new System.EventHandler(this.TextBox_PatientCtrlNum_Enter);
            // 
            // txtId
            // 
            this.txtId.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtId.Location = new System.Drawing.Point(25, 33);
            this.txtId.Mask = "??????0000";
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(220, 20);
            this.txtId.TabIndex = 0;
            this.txtId.Enter += new System.EventHandler(this.txtId_Enter);
            this.txtId.Leave += new System.EventHandler(this.txtId_Leave);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(21, 18);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(131, 13);
            this.label38.TabIndex = 44;
            this.label38.Text = "Unique Personal Identifier:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(12, 298);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(127, 13);
            this.label32.TabIndex = 42;
            this.label32.Text = "Transfer Facility Identifier:";
            // 
            // txtMRN
            // 
            this.txtMRN.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtMRN.Location = new System.Drawing.Point(24, 134);
            this.txtMRN.Mask = "AAAAAAAAAAAAAAAAA";
            this.txtMRN.Name = "txtMRN";
            this.txtMRN.Size = new System.Drawing.Size(219, 20);
            this.txtMRN.TabIndex = 8;
            this.txtMRN.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.txtMRN_MaskInputRejected);
            this.txtMRN.Enter += new System.EventHandler(this.txtMRN_Enter);
            // 
            // textBox_DischargedDatetime
            // 
            this.textBox_DischargedDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_DischargedDatetime.Location = new System.Drawing.Point(705, 132);
            this.textBox_DischargedDatetime.Mask = "00/00/0000 90:00";
            this.textBox_DischargedDatetime.Name = "textBox_DischargedDatetime";
            this.textBox_DischargedDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_DischargedDatetime.TabIndex = 11;
            this.textBox_DischargedDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_DischargedDatetime.Enter += new System.EventHandler(this.textBox_DischargedDatetime_Enter);
            this.textBox_DischargedDatetime.Leave += new System.EventHandler(this.textBox_DischargedDatetime_Leave);
            // 
            // textBox_AdmissionDateTime
            // 
            this.textBox_AdmissionDateTime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_AdmissionDateTime.Location = new System.Drawing.Point(511, 132);
            this.textBox_AdmissionDateTime.Mask = "00/00/0000 90:00";
            this.textBox_AdmissionDateTime.Name = "textBox_AdmissionDateTime";
            this.textBox_AdmissionDateTime.Size = new System.Drawing.Size(100, 20);
            this.textBox_AdmissionDateTime.TabIndex = 10;
            this.textBox_AdmissionDateTime.ValidatingType = typeof(System.DateTime);
            this.textBox_AdmissionDateTime.Enter += new System.EventHandler(this.textBox_AdmissionDateTime_Enter);
            this.textBox_AdmissionDateTime.Leave += new System.EventHandler(this.textBox_AdmissionDateTime_Leave);
            // 
            // txtDOB
            // 
            this.txtDOB.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtDOB.Location = new System.Drawing.Point(511, 34);
            this.txtDOB.Mask = "00/00/0000";
            this.txtDOB.Name = "txtDOB";
            this.txtDOB.Size = new System.Drawing.Size(100, 20);
            this.txtDOB.TabIndex = 2;
            this.txtDOB.ValidatingType = typeof(System.DateTime);
            this.txtDOB.Enter += new System.EventHandler(this.txtDOB_Enter);
            this.txtDOB.Leave += new System.EventHandler(this.txtDOB_Leave);
            // 
            // Label_AdmissionDatetime
            // 
            this.Label_AdmissionDatetime.AutoSize = true;
            this.Label_AdmissionDatetime.Location = new System.Drawing.Point(508, 116);
            this.Label_AdmissionDatetime.Name = "Label_AdmissionDatetime";
            this.Label_AdmissionDatetime.Size = new System.Drawing.Size(111, 13);
            this.Label_AdmissionDatetime.TabIndex = 29;
            this.Label_AdmissionDatetime.Text = "Admission Date/Time:";
            // 
            // Label_SourceofAdmission
            // 
            this.Label_SourceofAdmission.AutoSize = true;
            this.Label_SourceofAdmission.Location = new System.Drawing.Point(21, 163);
            this.Label_SourceofAdmission.Name = "Label_SourceofAdmission";
            this.Label_SourceofAdmission.Size = new System.Drawing.Size(106, 13);
            this.Label_SourceofAdmission.TabIndex = 28;
            this.Label_SourceofAdmission.Text = "Source of Admission:";
            // 
            // Label_DischargeDatetime
            // 
            this.Label_DischargeDatetime.AutoSize = true;
            this.Label_DischargeDatetime.Location = new System.Drawing.Point(702, 116);
            this.Label_DischargeDatetime.Name = "Label_DischargeDatetime";
            this.Label_DischargeDatetime.Size = new System.Drawing.Size(112, 13);
            this.Label_DischargeDatetime.TabIndex = 27;
            this.Label_DischargeDatetime.Text = "Discharge Date/Time:";
            // 
            // Label_DischargedStatus
            // 
            this.Label_DischargedStatus.AutoSize = true;
            this.Label_DischargedStatus.Location = new System.Drawing.Point(21, 209);
            this.Label_DischargedStatus.Name = "Label_DischargedStatus";
            this.Label_DischargedStatus.Size = new System.Drawing.Size(97, 13);
            this.Label_DischargedStatus.TabIndex = 26;
            this.Label_DischargedStatus.Text = "Discharged Status:";
            // 
            // Label_Transfer
            // 
            this.Label_Transfer.AutoSize = true;
            this.Label_Transfer.Location = new System.Drawing.Point(22, 252);
            this.Label_Transfer.Name = "Label_Transfer";
            this.Label_Transfer.Size = new System.Drawing.Size(82, 13);
            this.Label_Transfer.TabIndex = 25;
            this.Label_Transfer.Text = "Transfer Status:";
            // 
            // checkedListBox_Race
            // 
            this.checkedListBox_Race.FormattingEnabled = true;
            this.checkedListBox_Race.Location = new System.Drawing.Point(937, 24);
            this.checkedListBox_Race.Name = "checkedListBox_Race";
            this.checkedListBox_Race.Size = new System.Drawing.Size(284, 139);
            this.checkedListBox_Race.TabIndex = 4;
            // 
            // comboBox_Payor
            // 
            this.comboBox_Payor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Payor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_Payor.FormattingEnabled = true;
            this.comboBox_Payor.Items.AddRange(new object[] {
            "Select",
            "Self Pay",
            "Workers Comp",
            "Medicare",
            "Medicaid",
            "Other Federal Program",
            "Commercial Insurance",
            "Blue Cross",
            "CHAMPUS",
            "Other Non-Federal Program"});
            this.comboBox_Payor.Location = new System.Drawing.Point(279, 84);
            this.comboBox_Payor.Name = "comboBox_Payor";
            this.comboBox_Payor.Size = new System.Drawing.Size(150, 21);
            this.comboBox_Payor.TabIndex = 6;
            this.comboBox_Payor.SelectedIndexChanged += new System.EventHandler(this.comboBox_Payor_SelectedIndexChanged);
            // 
            // Combobox_Ethnicity
            // 
            this.Combobox_Ethnicity.BackColor = System.Drawing.SystemColors.Window;
            this.Combobox_Ethnicity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Combobox_Ethnicity.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Combobox_Ethnicity.FormattingEnabled = true;
            this.Combobox_Ethnicity.Items.AddRange(new object[] {
            "Select",
            "Spanish/Hispanic Origin",
            "Not of Spanish/Hispanic Origin",
            "Unknown"});
            this.Combobox_Ethnicity.Location = new System.Drawing.Point(24, 84);
            this.Combobox_Ethnicity.Name = "Combobox_Ethnicity";
            this.Combobox_Ethnicity.Size = new System.Drawing.Size(220, 21);
            this.Combobox_Ethnicity.TabIndex = 5;
            // 
            // Combobox_Gender
            // 
            this.Combobox_Gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Combobox_Gender.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Combobox_Gender.FormattingEnabled = true;
            this.Combobox_Gender.Items.AddRange(new object[] {
            "Select",
            "Male",
            "Female",
            "Unknown"});
            this.Combobox_Gender.Location = new System.Drawing.Point(698, 33);
            this.Combobox_Gender.Name = "Combobox_Gender";
            this.Combobox_Gender.Size = new System.Drawing.Size(121, 21);
            this.Combobox_Gender.TabIndex = 3;
            // 
            // Label_PatientCtrlNum
            // 
            this.Label_PatientCtrlNum.AutoSize = true;
            this.Label_PatientCtrlNum.Location = new System.Drawing.Point(277, 18);
            this.Label_PatientCtrlNum.Name = "Label_PatientCtrlNum";
            this.Label_PatientCtrlNum.Size = new System.Drawing.Size(122, 13);
            this.Label_PatientCtrlNum.TabIndex = 15;
            this.Label_PatientCtrlNum.Text = " Patient Control Number:";
            // 
            // Label_Ethnicity
            // 
            this.Label_Ethnicity.AutoSize = true;
            this.Label_Ethnicity.Location = new System.Drawing.Point(22, 67);
            this.Label_Ethnicity.Name = "Label_Ethnicity";
            this.Label_Ethnicity.Size = new System.Drawing.Size(50, 13);
            this.Label_Ethnicity.TabIndex = 13;
            this.Label_Ethnicity.Text = "Ethnicity:";
            // 
            // Label_InsuranceNumber
            // 
            this.Label_InsuranceNumber.AutoSize = true;
            this.Label_InsuranceNumber.Location = new System.Drawing.Point(499, 68);
            this.Label_InsuranceNumber.Name = "Label_InsuranceNumber";
            this.Label_InsuranceNumber.Size = new System.Drawing.Size(97, 13);
            this.Label_InsuranceNumber.TabIndex = 12;
            this.Label_InsuranceNumber.Text = "Insurance Number:";
            // 
            // Label_Race
            // 
            this.Label_Race.AutoSize = true;
            this.Label_Race.Location = new System.Drawing.Point(934, 8);
            this.Label_Race.Name = "Label_Race";
            this.Label_Race.Size = new System.Drawing.Size(36, 13);
            this.Label_Race.TabIndex = 11;
            this.Label_Race.Text = "Race:";
            // 
            // Label_Payor
            // 
            this.Label_Payor.AutoSize = true;
            this.Label_Payor.Location = new System.Drawing.Point(276, 68);
            this.Label_Payor.Name = "Label_Payor";
            this.Label_Payor.Size = new System.Drawing.Size(37, 13);
            this.Label_Payor.TabIndex = 10;
            this.Label_Payor.Text = "Payor:";
            // 
            // Label_Gender
            // 
            this.Label_Gender.AutoSize = true;
            this.Label_Gender.Location = new System.Drawing.Point(702, 18);
            this.Label_Gender.Name = "Label_Gender";
            this.Label_Gender.Size = new System.Drawing.Size(45, 13);
            this.Label_Gender.TabIndex = 9;
            this.Label_Gender.Text = "Gender:";
            // 
            // Label_FacilityIdentifier
            // 
            this.Label_FacilityIdentifier.AutoSize = true;
            this.Label_FacilityIdentifier.Location = new System.Drawing.Point(275, 116);
            this.Label_FacilityIdentifier.Name = "Label_FacilityIdentifier";
            this.Label_FacilityIdentifier.Size = new System.Drawing.Size(85, 13);
            this.Label_FacilityIdentifier.TabIndex = 8;
            this.Label_FacilityIdentifier.Text = "Facility Identifier:";
            // 
            // Label_MRN
            // 
            this.Label_MRN.AutoSize = true;
            this.Label_MRN.Location = new System.Drawing.Point(21, 116);
            this.Label_MRN.Name = "Label_MRN";
            this.Label_MRN.Size = new System.Drawing.Size(102, 13);
            this.Label_MRN.TabIndex = 7;
            this.Label_MRN.Text = "Medical Record No:";
            // 
            // Label_DateofBirth
            // 
            this.Label_DateofBirth.AutoSize = true;
            this.Label_DateofBirth.Location = new System.Drawing.Point(508, 18);
            this.Label_DateofBirth.Name = "Label_DateofBirth";
            this.Label_DateofBirth.Size = new System.Drawing.Size(69, 13);
            this.Label_DateofBirth.TabIndex = 6;
            this.Label_DateofBirth.Text = "Date of Birth:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.comboBox_VasopressorTransfer);
            this.tabPage3.Controls.Add(this.lbl_VasopressorTransfer);
            this.tabPage3.Controls.Add(this.label_VasopressorTransfer);
            this.tabPage3.Controls.Add(this.lbl_VasopressorAdministrationEndDateTime);
            this.tabPage3.Controls.Add(this.textBox_VasopressorAdministrationEndDatetime);
            this.tabPage3.Controls.Add(this.label_VasopressorAdministrationEndDateTime);
            this.tabPage3.Controls.Add(this.lbl_InitialLactateLevelCollection);
            this.tabPage3.Controls.Add(this.textBox_InitialLactateLevel);
            this.tabPage3.Controls.Add(this.lbl_SepticShockPresentationDatetime);
            this.tabPage3.Controls.Add(this.lbl_InitialLactateLevel);
            this.tabPage3.Controls.Add(this.lbl_AntibioticAdministration);
            this.tabPage3.Controls.Add(this.lbl_VasopressorAdministrationStartDateTime);
            this.tabPage3.Controls.Add(this.lbl_VasopressorAdministration);
            this.tabPage3.Controls.Add(this.lbl_CrystalloidFluidAdministrationDatetime);
            this.tabPage3.Controls.Add(this.lbl_CrystalloidFluidAdministration);
            this.tabPage3.Controls.Add(this.lbl_AntibioticAdministrationDatetime);
            this.tabPage3.Controls.Add(this.lbl_ElevatedLactateReason);
            this.tabPage3.Controls.Add(this.lbl_BloodCultureCollectionDatetime);
            this.tabPage3.Controls.Add(this.lbl_BloodCultureCollectionAcceptableDelay);
            this.tabPage3.Controls.Add(this.lbl_BloodCultureCollection);
            this.tabPage3.Controls.Add(this.lbl_InitialLactateLevelCollectionDatetime);
            this.tabPage3.Controls.Add(this.lbl_SepticShockPresent);
            this.tabPage3.Controls.Add(this.lbl_SevereSepsisPresentationDatetime);
            this.tabPage3.Controls.Add(this.lbl_SevereSepsisPresent);
            this.tabPage3.Controls.Add(this.lbl_EarliestDatetime);
            this.tabPage3.Controls.Add(this.textBox_AntibioticAdministrationDatetime);
            this.tabPage3.Controls.Add(this.textBox_BloodCultureCollectionDatetime);
            this.tabPage3.Controls.Add(this.textBox_VasopressorAdministrationStartDatetime);
            this.tabPage3.Controls.Add(this.textBox_CrystalloidFluidAdministrationDatetime);
            this.tabPage3.Controls.Add(this.textBox_InitialLactateLevelCollectionDatetime);
            this.tabPage3.Controls.Add(this.textBox_septicShockPresentationDatetime);
            this.tabPage3.Controls.Add(this.textBox_SevereSepsisPresentationDatetime);
            this.tabPage3.Controls.Add(this.textbox_TriageDatetime);
            this.tabPage3.Controls.Add(this.textBox_ArrivalDatetime);
            this.tabPage3.Controls.Add(this.comboBox_VasopressorAdministration);
            this.tabPage3.Controls.Add(this.comboBox_BloodCultureCollection);
            this.tabPage3.Controls.Add(this.comboBox_BloodCultureCollectionAcceptableDelay);
            this.tabPage3.Controls.Add(this.comboBox_ElevatedLactateReason);
            this.tabPage3.Controls.Add(this.comboBox_AntibioticAdministration);
            this.tabPage3.Controls.Add(this.comboBox_SepticShockPresent);
            this.tabPage3.Controls.Add(this.comboBox_InitialLactateLevelCollection);
            this.tabPage3.Controls.Add(this.comboBox_SevereSepsisPresent);
            this.tabPage3.Controls.Add(this.label_VasopressorAdministration);
            this.tabPage3.Controls.Add(this.label_VasopressorAdministrationStartDateTime);
            this.tabPage3.Controls.Add(this.Label_CrystalloidFluidAdministrationDatetime);
            this.tabPage3.Controls.Add(this.Label_CrystalloidFluidAdministration);
            this.tabPage3.Controls.Add(this.Label_AntibioticAdministrationDatetime);
            this.tabPage3.Controls.Add(this.Label_ElevatedLactateReason);
            this.tabPage3.Controls.Add(this.Label_BloodCultureCollection);
            this.tabPage3.Controls.Add(this.Label_InitialLactateLevel);
            this.tabPage3.Controls.Add(this.Label_SevereSepsisPresent);
            this.tabPage3.Controls.Add(this.Label_BloodCultureCollectionAcceptableDelay);
            this.tabPage3.Controls.Add(this.Label_SevereSepsisPresentationDatetime);
            this.tabPage3.Controls.Add(this.Label_AntibioticAdministration);
            this.tabPage3.Controls.Add(this.Label_InitialLactateLevelCollectionDatetime);
            this.tabPage3.Controls.Add(this.Label_SepticShockPresentationDatetime);
            this.tabPage3.Controls.Add(this.Label_BloodCultureCollectionDatetime);
            this.tabPage3.Controls.Add(this.Label_SepticShockPresent);
            this.tabPage3.Controls.Add(this.Label_InitialLactateLevelCollection);
            this.tabPage3.Controls.Add(this.Label_TriageDatetime);
            this.tabPage3.Controls.Add(this.Label_ArrivalDatetime);
            this.tabPage3.Controls.Add(this.comboBox_CrystalloidFluidAdministration);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1233, 551);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Adherence";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // comboBox_VasopressorTransfer
            // 
            this.comboBox_VasopressorTransfer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_VasopressorTransfer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_VasopressorTransfer.FormattingEnabled = true;
            this.comboBox_VasopressorTransfer.Location = new System.Drawing.Point(51, 502);
            this.comboBox_VasopressorTransfer.Name = "comboBox_VasopressorTransfer";
            this.comboBox_VasopressorTransfer.Size = new System.Drawing.Size(334, 21);
            this.comboBox_VasopressorTransfer.TabIndex = 20;
            this.comboBox_VasopressorTransfer.SelectedIndexChanged += new System.EventHandler(this.comboBox_VasopressorTransfer_SelectedIndexChanged);
            this.comboBox_VasopressorTransfer.Leave += new System.EventHandler(this.comboBox_VasopressorTransfer_Leave);
            // 
            // lbl_VasopressorTransfer
            // 
            this.lbl_VasopressorTransfer.AutoSize = true;
            this.lbl_VasopressorTransfer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_VasopressorTransfer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_VasopressorTransfer.ForeColor = System.Drawing.Color.Black;
            this.lbl_VasopressorTransfer.Location = new System.Drawing.Point(32, 502);
            this.lbl_VasopressorTransfer.Name = "lbl_VasopressorTransfer";
            this.lbl_VasopressorTransfer.Size = new System.Drawing.Size(14, 16);
            this.lbl_VasopressorTransfer.TabIndex = 117;
            this.lbl_VasopressorTransfer.Text = "*";
            // 
            // label_VasopressorTransfer
            // 
            this.label_VasopressorTransfer.AutoSize = true;
            this.label_VasopressorTransfer.Location = new System.Drawing.Point(46, 486);
            this.label_VasopressorTransfer.Name = "label_VasopressorTransfer";
            this.label_VasopressorTransfer.Size = new System.Drawing.Size(178, 13);
            this.label_VasopressorTransfer.TabIndex = 116;
            this.label_VasopressorTransfer.Text = "Vasopressor Administration Transfer:";
            // 
            // lbl_VasopressorAdministrationEndDateTime
            // 
            this.lbl_VasopressorAdministrationEndDateTime.AutoSize = true;
            this.lbl_VasopressorAdministrationEndDateTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_VasopressorAdministrationEndDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_VasopressorAdministrationEndDateTime.ForeColor = System.Drawing.Color.Black;
            this.lbl_VasopressorAdministrationEndDateTime.Location = new System.Drawing.Point(840, 441);
            this.lbl_VasopressorAdministrationEndDateTime.Name = "lbl_VasopressorAdministrationEndDateTime";
            this.lbl_VasopressorAdministrationEndDateTime.Size = new System.Drawing.Size(14, 16);
            this.lbl_VasopressorAdministrationEndDateTime.TabIndex = 114;
            this.lbl_VasopressorAdministrationEndDateTime.Text = "*";
            // 
            // textBox_VasopressorAdministrationEndDatetime
            // 
            this.textBox_VasopressorAdministrationEndDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_VasopressorAdministrationEndDatetime.Location = new System.Drawing.Point(855, 441);
            this.textBox_VasopressorAdministrationEndDatetime.Mask = "00/00/0000 90:00";
            this.textBox_VasopressorAdministrationEndDatetime.Name = "textBox_VasopressorAdministrationEndDatetime";
            this.textBox_VasopressorAdministrationEndDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_VasopressorAdministrationEndDatetime.TabIndex = 19;
            this.textBox_VasopressorAdministrationEndDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_VasopressorAdministrationEndDatetime.Leave += new System.EventHandler(this.textBox_VasopressorAdministrationEndDatetime_Leave);
            // 
            // label_VasopressorAdministrationEndDateTime
            // 
            this.label_VasopressorAdministrationEndDateTime.AutoSize = true;
            this.label_VasopressorAdministrationEndDateTime.Location = new System.Drawing.Point(852, 424);
            this.label_VasopressorAdministrationEndDateTime.Name = "label_VasopressorAdministrationEndDateTime";
            this.label_VasopressorAdministrationEndDateTime.Size = new System.Drawing.Size(212, 13);
            this.label_VasopressorAdministrationEndDateTime.TabIndex = 113;
            this.label_VasopressorAdministrationEndDateTime.Text = "Vasopressor Administration End Date/Time:";
            // 
            // lbl_InitialLactateLevelCollection
            // 
            this.lbl_InitialLactateLevelCollection.AutoSize = true;
            this.lbl_InitialLactateLevelCollection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_InitialLactateLevelCollection.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_InitialLactateLevelCollection.ForeColor = System.Drawing.Color.Black;
            this.lbl_InitialLactateLevelCollection.Location = new System.Drawing.Point(25, 153);
            this.lbl_InitialLactateLevelCollection.Name = "lbl_InitialLactateLevelCollection";
            this.lbl_InitialLactateLevelCollection.Size = new System.Drawing.Size(14, 16);
            this.lbl_InitialLactateLevelCollection.TabIndex = 111;
            this.lbl_InitialLactateLevelCollection.Text = "*";
            // 
            // textBox_InitialLactateLevel
            // 
            this.textBox_InitialLactateLevel.Location = new System.Drawing.Point(45, 214);
            this.textBox_InitialLactateLevel.MaxLength = 4;
            this.textBox_InitialLactateLevel.Name = "textBox_InitialLactateLevel";
            this.textBox_InitialLactateLevel.Size = new System.Drawing.Size(100, 20);
            this.textBox_InitialLactateLevel.TabIndex = 8;
            this.textBox_InitialLactateLevel.Enter += new System.EventHandler(this.textBox_InitialLactateLevel_Enter);
            this.textBox_InitialLactateLevel.Leave += new System.EventHandler(this.textBox_InitialLactateLevel_Leave);
            // 
            // lbl_SepticShockPresentationDatetime
            // 
            this.lbl_SepticShockPresentationDatetime.AutoSize = true;
            this.lbl_SepticShockPresentationDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SepticShockPresentationDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SepticShockPresentationDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_SepticShockPresentationDatetime.Location = new System.Drawing.Point(449, 101);
            this.lbl_SepticShockPresentationDatetime.Name = "lbl_SepticShockPresentationDatetime";
            this.lbl_SepticShockPresentationDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_SepticShockPresentationDatetime.TabIndex = 110;
            this.lbl_SepticShockPresentationDatetime.Text = "*";
            // 
            // lbl_InitialLactateLevel
            // 
            this.lbl_InitialLactateLevel.AutoSize = true;
            this.lbl_InitialLactateLevel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_InitialLactateLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_InitialLactateLevel.ForeColor = System.Drawing.Color.Black;
            this.lbl_InitialLactateLevel.Location = new System.Drawing.Point(30, 215);
            this.lbl_InitialLactateLevel.Name = "lbl_InitialLactateLevel";
            this.lbl_InitialLactateLevel.Size = new System.Drawing.Size(14, 16);
            this.lbl_InitialLactateLevel.TabIndex = 108;
            this.lbl_InitialLactateLevel.Text = "*";
            // 
            // lbl_AntibioticAdministration
            // 
            this.lbl_AntibioticAdministration.AutoSize = true;
            this.lbl_AntibioticAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_AntibioticAdministration.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AntibioticAdministration.ForeColor = System.Drawing.Color.Black;
            this.lbl_AntibioticAdministration.Location = new System.Drawing.Point(28, 333);
            this.lbl_AntibioticAdministration.Name = "lbl_AntibioticAdministration";
            this.lbl_AntibioticAdministration.Size = new System.Drawing.Size(14, 16);
            this.lbl_AntibioticAdministration.TabIndex = 107;
            this.lbl_AntibioticAdministration.Text = "*";
            // 
            // lbl_VasopressorAdministrationStartDateTime
            // 
            this.lbl_VasopressorAdministrationStartDateTime.AutoSize = true;
            this.lbl_VasopressorAdministrationStartDateTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_VasopressorAdministrationStartDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_VasopressorAdministrationStartDateTime.ForeColor = System.Drawing.Color.Black;
            this.lbl_VasopressorAdministrationStartDateTime.Location = new System.Drawing.Point(449, 446);
            this.lbl_VasopressorAdministrationStartDateTime.Name = "lbl_VasopressorAdministrationStartDateTime";
            this.lbl_VasopressorAdministrationStartDateTime.Size = new System.Drawing.Size(14, 16);
            this.lbl_VasopressorAdministrationStartDateTime.TabIndex = 86;
            this.lbl_VasopressorAdministrationStartDateTime.Text = "*";
            // 
            // lbl_VasopressorAdministration
            // 
            this.lbl_VasopressorAdministration.AutoSize = true;
            this.lbl_VasopressorAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_VasopressorAdministration.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_VasopressorAdministration.ForeColor = System.Drawing.Color.Black;
            this.lbl_VasopressorAdministration.Location = new System.Drawing.Point(30, 445);
            this.lbl_VasopressorAdministration.Name = "lbl_VasopressorAdministration";
            this.lbl_VasopressorAdministration.Size = new System.Drawing.Size(14, 16);
            this.lbl_VasopressorAdministration.TabIndex = 85;
            this.lbl_VasopressorAdministration.Text = "*";
            // 
            // lbl_CrystalloidFluidAdministrationDatetime
            // 
            this.lbl_CrystalloidFluidAdministrationDatetime.AutoSize = true;
            this.lbl_CrystalloidFluidAdministrationDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_CrystalloidFluidAdministrationDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CrystalloidFluidAdministrationDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_CrystalloidFluidAdministrationDatetime.Location = new System.Drawing.Point(451, 389);
            this.lbl_CrystalloidFluidAdministrationDatetime.Name = "lbl_CrystalloidFluidAdministrationDatetime";
            this.lbl_CrystalloidFluidAdministrationDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_CrystalloidFluidAdministrationDatetime.TabIndex = 82;
            this.lbl_CrystalloidFluidAdministrationDatetime.Text = "*";
            // 
            // lbl_CrystalloidFluidAdministration
            // 
            this.lbl_CrystalloidFluidAdministration.AutoSize = true;
            this.lbl_CrystalloidFluidAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_CrystalloidFluidAdministration.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CrystalloidFluidAdministration.ForeColor = System.Drawing.Color.Black;
            this.lbl_CrystalloidFluidAdministration.Location = new System.Drawing.Point(28, 389);
            this.lbl_CrystalloidFluidAdministration.Name = "lbl_CrystalloidFluidAdministration";
            this.lbl_CrystalloidFluidAdministration.Size = new System.Drawing.Size(14, 16);
            this.lbl_CrystalloidFluidAdministration.TabIndex = 80;
            this.lbl_CrystalloidFluidAdministration.Text = "*";
            // 
            // lbl_AntibioticAdministrationDatetime
            // 
            this.lbl_AntibioticAdministrationDatetime.AutoSize = true;
            this.lbl_AntibioticAdministrationDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_AntibioticAdministrationDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AntibioticAdministrationDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_AntibioticAdministrationDatetime.Location = new System.Drawing.Point(451, 333);
            this.lbl_AntibioticAdministrationDatetime.Name = "lbl_AntibioticAdministrationDatetime";
            this.lbl_AntibioticAdministrationDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_AntibioticAdministrationDatetime.TabIndex = 79;
            this.lbl_AntibioticAdministrationDatetime.Text = "*";
            // 
            // lbl_ElevatedLactateReason
            // 
            this.lbl_ElevatedLactateReason.AutoSize = true;
            this.lbl_ElevatedLactateReason.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ElevatedLactateReason.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ElevatedLactateReason.ForeColor = System.Drawing.Color.Black;
            this.lbl_ElevatedLactateReason.Location = new System.Drawing.Point(449, 218);
            this.lbl_ElevatedLactateReason.Name = "lbl_ElevatedLactateReason";
            this.lbl_ElevatedLactateReason.Size = new System.Drawing.Size(14, 16);
            this.lbl_ElevatedLactateReason.TabIndex = 77;
            this.lbl_ElevatedLactateReason.Text = "*";
            // 
            // lbl_BloodCultureCollectionDatetime
            // 
            this.lbl_BloodCultureCollectionDatetime.AutoSize = true;
            this.lbl_BloodCultureCollectionDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_BloodCultureCollectionDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_BloodCultureCollectionDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_BloodCultureCollectionDatetime.Location = new System.Drawing.Point(841, 271);
            this.lbl_BloodCultureCollectionDatetime.Name = "lbl_BloodCultureCollectionDatetime";
            this.lbl_BloodCultureCollectionDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_BloodCultureCollectionDatetime.TabIndex = 75;
            this.lbl_BloodCultureCollectionDatetime.Text = "*";
            // 
            // lbl_BloodCultureCollectionAcceptableDelay
            // 
            this.lbl_BloodCultureCollectionAcceptableDelay.AutoSize = true;
            this.lbl_BloodCultureCollectionAcceptableDelay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_BloodCultureCollectionAcceptableDelay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_BloodCultureCollectionAcceptableDelay.ForeColor = System.Drawing.Color.Black;
            this.lbl_BloodCultureCollectionAcceptableDelay.Location = new System.Drawing.Point(450, 275);
            this.lbl_BloodCultureCollectionAcceptableDelay.Name = "lbl_BloodCultureCollectionAcceptableDelay";
            this.lbl_BloodCultureCollectionAcceptableDelay.Size = new System.Drawing.Size(14, 16);
            this.lbl_BloodCultureCollectionAcceptableDelay.TabIndex = 74;
            this.lbl_BloodCultureCollectionAcceptableDelay.Text = "*";
            // 
            // lbl_BloodCultureCollection
            // 
            this.lbl_BloodCultureCollection.AutoSize = true;
            this.lbl_BloodCultureCollection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_BloodCultureCollection.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_BloodCultureCollection.ForeColor = System.Drawing.Color.Black;
            this.lbl_BloodCultureCollection.Location = new System.Drawing.Point(28, 275);
            this.lbl_BloodCultureCollection.Name = "lbl_BloodCultureCollection";
            this.lbl_BloodCultureCollection.Size = new System.Drawing.Size(14, 16);
            this.lbl_BloodCultureCollection.TabIndex = 72;
            this.lbl_BloodCultureCollection.Text = "*";
            // 
            // lbl_InitialLactateLevelCollectionDatetime
            // 
            this.lbl_InitialLactateLevelCollectionDatetime.AutoSize = true;
            this.lbl_InitialLactateLevelCollectionDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_InitialLactateLevelCollectionDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_InitialLactateLevelCollectionDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_InitialLactateLevelCollectionDatetime.Location = new System.Drawing.Point(448, 156);
            this.lbl_InitialLactateLevelCollectionDatetime.Name = "lbl_InitialLactateLevelCollectionDatetime";
            this.lbl_InitialLactateLevelCollectionDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_InitialLactateLevelCollectionDatetime.TabIndex = 70;
            this.lbl_InitialLactateLevelCollectionDatetime.Text = "*";
            // 
            // lbl_SepticShockPresent
            // 
            this.lbl_SepticShockPresent.AutoSize = true;
            this.lbl_SepticShockPresent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SepticShockPresent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SepticShockPresent.ForeColor = System.Drawing.Color.Black;
            this.lbl_SepticShockPresent.Location = new System.Drawing.Point(27, 101);
            this.lbl_SepticShockPresent.Name = "lbl_SepticShockPresent";
            this.lbl_SepticShockPresent.Size = new System.Drawing.Size(14, 16);
            this.lbl_SepticShockPresent.TabIndex = 67;
            this.lbl_SepticShockPresent.Text = "*";
            // 
            // lbl_SevereSepsisPresentationDatetime
            // 
            this.lbl_SevereSepsisPresentationDatetime.AutoSize = true;
            this.lbl_SevereSepsisPresentationDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SevereSepsisPresentationDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SevereSepsisPresentationDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_SevereSepsisPresentationDatetime.Location = new System.Drawing.Point(839, 34);
            this.lbl_SevereSepsisPresentationDatetime.Name = "lbl_SevereSepsisPresentationDatetime";
            this.lbl_SevereSepsisPresentationDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_SevereSepsisPresentationDatetime.TabIndex = 66;
            this.lbl_SevereSepsisPresentationDatetime.Text = "*";
            // 
            // lbl_SevereSepsisPresent
            // 
            this.lbl_SevereSepsisPresent.AutoSize = true;
            this.lbl_SevereSepsisPresent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SevereSepsisPresent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SevereSepsisPresent.ForeColor = System.Drawing.Color.Black;
            this.lbl_SevereSepsisPresent.Location = new System.Drawing.Point(450, 37);
            this.lbl_SevereSepsisPresent.Name = "lbl_SevereSepsisPresent";
            this.lbl_SevereSepsisPresent.Size = new System.Drawing.Size(14, 16);
            this.lbl_SevereSepsisPresent.TabIndex = 65;
            this.lbl_SevereSepsisPresent.Text = "*";
            // 
            // lbl_EarliestDatetime
            // 
            this.lbl_EarliestDatetime.AutoSize = true;
            this.lbl_EarliestDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_EarliestDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EarliestDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_EarliestDatetime.Location = new System.Drawing.Point(22, 38);
            this.lbl_EarliestDatetime.Name = "lbl_EarliestDatetime";
            this.lbl_EarliestDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_EarliestDatetime.TabIndex = 64;
            this.lbl_EarliestDatetime.Text = "*";
            // 
            // textBox_AntibioticAdministrationDatetime
            // 
            this.textBox_AntibioticAdministrationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_AntibioticAdministrationDatetime.Location = new System.Drawing.Point(467, 333);
            this.textBox_AntibioticAdministrationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_AntibioticAdministrationDatetime.Name = "textBox_AntibioticAdministrationDatetime";
            this.textBox_AntibioticAdministrationDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_AntibioticAdministrationDatetime.TabIndex = 14;
            this.textBox_AntibioticAdministrationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_AntibioticAdministrationDatetime.Enter += new System.EventHandler(this.textBox_AntibioticAdministrationDatetime_Enter);
            this.textBox_AntibioticAdministrationDatetime.Leave += new System.EventHandler(this.textBox_AntibioticAdministrationDatetime_Leave);
            // 
            // textBox_BloodCultureCollectionDatetime
            // 
            this.textBox_BloodCultureCollectionDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_BloodCultureCollectionDatetime.Location = new System.Drawing.Point(857, 271);
            this.textBox_BloodCultureCollectionDatetime.Mask = "00/00/0000 90:00";
            this.textBox_BloodCultureCollectionDatetime.Name = "textBox_BloodCultureCollectionDatetime";
            this.textBox_BloodCultureCollectionDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_BloodCultureCollectionDatetime.TabIndex = 12;
            this.textBox_BloodCultureCollectionDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_BloodCultureCollectionDatetime.Enter += new System.EventHandler(this.textBox_BloodCultureCollectionDatetime_Enter);
            this.textBox_BloodCultureCollectionDatetime.Leave += new System.EventHandler(this.textBox_BloodCultureCollectionDatetime_Leave);
            // 
            // textBox_VasopressorAdministrationStartDatetime
            // 
            this.textBox_VasopressorAdministrationStartDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_VasopressorAdministrationStartDatetime.Location = new System.Drawing.Point(464, 446);
            this.textBox_VasopressorAdministrationStartDatetime.Mask = "00/00/0000 90:00";
            this.textBox_VasopressorAdministrationStartDatetime.Name = "textBox_VasopressorAdministrationStartDatetime";
            this.textBox_VasopressorAdministrationStartDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_VasopressorAdministrationStartDatetime.TabIndex = 18;
            this.textBox_VasopressorAdministrationStartDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_VasopressorAdministrationStartDatetime.Enter += new System.EventHandler(this.textBox_VasopressorAdministrationDatetime_Enter);
            this.textBox_VasopressorAdministrationStartDatetime.Leave += new System.EventHandler(this.textBox_VasopressorAdministrationDatetime_Leave);
            // 
            // textBox_CrystalloidFluidAdministrationDatetime
            // 
            this.textBox_CrystalloidFluidAdministrationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_CrystalloidFluidAdministrationDatetime.Location = new System.Drawing.Point(468, 389);
            this.textBox_CrystalloidFluidAdministrationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_CrystalloidFluidAdministrationDatetime.Name = "textBox_CrystalloidFluidAdministrationDatetime";
            this.textBox_CrystalloidFluidAdministrationDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_CrystalloidFluidAdministrationDatetime.TabIndex = 16;
            this.textBox_CrystalloidFluidAdministrationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_CrystalloidFluidAdministrationDatetime.Enter += new System.EventHandler(this.textBox_CrystalloidFluidAdministrationDatetime_Enter);
            this.textBox_CrystalloidFluidAdministrationDatetime.Leave += new System.EventHandler(this.textBox_CrystalloidFluidAdministrationDatetime_Leave);
            // 
            // textBox_InitialLactateLevelCollectionDatetime
            // 
            this.textBox_InitialLactateLevelCollectionDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_InitialLactateLevelCollectionDatetime.Location = new System.Drawing.Point(465, 156);
            this.textBox_InitialLactateLevelCollectionDatetime.Mask = "00/00/0000 90:00";
            this.textBox_InitialLactateLevelCollectionDatetime.Name = "textBox_InitialLactateLevelCollectionDatetime";
            this.textBox_InitialLactateLevelCollectionDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_InitialLactateLevelCollectionDatetime.TabIndex = 7;
            this.textBox_InitialLactateLevelCollectionDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_InitialLactateLevelCollectionDatetime.Enter += new System.EventHandler(this.textBox_InitialLactateLevelCollectionDatetime_Enter);
            this.textBox_InitialLactateLevelCollectionDatetime.Leave += new System.EventHandler(this.textBox_InitialLactateLevelCollectionDatetime_Leave);
            // 
            // textBox_septicShockPresentationDatetime
            // 
            this.textBox_septicShockPresentationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_septicShockPresentationDatetime.Location = new System.Drawing.Point(465, 99);
            this.textBox_septicShockPresentationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_septicShockPresentationDatetime.Name = "textBox_septicShockPresentationDatetime";
            this.textBox_septicShockPresentationDatetime.Size = new System.Drawing.Size(100, 20);
            this.textBox_septicShockPresentationDatetime.TabIndex = 5;
            this.textBox_septicShockPresentationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_septicShockPresentationDatetime.Enter += new System.EventHandler(this.textBox_septicShockPresentationDatetime_Enter);
            this.textBox_septicShockPresentationDatetime.Leave += new System.EventHandler(this.textBox_septicShockPresentationDatetime_Leave);
            // 
            // textBox_SevereSepsisPresentationDatetime
            // 
            this.textBox_SevereSepsisPresentationDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_SevereSepsisPresentationDatetime.Location = new System.Drawing.Point(854, 33);
            this.textBox_SevereSepsisPresentationDatetime.Mask = "00/00/0000 90:00";
            this.textBox_SevereSepsisPresentationDatetime.Name = "textBox_SevereSepsisPresentationDatetime";
            this.textBox_SevereSepsisPresentationDatetime.Size = new System.Drawing.Size(93, 20);
            this.textBox_SevereSepsisPresentationDatetime.TabIndex = 3;
            this.textBox_SevereSepsisPresentationDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_SevereSepsisPresentationDatetime.Enter += new System.EventHandler(this.textBox_SevereSepsisPresentationDatetime_Enter);
            this.textBox_SevereSepsisPresentationDatetime.Leave += new System.EventHandler(this.textBox_SevereSepsisPresentationDatetime_Leave);
            // 
            // textbox_TriageDatetime
            // 
            this.textbox_TriageDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textbox_TriageDatetime.Location = new System.Drawing.Point(243, 32);
            this.textbox_TriageDatetime.Mask = "00/00/0000 90:00";
            this.textbox_TriageDatetime.Name = "textbox_TriageDatetime";
            this.textbox_TriageDatetime.Size = new System.Drawing.Size(100, 20);
            this.textbox_TriageDatetime.TabIndex = 1;
            this.textbox_TriageDatetime.ValidatingType = typeof(System.DateTime);
            this.textbox_TriageDatetime.Enter += new System.EventHandler(this.textbox_TriageDatetime_Enter);
            this.textbox_TriageDatetime.Leave += new System.EventHandler(this.textbox_TriageDatetime_Leave);
            // 
            // textBox_ArrivalDatetime
            // 
            this.textBox_ArrivalDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_ArrivalDatetime.Location = new System.Drawing.Point(38, 34);
            this.textBox_ArrivalDatetime.Mask = "00/00/0000 90:00";
            this.textBox_ArrivalDatetime.Name = "textBox_ArrivalDatetime";
            this.textBox_ArrivalDatetime.Size = new System.Drawing.Size(95, 20);
            this.textBox_ArrivalDatetime.TabIndex = 0;
            this.textBox_ArrivalDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_ArrivalDatetime.Enter += new System.EventHandler(this.textBox_EarliestDatetime_Enter);
            this.textBox_ArrivalDatetime.Leave += new System.EventHandler(this.textBox_EarliestDatetime_Leave);
            // 
            // comboBox_VasopressorAdministration
            // 
            this.comboBox_VasopressorAdministration.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_VasopressorAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_VasopressorAdministration.FormattingEnabled = true;
            this.comboBox_VasopressorAdministration.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_VasopressorAdministration.Location = new System.Drawing.Point(47, 445);
            this.comboBox_VasopressorAdministration.Name = "comboBox_VasopressorAdministration";
            this.comboBox_VasopressorAdministration.Size = new System.Drawing.Size(100, 21);
            this.comboBox_VasopressorAdministration.TabIndex = 17;
            this.comboBox_VasopressorAdministration.SelectedIndexChanged += new System.EventHandler(this.comboBox_VasopressorAdministration_SelectedIndexChanged);
            this.comboBox_VasopressorAdministration.Leave += new System.EventHandler(this.comboBox_VasopressorAdministration_Leave);
            // 
            // comboBox_BloodCultureCollection
            // 
            this.comboBox_BloodCultureCollection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_BloodCultureCollection.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_BloodCultureCollection.FormattingEnabled = true;
            this.comboBox_BloodCultureCollection.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_BloodCultureCollection.Location = new System.Drawing.Point(45, 275);
            this.comboBox_BloodCultureCollection.Name = "comboBox_BloodCultureCollection";
            this.comboBox_BloodCultureCollection.Size = new System.Drawing.Size(190, 21);
            this.comboBox_BloodCultureCollection.TabIndex = 10;
            this.comboBox_BloodCultureCollection.SelectedIndexChanged += new System.EventHandler(this.comboBox_BloodCultureCollection_SelectedIndexChanged);
            this.comboBox_BloodCultureCollection.Leave += new System.EventHandler(this.comboBox_BloodCultureCollection_Leave);
            // 
            // comboBox_BloodCultureCollectionAcceptableDelay
            // 
            this.comboBox_BloodCultureCollectionAcceptableDelay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_BloodCultureCollectionAcceptableDelay.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_BloodCultureCollectionAcceptableDelay.FormattingEnabled = true;
            this.comboBox_BloodCultureCollectionAcceptableDelay.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_BloodCultureCollectionAcceptableDelay.Location = new System.Drawing.Point(468, 275);
            this.comboBox_BloodCultureCollectionAcceptableDelay.Name = "comboBox_BloodCultureCollectionAcceptableDelay";
            this.comboBox_BloodCultureCollectionAcceptableDelay.Size = new System.Drawing.Size(169, 21);
            this.comboBox_BloodCultureCollectionAcceptableDelay.TabIndex = 11;
            this.comboBox_BloodCultureCollectionAcceptableDelay.Leave += new System.EventHandler(this.comboBox_BloodCultureCollectionAcceptableDelay_Leave);
            // 
            // comboBox_ElevatedLactateReason
            // 
            this.comboBox_ElevatedLactateReason.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ElevatedLactateReason.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ElevatedLactateReason.FormattingEnabled = true;
            this.comboBox_ElevatedLactateReason.Items.AddRange(new object[] {
            "Select",
            "No pathogen reported",
            "Gram positive bacteria",
            "Gram negative bacteria",
            "Anaerobic bacteria",
            "Yeast",
            "Mold",
            "Mixed pathogens",
            "Viral"});
            this.comboBox_ElevatedLactateReason.Location = new System.Drawing.Point(466, 214);
            this.comboBox_ElevatedLactateReason.Name = "comboBox_ElevatedLactateReason";
            this.comboBox_ElevatedLactateReason.Size = new System.Drawing.Size(190, 21);
            this.comboBox_ElevatedLactateReason.TabIndex = 9;
            this.comboBox_ElevatedLactateReason.SelectedIndexChanged += new System.EventHandler(this.comboBox_ElevatedLactateReason_SelectedIndexChanged);
            // 
            // comboBox_AntibioticAdministration
            // 
            this.comboBox_AntibioticAdministration.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AntibioticAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_AntibioticAdministration.FormattingEnabled = true;
            this.comboBox_AntibioticAdministration.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_AntibioticAdministration.Location = new System.Drawing.Point(44, 333);
            this.comboBox_AntibioticAdministration.Name = "comboBox_AntibioticAdministration";
            this.comboBox_AntibioticAdministration.Size = new System.Drawing.Size(192, 21);
            this.comboBox_AntibioticAdministration.TabIndex = 13;
            this.comboBox_AntibioticAdministration.SelectedIndexChanged += new System.EventHandler(this.comboBox_AntibioticAdministration_SelectedIndexChanged);
            this.comboBox_AntibioticAdministration.Leave += new System.EventHandler(this.comboBox_AntibioticAdministration_Leave);
            // 
            // comboBox_SepticShockPresent
            // 
            this.comboBox_SepticShockPresent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_SepticShockPresent.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_SepticShockPresent.FormattingEnabled = true;
            this.comboBox_SepticShockPresent.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_SepticShockPresent.Location = new System.Drawing.Point(43, 101);
            this.comboBox_SepticShockPresent.Name = "comboBox_SepticShockPresent";
            this.comboBox_SepticShockPresent.Size = new System.Drawing.Size(191, 21);
            this.comboBox_SepticShockPresent.TabIndex = 4;
            this.comboBox_SepticShockPresent.SelectedIndexChanged += new System.EventHandler(this.comboBox_SepticShockPresent_SelectedIndexChanged);
            // 
            // comboBox_InitialLactateLevelCollection
            // 
            this.comboBox_InitialLactateLevelCollection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_InitialLactateLevelCollection.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_InitialLactateLevelCollection.FormattingEnabled = true;
            this.comboBox_InitialLactateLevelCollection.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_InitialLactateLevelCollection.Location = new System.Drawing.Point(44, 154);
            this.comboBox_InitialLactateLevelCollection.Name = "comboBox_InitialLactateLevelCollection";
            this.comboBox_InitialLactateLevelCollection.Size = new System.Drawing.Size(190, 21);
            this.comboBox_InitialLactateLevelCollection.TabIndex = 6;
            this.comboBox_InitialLactateLevelCollection.SelectedIndexChanged += new System.EventHandler(this.comboBox_InitialLactateLevelCollection_SelectedIndexChanged);
            this.comboBox_InitialLactateLevelCollection.Leave += new System.EventHandler(this.comboBox_InitialLactateLevelCollection_Leave);
            // 
            // comboBox_SevereSepsisPresent
            // 
            this.comboBox_SevereSepsisPresent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_SevereSepsisPresent.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_SevereSepsisPresent.FormattingEnabled = true;
            this.comboBox_SevereSepsisPresent.Items.AddRange(new object[] {
            "",
            "Severe Sepsis was present.",
            "Severe Sepsis was not present, or Unable to Determine."});
            this.comboBox_SevereSepsisPresent.Location = new System.Drawing.Point(465, 33);
            this.comboBox_SevereSepsisPresent.Name = "comboBox_SevereSepsisPresent";
            this.comboBox_SevereSepsisPresent.Size = new System.Drawing.Size(291, 21);
            this.comboBox_SevereSepsisPresent.TabIndex = 2;
            this.comboBox_SevereSepsisPresent.SelectedIndexChanged += new System.EventHandler(this.comboBox_SevereSepsisPresent_SelectedIndexChanged);
            // 
            // label_VasopressorAdministration
            // 
            this.label_VasopressorAdministration.AutoSize = true;
            this.label_VasopressorAdministration.Location = new System.Drawing.Point(44, 429);
            this.label_VasopressorAdministration.Name = "label_VasopressorAdministration";
            this.label_VasopressorAdministration.Size = new System.Drawing.Size(136, 13);
            this.label_VasopressorAdministration.TabIndex = 30;
            this.label_VasopressorAdministration.Text = "Vasopressor Administration:";
            // 
            // label_VasopressorAdministrationStartDateTime
            // 
            this.label_VasopressorAdministrationStartDateTime.AutoSize = true;
            this.label_VasopressorAdministrationStartDateTime.Location = new System.Drawing.Point(461, 429);
            this.label_VasopressorAdministrationStartDateTime.Name = "label_VasopressorAdministrationStartDateTime";
            this.label_VasopressorAdministrationStartDateTime.Size = new System.Drawing.Size(215, 13);
            this.label_VasopressorAdministrationStartDateTime.TabIndex = 29;
            this.label_VasopressorAdministrationStartDateTime.Text = "Vasopressor Administration Start Date/Time:";
            // 
            // Label_CrystalloidFluidAdministrationDatetime
            // 
            this.Label_CrystalloidFluidAdministrationDatetime.AutoSize = true;
            this.Label_CrystalloidFluidAdministrationDatetime.Location = new System.Drawing.Point(465, 373);
            this.Label_CrystalloidFluidAdministrationDatetime.Name = "Label_CrystalloidFluidAdministrationDatetime";
            this.Label_CrystalloidFluidAdministrationDatetime.Size = new System.Drawing.Size(204, 13);
            this.Label_CrystalloidFluidAdministrationDatetime.TabIndex = 26;
            this.Label_CrystalloidFluidAdministrationDatetime.Text = "Crystalloid Fluid Administration Date/Time:";
            // 
            // Label_CrystalloidFluidAdministration
            // 
            this.Label_CrystalloidFluidAdministration.AutoSize = true;
            this.Label_CrystalloidFluidAdministration.Location = new System.Drawing.Point(42, 373);
            this.Label_CrystalloidFluidAdministration.Name = "Label_CrystalloidFluidAdministration";
            this.Label_CrystalloidFluidAdministration.Size = new System.Drawing.Size(150, 13);
            this.Label_CrystalloidFluidAdministration.TabIndex = 25;
            this.Label_CrystalloidFluidAdministration.Text = "Crystalloid Fluid Administration:";
            // 
            // Label_AntibioticAdministrationDatetime
            // 
            this.Label_AntibioticAdministrationDatetime.AutoSize = true;
            this.Label_AntibioticAdministrationDatetime.Location = new System.Drawing.Point(464, 317);
            this.Label_AntibioticAdministrationDatetime.Name = "Label_AntibioticAdministrationDatetime";
            this.Label_AntibioticAdministrationDatetime.Size = new System.Drawing.Size(175, 13);
            this.Label_AntibioticAdministrationDatetime.TabIndex = 23;
            this.Label_AntibioticAdministrationDatetime.Text = "Antibiotic Administration Date/Time:";
            // 
            // Label_ElevatedLactateReason
            // 
            this.Label_ElevatedLactateReason.AutoSize = true;
            this.Label_ElevatedLactateReason.Location = new System.Drawing.Point(463, 198);
            this.Label_ElevatedLactateReason.Name = "Label_ElevatedLactateReason";
            this.Label_ElevatedLactateReason.Size = new System.Drawing.Size(131, 13);
            this.Label_ElevatedLactateReason.TabIndex = 22;
            this.Label_ElevatedLactateReason.Text = "Elevated Lactate Reason:";
            // 
            // Label_BloodCultureCollection
            // 
            this.Label_BloodCultureCollection.AutoSize = true;
            this.Label_BloodCultureCollection.Location = new System.Drawing.Point(41, 257);
            this.Label_BloodCultureCollection.Name = "Label_BloodCultureCollection";
            this.Label_BloodCultureCollection.Size = new System.Drawing.Size(122, 13);
            this.Label_BloodCultureCollection.TabIndex = 21;
            this.Label_BloodCultureCollection.Text = "Blood Culture Collection:";
            // 
            // Label_InitialLactateLevel
            // 
            this.Label_InitialLactateLevel.AutoSize = true;
            this.Label_InitialLactateLevel.Location = new System.Drawing.Point(41, 198);
            this.Label_InitialLactateLevel.Name = "Label_InitialLactateLevel";
            this.Label_InitialLactateLevel.Size = new System.Drawing.Size(102, 13);
            this.Label_InitialLactateLevel.TabIndex = 19;
            this.Label_InitialLactateLevel.Text = "Initial Lactate Level:";
            // 
            // Label_SevereSepsisPresent
            // 
            this.Label_SevereSepsisPresent.AutoSize = true;
            this.Label_SevereSepsisPresent.Location = new System.Drawing.Point(462, 16);
            this.Label_SevereSepsisPresent.Name = "Label_SevereSepsisPresent";
            this.Label_SevereSepsisPresent.Size = new System.Drawing.Size(117, 13);
            this.Label_SevereSepsisPresent.TabIndex = 18;
            this.Label_SevereSepsisPresent.Text = "Severe Sepsis Present:";
            // 
            // Label_BloodCultureCollectionAcceptableDelay
            // 
            this.Label_BloodCultureCollectionAcceptableDelay.AutoSize = true;
            this.Label_BloodCultureCollectionAcceptableDelay.Location = new System.Drawing.Point(465, 257);
            this.Label_BloodCultureCollectionAcceptableDelay.Name = "Label_BloodCultureCollectionAcceptableDelay";
            this.Label_BloodCultureCollectionAcceptableDelay.Size = new System.Drawing.Size(209, 13);
            this.Label_BloodCultureCollectionAcceptableDelay.TabIndex = 17;
            this.Label_BloodCultureCollectionAcceptableDelay.Text = "Blood Culture Collection Acceptable Delay:";
            // 
            // Label_SevereSepsisPresentationDatetime
            // 
            this.Label_SevereSepsisPresentationDatetime.Location = new System.Drawing.Point(854, 11);
            this.Label_SevereSepsisPresentationDatetime.Name = "Label_SevereSepsisPresentationDatetime";
            this.Label_SevereSepsisPresentationDatetime.Size = new System.Drawing.Size(214, 15);
            this.Label_SevereSepsisPresentationDatetime.TabIndex = 16;
            this.Label_SevereSepsisPresentationDatetime.Text = "Severe Sepsis Presentation Date/Time:";
            this.Label_SevereSepsisPresentationDatetime.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Label_AntibioticAdministration
            // 
            this.Label_AntibioticAdministration.AutoSize = true;
            this.Label_AntibioticAdministration.Location = new System.Drawing.Point(39, 317);
            this.Label_AntibioticAdministration.Name = "Label_AntibioticAdministration";
            this.Label_AntibioticAdministration.Size = new System.Drawing.Size(121, 13);
            this.Label_AntibioticAdministration.TabIndex = 14;
            this.Label_AntibioticAdministration.Text = "Antibiotic Administration:";
            // 
            // Label_InitialLactateLevelCollectionDatetime
            // 
            this.Label_InitialLactateLevelCollectionDatetime.AutoSize = true;
            this.Label_InitialLactateLevelCollectionDatetime.Location = new System.Drawing.Point(462, 139);
            this.Label_InitialLactateLevelCollectionDatetime.Name = "Label_InitialLactateLevelCollectionDatetime";
            this.Label_InitialLactateLevelCollectionDatetime.Size = new System.Drawing.Size(205, 13);
            this.Label_InitialLactateLevelCollectionDatetime.TabIndex = 10;
            this.Label_InitialLactateLevelCollectionDatetime.Text = "Initial Lactate Level Collection Date/Time:";
            // 
            // Label_SepticShockPresentationDatetime
            // 
            this.Label_SepticShockPresentationDatetime.Location = new System.Drawing.Point(462, 74);
            this.Label_SepticShockPresentationDatetime.Name = "Label_SepticShockPresentationDatetime";
            this.Label_SepticShockPresentationDatetime.Size = new System.Drawing.Size(204, 20);
            this.Label_SepticShockPresentationDatetime.TabIndex = 9;
            this.Label_SepticShockPresentationDatetime.Text = "Septic Shock Presentation Date/Time:";
            // 
            // Label_BloodCultureCollectionDatetime
            // 
            this.Label_BloodCultureCollectionDatetime.AutoSize = true;
            this.Label_BloodCultureCollectionDatetime.Location = new System.Drawing.Point(854, 252);
            this.Label_BloodCultureCollectionDatetime.Name = "Label_BloodCultureCollectionDatetime";
            this.Label_BloodCultureCollectionDatetime.Size = new System.Drawing.Size(176, 13);
            this.Label_BloodCultureCollectionDatetime.TabIndex = 8;
            this.Label_BloodCultureCollectionDatetime.Text = "Blood Culture Collection Date/Time:";
            // 
            // Label_SepticShockPresent
            // 
            this.Label_SepticShockPresent.Location = new System.Drawing.Point(39, 79);
            this.Label_SepticShockPresent.Name = "Label_SepticShockPresent";
            this.Label_SepticShockPresent.Size = new System.Drawing.Size(123, 15);
            this.Label_SepticShockPresent.TabIndex = 7;
            this.Label_SepticShockPresent.Text = "Septic Shock Present:";
            this.Label_SepticShockPresent.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Label_InitialLactateLevelCollection
            // 
            this.Label_InitialLactateLevelCollection.AutoSize = true;
            this.Label_InitialLactateLevelCollection.Location = new System.Drawing.Point(41, 139);
            this.Label_InitialLactateLevelCollection.Name = "Label_InitialLactateLevelCollection";
            this.Label_InitialLactateLevelCollection.Size = new System.Drawing.Size(151, 13);
            this.Label_InitialLactateLevelCollection.TabIndex = 6;
            this.Label_InitialLactateLevelCollection.Text = "Initial Lactate Level Collection:";
            // 
            // Label_TriageDatetime
            // 
            this.Label_TriageDatetime.AutoSize = true;
            this.Label_TriageDatetime.Location = new System.Drawing.Point(240, 13);
            this.Label_TriageDatetime.Name = "Label_TriageDatetime";
            this.Label_TriageDatetime.Size = new System.Drawing.Size(94, 13);
            this.Label_TriageDatetime.TabIndex = 4;
            this.Label_TriageDatetime.Text = "Triage Date/Time:";
            // 
            // Label_ArrivalDatetime
            // 
            this.Label_ArrivalDatetime.AutoSize = true;
            this.Label_ArrivalDatetime.Location = new System.Drawing.Point(27, 16);
            this.Label_ArrivalDatetime.Name = "Label_ArrivalDatetime";
            this.Label_ArrivalDatetime.Size = new System.Drawing.Size(93, 13);
            this.Label_ArrivalDatetime.TabIndex = 3;
            this.Label_ArrivalDatetime.Text = "Arrival Date/Time:";
            // 
            // comboBox_CrystalloidFluidAdministration
            // 
            this.comboBox_CrystalloidFluidAdministration.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_CrystalloidFluidAdministration.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_CrystalloidFluidAdministration.FormattingEnabled = true;
            this.comboBox_CrystalloidFluidAdministration.Location = new System.Drawing.Point(47, 389);
            this.comboBox_CrystalloidFluidAdministration.Name = "comboBox_CrystalloidFluidAdministration";
            this.comboBox_CrystalloidFluidAdministration.Size = new System.Drawing.Size(334, 21);
            this.comboBox_CrystalloidFluidAdministration.TabIndex = 15;
            this.comboBox_CrystalloidFluidAdministration.SelectedIndexChanged += new System.EventHandler(this.comboBox_CrystalloidFluidAdministration_SelectedIndexChanged);
            this.comboBox_CrystalloidFluidAdministration.Leave += new System.EventHandler(this.comboBox_CrystalloidFluidAdministration_Leave);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.comboBox_MechanicalVentilationTransfer);
            this.tabPage4.Controls.Add(this.lbl_MechanicalVentaltionTransfer);
            this.tabPage4.Controls.Add(this.label_MechanicalVentaltionTransfer);
            this.tabPage4.Controls.Add(this.lbl_MechanicalVentilationEndDateTime);
            this.tabPage4.Controls.Add(this.textBox_MechanicalVentilationEndDatetime);
            this.tabPage4.Controls.Add(this.label_MechanicalVentilationEndDateTime);
            this.tabPage4.Controls.Add(this.lbl_ICUDischargeDatetime);
            this.tabPage4.Controls.Add(this.lbl_ICUAdmissionDatetime);
            this.tabPage4.Controls.Add(this.lbl_MechanicalVentilationStartDatetime);
            this.tabPage4.Controls.Add(this.lbl_Diabetes);
            this.tabPage4.Controls.Add(this.lbl_ChronicRenalFailure);
            this.tabPage4.Controls.Add(this.lbl_OrganTransplant);
            this.tabPage4.Controls.Add(this.lbl_ChronicLiverDisease);
            this.tabPage4.Controls.Add(this.lbl_CongestiveHeartFailure);
            this.tabPage4.Controls.Add(this.lbl_ImmuneModifyingMedications);
            this.tabPage4.Controls.Add(this.lbl_Lymphoma);
            this.tabPage4.Controls.Add(this.lbl_MetastaticCancer);
            this.tabPage4.Controls.Add(this.lbl_AIDSDisease);
            this.tabPage4.Controls.Add(this.lbl_ChronicRespiratoryFailure);
            this.tabPage4.Controls.Add(this.lbl_ICU);
            this.tabPage4.Controls.Add(this.lbl_MechanicalVentilation);
            this.tabPage4.Controls.Add(this.lbl_SiteofInfection);
            this.tabPage4.Controls.Add(this.lbl_LowerRespiratoryInfection);
            this.tabPage4.Controls.Add(this.lbl_InfectionEtiology);
            this.tabPage4.Controls.Add(this.lbl_Bandemia);
            this.tabPage4.Controls.Add(this.lbl_AlteredMentalStatus);
            this.tabPage4.Controls.Add(this.lbl_PlateletCount);
            this.tabPage4.Controls.Add(this.textBox_ICUDischargeDatetime);
            this.tabPage4.Controls.Add(this.textBox_ICUAdmissionDatetime);
            this.tabPage4.Controls.Add(this.textBox_MechanicalVentilationStartDatetime);
            this.tabPage4.Controls.Add(this.comboBox_ICU);
            this.tabPage4.Controls.Add(this.comboBox_AIDSDisease);
            this.tabPage4.Controls.Add(this.comboBox_ChronicRespiratoryFailure);
            this.tabPage4.Controls.Add(this.comboBox_MechanicalVentilation);
            this.tabPage4.Controls.Add(this.comboBox_InfectionEtiology);
            this.tabPage4.Controls.Add(this.comboBox_SiteofInfection);
            this.tabPage4.Controls.Add(this.comboBox_Lymphoma);
            this.tabPage4.Controls.Add(this.comboBox_AlteredMentalStatus);
            this.tabPage4.Controls.Add(this.comboBox_Diabetes);
            this.tabPage4.Controls.Add(this.comboBox_ChronicLiverDisease);
            this.tabPage4.Controls.Add(this.comboBox_OrganTransplant);
            this.tabPage4.Controls.Add(this.comboBox_ImmuneModifyingMedications);
            this.tabPage4.Controls.Add(this.comboBox_ChronicRenalFailure);
            this.tabPage4.Controls.Add(this.comboBox_CongestiveHeartFailure);
            this.tabPage4.Controls.Add(this.comboBox_PlateletCount);
            this.tabPage4.Controls.Add(this.comboBox_Bandemia);
            this.tabPage4.Controls.Add(this.comboBox_LowerRespiratoryInfection);
            this.tabPage4.Controls.Add(this.comboBox_MetastaticCancer);
            this.tabPage4.Controls.Add(this.label43);
            this.tabPage4.Controls.Add(this.label44);
            this.tabPage4.Controls.Add(this.label45);
            this.tabPage4.Controls.Add(this.label47);
            this.tabPage4.Controls.Add(this.label48);
            this.tabPage4.Controls.Add(this.label49);
            this.tabPage4.Controls.Add(this.label50);
            this.tabPage4.Controls.Add(this.label51);
            this.tabPage4.Controls.Add(this.label1);
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.label6);
            this.tabPage4.Controls.Add(this.label11);
            this.tabPage4.Controls.Add(this.label_MechanicalVentilationStartDateTime);
            this.tabPage4.Controls.Add(this.label31);
            this.tabPage4.Controls.Add(this.label33);
            this.tabPage4.Controls.Add(this.label34);
            this.tabPage4.Controls.Add(this.label35);
            this.tabPage4.Controls.Add(this.label36);
            this.tabPage4.Controls.Add(this.label37);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1233, 551);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Severity/Comorbidity";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // comboBox_MechanicalVentilationTransfer
            // 
            this.comboBox_MechanicalVentilationTransfer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_MechanicalVentilationTransfer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_MechanicalVentilationTransfer.FormattingEnabled = true;
            this.comboBox_MechanicalVentilationTransfer.Location = new System.Drawing.Point(856, 152);
            this.comboBox_MechanicalVentilationTransfer.Name = "comboBox_MechanicalVentilationTransfer";
            this.comboBox_MechanicalVentilationTransfer.Size = new System.Drawing.Size(334, 21);
            this.comboBox_MechanicalVentilationTransfer.TabIndex = 9;
            this.comboBox_MechanicalVentilationTransfer.SelectedIndexChanged += new System.EventHandler(this.comboBox_MechanicalVentilationTransfer_SelectedIndexChanged);
            // 
            // lbl_MechanicalVentaltionTransfer
            // 
            this.lbl_MechanicalVentaltionTransfer.AutoSize = true;
            this.lbl_MechanicalVentaltionTransfer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_MechanicalVentaltionTransfer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MechanicalVentaltionTransfer.ForeColor = System.Drawing.Color.Black;
            this.lbl_MechanicalVentaltionTransfer.Location = new System.Drawing.Point(841, 152);
            this.lbl_MechanicalVentaltionTransfer.Name = "lbl_MechanicalVentaltionTransfer";
            this.lbl_MechanicalVentaltionTransfer.Size = new System.Drawing.Size(14, 16);
            this.lbl_MechanicalVentaltionTransfer.TabIndex = 100;
            this.lbl_MechanicalVentaltionTransfer.Text = "*";
            // 
            // label_MechanicalVentaltionTransfer
            // 
            this.label_MechanicalVentaltionTransfer.AutoSize = true;
            this.label_MechanicalVentaltionTransfer.Location = new System.Drawing.Point(853, 136);
            this.label_MechanicalVentaltionTransfer.Name = "label_MechanicalVentaltionTransfer";
            this.label_MechanicalVentaltionTransfer.Size = new System.Drawing.Size(157, 13);
            this.label_MechanicalVentaltionTransfer.TabIndex = 99;
            this.label_MechanicalVentaltionTransfer.Text = "Mechanical Ventaltion Transfer:";
            // 
            // lbl_MechanicalVentilationEndDateTime
            // 
            this.lbl_MechanicalVentilationEndDateTime.AutoSize = true;
            this.lbl_MechanicalVentilationEndDateTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_MechanicalVentilationEndDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MechanicalVentilationEndDateTime.ForeColor = System.Drawing.Color.Black;
            this.lbl_MechanicalVentilationEndDateTime.Location = new System.Drawing.Point(584, 151);
            this.lbl_MechanicalVentilationEndDateTime.Name = "lbl_MechanicalVentilationEndDateTime";
            this.lbl_MechanicalVentilationEndDateTime.Size = new System.Drawing.Size(14, 16);
            this.lbl_MechanicalVentilationEndDateTime.TabIndex = 97;
            this.lbl_MechanicalVentilationEndDateTime.Text = "*";
            // 
            // textBox_MechanicalVentilationEndDatetime
            // 
            this.textBox_MechanicalVentilationEndDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_MechanicalVentilationEndDatetime.Location = new System.Drawing.Point(599, 152);
            this.textBox_MechanicalVentilationEndDatetime.Mask = "00/00/0000 90:00";
            this.textBox_MechanicalVentilationEndDatetime.Name = "textBox_MechanicalVentilationEndDatetime";
            this.textBox_MechanicalVentilationEndDatetime.Size = new System.Drawing.Size(95, 20);
            this.textBox_MechanicalVentilationEndDatetime.TabIndex = 8;
            this.textBox_MechanicalVentilationEndDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_MechanicalVentilationEndDatetime.Leave += new System.EventHandler(this.textBox_MechanicalVentilationEndDatetime_Leave);
            // 
            // label_MechanicalVentilationEndDateTime
            // 
            this.label_MechanicalVentilationEndDateTime.AutoSize = true;
            this.label_MechanicalVentilationEndDateTime.Location = new System.Drawing.Point(596, 136);
            this.label_MechanicalVentilationEndDateTime.Name = "label_MechanicalVentilationEndDateTime";
            this.label_MechanicalVentilationEndDateTime.Size = new System.Drawing.Size(193, 13);
            this.label_MechanicalVentilationEndDateTime.TabIndex = 96;
            this.label_MechanicalVentilationEndDateTime.Text = "Mechanical Ventilation End Date/Time:";
            // 
            // lbl_ICUDischargeDatetime
            // 
            this.lbl_ICUDischargeDatetime.AutoSize = true;
            this.lbl_ICUDischargeDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ICUDischargeDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ICUDischargeDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_ICUDischargeDatetime.Location = new System.Drawing.Point(584, 211);
            this.lbl_ICUDischargeDatetime.Name = "lbl_ICUDischargeDatetime";
            this.lbl_ICUDischargeDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_ICUDischargeDatetime.TabIndex = 94;
            this.lbl_ICUDischargeDatetime.Text = "*";
            // 
            // lbl_ICUAdmissionDatetime
            // 
            this.lbl_ICUAdmissionDatetime.AutoSize = true;
            this.lbl_ICUAdmissionDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ICUAdmissionDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ICUAdmissionDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_ICUAdmissionDatetime.Location = new System.Drawing.Point(315, 210);
            this.lbl_ICUAdmissionDatetime.Name = "lbl_ICUAdmissionDatetime";
            this.lbl_ICUAdmissionDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_ICUAdmissionDatetime.TabIndex = 93;
            this.lbl_ICUAdmissionDatetime.Text = "*";
            // 
            // lbl_MechanicalVentilationStartDatetime
            // 
            this.lbl_MechanicalVentilationStartDatetime.AutoSize = true;
            this.lbl_MechanicalVentilationStartDatetime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_MechanicalVentilationStartDatetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MechanicalVentilationStartDatetime.ForeColor = System.Drawing.Color.Black;
            this.lbl_MechanicalVentilationStartDatetime.Location = new System.Drawing.Point(315, 151);
            this.lbl_MechanicalVentilationStartDatetime.Name = "lbl_MechanicalVentilationStartDatetime";
            this.lbl_MechanicalVentilationStartDatetime.Size = new System.Drawing.Size(14, 16);
            this.lbl_MechanicalVentilationStartDatetime.TabIndex = 92;
            this.lbl_MechanicalVentilationStartDatetime.Text = "*";
            // 
            // lbl_Diabetes
            // 
            this.lbl_Diabetes.AutoSize = true;
            this.lbl_Diabetes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Diabetes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Diabetes.ForeColor = System.Drawing.Color.Black;
            this.lbl_Diabetes.Location = new System.Drawing.Point(17, 487);
            this.lbl_Diabetes.Name = "lbl_Diabetes";
            this.lbl_Diabetes.Size = new System.Drawing.Size(14, 16);
            this.lbl_Diabetes.TabIndex = 91;
            this.lbl_Diabetes.Text = "*";
            // 
            // lbl_ChronicRenalFailure
            // 
            this.lbl_ChronicRenalFailure.AutoSize = true;
            this.lbl_ChronicRenalFailure.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ChronicRenalFailure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ChronicRenalFailure.ForeColor = System.Drawing.Color.Black;
            this.lbl_ChronicRenalFailure.Location = new System.Drawing.Point(17, 434);
            this.lbl_ChronicRenalFailure.Name = "lbl_ChronicRenalFailure";
            this.lbl_ChronicRenalFailure.Size = new System.Drawing.Size(14, 16);
            this.lbl_ChronicRenalFailure.TabIndex = 90;
            this.lbl_ChronicRenalFailure.Text = "*";
            // 
            // lbl_OrganTransplant
            // 
            this.lbl_OrganTransplant.AutoSize = true;
            this.lbl_OrganTransplant.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_OrganTransplant.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_OrganTransplant.ForeColor = System.Drawing.Color.Black;
            this.lbl_OrganTransplant.Location = new System.Drawing.Point(583, 484);
            this.lbl_OrganTransplant.Name = "lbl_OrganTransplant";
            this.lbl_OrganTransplant.Size = new System.Drawing.Size(14, 16);
            this.lbl_OrganTransplant.TabIndex = 89;
            this.lbl_OrganTransplant.Text = "*";
            // 
            // lbl_ChronicLiverDisease
            // 
            this.lbl_ChronicLiverDisease.AutoSize = true;
            this.lbl_ChronicLiverDisease.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ChronicLiverDisease.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ChronicLiverDisease.ForeColor = System.Drawing.Color.Black;
            this.lbl_ChronicLiverDisease.Location = new System.Drawing.Point(584, 434);
            this.lbl_ChronicLiverDisease.Name = "lbl_ChronicLiverDisease";
            this.lbl_ChronicLiverDisease.Size = new System.Drawing.Size(14, 16);
            this.lbl_ChronicLiverDisease.TabIndex = 88;
            this.lbl_ChronicLiverDisease.Text = "*";
            // 
            // lbl_CongestiveHeartFailure
            // 
            this.lbl_CongestiveHeartFailure.AutoSize = true;
            this.lbl_CongestiveHeartFailure.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_CongestiveHeartFailure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CongestiveHeartFailure.ForeColor = System.Drawing.Color.Black;
            this.lbl_CongestiveHeartFailure.Location = new System.Drawing.Point(583, 379);
            this.lbl_CongestiveHeartFailure.Name = "lbl_CongestiveHeartFailure";
            this.lbl_CongestiveHeartFailure.Size = new System.Drawing.Size(14, 16);
            this.lbl_CongestiveHeartFailure.TabIndex = 87;
            this.lbl_CongestiveHeartFailure.Text = "*";
            // 
            // lbl_ImmuneModifyingMedications
            // 
            this.lbl_ImmuneModifyingMedications.AutoSize = true;
            this.lbl_ImmuneModifyingMedications.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ImmuneModifyingMedications.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ImmuneModifyingMedications.ForeColor = System.Drawing.Color.Black;
            this.lbl_ImmuneModifyingMedications.Location = new System.Drawing.Point(17, 379);
            this.lbl_ImmuneModifyingMedications.Name = "lbl_ImmuneModifyingMedications";
            this.lbl_ImmuneModifyingMedications.Size = new System.Drawing.Size(14, 16);
            this.lbl_ImmuneModifyingMedications.TabIndex = 86;
            this.lbl_ImmuneModifyingMedications.Text = "*";
            // 
            // lbl_Lymphoma
            // 
            this.lbl_Lymphoma.AutoSize = true;
            this.lbl_Lymphoma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Lymphoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Lymphoma.ForeColor = System.Drawing.Color.Black;
            this.lbl_Lymphoma.Location = new System.Drawing.Point(584, 323);
            this.lbl_Lymphoma.Name = "lbl_Lymphoma";
            this.lbl_Lymphoma.Size = new System.Drawing.Size(14, 16);
            this.lbl_Lymphoma.TabIndex = 85;
            this.lbl_Lymphoma.Text = "*";
            // 
            // lbl_MetastaticCancer
            // 
            this.lbl_MetastaticCancer.AutoSize = true;
            this.lbl_MetastaticCancer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_MetastaticCancer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MetastaticCancer.ForeColor = System.Drawing.Color.Black;
            this.lbl_MetastaticCancer.Location = new System.Drawing.Point(17, 323);
            this.lbl_MetastaticCancer.Name = "lbl_MetastaticCancer";
            this.lbl_MetastaticCancer.Size = new System.Drawing.Size(14, 16);
            this.lbl_MetastaticCancer.TabIndex = 84;
            this.lbl_MetastaticCancer.Text = "*";
            // 
            // lbl_AIDSDisease
            // 
            this.lbl_AIDSDisease.AutoSize = true;
            this.lbl_AIDSDisease.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_AIDSDisease.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AIDSDisease.ForeColor = System.Drawing.Color.Black;
            this.lbl_AIDSDisease.Location = new System.Drawing.Point(584, 273);
            this.lbl_AIDSDisease.Name = "lbl_AIDSDisease";
            this.lbl_AIDSDisease.Size = new System.Drawing.Size(14, 16);
            this.lbl_AIDSDisease.TabIndex = 83;
            this.lbl_AIDSDisease.Text = "*";
            // 
            // lbl_ChronicRespiratoryFailure
            // 
            this.lbl_ChronicRespiratoryFailure.AutoSize = true;
            this.lbl_ChronicRespiratoryFailure.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ChronicRespiratoryFailure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ChronicRespiratoryFailure.ForeColor = System.Drawing.Color.Black;
            this.lbl_ChronicRespiratoryFailure.Location = new System.Drawing.Point(17, 273);
            this.lbl_ChronicRespiratoryFailure.Name = "lbl_ChronicRespiratoryFailure";
            this.lbl_ChronicRespiratoryFailure.Size = new System.Drawing.Size(14, 16);
            this.lbl_ChronicRespiratoryFailure.TabIndex = 82;
            this.lbl_ChronicRespiratoryFailure.Text = "*";
            // 
            // lbl_ICU
            // 
            this.lbl_ICU.AutoSize = true;
            this.lbl_ICU.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ICU.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ICU.ForeColor = System.Drawing.Color.Black;
            this.lbl_ICU.Location = new System.Drawing.Point(17, 210);
            this.lbl_ICU.Name = "lbl_ICU";
            this.lbl_ICU.Size = new System.Drawing.Size(14, 16);
            this.lbl_ICU.TabIndex = 81;
            this.lbl_ICU.Text = "*";
            // 
            // lbl_MechanicalVentilation
            // 
            this.lbl_MechanicalVentilation.AutoSize = true;
            this.lbl_MechanicalVentilation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_MechanicalVentilation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MechanicalVentilation.ForeColor = System.Drawing.Color.Black;
            this.lbl_MechanicalVentilation.Location = new System.Drawing.Point(17, 152);
            this.lbl_MechanicalVentilation.Name = "lbl_MechanicalVentilation";
            this.lbl_MechanicalVentilation.Size = new System.Drawing.Size(14, 16);
            this.lbl_MechanicalVentilation.TabIndex = 80;
            this.lbl_MechanicalVentilation.Text = "*";
            // 
            // lbl_SiteofInfection
            // 
            this.lbl_SiteofInfection.AutoSize = true;
            this.lbl_SiteofInfection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_SiteofInfection.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SiteofInfection.ForeColor = System.Drawing.Color.Black;
            this.lbl_SiteofInfection.Location = new System.Drawing.Point(583, 94);
            this.lbl_SiteofInfection.Name = "lbl_SiteofInfection";
            this.lbl_SiteofInfection.Size = new System.Drawing.Size(14, 16);
            this.lbl_SiteofInfection.TabIndex = 79;
            this.lbl_SiteofInfection.Text = "*";
            // 
            // lbl_LowerRespiratoryInfection
            // 
            this.lbl_LowerRespiratoryInfection.AutoSize = true;
            this.lbl_LowerRespiratoryInfection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_LowerRespiratoryInfection.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_LowerRespiratoryInfection.ForeColor = System.Drawing.Color.Black;
            this.lbl_LowerRespiratoryInfection.Location = new System.Drawing.Point(584, 35);
            this.lbl_LowerRespiratoryInfection.Name = "lbl_LowerRespiratoryInfection";
            this.lbl_LowerRespiratoryInfection.Size = new System.Drawing.Size(14, 16);
            this.lbl_LowerRespiratoryInfection.TabIndex = 78;
            this.lbl_LowerRespiratoryInfection.Text = "*";
            // 
            // lbl_InfectionEtiology
            // 
            this.lbl_InfectionEtiology.AutoSize = true;
            this.lbl_InfectionEtiology.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_InfectionEtiology.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_InfectionEtiology.ForeColor = System.Drawing.Color.Black;
            this.lbl_InfectionEtiology.Location = new System.Drawing.Point(315, 91);
            this.lbl_InfectionEtiology.Name = "lbl_InfectionEtiology";
            this.lbl_InfectionEtiology.Size = new System.Drawing.Size(14, 16);
            this.lbl_InfectionEtiology.TabIndex = 77;
            this.lbl_InfectionEtiology.Text = "*";
            // 
            // lbl_Bandemia
            // 
            this.lbl_Bandemia.AutoSize = true;
            this.lbl_Bandemia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_Bandemia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Bandemia.ForeColor = System.Drawing.Color.Black;
            this.lbl_Bandemia.Location = new System.Drawing.Point(315, 33);
            this.lbl_Bandemia.Name = "lbl_Bandemia";
            this.lbl_Bandemia.Size = new System.Drawing.Size(14, 16);
            this.lbl_Bandemia.TabIndex = 76;
            this.lbl_Bandemia.Text = "*";
            // 
            // lbl_AlteredMentalStatus
            // 
            this.lbl_AlteredMentalStatus.AutoSize = true;
            this.lbl_AlteredMentalStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_AlteredMentalStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AlteredMentalStatus.ForeColor = System.Drawing.Color.Black;
            this.lbl_AlteredMentalStatus.Location = new System.Drawing.Point(16, 93);
            this.lbl_AlteredMentalStatus.Name = "lbl_AlteredMentalStatus";
            this.lbl_AlteredMentalStatus.Size = new System.Drawing.Size(14, 16);
            this.lbl_AlteredMentalStatus.TabIndex = 75;
            this.lbl_AlteredMentalStatus.Text = "*";
            // 
            // lbl_PlateletCount
            // 
            this.lbl_PlateletCount.AutoSize = true;
            this.lbl_PlateletCount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_PlateletCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PlateletCount.ForeColor = System.Drawing.Color.Black;
            this.lbl_PlateletCount.Location = new System.Drawing.Point(17, 37);
            this.lbl_PlateletCount.Name = "lbl_PlateletCount";
            this.lbl_PlateletCount.Size = new System.Drawing.Size(14, 16);
            this.lbl_PlateletCount.TabIndex = 74;
            this.lbl_PlateletCount.Text = "*";
            // 
            // textBox_ICUDischargeDatetime
            // 
            this.textBox_ICUDischargeDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_ICUDischargeDatetime.Location = new System.Drawing.Point(598, 211);
            this.textBox_ICUDischargeDatetime.Mask = "00/00/0000 90:00";
            this.textBox_ICUDischargeDatetime.Name = "textBox_ICUDischargeDatetime";
            this.textBox_ICUDischargeDatetime.Size = new System.Drawing.Size(95, 20);
            this.textBox_ICUDischargeDatetime.TabIndex = 12;
            this.textBox_ICUDischargeDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_ICUDischargeDatetime.Enter += new System.EventHandler(this.textBox_ICUDischargeDatetime_Enter);
            this.textBox_ICUDischargeDatetime.Leave += new System.EventHandler(this.textBox_ICUDischargeDatetime_Leave);
            // 
            // textBox_ICUAdmissionDatetime
            // 
            this.textBox_ICUAdmissionDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_ICUAdmissionDatetime.Location = new System.Drawing.Point(330, 211);
            this.textBox_ICUAdmissionDatetime.Mask = "00/00/0000 90:00";
            this.textBox_ICUAdmissionDatetime.Name = "textBox_ICUAdmissionDatetime";
            this.textBox_ICUAdmissionDatetime.Size = new System.Drawing.Size(95, 20);
            this.textBox_ICUAdmissionDatetime.TabIndex = 11;
            this.textBox_ICUAdmissionDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_ICUAdmissionDatetime.Enter += new System.EventHandler(this.textBox_ICUAdmissionDatetime_Enter);
            this.textBox_ICUAdmissionDatetime.Leave += new System.EventHandler(this.textBox_ICUAdmissionDatetime_Leave);
            // 
            // textBox_MechanicalVentilationStartDatetime
            // 
            this.textBox_MechanicalVentilationStartDatetime.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textBox_MechanicalVentilationStartDatetime.Location = new System.Drawing.Point(330, 152);
            this.textBox_MechanicalVentilationStartDatetime.Mask = "00/00/0000 90:00";
            this.textBox_MechanicalVentilationStartDatetime.Name = "textBox_MechanicalVentilationStartDatetime";
            this.textBox_MechanicalVentilationStartDatetime.Size = new System.Drawing.Size(95, 20);
            this.textBox_MechanicalVentilationStartDatetime.TabIndex = 7;
            this.textBox_MechanicalVentilationStartDatetime.ValidatingType = typeof(System.DateTime);
            this.textBox_MechanicalVentilationStartDatetime.Enter += new System.EventHandler(this.textBox_MechanicalVentilationStartDatetime_Enter);
            this.textBox_MechanicalVentilationStartDatetime.Leave += new System.EventHandler(this.textBox_MechanicalVentilationStartDatetime_Leave);
            // 
            // comboBox_ICU
            // 
            this.comboBox_ICU.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ICU.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ICU.FormattingEnabled = true;
            this.comboBox_ICU.Items.AddRange(new object[] {
            "Select",
            "Patient not admitted to ICU",
            "Patient admitted to ICU"});
            this.comboBox_ICU.Location = new System.Drawing.Point(32, 210);
            this.comboBox_ICU.Name = "comboBox_ICU";
            this.comboBox_ICU.Size = new System.Drawing.Size(265, 21);
            this.comboBox_ICU.TabIndex = 10;
            this.comboBox_ICU.SelectedIndexChanged += new System.EventHandler(this.comboBox_ICU_SelectedIndexChanged);
            // 
            // comboBox_AIDSDisease
            // 
            this.comboBox_AIDSDisease.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AIDSDisease.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_AIDSDisease.FormattingEnabled = true;
            this.comboBox_AIDSDisease.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_AIDSDisease.Location = new System.Drawing.Point(599, 272);
            this.comboBox_AIDSDisease.Name = "comboBox_AIDSDisease";
            this.comboBox_AIDSDisease.Size = new System.Drawing.Size(476, 21);
            this.comboBox_AIDSDisease.TabIndex = 14;
            // 
            // comboBox_ChronicRespiratoryFailure
            // 
            this.comboBox_ChronicRespiratoryFailure.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ChronicRespiratoryFailure.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ChronicRespiratoryFailure.FormattingEnabled = true;
            this.comboBox_ChronicRespiratoryFailure.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_ChronicRespiratoryFailure.Location = new System.Drawing.Point(32, 272);
            this.comboBox_ChronicRespiratoryFailure.Name = "comboBox_ChronicRespiratoryFailure";
            this.comboBox_ChronicRespiratoryFailure.Size = new System.Drawing.Size(476, 21);
            this.comboBox_ChronicRespiratoryFailure.TabIndex = 13;
            // 
            // comboBox_MechanicalVentilation
            // 
            this.comboBox_MechanicalVentilation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_MechanicalVentilation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_MechanicalVentilation.FormattingEnabled = true;
            this.comboBox_MechanicalVentilation.Items.AddRange(new object[] {
            "Select",
            "No mechanical ventilation",
            "Mechanical ventilation"});
            this.comboBox_MechanicalVentilation.Location = new System.Drawing.Point(32, 152);
            this.comboBox_MechanicalVentilation.Name = "comboBox_MechanicalVentilation";
            this.comboBox_MechanicalVentilation.Size = new System.Drawing.Size(265, 21);
            this.comboBox_MechanicalVentilation.TabIndex = 6;
            this.comboBox_MechanicalVentilation.SelectedIndexChanged += new System.EventHandler(this.comboBox_MechanicalVentilation_SelectedIndexChanged);
            // 
            // comboBox_InfectionEtiology
            // 
            this.comboBox_InfectionEtiology.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_InfectionEtiology.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_InfectionEtiology.FormattingEnabled = true;
            this.comboBox_InfectionEtiology.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_InfectionEtiology.Location = new System.Drawing.Point(330, 90);
            this.comboBox_InfectionEtiology.Name = "comboBox_InfectionEtiology";
            this.comboBox_InfectionEtiology.Size = new System.Drawing.Size(95, 21);
            this.comboBox_InfectionEtiology.TabIndex = 4;
            // 
            // comboBox_SiteofInfection
            // 
            this.comboBox_SiteofInfection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_SiteofInfection.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_SiteofInfection.FormattingEnabled = true;
            this.comboBox_SiteofInfection.Items.AddRange(new object[] {
            "Select",
            "Urinary",
            "Respiratory",
            "Gastrointestinal",
            "Skin",
            "Central Nervous System",
            "Unknown"});
            this.comboBox_SiteofInfection.Location = new System.Drawing.Point(598, 93);
            this.comboBox_SiteofInfection.Name = "comboBox_SiteofInfection";
            this.comboBox_SiteofInfection.Size = new System.Drawing.Size(477, 21);
            this.comboBox_SiteofInfection.TabIndex = 5;
            // 
            // comboBox_Lymphoma
            // 
            this.comboBox_Lymphoma.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Lymphoma.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_Lymphoma.FormattingEnabled = true;
            this.comboBox_Lymphoma.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_Lymphoma.Location = new System.Drawing.Point(599, 323);
            this.comboBox_Lymphoma.Name = "comboBox_Lymphoma";
            this.comboBox_Lymphoma.Size = new System.Drawing.Size(476, 21);
            this.comboBox_Lymphoma.TabIndex = 16;
            // 
            // comboBox_AlteredMentalStatus
            // 
            this.comboBox_AlteredMentalStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_AlteredMentalStatus.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_AlteredMentalStatus.FormattingEnabled = true;
            this.comboBox_AlteredMentalStatus.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_AlteredMentalStatus.Location = new System.Drawing.Point(32, 92);
            this.comboBox_AlteredMentalStatus.Name = "comboBox_AlteredMentalStatus";
            this.comboBox_AlteredMentalStatus.Size = new System.Drawing.Size(95, 21);
            this.comboBox_AlteredMentalStatus.TabIndex = 3;
            // 
            // comboBox_Diabetes
            // 
            this.comboBox_Diabetes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Diabetes.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_Diabetes.FormattingEnabled = true;
            this.comboBox_Diabetes.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_Diabetes.Location = new System.Drawing.Point(32, 487);
            this.comboBox_Diabetes.Name = "comboBox_Diabetes";
            this.comboBox_Diabetes.Size = new System.Drawing.Size(476, 21);
            this.comboBox_Diabetes.TabIndex = 21;
            // 
            // comboBox_ChronicLiverDisease
            // 
            this.comboBox_ChronicLiverDisease.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ChronicLiverDisease.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ChronicLiverDisease.FormattingEnabled = true;
            this.comboBox_ChronicLiverDisease.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_ChronicLiverDisease.Location = new System.Drawing.Point(599, 433);
            this.comboBox_ChronicLiverDisease.Name = "comboBox_ChronicLiverDisease";
            this.comboBox_ChronicLiverDisease.Size = new System.Drawing.Size(476, 21);
            this.comboBox_ChronicLiverDisease.TabIndex = 20;
            // 
            // comboBox_OrganTransplant
            // 
            this.comboBox_OrganTransplant.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_OrganTransplant.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_OrganTransplant.FormattingEnabled = true;
            this.comboBox_OrganTransplant.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_OrganTransplant.Location = new System.Drawing.Point(598, 487);
            this.comboBox_OrganTransplant.Name = "comboBox_OrganTransplant";
            this.comboBox_OrganTransplant.Size = new System.Drawing.Size(477, 21);
            this.comboBox_OrganTransplant.TabIndex = 22;
            // 
            // comboBox_ImmuneModifyingMedications
            // 
            this.comboBox_ImmuneModifyingMedications.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ImmuneModifyingMedications.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ImmuneModifyingMedications.FormattingEnabled = true;
            this.comboBox_ImmuneModifyingMedications.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_ImmuneModifyingMedications.Location = new System.Drawing.Point(32, 379);
            this.comboBox_ImmuneModifyingMedications.Name = "comboBox_ImmuneModifyingMedications";
            this.comboBox_ImmuneModifyingMedications.Size = new System.Drawing.Size(476, 21);
            this.comboBox_ImmuneModifyingMedications.TabIndex = 17;
            // 
            // comboBox_ChronicRenalFailure
            // 
            this.comboBox_ChronicRenalFailure.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ChronicRenalFailure.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_ChronicRenalFailure.FormattingEnabled = true;
            this.comboBox_ChronicRenalFailure.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_ChronicRenalFailure.Location = new System.Drawing.Point(32, 433);
            this.comboBox_ChronicRenalFailure.Name = "comboBox_ChronicRenalFailure";
            this.comboBox_ChronicRenalFailure.Size = new System.Drawing.Size(476, 21);
            this.comboBox_ChronicRenalFailure.TabIndex = 19;
            // 
            // comboBox_CongestiveHeartFailure
            // 
            this.comboBox_CongestiveHeartFailure.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_CongestiveHeartFailure.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_CongestiveHeartFailure.FormattingEnabled = true;
            this.comboBox_CongestiveHeartFailure.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_CongestiveHeartFailure.Location = new System.Drawing.Point(598, 379);
            this.comboBox_CongestiveHeartFailure.Name = "comboBox_CongestiveHeartFailure";
            this.comboBox_CongestiveHeartFailure.Size = new System.Drawing.Size(477, 21);
            this.comboBox_CongestiveHeartFailure.TabIndex = 18;
            // 
            // comboBox_PlateletCount
            // 
            this.comboBox_PlateletCount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_PlateletCount.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_PlateletCount.FormattingEnabled = true;
            this.comboBox_PlateletCount.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_PlateletCount.Location = new System.Drawing.Point(32, 36);
            this.comboBox_PlateletCount.Name = "comboBox_PlateletCount";
            this.comboBox_PlateletCount.Size = new System.Drawing.Size(95, 21);
            this.comboBox_PlateletCount.TabIndex = 0;
            // 
            // comboBox_Bandemia
            // 
            this.comboBox_Bandemia.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Bandemia.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_Bandemia.FormattingEnabled = true;
            this.comboBox_Bandemia.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_Bandemia.Location = new System.Drawing.Point(330, 31);
            this.comboBox_Bandemia.Name = "comboBox_Bandemia";
            this.comboBox_Bandemia.Size = new System.Drawing.Size(95, 21);
            this.comboBox_Bandemia.TabIndex = 1;
            // 
            // comboBox_LowerRespiratoryInfection
            // 
            this.comboBox_LowerRespiratoryInfection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_LowerRespiratoryInfection.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_LowerRespiratoryInfection.FormattingEnabled = true;
            this.comboBox_LowerRespiratoryInfection.Items.AddRange(new object[] {
            "Select",
            "Yes",
            "No"});
            this.comboBox_LowerRespiratoryInfection.Location = new System.Drawing.Point(599, 34);
            this.comboBox_LowerRespiratoryInfection.Name = "comboBox_LowerRespiratoryInfection";
            this.comboBox_LowerRespiratoryInfection.Size = new System.Drawing.Size(95, 21);
            this.comboBox_LowerRespiratoryInfection.TabIndex = 2;
            // 
            // comboBox_MetastaticCancer
            // 
            this.comboBox_MetastaticCancer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_MetastaticCancer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_MetastaticCancer.FormattingEnabled = true;
            this.comboBox_MetastaticCancer.Items.AddRange(new object[] {
            "Select",
            "Not present on admission",
            "Present on admission",
            "Not known upon admission but discovered prior to presentation of severe sepsis",
            "Not known upon admission but discovered after the presentation of severe sepsis"});
            this.comboBox_MetastaticCancer.Location = new System.Drawing.Point(32, 323);
            this.comboBox_MetastaticCancer.Name = "comboBox_MetastaticCancer";
            this.comboBox_MetastaticCancer.Size = new System.Drawing.Size(476, 21);
            this.comboBox_MetastaticCancer.TabIndex = 15;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(595, 417);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(113, 13);
            this.label43.TabIndex = 73;
            this.label43.Text = "Chronic Liver Disease:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(595, 471);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(92, 13);
            this.label44.TabIndex = 72;
            this.label44.Text = "Organ Transplant:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(29, 471);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(52, 13);
            this.label45.TabIndex = 71;
            this.label45.Text = "Diabetes:";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(29, 417);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(111, 13);
            this.label47.TabIndex = 69;
            this.label47.Text = "Chronic Renal Failure:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(596, 307);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(198, 13);
            this.label48.TabIndex = 68;
            this.label48.Text = "Lymphoma/Leukemia/Multiple Myeloma:";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(29, 363);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(155, 13);
            this.label49.TabIndex = 67;
            this.label49.Text = "Immune Modifying Medications:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(595, 363);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(126, 13);
            this.label50.TabIndex = 66;
            this.label50.Text = "Congestive Heart Failure:";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(29, 307);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(96, 13);
            this.label51.TabIndex = 65;
            this.label51.Text = "Metastatic Cancer:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(595, 256);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 13);
            this.label1.TabIndex = 64;
            this.label1.Text = "AIDS/HIV Disease:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 194);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 63;
            this.label2.Text = "ICU:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 256);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 13);
            this.label3.TabIndex = 62;
            this.label3.Text = "Chronic Respiratory Failure:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(595, 194);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 13);
            this.label4.TabIndex = 61;
            this.label4.Text = "ICU Discharge Date/Time:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(327, 194);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 13);
            this.label6.TabIndex = 60;
            this.label6.Text = "ICU Admission Date/Time:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(595, 77);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 13);
            this.label11.TabIndex = 59;
            this.label11.Text = "Site of Infection:";
            // 
            // label_MechanicalVentilationStartDateTime
            // 
            this.label_MechanicalVentilationStartDateTime.AutoSize = true;
            this.label_MechanicalVentilationStartDateTime.Location = new System.Drawing.Point(327, 136);
            this.label_MechanicalVentilationStartDateTime.Name = "label_MechanicalVentilationStartDateTime";
            this.label_MechanicalVentilationStartDateTime.Size = new System.Drawing.Size(196, 13);
            this.label_MechanicalVentilationStartDateTime.TabIndex = 58;
            this.label_MechanicalVentilationStartDateTime.Text = "Mechanical Ventilation Start Date/Time:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(29, 136);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(117, 13);
            this.label31.TabIndex = 57;
            this.label31.Text = "Mechanical Ventilation:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(327, 75);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(227, 13);
            this.label33.TabIndex = 55;
            this.label33.Text = "Infection Etiology (Hospital Acquired Infection):";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(327, 15);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(57, 13);
            this.label34.TabIndex = 54;
            this.label34.Text = "Bandemia:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(596, 18);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(139, 13);
            this.label35.TabIndex = 53;
            this.label35.Text = "Lower Respiratory Infection:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(28, 76);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(111, 13);
            this.label36.TabIndex = 52;
            this.label36.Text = "Altered Mental Status:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(29, 20);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(173, 13);
            this.label37.TabIndex = 51;
            this.label37.Text = "Platelet Count (Thrombocytopenia):";
            // 
            // button_SaveCase
            // 
            this.button_SaveCase.Location = new System.Drawing.Point(1141, 591);
            this.button_SaveCase.Name = "button_SaveCase";
            this.button_SaveCase.Size = new System.Drawing.Size(109, 34);
            this.button_SaveCase.TabIndex = 500;
            this.button_SaveCase.Text = "Save Case";
            this.button_SaveCase.UseVisualStyleBackColor = true;
            this.button_SaveCase.Click += new System.EventHandler(this.button_SaveCase_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Black;
            this.label39.Location = new System.Drawing.Point(16, 594);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(14, 16);
            this.label39.TabIndex = 61;
            this.label39.Text = "*";
            // 
            // lbl_nt
            // 
            this.lbl_nt.AutoSize = true;
            this.lbl_nt.Location = new System.Drawing.Point(26, 594);
            this.lbl_nt.Name = "lbl_nt";
            this.lbl_nt.Size = new System.Drawing.Size(133, 13);
            this.lbl_nt.TabIndex = 61;
            this.lbl_nt.Text = "Indicates Mandatory Fields";
            // 
            // label_Copyright
            // 
            this.label_Copyright.AutoSize = true;
            this.label_Copyright.Location = new System.Drawing.Point(558, 670);
            this.label_Copyright.Name = "label_Copyright";
            this.label_Copyright.Size = new System.Drawing.Size(86, 13);
            this.label_Copyright.TabIndex = 502;
            this.label_Copyright.Text = "© HANYS 2020.";
            // 
            // Label_Contact
            // 
            this.Label_Contact.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Contact.AutoSize = true;
            this.Label_Contact.Location = new System.Drawing.Point(1076, 667);
            this.Label_Contact.Name = "Label_Contact";
            this.Label_Contact.Size = new System.Drawing.Size(122, 13);
            this.Label_Contact.TabIndex = 504;
            this.Label_Contact.Text = "Contact Sepsis support:-";
            // 
            // Label_ClickHere
            // 
            this.Label_ClickHere.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_ClickHere.AutoSize = true;
            this.Label_ClickHere.Location = new System.Drawing.Point(1196, 667);
            this.Label_ClickHere.Name = "Label_ClickHere";
            this.Label_ClickHere.Size = new System.Drawing.Size(56, 13);
            this.Label_ClickHere.TabIndex = 503;
            this.Label_ClickHere.TabStop = true;
            this.Label_ClickHere.Text = "Click Here";
            this.Label_ClickHere.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Label_ClickHere_LinkClicked);
            // 
            // button_Validate
            // 
            this.button_Validate.Location = new System.Drawing.Point(1026, 591);
            this.button_Validate.Name = "button_Validate";
            this.button_Validate.Size = new System.Drawing.Size(109, 34);
            this.button_Validate.TabIndex = 505;
            this.button_Validate.Text = "Validate Case";
            this.button_Validate.UseVisualStyleBackColor = true;
            this.button_Validate.Click += new System.EventHandler(this.button_Validate_Click);
            // 
            // label_Name
            // 
            this.label_Name.AutoSize = true;
            this.label_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Name.Location = new System.Drawing.Point(514, 8);
            this.label_Name.Name = "label_Name";
            this.label_Name.Size = new System.Drawing.Size(175, 20);
            this.label_Name.TabIndex = 82;
            this.label_Name.Text = "Pediatric Version 1.1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(10, 637);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(170, 47);
            this.pictureBox1.TabIndex = 501;
            this.pictureBox1.TabStop = false;
            // 
            // SepsisCaseDetails_1_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 687);
            this.Controls.Add(this.label_Name);
            this.Controls.Add(this.button_Validate);
            this.Controls.Add(this.Label_Contact);
            this.Controls.Add(this.Label_ClickHere);
            this.Controls.Add(this.label_Copyright);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbl_nt);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.button_SaveCase);
            this.Controls.Add(this.tabControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SepsisCaseDetails_1_1";
            this.Text = "HANYS Sepsis Reporting Tool";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SepsisCaseDetails_1_1_FormClosing);
            this.Load += new System.EventHandler(this.SepsisCaseDetails_1_1_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.Button button_SaveCase;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label_VasopressorAdministration;
        private System.Windows.Forms.Label label_VasopressorAdministrationStartDateTime;
        private System.Windows.Forms.Label Label_CrystalloidFluidAdministrationDatetime;
        private System.Windows.Forms.Label Label_CrystalloidFluidAdministration;
        private System.Windows.Forms.Label Label_AntibioticAdministrationDatetime;
        private System.Windows.Forms.Label Label_BloodCultureCollection;
        private System.Windows.Forms.Label Label_InitialLactateLevel;
        private System.Windows.Forms.Label Label_SevereSepsisPresent;
        private System.Windows.Forms.Label Label_BloodCultureCollectionAcceptableDelay;
        private System.Windows.Forms.Label Label_SevereSepsisPresentationDatetime;
        private System.Windows.Forms.Label Label_AntibioticAdministration;
        private System.Windows.Forms.Label Label_InitialLactateLevelCollectionDatetime;
        private System.Windows.Forms.Label Label_SepticShockPresentationDatetime;
        private System.Windows.Forms.Label Label_BloodCultureCollectionDatetime;
        private System.Windows.Forms.Label Label_SepticShockPresent;
        private System.Windows.Forms.Label Label_InitialLactateLevelCollection;
        private System.Windows.Forms.Label Label_TriageDatetime;
        private System.Windows.Forms.Label Label_ArrivalDatetime;
        private System.Windows.Forms.ComboBox comboBox_VasopressorAdministration;
        private System.Windows.Forms.ComboBox comboBox_BloodCultureCollection;
        private System.Windows.Forms.ComboBox comboBox_BloodCultureCollectionAcceptableDelay;
        private System.Windows.Forms.ComboBox comboBox_AntibioticAdministration;
        private System.Windows.Forms.ComboBox comboBox_SepticShockPresent;
        private System.Windows.Forms.ComboBox comboBox_InitialLactateLevelCollection;
        private System.Windows.Forms.ComboBox comboBox_SevereSepsisPresent;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label_MechanicalVentilationStartDateTime;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox comboBox_ICU;
        private System.Windows.Forms.ComboBox comboBox_AIDSDisease;
        private System.Windows.Forms.ComboBox comboBox_ChronicRespiratoryFailure;
        private System.Windows.Forms.ComboBox comboBox_MechanicalVentilation;
        private System.Windows.Forms.ComboBox comboBox_InfectionEtiology;
        private System.Windows.Forms.ComboBox comboBox_SiteofInfection;
        private System.Windows.Forms.ComboBox comboBox_Lymphoma;
        private System.Windows.Forms.ComboBox comboBox_AlteredMentalStatus;
        private System.Windows.Forms.ComboBox comboBox_Diabetes;
        private System.Windows.Forms.ComboBox comboBox_ChronicLiverDisease;
        private System.Windows.Forms.ComboBox comboBox_OrganTransplant;
        private System.Windows.Forms.ComboBox comboBox_ImmuneModifyingMedications;
        private System.Windows.Forms.ComboBox comboBox_ChronicRenalFailure;
        private System.Windows.Forms.ComboBox comboBox_CongestiveHeartFailure;
        private System.Windows.Forms.ComboBox comboBox_PlateletCount;
        private System.Windows.Forms.ComboBox comboBox_Bandemia;
        private System.Windows.Forms.ComboBox comboBox_LowerRespiratoryInfection;
        private System.Windows.Forms.ComboBox comboBox_MetastaticCancer;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.MaskedTextBox txtMRN;
        private System.Windows.Forms.MaskedTextBox textBox_DischargedDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_AdmissionDateTime;
        private System.Windows.Forms.MaskedTextBox txtDOB;
        private System.Windows.Forms.Label Label_AdmissionDatetime;
        private System.Windows.Forms.Label Label_SourceofAdmission;
        private System.Windows.Forms.Label Label_DischargeDatetime;
        private System.Windows.Forms.Label Label_DischargedStatus;
        private System.Windows.Forms.Label Label_Transfer;
        private System.Windows.Forms.CheckedListBox checkedListBox_Race;
        private System.Windows.Forms.ComboBox comboBox_Payor;
        private System.Windows.Forms.ComboBox Combobox_Ethnicity;
        private System.Windows.Forms.ComboBox Combobox_Gender;
        private System.Windows.Forms.Label Label_PatientCtrlNum;
        private System.Windows.Forms.Label Label_Ethnicity;
        private System.Windows.Forms.Label Label_InsuranceNumber;
        private System.Windows.Forms.Label Label_Race;
        private System.Windows.Forms.Label Label_Payor;
        private System.Windows.Forms.Label Label_Gender;
        private System.Windows.Forms.Label Label_FacilityIdentifier;
        private System.Windows.Forms.Label Label_MRN;
        private System.Windows.Forms.Label Label_DateofBirth;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.MaskedTextBox TextBox_InsuranceNumber;
        private System.Windows.Forms.MaskedTextBox TextBox_PatientCtrlNum;
        private System.Windows.Forms.MaskedTextBox txtId;
        private System.Windows.Forms.MaskedTextBox TextBox_FacilityIdentifier;
        private System.Windows.Forms.MaskedTextBox textbox_TriageDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_ArrivalDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_septicShockPresentationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_SevereSepsisPresentationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_InitialLactateLevelCollectionDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_AntibioticAdministrationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_BloodCultureCollectionDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_VasopressorAdministrationStartDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_CrystalloidFluidAdministrationDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_ICUDischargeDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_ICUAdmissionDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_MechanicalVentilationStartDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_TransferFacilityIdentifier;
        private System.Windows.Forms.Label lbl_DischargeDatetime;
        private System.Windows.Forms.Label lbl_AdmissionDateTime;
        private System.Windows.Forms.Label lbl_FacilityIdentifier;
        private System.Windows.Forms.Label lbl_MRN;
        private System.Windows.Forms.Label lbl_InsuranceNumber;
        private System.Windows.Forms.Label lbl_Payor;
        private System.Windows.Forms.Label lbl_Ethnicity;
        private System.Windows.Forms.Label lbl_Race;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.Label lbl_DOB;
        private System.Windows.Forms.Label lbl_PatientCtrlNum;
        private System.Windows.Forms.Label lbl_txID;
        private System.Windows.Forms.Label lbl_TransferFacilityIdentifier;
        private System.Windows.Forms.Label lbl_TransferStatus;
        private System.Windows.Forms.Label lbl_DischargedStatus;
        private System.Windows.Forms.Label lbl_SourceofAdmission;
        private System.Windows.Forms.Label lbl_SepticShockPresent;
        private System.Windows.Forms.Label lbl_SevereSepsisPresentationDatetime;
        private System.Windows.Forms.Label lbl_SevereSepsisPresent;
        private System.Windows.Forms.Label lbl_EarliestDatetime;
        private System.Windows.Forms.Label lbl_Diabetes;
        private System.Windows.Forms.Label lbl_ChronicRenalFailure;
        private System.Windows.Forms.Label lbl_OrganTransplant;
        private System.Windows.Forms.Label lbl_ChronicLiverDisease;
        private System.Windows.Forms.Label lbl_CongestiveHeartFailure;
        private System.Windows.Forms.Label lbl_ImmuneModifyingMedications;
        private System.Windows.Forms.Label lbl_Lymphoma;
        private System.Windows.Forms.Label lbl_MetastaticCancer;
        private System.Windows.Forms.Label lbl_AIDSDisease;
        private System.Windows.Forms.Label lbl_ChronicRespiratoryFailure;
        private System.Windows.Forms.Label lbl_ICU;
        private System.Windows.Forms.Label lbl_MechanicalVentilation;
        private System.Windows.Forms.Label lbl_SiteofInfection;
        private System.Windows.Forms.Label lbl_LowerRespiratoryInfection;
        private System.Windows.Forms.Label lbl_InfectionEtiology;
        private System.Windows.Forms.Label lbl_Bandemia;
        private System.Windows.Forms.Label lbl_AlteredMentalStatus;
        private System.Windows.Forms.Label lbl_PlateletCount;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label lbl_nt;
        private System.Windows.Forms.Label lbl_CrystalloidFluidAdministrationDatetime;
        private System.Windows.Forms.Label lbl_CrystalloidFluidAdministration;
        private System.Windows.Forms.Label lbl_AntibioticAdministrationDatetime;
        private System.Windows.Forms.Label lbl_BloodCultureCollectionDatetime;
        private System.Windows.Forms.Label lbl_BloodCultureCollectionAcceptableDelay;
        private System.Windows.Forms.Label lbl_BloodCultureCollection;
        private System.Windows.Forms.Label lbl_InitialLactateLevelCollectionDatetime;
        private System.Windows.Forms.Label lbl_VasopressorAdministration;
        private System.Windows.Forms.Label lbl_VasopressorAdministrationStartDateTime;
        private System.Windows.Forms.Label lbl_ICUDischargeDatetime;
        private System.Windows.Forms.Label lbl_ICUAdmissionDatetime;
        private System.Windows.Forms.Label lbl_MechanicalVentilationStartDatetime;
        private System.Windows.Forms.Label lbl_AntibioticAdministration;
        private System.Windows.Forms.Label lbl_InitialLactateLevel;
        private System.Windows.Forms.Label lbl_SepticShockPresentationDatetime;
        private System.Windows.Forms.TextBox textBox_InitialLactateLevel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label_Copyright;
        private System.Windows.Forms.Label Label_Contact;
        private System.Windows.Forms.LinkLabel Label_ClickHere;
        private System.Windows.Forms.Label lbl_InitialLactateLevelCollection;
        private System.Windows.Forms.Label lbl_ElevatedLactateReason;
        private System.Windows.Forms.ComboBox comboBox_ElevatedLactateReason;
        private System.Windows.Forms.Label Label_ElevatedLactateReason;
        private System.Windows.Forms.Label lbl_ExcludedExplain;
        private System.Windows.Forms.Label lbl_ExcludedDatetime;
        private System.Windows.Forms.MaskedTextBox textBox_ExcludedDatetime;
        private System.Windows.Forms.CheckedListBox checkedListBox_ExcludedExplain;
        private System.Windows.Forms.Label Label_ExcludedDatetime;
        private System.Windows.Forms.Label Label_ExcludedExplain;
        private System.Windows.Forms.Label lbl_ExcludedReason;
        private System.Windows.Forms.CheckedListBox checkedListBox_ExcludedReason;
        private System.Windows.Forms.Label Label_ExcludedReason;
        private System.Windows.Forms.Label lbl_ExcludedFromProtocol;
        private System.Windows.Forms.ComboBox comboBox_ExcludedFromProtocol;
        private System.Windows.Forms.Label Label_ExcludedFromProtocol;
        private System.Windows.Forms.Label lbl_SepsisIdentificationPlace;
        private System.Windows.Forms.ComboBox Combobox_SepsisIdentificationPlace;
        private System.Windows.Forms.Label label_SepsisIdentificationPlace;
        private ComboBox comboBox_SourceofAdmission;
        private ComboBox comboBox_DischargeStatus;
        private ComboBox comboBox_TransferStatus;
        private ComboBox comboBox_CrystalloidFluidAdministration;
        private System.Windows.Forms.Button button_Validate;
        private System.Windows.Forms.Label label_Name;
        private System.Windows.Forms.Label lbl_VasopressorAdministrationEndDateTime;
        private System.Windows.Forms.MaskedTextBox textBox_VasopressorAdministrationEndDatetime;
        private System.Windows.Forms.Label label_VasopressorAdministrationEndDateTime;
        private ComboBox comboBox_VasopressorTransfer;
        private System.Windows.Forms.Label lbl_VasopressorTransfer;
        private System.Windows.Forms.Label label_VasopressorTransfer;
        private System.Windows.Forms.Label lbl_MechanicalVentilationEndDateTime;
        private System.Windows.Forms.MaskedTextBox textBox_MechanicalVentilationEndDatetime;
        private System.Windows.Forms.Label label_MechanicalVentilationEndDateTime;
        private ComboBox comboBox_MechanicalVentilationTransfer;
        private System.Windows.Forms.Label lbl_MechanicalVentaltionTransfer;
        private System.Windows.Forms.Label label_MechanicalVentaltionTransfer;
    }
}