﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.Threading.Tasks;

namespace HANYSSepsisReporting
{
    [RunInstaller(true)]
    public partial class Installer_sepsis : System.Configuration.Install.Installer
    {
        public Installer_sepsis()
        {
            InitializeComponent();
        }


        public override void Commit(System.Collections.IDictionary savedState)
        {
            base.Commit(savedState);
            System.Diagnostics.Process.Start(System.IO.Path.GetDirectoryName(this.Context.Parameters["AssemblyPath"]) + @"\HANYSSepsisReporting.exe");

        }


    }
}
