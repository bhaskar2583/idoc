﻿using Dapper;
using LicenseValidator;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1;

namespace HANYSSepsisReporting
{
    public partial class Verify : Form
    {
        SepsisMaster sm;

        public Verify(SepsisMaster master)
        {
            InitializeComponent();
            sm = master;
        }

        private void button_Submit_Click(object sender, EventArgs e)
        {
            if (IsnullString(textBox1.Text.ToString().Trim()) == null)
            {
                MessageBox.Show("Please Enter Key1:");
                textBox1.Focus();
                return;
            }
            if (IsnullString(textBox3.Text.ToString().Trim()) == null)
            {
                MessageBox.Show("Please Enter Key2:");
                textBox3.Focus();
                return;
            }
            if (IsnullString(textBox2.Text.ToString().Trim()) == null)
            {
                MessageBox.Show("Please Enter Key3:");
                textBox2.Focus();
                return;
            }
            if (IsnullString(textBox4.Text.ToString().Trim()) == null)
            {
                MessageBox.Show("Please Enter Key4:");
                textBox4.Focus();
                return;
            }

            OdbcConnection Conn;
            WindowsFormsApplication1.DataBaseConnection Db = new WindowsFormsApplication1.DataBaseConnection();

            string ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;

            using(Conn = new OdbcConnection(ConnectionString))
            {
                try
                {
                    Conn.Open();
                    var result = Conn.Query<MetaData>("select * from Metadata", commandType: CommandType.Text).FirstOrDefault();
                    Conn.Close();

                    var key1 = textBox1.Text.ToString().Trim();
                    var key2 = textBox3.Text.ToString().Trim();
                    var key3 = textBox2.Text.ToString().Trim();
                    var key4 = textBox4.Text.ToString().Trim();

                    if (result == null)
                    {
                        Conn.Open();
                        string insertquery = "INSERT INTO [dbo].[Metadata]([Key1],[Key2],[Key3],[Key4])VALUES('" + key1 + "','" + key2 + "','" + key3 + "','" + key4 + "')";
                        OdbcCommand cmd = new OdbcCommand(insertquery, Conn);
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                        Conn.Close();
                    }
                    else
                    {
                        Conn.Open();
                        Conn.Query<MetaData>("Update Metadata set Key1='" + key1
                            + "',Key2='" + key2
                            + "',Key3='" + key3
                            + "',Key4='" + key4 + "'");
                        Conn.Close();
                    }                   

                    var enddate = LicenseValidator.LicenseManager.GetEndDate_Check();
                    var level = LicenseValidator.LicenseManager.GetLevel_Check();

                    if (enddate == false || level == false)
                    {
                        MessageBox.Show("Error while Updating Keys:! Please re-enter .");
                        try
                        {
                            Conn.Open();
                            Conn.Query<MetaData>("DELETE FROM Metadata");
                            Conn.Close();

                            ClearTextBoxes(this);
                        }
                        catch(Exception ex)
                        {
                            MessageBox.Show("Error while deleting Keys: " + ex.Message);
                            Kill();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Key Updated Succesfully! Please restart the Tool.");
                        Kill();
                    }                   
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Error while Updating Keys: " + ex.Message);
                    Kill();
                }
            }
        }
        private void Kill()
        {
            foreach (var process in Process.GetProcessesByName("HANYSSepsisReporting"))
            {
                process.Kill();
            }
        }
        public string IsnullString(string inputString)
        {
            if (inputString == "" || inputString == "Select" || inputString == null)
            {
                inputString = null;
                return inputString;
            }
            return inputString;

        }

        private void Label_ClickHere_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            WindowsFormsApplication1.Help hp = new WindowsFormsApplication1.Help();
            hp.Show();
        }
        private void Verify_FormClosing(object sender, FormClosingEventArgs e)
        {
            sm.Show();
        }
        public void ClearTextBoxes(Control form)
        {
            foreach (Control control in form.Controls)
            {
                if (control is TextBox)
                {
                    ((TextBox)control).Clear();
                }

                if (control.HasChildren)
                {
                    ClearTextBoxes(control);
                }
                if (control.GetType() == typeof(TextBox))
                {
                    control.Text = "";
                }
            }
        }
    }
}
