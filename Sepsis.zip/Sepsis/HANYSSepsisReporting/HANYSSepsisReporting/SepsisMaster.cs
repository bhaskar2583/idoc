﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Odbc;
using System.IO;
using System.Globalization;
using WindowsFormsApplication1;
using System.Diagnostics;
using HANYSSepsisReporting;
using LicenseValidator;
using System.Security.Principal;
using System.Reflection;
using Dapper;

namespace WindowsFormsApplication1
{
    public partial class SepsisMaster : Form
    {
        string ConnectionString;
        string strHeader = "";
        string strData = "";
        int count = 0;
        int removenum = 0;
        //string sDSN = "Sepsis";
        DataSet ds;
        string query = "";
        string FileName = "";
        string CurrentDate = "";
        string Currenttime = "";
       public string Version { get; set; }
        string DateCreatedFrom { get; set; }
        string DateCreatedTo { get; set; }
        string txtPCN { get; set; }
        string txtMRN1 { get; set; }
        //DateTime? CSV_Date { get; set; }
        string CSV_Date { get; set; }
        string PFI { get; set; }
        int? RecordComplete { get; set; }
        int? CSVGenerated { get; set; }

        DateTime dDate;

        TextWriter sw;

        int recordcompletecount = 0;
      ArrayList recordcompleteUniqueID  = new ArrayList();

        ArrayList SamplingIncomplete = new ArrayList();
        ArrayList ExportCSV_Sorting = new ArrayList();
      StringBuilder querystring = new StringBuilder();
        StringBuilder SamplingIncompleteString = new StringBuilder();
        int DataSetfillflag = 0;

       
        OdbcConnection Conn;
        DataBaseConnection Db = new DataBaseConnection();
        public SepsisMaster()
        {
            InitializeComponent();
          
        }

        private Timer atimer;

        public event EventHandler ButtonFirstFormClicked;

        void button_Clicked(object sender, EventArgs e)
        {
            if (ButtonFirstFormClicked != null)
                ButtonFirstFormClicked(sender, e);
        }


        public void InitTimer()
        {
            atimer = new Timer();
            atimer.Tick += new EventHandler(atimer_Tick);
            atimer.Interval = 1440 * 60000;
            atimer.Start();
        }
        private void atimer_Tick(object sender,EventArgs e)
        {
            LicenseValidator.LicenseManager.Trigger();
            var endDate = LicenseValidator.LicenseManager.GetEndDate();
            var startDate = Class1.Begin;
            var timeDiffInDays = (endDate - Convert.ToDateTime(Class1.Begin)).Days;
            if (LicenseValidator.LicenseManager.IsLicenseExpired)
            {
                button_ExportData.Enabled = false;
                button_ExportSampling.Enabled = false;
                button_Subscribe.Show();
                button_AddDemoGraphics.Hide();
                Label mylab = new Label();
                mylab.Text = "Your License is Expired, Please contact HANYS!";
                mylab.Location = new Point(33, 7);
                mylab.AutoSize = true;
                mylab.Font = new Font("Calibri", 10);
                mylab.BorderStyle = BorderStyle.Fixed3D;
                mylab.ForeColor = Color.Red;
                mylab.Margin = new Padding(3, 0, 3, 0);
                mylab.Size = new Size(35, 13);
                //mylab.Padding = new Padding(6);

                this.Controls.Add(mylab);
            }
            else
            {
                if (timeDiffInDays < 30)
                {
                    button_Subscribe.Show();
                    string text = "Your License is going to Expire in: " + timeDiffInDays + " Days";
                    Label mylab = new Label();
                    mylab.Text = text;
                    mylab.Location = new Point(33, 7);
                    mylab.AutoSize = true;
                    mylab.Font = new Font("Calibri", 10);
                    mylab.BorderStyle = BorderStyle.Fixed3D;
                    mylab.ForeColor = Color.Red;
                    mylab.Margin = new Padding(3, 0, 3, 0);
                    mylab.Size = new Size(35, 13);
                    //mylab.Padding = new Padding(6);
                    this.Controls.Add(mylab);
                }
                else
                    button_Subscribe.Hide();

                if (LicenseValidator.LicenseManager.IsLicenseExpiredForLevel2 && !LicenseValidator.LicenseManager.IsLicenseExpired)
                {
                    button_AddDemoGraphics.Show();
                }
                else
                {
                    button_AddDemoGraphics.Hide();
                    button_Subscribe.Hide();
                }
            }
        }

        private void SepsisMaster_FormClosing(object sender, FormClosingEventArgs e)
        {
            foreach (var process in Process.GetProcessesByName("HANYSSepsisReporting"))
            {
                process.Kill();
            }
        }

        private void button_ExportData_Click(object sender, EventArgs e)
        {
            try
            {

                if (dataGridView_DisplayData.RowCount >= 1)
                {

                    if (comboBox_PFI.Text.ToString().Trim() == "All")
                    {
                        MessageBox.Show("Your CSV contains more than one Facility Identifier.", "Sepsis Master Error");
                        comboBox_PFI.Focus();
                        return;
                    }
  
                    var versionID = ds.Tables["MasterDisplay"]
                                         .AsEnumerable()
                                         //.Where(r => r.Field<string>("version") == comboBox_Version.Text.Trim())
                                          .Where(r => r.Field<string>("version") == Version)
                                         .Select(r => r.Field<string>("version"))
                                         .Distinct();



                    if (versionID.Count() == 0)
                    {
                        MessageBox.Show("Version selected does not match with version in the wizard. Please click Search button.", "Sepsis Master Error");
                        comboBox_Version.Focus();
                        return;
                    }



                    int uniqueCount = ds.Tables["MasterDisplay"]
                                         .AsEnumerable()
                                         .Where(r => r.Field<string>("facility_identifier") != null) 
                                         .Select(r => r.Field<string>("facility_identifier"))
                                         .Distinct()
                                         .Count();


                    if (uniqueCount > 1)
                    {
                        MessageBox.Show("Press the Search button to display just the cases for your Facility Identifier.", "Sepsis Master Error");
                        button_Search.Focus();
                        return;
                    }

                    recordcompleteUniqueID.Clear();

                    for (int i = 0; i <= dataGridView_DisplayData.Rows.Count -1; i++)
                    {
                        if (dataGridView_DisplayData.Rows[i].Cells[0].Value.ToString() != "")
                        {
                        //if (bool.Parse(dataGridView_DisplayData.Rows[i].Cells["Record_Completed"].Value.ToString()) == true && bool.Parse(dataGridView_DisplayData.Rows[i].Cells["ExportCSV"].Value.ToString()) == true)
                        //{

                            //recordcompletecount++;
                            recordcompleteUniqueID.Add(dataGridView_DisplayData.Rows[i].Cells["UniqueId"].Value.ToString());
                        }
                    }



                    //for (int i = 0; i <= ds.Tables["MasterDisplay"].Rows.Count - 1; i++)
                    //{
                    //    if (bool.Parse(ds.Tables["MasterDisplay"].Rows[i]["Record_Completed"].ToString()) == true && bool.Parse(ds.Tables["MasterDisplay"].Rows[i]["ExportCSV"].ToString()) == true)
                    //    {

                    //        recordcompletecount++;
                    //        recordcompleteUniqueID.Add(ds.Tables["MasterDisplay"].Rows[i]["UniqueId"].ToString());
                    //    }
                    //}


                    querystring.Clear();

                    if (recordcompleteUniqueID.Count > 0)
                    {
                        if (recordcompleteUniqueID.Count == 1)
                        {
                            querystring.Append(recordcompleteUniqueID[0]);
                        }
                        else
                        {
                       
                            //else
                            //{
                            //    //lbl_Note.Hide();
                            //}


                            for (int i = 0; i <= recordcompleteUniqueID.Count - 1; i++)
                            {
                                querystring.Append(recordcompleteUniqueID[i]);
                                if (i != recordcompleteUniqueID.Count - 1)
                                    querystring.Append(",");

                            }


                        }

                        if (recordcompleteUniqueID.Count != ds.Tables["MasterDisplay"].Rows.Count)
                        {
                            //lbl_Note.Show();
                            MessageBox.Show("Please note, Only the records completed successfully will be uploaded to CSV.", "Export Message");
                        }


                        ExportForm Exp = new ExportForm(querystring.ToString(), Version, this);
                        this.Hide();
                        Exp.Show();


                    }

                    else
                    {
                        MessageBox.Show("No case to export", "Export Details");
                    }
                }
                else
                {
                    MessageBox.Show("There is no data in the grid to export to CSV.", "Export Details");
                }
                         
            }
            catch (Exception ex)
            {

            }
        }

        private bool IsRunAsAdmin()
        {
            WindowsIdentity id = WindowsIdentity.GetCurrent();
            WindowsPrincipal principal = new WindowsPrincipal(id);

            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }

        private void SepsisMaster_Shown(Object sender, EventArgs e)
        {

            if (ODBCManager.DSNExists("Hanys_sepsis") == false)
            {
                if (!IsRunAsAdmin())
                {
                    MessageBox.Show("Hanys Sepsis Tool is not connected to Database please close the application and run it as Administraion for further steps.");
                    foreach (var process in Process.GetProcessesByName("HANYSSepsisReporting"))
                    {
                        process.Kill();
                    }
                    //ProcessStartInfo proc = new ProcessStartInfo();
                    //proc.UseShellExecute = true;
                    //proc.WorkingDirectory = Environment.CurrentDirectory;
                    //proc.FileName = Assembly.GetEntryAssembly().CodeBase;

                    //proc.Verb = "runas";

                    //try
                    //{
                    //    Process.Start(proc);
                    //    Application.Exit();
                    //}
                    //catch (Exception ex)
                    //{
                    //    Console.WriteLine("This program must be run as an administrator! \n\n" + ex.ToString());
                    //}                    
                }
                else
                {
                    ODBC dg = new ODBC(this);
                    dg.Show();
                    this.Hide();
                }
            }
            if(ODBCManager.DSNExists("Hanys_sepsis") == true)
            {
                var enddate = LicenseValidator.LicenseManager.GetEndDate_Check();
                if (enddate == false)
                {
                    Verify dg = new Verify(this);
                    dg.Show();
                    this.Hide();
                }
            }
        }


        private void SepsisMaster_Load(object sender, EventArgs e)
        {
            Load_Data();

           // this.reportViewer1.RefreshReport();
        }

       public void Load_Data()
        {
            if (ODBCManager.DSNExists("Hanys_sepsis") == false)
            {
                return;
            }
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;
            Conn = new OdbcConnection(ConnectionString);
            var metadata = LicenseValidator.LicenseManager.GetMetadata();
            if (metadata == null)
            {
                MessageBox.Show("Please Enter Your Subscription Key (or) Contact Hanys!");
                return;
            }
            var enddate = LicenseValidator.LicenseManager.GetEndDate_Check();
            var level = LicenseValidator.LicenseManager.GetLevel_Check();
            if (enddate == false || level == false)
            {
                MessageBox.Show("Subcription Key is not Valid! Please enter Keys.");

                Conn.Open();
                Conn.Query<MetaData>("DELETE FROM Metadata");
                Conn.Close();

                return;
            }
            LicenseValidator.LicenseManager.Trigger();

            InitTimer();
            var endDate = LicenseValidator.LicenseManager.GetEndDate();
            var startDate = Class1.Begin;
            var timeDiffInDays = (endDate - Convert.ToDateTime(Class1.Begin)).Days;
            if (LicenseValidator.LicenseManager.IsLicenseExpired)
            {
                button_ExportData.Enabled = false;
                button_ExportSampling.Enabled = false;
                button_Subscribe.Show();
                button_AddDemoGraphics.Hide();
                Label mylab = new Label();
                mylab.Text = "Your License is Expired, Please contact HANYS!";
                mylab.Location = new Point(33, 7);
                mylab.AutoSize = true;
                mylab.Font = new Font("Calibri", 10);
                mylab.BorderStyle = BorderStyle.Fixed3D;
                mylab.ForeColor = Color.Red;
                mylab.Margin = new Padding(3, 0, 3, 0);
                mylab.Size = new Size(35, 13);
                //mylab.Padding = new Padding(6);

                this.Controls.Add(mylab);
            }
            else
            {
                if (timeDiffInDays < 30)
                {
                    button_Subscribe.Show();
                    string text = "Your License is going to Expire in: " + timeDiffInDays + " Days";
                    Label mylab = new Label();
                    mylab.Text = text;
                    mylab.Location = new Point(33, 7);
                    mylab.AutoSize = true;
                    mylab.Font = new Font("Calibri", 10);
                    mylab.BorderStyle = BorderStyle.Fixed3D;
                    mylab.ForeColor = Color.Red;
                    mylab.Margin = new Padding(3, 0, 3, 0);
                    mylab.Size = new Size(35, 13);
                    //mylab.Padding = new Padding(6);
                    this.Controls.Add(mylab);
                }
                else
                    button_Subscribe.Hide();

                if (LicenseValidator.LicenseManager.IsLicenseExpiredForLevel2 && !LicenseValidator.LicenseManager.IsLicenseExpired)
                {
                    button_AddDemoGraphics.Show();
                }
                else
                {
                    button_AddDemoGraphics.Hide();
                   //button_Subscribe.Hide();
                }
            }
            try
            {

                comboBox_Version.Items.Clear();
                radioButton_Adult.Checked = true;

                //if (radioButton_Adult.Checked == true)
                //    comboBox_Version.Items.Add("6.2");
                //else
                //    comboBox_Version.Items.Add("1.1");






                //comboBox_Version.Items.Add("5.1");
                //comboBox_Version.Items.Add("4.1");


                comboBox_Version.SelectedIndex = 0;

                if (comboBox_Version.Text.ToString().Trim() == "6.3")
                    Version = "6.2";
                else
                    Version = comboBox_Version.Text.ToString().Trim();

                //comboBox_Version.SelectedItem = "4.1";
                //DataBaseConnection Db = new DataBaseConnection();
                // lbl_Note.Hide();


                using (Conn = new OdbcConnection(ConnectionString))
                {
                    DataSet ds1 = new DataSet();

                    Conn.Open();



                    //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                    using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("Select distinct facility_identifier 'uniqueId', facility_identifier from sepsis_collab where version ='" + Version + "'", Conn))
                    {

                        dbDataAdapter.Fill(ds1, "FaciltyIdentifier");
                        //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                        // dbDataAdapter.Fill(ds, "sepsis_collab");

                    }

                    //using (OdbcDataAdapter dbDataAdapter_CSVDate = new OdbcDataAdapter("select distinct (CONVERT(VARCHAR(10),CsVGenerated_date,101) + ' ' + CONVERT(VARCHAR(10),CsVGenerated_date,108)) as 'CsVGenerated_date' from [dbo].[sepsis_collab] where CsVGenerated_date is not null", Conn))
                    using (OdbcDataAdapter dbDataAdapter_CSVDate = new OdbcDataAdapter("Select top 1 '' as 'CsVGenerated_date' from [dbo].[sepsis_collab] union select distinct (CONVERT(VARCHAR(10),CsVGenerated_date,101) + ' ' + CONVERT(VARCHAR(10),CsVGenerated_date,108)) as 'CsVGenerated_date' from [dbo].[sepsis_collab] where CsVGenerated_date is not null and version ='" + Version + "'", Conn))
                    {

                        dbDataAdapter_CSVDate.Fill(ds1, "CSVGenerated");
                        //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                        // dbDataAdapter.Fill(ds, "sepsis_collab");

                    }


                    Conn.Close();

                    //comboBox_PFI.ValueMember = "ComboBox_Key";
                    //comboBox_PFI.DisplayMember = "ComboBox_Value";
                    //DataRow dr = ds1.Tables[0].NewRow();
                    //dr["uniqueId"] = "";
                    //dr["facility_identifier"] = "";// Some ID
                    //ds1.Tables[0].Rows.InsertAt(dr, 0);

                    if (ds1.Tables["FaciltyIdentifier"].Rows.Count > 1)
                    {

                        //for (int i = 0; i <= ds1.Tables["FaciltyIdentifier"].Rows.Count - 1; i++)
                        //{
                        if (ds1.Tables["FaciltyIdentifier"].Rows[0][0].ToString() == "")
                        {
                            ds1.Tables["FaciltyIdentifier"].Rows.RemoveAt(0);
                        }
                        // }

                        DataRow dr = ds1.Tables[0].NewRow();
                        dr["uniqueId"] = "";
                        dr["facility_identifier"] = "All";// Some ID
                        ds1.Tables[0].Rows.InsertAt(dr, 0);

                        //ds1.Tables[1].Columns[0].DataType = typeof(string);


                        //DataTable dtCloned = ds1.Tables[1].Clone();
                        //dtCloned.Columns[0].DataType = typeof(string);
                        //foreach (DataRow row in ds1.Tables[1].Rows)
                        //{
                        //    dtCloned.ImportRow(row);
                        //}




                        // dtCloned.Columns[0].DataType = typeof(string);


                        //dataGridView_DisplayData.Columns["Date_Created"].DefaultCellStyle.Format = "MM/dd/yyyy HH:mm";

                        DataRow dr_Date = ds1.Tables[1].NewRow();
                        dr_Date["CsVGenerated_date"] = "";// Some ID
                        ds1.Tables[1].Rows.InsertAt(dr_Date, 0);
                        //ds1.Tables[0].Rows.Add(dr);
                        // comboBox_PFI.Items.Add("All");

                        //comboBox_PFI.Items.Insert(0,);
                        comboBox_PFI.DataSource = ds1.Tables["FaciltyIdentifier"];
                        comboBox_PFI.ValueMember = "uniqueId";
                        comboBox_PFI.DisplayMember = "facility_identifier";
                        comboBox_PFI.SelectedIndex = 0;


                        comboBox_CSVGeneratedDate.DataSource = ds1.Tables["CSVGenerated"];
                        comboBox_CSVGeneratedDate.ValueMember = "CsVGenerated_date";
                        comboBox_CSVGeneratedDate.DisplayMember = "CsVGenerated_date";
                        comboBox_CSVGeneratedDate.SelectedIndex = 0;
                    }
                    else if (ds1.Tables["FaciltyIdentifier"].Rows.Count > 0)
                    {

                        comboBox_PFI.DataSource = ds1.Tables["FaciltyIdentifier"];
                        comboBox_PFI.ValueMember = "uniqueId";
                        comboBox_PFI.DisplayMember = "facility_identifier";


                        comboBox_CSVGeneratedDate.DataSource = ds1.Tables["CSVGenerated"];
                        comboBox_CSVGeneratedDate.ValueMember = "CsVGenerated_date";
                        comboBox_CSVGeneratedDate.DisplayMember = "CsVGenerated_date";
                        // comboBox_CSVGeneratedDate.SelectedIndex = 0;


                    }
                    //else
                    //{

                    //}
                }
          
            }
            catch (Exception ex)
            {

            }

        }





        //private void dataGridView_DisplayData_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        //{
        //    if (e.RowIndex == 1)
        //    {
        //        DataGridViewCell cell = dataGridView_DisplayData.Rows[e.RowIndex].Cells["Record_Completed"];
        //        DataGridViewCheckBoxCell chkCell = cell as DataGridViewCheckBoxCell;
        //        chkCell.Value = false;
        //        chkCell.FlatStyle = FlatStyle.Flat;
        //        chkCell.Style.ForeColor = Color.DarkGray;
        //        cell.ReadOnly = true;

        //    }
        //}



        private void button_Search_Click(object sender, EventArgs e)
        {
            try 
            {

            LoadGrid();

            }
            catch (Exception ex)
            {

            }
    

        }

        public void LoadGrid()
        {
            try
                    {

                      

                if (comboBox_Version.Text.ToString().Trim() == "")
                {
                    MessageBox.Show("Please select Version.", "Sepsis Master Error");
                    comboBox_Version.Focus();
                    return;
                }





                if (comboBox_Version.Text.ToString().Trim() == "6.3")
                    Version = "6.2";
                else
                    Version = comboBox_Version.Text.ToString().Trim();




                   

                  

                   DateCreatedFrom = textbox_DataCreatedFrom.Text.ToString();
                   DateCreatedTo = textBox_DateCreatedTo.Text.ToString();
                   txtPCN = TextBox_PatientCtrlNum.Text.ToString();  
                   txtMRN1 = txtMRN.Text.ToString();
                   //if (comboBox_CSVGeneratedDate.Text.ToString().Trim() != "")
                   //{
                      // CSV_Date =  DateTime.Parse(comboBox_CSVGeneratedDate.Text.ToString().Trim());
                       CSV_Date = comboBox_CSVGeneratedDate.Text.ToString().Trim();
                   //}
                
                   if (DateCreatedFrom == "  /  /")
                   {
                       DateCreatedFrom = "";
                   }

                   if (DateCreatedTo == "  /  /")
                   {
                       DateCreatedTo = "";
                   }
               
                if (radioButton_RecordCompleteYes.Checked == true)
                {
                    RecordComplete = 1;
               }
                else if(radioButton_RecordCompleteNo.Checked == true)
                {
                     RecordComplete = 0;
                }
                else if (radioButton_RecordCompleteBoth.Checked == true)
                {
                    RecordComplete = null;
                }
                else
                {
                    RecordComplete = null;
                }

               
                    
                if ( radioButton_CSVGeneratedYes.Checked == true)
                {
                    CSVGenerated = 1;
               }

                else if (radioButton_CSVGeneratedNo.Checked == true)
                {
                     CSVGenerated = 0;
                }
                else if (radioButton_CSVGeneratedBoth.Checked == true)
                {
                    CSVGenerated = null;
                }
                else
                {
                    CSVGenerated = null;
                }



                if (comboBox_PFI.Text == "" || comboBox_PFI.Text == "All")
                {
                    PFI = null;
                }
                //else if (comboBox_PFI.Text == "")
                //{

                //}
                else
                {
                    PFI = comboBox_PFI.Text.ToString().Trim();
                }

               
                    // ConnectionString = "FIL=Sql server;DSN=" + sDSN;

                    ds = new DataSet();

                    //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                    using (Conn = new OdbcConnection(ConnectionString))
                    {
                        Conn.Open();

                        //query = "select UniqueId, unique_personal_identifier, patient_control_number, date_of_birth, medical_record_number,Date_Created, Record_Completed, CSVGenerated from sepsis_collab ";
                        //query = query + "where Version = " + comboBox_Version.Text.ToString().Trim();
                        //query = "Sepsis_SelectMaster";
                        query = "{call Sepsis_SelectMaster(?,?,?,?,?,?,?,?,?)}";

                        //using (SqlCommand Sqlcmd = new SqlCommand())
                        using (OdbcCommand Sqlcmd = new OdbcCommand())
                        {


                            Sqlcmd.CommandText = query;
                            Sqlcmd.CommandType = CommandType.StoredProcedure;

                            Sqlcmd.Connection = Conn;


                            //Sqlcmd.Parameters.Add(new SqlParameter("Version", Version));
                            //Sqlcmd.Parameters.Add(new SqlParameter("DateCreatedFrom", DateCreatedFrom));
                            //Sqlcmd.Parameters.Add(new SqlParameter("DatecreatedTo", DateCreatedTo));
                            //Sqlcmd.Parameters.Add(new SqlParameter("RecordComplete", RecordComplete));
                            //Sqlcmd.Parameters.Add(new SqlParameter("CSVGenerated", CSVGenerated));
                            //Sqlcmd.Parameters.Add(new SqlParameter("MRN", txtMRN1));
                            //Sqlcmd.Parameters.Add(new SqlParameter("PCN",  txtPCN));


                            Sqlcmd.Parameters.Add(new OdbcParameter("Version", Version));
                            Sqlcmd.Parameters.Add(new OdbcParameter("DateCreatedFrom", DateCreatedFrom));
                            Sqlcmd.Parameters.Add(new OdbcParameter("DatecreatedTo", DateCreatedTo));
                            Sqlcmd.Parameters.Add(new OdbcParameter("RecordComplete", RecordComplete));
                            Sqlcmd.Parameters.Add(new OdbcParameter("CSVGenerated", CSVGenerated));
                            Sqlcmd.Parameters.Add(new OdbcParameter("MRN", txtMRN1));
                            Sqlcmd.Parameters.Add(new OdbcParameter("PCN", txtPCN));
                            Sqlcmd.Parameters.Add(new OdbcParameter("PFI", PFI));
                            Sqlcmd.Parameters.Add(new OdbcParameter("CSV_Date", CSV_Date));


                            //SqlDataAdapter dbDataAdapter = new SqlDataAdapter(Sqlcmd);
                            OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter(Sqlcmd);

                            dbDataAdapter.Fill(ds, "MasterDisplay");
                            //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where Date_Created between '2016/10/25' and '2017/1/28'";
                            //dbDataAdapter.Fill(ds, "sepsis_collab");

                            dataGridView_DisplayData.DataSource = ds.Tables["MasterDisplay"];

                            dataGridView_DisplayData.Columns["UniqueId"].Visible = false; // will be use while selecting particular records for edits.
                            dataGridView_DisplayData.Columns["unique_personal_identifier"].HeaderText = "Unique Personal Identifier";
                            dataGridView_DisplayData.Columns["patient_control_number"].HeaderText = "patient Control Number";
                            dataGridView_DisplayData.Columns["date_of_birth"].HeaderText = "Date of Birth";
                            dataGridView_DisplayData.Columns["medical_record_number"].HeaderText = "Medical Record Number";
                            dataGridView_DisplayData.Columns["facility_identifier"].HeaderText = "Facility Identifier";
                            dataGridView_DisplayData.Columns["Date_Created"].HeaderText = "Discharged Date";
                            dataGridView_DisplayData.Columns["Record_Completed"].HeaderText = "Record Completed";
                            //dataGridView_DisplayData.Columns["CSVGenerated"].HeaderText = "CSV Generated";
                            dataGridView_DisplayData.Columns["CsvGenerated_Date"].HeaderText = "CSV Generated Date";
                            dataGridView_DisplayData.Columns["version"].Visible = false; // will be use while selecting particular records for edits.

                            //foreach (DataGridViewColumn column in this.dataGridView_DisplayData.Columns)
                            //{
                            //    if (column.Name == "Date_Created")
                            //    {
                            //        column.ValueType = typeof(string);

                            //    }

                            //}


                          // dataGridView_DisplayData.Columns["Date_Created"].DefaultCellStyle.Format = "MM/dd/yyyy HH:mm";

                           dataGridView_DisplayData.Columns["Date_Created"].DefaultCellStyle.Format = "MM/dd/yyyy";
                          // dataGridView_DisplayData.Columns["CsvGenerated_Date"].DefaultCellStyle.Format = "MM/dd/yyyy";

                           var col3 = new DataGridViewTextBoxColumn();

                           var col9 = new DataGridViewCheckBoxColumn();
                         

                           //col3.HeaderText = "Column3";
                            
                              if (dataGridView_DisplayData.Columns[0].Name == "CaseNumber")
                              {
                                  dataGridView_DisplayData.Columns.RemoveAt(0);
                              }

                              if (dataGridView_DisplayData.Columns[0].Name == "ExportCSV")
                              {
                                  dataGridView_DisplayData.Columns.RemoveAt(0);
                              }

                           col3.HeaderText = "Case Number";
                           col3.Name = "CaseNumber";

                           col9.HeaderText = "Export to CSV";
                           col9.Name = "ExportCSV";
                          // dataGridView_DisplayData.Columns.RemoveAt(0);

                           dataGridView_DisplayData.Columns.Insert(0, col3);
                           dataGridView_DisplayData.Columns[0].ReadOnly = true;

                           dataGridView_DisplayData.Columns.Insert(9, col9);
                 





                           for (int i = 0; i <= dataGridView_DisplayData.ColumnCount - 1; i++)
                           {
                               dataGridView_DisplayData.Columns[i].ReadOnly = true;

                        
                           }

                           count = 0;
                           ExportCSV_Sorting.Clear();

                            for (int i = 0; i <= dataGridView_DisplayData.RowCount - 1; i++)
                            {

                                //if (dataGridView_DisplayData.Rows[i].Cells["Date_Created"].Value.ToString() != "")
                                //{
                                //dDate= DateTime.Parse(dataGridView_DisplayData.Rows[i].Cells["Date_Created"].Value.ToString());
                                    //dataGridView_DisplayData.Rows[i].Cells[9].co
                                   
                                //    //dataGridView_DisplayData.Rows[i].Cells["Date_Created"].Value = "";
                                //dataGridView_DisplayData.Rows[i].Cells["Date_Created"].Value.ToString("MM/dd/yyyy HH:mm");

                                //dataGridView_DisplayData.Rows[i].Cells["Date_Created"].Value = DateTime.Parse(dDate.ToString("MM/dd/yyyy HH:mm"));
                                
                                //}
                                //dataGridView_DisplayData["Admission Date", i].ToString() = DateTime.Parse(dataGridView_DisplayData["Admission Date", i].ToString()).ToString();
                                DataGridViewCell cell = dataGridView_DisplayData.Rows[i].Cells["Record_Completed"];
                                DataGridViewCheckBoxCell chkCell = cell as DataGridViewCheckBoxCell;
                                DataGridViewRow Rw = dataGridView_DisplayData.Rows[i];

                                DataGridViewCell cell_csv = dataGridView_DisplayData.Rows[i].Cells["ExportCSV"];
                                DataGridViewCheckBoxCell chkCell_csv = cell_csv as DataGridViewCheckBoxCell;
                                chkCell_csv.Value = true;

                               

                                if (Convert.ToBoolean(chkCell.Value) == true && Convert.ToBoolean(cell_csv.Value) == true)
                                {
                                    dataGridView_DisplayData.Rows[i].Cells["CaseNumber"].Value = ++count;

                                    ExportCSV_Sorting.Add(dataGridView_DisplayData.Rows[i].Cells["UniqueId"].Value);
                                }
                                else
                                    dataGridView_DisplayData.Rows[i].Cells["CaseNumber"].Value = "";



                                if (Convert.ToBoolean(chkCell.Value) != true)
                                {

                                    chkCell_csv.ReadOnly = true;
                                    chkCell_csv.FlatStyle = FlatStyle.Flat;
                                    chkCell_csv.Style.ForeColor = Color.DarkGray;
                                    Rw.DefaultCellStyle.BackColor = Color.Yellow;


                                }
                                else
                                {
                                    chkCell_csv.ReadOnly = false;

                                    Rw.DefaultCellStyle.BackColor = Color.White;
                                }
                            }

                            count = 0;

                        }


                        Conn.Close();
                    }

                }
            
            catch (Exception ex)
            {
                int line = 0;

                StackTrace st = new StackTrace(true);
                for (int i = 0; i < st.FrameCount; i++)
                {

                    StackFrame sf = st.GetFrame(i);
                    var frame = sf.GetMethod();
                    line = sf.GetFileLineNumber();

                    if (line > 0)
                        break;

                }


                using (Conn = new OdbcConnection(ConnectionString))
                {
                    Conn.Open();

                    query = "{call Sepsis_ErrorLog(?,?,?,?)}";

                    //using (SqlCommand Sqlcmd = new SqlCommand())
                    using (OdbcCommand Sqlcmd = new OdbcCommand())
                    {

                        Sqlcmd.CommandText = query;
                        Sqlcmd.CommandType = CommandType.StoredProcedure;
                        Sqlcmd.Connection = Conn;

                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Line", line));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Desc", ex.Message));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Form", "SepsisCaseDetails.cs"));
                        Sqlcmd.Parameters.Add(new OdbcParameter("Error_Datetime", DateTime.Now));


                        Sqlcmd.ExecuteNonQuery();




                        Conn.Close();



                    }
                }

            }
        }

        private void button_AddNewCase_Click(object sender, EventArgs e)
        {
            try
            {

                if (comboBox_Version.Text == "4.1")
                {
                    SepsisCaseDetails sp = new SepsisCaseDetails(this);
                    this.Hide();
                    sp.Show();
                    Control[] ctrls = sp.Controls.Find("txtId", true);
                    if (ctrls.Length > 0)
                    {
                        MaskedTextBox txt = (MaskedTextBox)ctrls[0];
                        txt.Focus();
                    }
               
                }
                else if (comboBox_Version.Text == "5.1")
                {
                    SepsisCaseDetails_5 sp = new SepsisCaseDetails_5(this);
                    this.Hide();
                    sp.Show();
                    Control[] ctrls = sp.Controls.Find("txtId", true);
                    if (ctrls.Length > 0)
                    {
                        MaskedTextBox txt = (MaskedTextBox)ctrls[0];
                        txt.Focus();
                    }

                }
                else if (comboBox_Version.Text == "6.3")
                {
                    SepsisCaseDetails_6 sp = new SepsisCaseDetails_6(this);
                    this.Hide();
                    sp.Show();
                    Control[] ctrls = sp.Controls.Find("txtId", true);
                    if (ctrls.Length > 0)
                    {
                        MaskedTextBox txt = (MaskedTextBox)ctrls[0];
                        txt.Focus();
                    }

                }
                else if (comboBox_Version.Text == "7.1")
                {
                    SepsisCaseDetails_7 sp = new SepsisCaseDetails_7(this);
                    this.Hide();
                    sp.Show();
                    Control[] ctrls = sp.Controls.Find("txtId", true);
                    if (ctrls.Length > 0)
                    {
                        MaskedTextBox txt = (MaskedTextBox)ctrls[0];
                        txt.Focus();
                    }

                }

                else if (comboBox_Version.Text == "1.1")
                {
                    SepsisCaseDetails_1_1 sp = new SepsisCaseDetails_1_1(this);
                    this.Hide();
                    sp.Show();
                    Control[] ctrls = sp.Controls.Find("txtId", true);
                    if (ctrls.Length > 0)
                    {
                        MaskedTextBox txt = (MaskedTextBox)ctrls[0];
                        txt.Focus();
                    }

                }
                else if (comboBox_Version.Text == "2.0")
                {
                    SepsisCaseDetails_2_0 sp = new SepsisCaseDetails_2_0(this);
                    this.Hide();
                    sp.Show();
                    Control[] ctrls = sp.Controls.Find("txtId", true);
                    if (ctrls.Length > 0)
                    {
                        MaskedTextBox txt = (MaskedTextBox)ctrls[0];
                        txt.Focus();
                    }
                }

            }
            catch (Exception ex)
            {

            }
            
        }

        private void dataGridView_DisplayData_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {

              
                }
            catch (Exception ex)
            {

            }
        }

        private void dataGridView_DisplayData_Sorted(object sender, EventArgs e)
        {
            try
            {

                
                var col3 = new DataGridViewTextBoxColumn();

                //ExportCSV_Sorting.Clear();

                //col3.HeaderText = "Column3";


                col3.HeaderText = "Case Number";
                col3.Name = "CaseNumber";
                dataGridView_DisplayData.Columns.RemoveAt(0);

                dataGridView_DisplayData.Columns.Insert(0, col3);
                //dataGridView_DisplayData.Columns.Add();

                count = 0;

                //for (int j = 0; j <= ExportCSV_Sorting.Count - 1; j++)
                //{
                //    foreach (DataGridViewRow row in dataGridView_DisplayData.Rows)
                //    {

                //        if (row.Cells["UniqueId"].Value.ToString().Trim() == ExportCSV_Sorting[j].ToString().Trim())
                //        {
                //            //(dataGridView_DisplayData.Rows[i].Cells["ExportCSV"] as DataGridViewCheckBoxCell).Value = true;
                //            row.Cells["ExportCSV"].Value = true;
                //            break;

                //        }
                //        //row.Cells[CheckBoxColumn1.Name].Value = true;
                //    }
                

                //}

            


            for (int i = 0; i <= dataGridView_DisplayData.RowCount - 1; i++)
            {

           
                DataGridViewCell cell = dataGridView_DisplayData.Rows[i].Cells["Record_Completed"];
                DataGridViewCheckBoxCell chkCell = cell as DataGridViewCheckBoxCell;
                DataGridViewRow Rw = dataGridView_DisplayData.Rows[i];

                DataGridViewCell cell_csv = dataGridView_DisplayData.Rows[i].Cells["ExportCSV"];
                DataGridViewCheckBoxCell chkCell_csv = cell_csv as DataGridViewCheckBoxCell;
                //Console.WriteLine(cell_csv.Value);
                //if (dataGridView_DisplayData[9, i].Selected == true)
                //{
                //    dataGridView_DisplayData[9, i].Selected = false;
                //    dataGridView_DisplayData[0, 0].Selected = true;
                //}

                for (int j = 0; j <= ExportCSV_Sorting.Count - 1; j++)
                {
                    if (dataGridView_DisplayData.Rows[i].Cells["UniqueId"].Value.ToString().Trim() == ExportCSV_Sorting[j].ToString().Trim())
                    {
                      
                        (dataGridView_DisplayData.Rows[i].Cells["ExportCSV"] as DataGridViewCheckBoxCell).Value = true;
                        chkCell_csv.Value = true;
                        break;

                    }

                }


                if (Convert.ToBoolean(chkCell.Value) == true && Convert.ToBoolean(cell_csv.Value) == true)
                {
                    dataGridView_DisplayData.Rows[i].Cells["CaseNumber"].Value = ++count;
                   
                }
                else
                    dataGridView_DisplayData.Rows[i].Cells["CaseNumber"].Value = "";

                if (Convert.ToBoolean(chkCell.Value) != true)
                {
                    chkCell_csv.ReadOnly = true;
                    chkCell_csv.FlatStyle = FlatStyle.Flat;
                    chkCell_csv.Style.ForeColor = Color.DarkGray;

                    Rw.DefaultCellStyle.BackColor = Color.Yellow;


                }
                else
                {
                    chkCell_csv.ReadOnly = false;
                    Rw.DefaultCellStyle.BackColor = Color.White;
                }

                //if (i == dataGridView_DisplayData.RowCount - 1)
                //{
            
                  
               
                }

            }
            catch (Exception ex)
            {

            }

        }

        private void SepsisMaster_HelpButtonClicked(object sender, CancelEventArgs e)
        {
            Help hp = new Help();
            hp.Show();
            e.Cancel = true;
        }

        private void dataGridView_DisplayData_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {

                if (comboBox_Version.Text == "4.1")
                {

                    SepsisCaseDetails SD = new SepsisCaseDetails(int.Parse(dataGridView_DisplayData["UniqueId", e.RowIndex].Value.ToString()), this);
                    this.Hide();
                    SD.Show();
                    Control[] ctrls = SD.Controls.Find("txtId", true);
                    if (ctrls.Length > 0)
                    {
                        MaskedTextBox txt = (MaskedTextBox)ctrls[0];
                        txt.Focus();
                    }
                    SD.SituationalDisplayforEdit();
                    SD.MandatoryColorChange();
               
                }
                else if (comboBox_Version.Text == "5.1")
                {

                    SepsisCaseDetails_5 SD = new SepsisCaseDetails_5(int.Parse(dataGridView_DisplayData["UniqueId", e.RowIndex].Value.ToString()), this);
                    this.Hide();
                    SD.Show();
                    Control[] ctrls = SD.Controls.Find("txtId", true);
                    if (ctrls.Length > 0)
                    {
                        MaskedTextBox txt = (MaskedTextBox)ctrls[0];
                        txt.Focus();
                    }
                    
                    SD.SituationalDisplayforEdit();
                    SD.MandatoryColorChange();
                }

                else if (comboBox_Version.Text == "6.3")
                {

                    SepsisCaseDetails_6 SD = new SepsisCaseDetails_6(int.Parse(dataGridView_DisplayData["UniqueId", e.RowIndex].Value.ToString()), this);
                    this.Hide();
                    SD.Show();
                    Control[] ctrls = SD.Controls.Find("txtId", true);
                    if (ctrls.Length > 0)
                    {
                        MaskedTextBox txt = (MaskedTextBox)ctrls[0];
                        txt.Focus();
                    }

                    SD.SituationalDisplayforEdit();
                    SD.MandatoryColorChange();

                }
                else if (comboBox_Version.Text == "7.1")
                {

                    SepsisCaseDetails_7 SD = new SepsisCaseDetails_7(int.Parse(dataGridView_DisplayData["UniqueId", e.RowIndex].Value.ToString()), this);
                    this.Hide();
                    SD.Show();
                    Control[] ctrls = SD.Controls.Find("txtId", true);
                    if (ctrls.Length > 0)
                    {
                        MaskedTextBox txt = (MaskedTextBox)ctrls[0];
                        txt.Focus();
                    }

                    SD.SituationalDisplayforEdit();
                    SD.MandatoryColorChange();

                }
                else if (comboBox_Version.Text == "1.1")
                {

                    SepsisCaseDetails_1_1 SD = new SepsisCaseDetails_1_1(int.Parse(dataGridView_DisplayData["UniqueId", e.RowIndex].Value.ToString()), this);
                    this.Hide();
                    SD.Show();
                    Control[] ctrls = SD.Controls.Find("txtId", true);
                    if (ctrls.Length > 0)
                    {
                        MaskedTextBox txt = (MaskedTextBox)ctrls[0];
                        txt.Focus();
                    }

                    SD.SituationalDisplayforEdit();
                    SD.MandatoryColorChange();
                }

                else if (comboBox_Version.Text == "2.0")
                {
                    SepsisCaseDetails_2_0 sp = new SepsisCaseDetails_2_0(int.Parse(dataGridView_DisplayData["UniqueId", e.RowIndex].Value.ToString()), this);
                    this.Hide();
                    sp.Show();
                    Control[] ctrls = sp.Controls.Find("txtId", true);
                    if (ctrls.Length > 0)
                    {
                        MaskedTextBox txt = (MaskedTextBox)ctrls[0];
                        txt.Focus();
                    }
                    sp.SituationalDisplayforEdit();
                    sp.MandatoryColorChange();
                }


                //if (dataGridView_DisplayData.CurrentCell.ColumnIndex.Equals(1) && e.RowIndex != -1)
                //{
                //    if (dataGridView_DisplayData.CurrentCell != null && dataGridView_DisplayData.CurrentCell.Value != null)
                //    {

                // MessageBox.Show(dataGridView_DisplayData.CurrentCell.Value.ToString());
                //    }
                //}
            }
            catch (Exception ex)
            {

            }

        }



        private void dataGridView_DisplayData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //if (dataGridView_DisplayData.CurrentCell.OwningColumn.Name == "ExportCSV" && e.RowIndex != -1)
                //{


                //    for (int i = 0; i <= dataGridView_DisplayData.RowCount - 1; i++)
                //    {
                //        if (dataGridView_DisplayData[9, i].Selected == true)
                //            dataGridView_DisplayData[9, i].Selected = false;

                //    }
                //    //dataGridView_DisplayData.Rows[e.RowIndex].Cells[1].Selected = true;
                //    //dataGridView_DisplayData.CurrentCell = dataGridView_DisplayData.Rows[e.RowIndex].Cells[1];
                //    // dataGridView_DisplayData[1, e.RowIndex].Selected = true;
                //}
  

                if (dataGridView_DisplayData.CurrentCell.OwningColumn.Name == "ExportCSV" && e.RowIndex != -1)
                {
                    count = 0;
                    ExportCSV_Sorting.Clear();
                    if (dataGridView_DisplayData.Columns[0].Name == "CaseNumber")
                    {
                        dataGridView_DisplayData.Columns.RemoveAt(0);
                    }

                    var col = new DataGridViewTextBoxColumn();
                    col.HeaderText = "Case Number";
                    col.Name = "CaseNumber";
                    // dataGridView_DisplayData.Columns.RemoveAt(0);

                    dataGridView_DisplayData.Columns.Insert(0, col);
                    dataGridView_DisplayData.Columns[0].ReadOnly = true;

                    for (int i = 0; i <= dataGridView_DisplayData.RowCount - 1; i++)
                    {


                        DataGridViewCell cell = dataGridView_DisplayData.Rows[i].Cells["Record_Completed"];
                        DataGridViewCheckBoxCell chkCell = cell as DataGridViewCheckBoxCell;
                        //DataGridViewRow Rw = dataGridView_DisplayData.Rows[i];

                        DataGridViewCell cell_csv = dataGridView_DisplayData.Rows[i].Cells["ExportCSV"];
                        DataGridViewCheckBoxCell chkCell_csv = cell_csv as DataGridViewCheckBoxCell;

                        if (Convert.ToBoolean(chkCell.Value) == true && Convert.ToBoolean(chkCell_csv.Value) == true)
                        {
                            dataGridView_DisplayData.Rows[i].Cells["CaseNumber"].Value = ++count;

                            ExportCSV_Sorting.Add(dataGridView_DisplayData.Rows[i].Cells["UniqueId"].Value);
                        }
                        else
                            dataGridView_DisplayData.Rows[i].Cells["CaseNumber"].Value = "";

                    }
                }

            }
            catch (Exception ex)
            {

            }
        }

     

        private void Label_ClickHere_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Help hp = new Help();
            hp.Show();
        }

        private void comboBox_Version_SelectedIndexChanged(object sender, EventArgs e)
        {


            try
            {
               
           
                ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;


                if (comboBox_Version.Text.ToString().Trim() == "6.3")
                    Version = "6.2";
                else
                    Version = comboBox_Version.Text.ToString().Trim();

                using (Conn = new OdbcConnection(ConnectionString))
                {
                    DataSet ds1 = new DataSet();

                    Conn.Open();



                    //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                    using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter("Select distinct facility_identifier 'uniqueId', facility_identifier from sepsis_collab where version ='"+ Version + "'", Conn))
                    {

                        dbDataAdapter.Fill(ds1, "FaciltyIdentifier");
                        //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                        // dbDataAdapter.Fill(ds, "sepsis_collab");

                    }

                    using (OdbcDataAdapter dbDataAdapter_CSVDate = new OdbcDataAdapter("select distinct (CONVERT(VARCHAR(10),CsVGenerated_date,101) + ' ' + CONVERT(VARCHAR(10),CsVGenerated_date,108)) as 'CsVGenerated_date' from [dbo].[sepsis_collab] where CsVGenerated_date is not null", Conn))
                    {

                        dbDataAdapter_CSVDate.Fill(ds1, "CSVGenerated");
                        //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                        // dbDataAdapter.Fill(ds, "sepsis_collab");

                    }


                    Conn.Close();

                    //comboBox_PFI.ValueMember = "ComboBox_Key";
                    //comboBox_PFI.DisplayMember = "ComboBox_Value";
                    //DataRow dr = ds1.Tables[0].NewRow();
                    //dr["uniqueId"] = "";
                    //dr["facility_identifier"] = "";// Some ID
                    //ds1.Tables[0].Rows.InsertAt(dr, 0);

                    if (ds1.Tables["FaciltyIdentifier"].Rows.Count > 1)
                    {

                        //for (int i = 0; i <= ds1.Tables["FaciltyIdentifier"].Rows.Count - 1; i++)
                        //{
                        if (ds1.Tables["FaciltyIdentifier"].Rows[0][0].ToString() == "")
                        {
                            ds1.Tables["FaciltyIdentifier"].Rows.RemoveAt(0);
                        }
                        // }

                        DataRow dr = ds1.Tables[0].NewRow();
                        dr["uniqueId"] = "";
                        dr["facility_identifier"] = "All";// Some ID
                        ds1.Tables[0].Rows.InsertAt(dr, 0);

                        //ds1.Tables[1].Columns[0].DataType = typeof(string);


                        //DataTable dtCloned = ds1.Tables[1].Clone();
                        //dtCloned.Columns[0].DataType = typeof(string);
                        //foreach (DataRow row in ds1.Tables[1].Rows)
                        //{
                        //    dtCloned.ImportRow(row);
                        //}




                        // dtCloned.Columns[0].DataType = typeof(string);


                        //dataGridView_DisplayData.Columns["Date_Created"].DefaultCellStyle.Format = "MM/dd/yyyy HH:mm";

                        DataRow dr_Date = ds1.Tables[1].NewRow();
                        dr_Date["CsVGenerated_date"] = "";// Some ID
                        ds1.Tables[1].Rows.InsertAt(dr_Date, 0);
                        //ds1.Tables[0].Rows.Add(dr);
                        // comboBox_PFI.Items.Add("All");

                        //comboBox_PFI.Items.Insert(0,);
                        comboBox_PFI.DataSource = ds1.Tables["FaciltyIdentifier"];
                        comboBox_PFI.ValueMember = "uniqueId";
                        comboBox_PFI.DisplayMember = "facility_identifier";
                        comboBox_PFI.SelectedIndex = 0;


                        comboBox_CSVGeneratedDate.DataSource = ds1.Tables["CSVGenerated"];
                        comboBox_CSVGeneratedDate.ValueMember = "CsVGenerated_date";
                        comboBox_CSVGeneratedDate.DisplayMember = "CsVGenerated_date";
                        comboBox_CSVGeneratedDate.SelectedIndex = 0;
                    }
                    else if (ds1.Tables["FaciltyIdentifier"].Rows.Count > 0)
                    {

                        comboBox_PFI.DataSource = ds1.Tables["FaciltyIdentifier"];
                        comboBox_PFI.ValueMember = "uniqueId";
                        comboBox_PFI.DisplayMember = "facility_identifier";


                        comboBox_CSVGeneratedDate.DataSource = ds1.Tables["CSVGeneratedDate"];
                        comboBox_CSVGeneratedDate.ValueMember = "CsVGenerated_date";
                        comboBox_CSVGeneratedDate.DisplayMember = "CsVGenerated_date";
                        // comboBox_CSVGeneratedDate.SelectedIndex = 0;


                    }
                    else

                    {
                        comboBox_PFI.DataSource = null;
                       
                    }
                    //else
                    //{

                    //}

                    ds1.Dispose();

                }



                dataGridView_DisplayData.DataSource = null;
                dataGridView_DisplayData.Columns.Clear();

            }
            catch (Exception ex)
            {

            }




        }

        private void button_ClearCSVChecks_Click(object sender, EventArgs e)
        {
            try { 

                count = 0;
                ExportCSV_Sorting.Clear();
              
                dataGridView_DisplayData.Columns.RemoveAt(0);

                var col = new DataGridViewTextBoxColumn();
                col.HeaderText = "Case Number";
                col.Name = "CaseNumber";
         

                dataGridView_DisplayData.Columns.Insert(0, col);
                dataGridView_DisplayData.Columns[0].ReadOnly = true;

                for (int i = 0; i <= dataGridView_DisplayData.RowCount - 1; i++)
                {


                    DataGridViewCell cell = dataGridView_DisplayData.Rows[i].Cells["Record_Completed"];
                    DataGridViewCheckBoxCell chkCell = cell as DataGridViewCheckBoxCell;
                    //DataGridViewRow Rw = dataGridView_DisplayData.Rows[i];

                    DataGridViewCell cell_csv = dataGridView_DisplayData.Rows[i].Cells["ExportCSV"];
                    DataGridViewCheckBoxCell chkCell_csv = cell_csv as DataGridViewCheckBoxCell;

                    if (Convert.ToBoolean(chkCell.Value) == true && Convert.ToBoolean(chkCell_csv.Value) == true)
                    {
                        chkCell_csv.Value = false;
                        dataGridView_DisplayData.Rows[i].Cells["CaseNumber"].Value = "";

                        ExportCSV_Sorting.Clear();

                        // ExportCSV_Sorting.Add(dataGridView_DisplayData.Rows[i].Cells["UniqueId"].Value);
                    }
                    else if (Convert.ToBoolean(chkCell.Value) == true && Convert.ToBoolean(chkCell_csv.Value) == false)
                    {
                        chkCell_csv.Value = true;
                        //dataGridView_DisplayData.Rows[i].Cells["CaseNumber"].Value = "";
                        dataGridView_DisplayData.Rows[i].Cells["CaseNumber"].Value = ++count;

                        ExportCSV_Sorting.Add(dataGridView_DisplayData.Rows[i].Cells["UniqueId"].Value);
                    }

                }
            

            //for (int i = 0; i <= dataGridView_DisplayData.RowCount - 1; i++)
            //{


               

            //    DataGridViewCell cell_csv = dataGridView_DisplayData.Rows[i].Cells["ExportCSV"];
            //    DataGridViewCheckBoxCell chkCell_csv = cell_csv as DataGridViewCheckBoxCell;
            //    if (Convert.ToBoolean(chkCell_csv.Value) == true)
            //      chkCell_csv.Value = false;
            //    else
            //        chkCell_csv.Value = true;
            //}

        }
            catch (Exception ex)
            {

            }


}

        private void button_ExportSampling_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView_DisplayData.RowCount >= 1)
                {
                    if (comboBox_PFI.Text.ToString().Trim() == "All")
                    {
                        MessageBox.Show("Your CSV contains more than one Facility Identifier.", "Sepsis Master Error");
                        comboBox_PFI.Focus();
                        return;
                    }

                    var versionID = ds.Tables["MasterDisplay"]
                                         .AsEnumerable()
                                         //.Where(r => r.Field<string>("version") == comboBox_Version.Text.Trim())
                                          .Where(r => r.Field<string>("version") == Version)
                                         .Select(r => r.Field<string>("version"))
                                         .Distinct();


                    if (versionID.Count() == 0)
                    {
                        MessageBox.Show("Version selected does not match with version in the wizard. Please click Search button.", "Sepsis Master Error");
                        comboBox_Version.Focus();
                        return;
                    }

                    int uniqueCount = ds.Tables["MasterDisplay"]
                                         .AsEnumerable()
                                         .Where(r => r.Field<string>("facility_identifier") != null)
                                         .Select(r => r.Field<string>("facility_identifier"))
                                         .Distinct()
                                         .Count();

                    if (uniqueCount > 1)
                    {
                        MessageBox.Show("Press the Search button to display just the cases for your Facility Identifier.", "Sepsis Master Error");
                        button_Search.Focus();
                        return;
                    }

                    recordcompleteUniqueID.Clear();

                   
                    for (int i = 0; i <= dataGridView_DisplayData.Rows.Count - 1; i++)
                    {
                        //if (dataGridView_DisplayData.Rows[i].Cells[0].Value.ToString() != "")
                        //{
                            //if (bool.Parse(dataGridView_DisplayData.Rows[i].Cells["Record_Completed"].Value.ToString()) == true && bool.Parse(dataGridView_DisplayData.Rows[i].Cells["ExportCSV"].Value.ToString()) == true)
                            //{

                            //recordcompletecount++;
                            recordcompleteUniqueID.Add(dataGridView_DisplayData.Rows[i].Cells["UniqueId"].Value.ToString());
                        //}
                    }


                    //for (int i = 0; i <= ds.Tables["MasterDisplay"].Rows.Count - 1; i++)
                    //{
                    //    if (bool.Parse(ds.Tables["MasterDisplay"].Rows[i]["Record_Completed"].ToString()) == true && bool.Parse(ds.Tables["MasterDisplay"].Rows[i]["ExportCSV"].ToString()) == true)
                    //    {

                    //        recordcompletecount++;
                    //        recordcompleteUniqueID.Add(ds.Tables["MasterDisplay"].Rows[i]["UniqueId"].ToString());
                    //    }
                    //}


                    querystring.Clear();

                    if (recordcompleteUniqueID.Count > 0)
                    {
                        if (recordcompleteUniqueID.Count == 1)
                        {
                            querystring.Append(recordcompleteUniqueID[0]);
                        }
                        else
                        {

                            //else
                            //{
                            //    //lbl_Note.Hide();
                            //}


                            for (int i = 0; i <= recordcompleteUniqueID.Count - 1; i++)
                            {
                                querystring.Append(recordcompleteUniqueID[i]);
                                if (i != recordcompleteUniqueID.Count - 1)
                                    querystring.Append(",");

                            }
                        }

                        //if (recordcompleteUniqueID.Count != ds.Tables["MasterDisplay"].Rows.Count)
                        //{
                        //    //lbl_Note.Show();
                        //    MessageBox.Show("Please note, Only the records completed successfully will be uploaded to CSV.", "Export Message");
                        //}
                        DataSet ds = new DataSet();

                        string SelectData ="";

                        SelectData = SelectData + "Select admission_datetime, date_of_birth, discharge_datetime, discharge_status, facility_identifier, gender, medical_record_number, patient_control_number, source_of_admission, unique_personal_identifier";
                        SelectData = SelectData + " from sepsis_collab where UniqueId in (" + querystring.ToString() + ")";

                        ds.Clear();

                            //using (SqlConnection Conn = new SqlConnection(ConnectionString))
                            using (Conn = new OdbcConnection(ConnectionString))
                        {
                            //if (DataSetfillflag == 1)
                            //{
                            //    DataSetfillflag = 0;
                            //    ds.Tables["sepsis_collab"].Clear();
                            //    ds.Tables["CSV_MAPPING"].Clear();
                            //}

                            Conn.Open();

                            //using (SqlDataAdapter dbDataAdapter = new SqlDataAdapter("Select * from CSV_MAPPING where version = '" + Version +"' order by order_no", Conn))
                            using (OdbcDataAdapter dbDataAdapter = new OdbcDataAdapter(SelectData, Conn))
                            {

                                dbDataAdapter.Fill(ds, "SamplingData");
                                //dbDataAdapter.SelectCommand.CommandText = "  Select * from sepsis_collab where UniqueId in (" + _querystring + ")";
                                      
                            }

                            Conn.Close();
                        }

                        SamplingIncomplete.Clear();
                        for (int i = 0; i <= ds.Tables["SamplingData"].Rows.Count - 1; i++)
                        {
                            for (int j = 0; j <= ds.Tables["SamplingData"].Columns.Count - 1; j++)
                            {
                               
                               if (Convert.ToString(ds.Tables["SamplingData"].Rows[i][j]) == "")
                                {
                                    SamplingIncomplete.Add(ds.Tables["SamplingData"].Rows[i][9]);
                                    break;
                                }

                            }
                        }

                        if (SamplingIncomplete.Count > 0)
                        {
                            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                            FileName = "SamplingError.txt";
                            System.IO.Directory.CreateDirectory(path + "\\SamplingLog");
                            sw = new StreamWriter(path + "\\SamplingLog\\" + FileName);


                            SamplingIncompleteString.Clear();

                            //sw.WriteLine("{0}", DateTime.Now.ToString("mm-dd-yyyy HHmmss"));
                  
                            sw.WriteLine("{0}", "Following data does not meet sampling criteria:");
                            sw.WriteLine("{0}", "");
                            //SamplingIncompleteString.AppendLine("Following data does not meet sampling criteria:");
                            //SamplingIncompleteString.AppendLine("");

                            for (int i = 0; i <= SamplingIncomplete.Count - 1; i++)
                            {

                                sw.Write("{0}", i + 1 + ")");
                                sw.WriteLine("{0}", SamplingIncomplete[i].ToString());
                                //SamplingIncompleteString.Append(i + 1 + ")");
                                //SamplingIncompleteString.AppendLine(SamplingIncomplete[i].ToString());

                            }

                            SamplingIncompleteString.AppendLine("Few cases does not meet sampling requirements, Please find sampling error log at: ");
                            SamplingIncompleteString.AppendLine(path + "\\SamplingLog\\" + FileName);

                          MessageBox.Show(SamplingIncompleteString.ToString(), "Export Sampling Details");
                            sw.Close();
                        }
                    else
                    {
                        ExportForm Exp = new ExportForm(querystring.ToString(), Version, this, 1);
                        this.Hide();
                        Exp.Show();
                    }

                    }

                    else
                    {
                        MessageBox.Show("No case to export for Sampling", "Export Sampling Details");
                    }
                }
                else
                {
                    MessageBox.Show("There is no data in the grid to export to CSV.", "Export Details");
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void button_Reports_Click(object sender, EventArgs e)
        {
            if (comboBox_PFI.Text.ToString().Trim() == "All")
            {
                MessageBox.Show("Please select your Facility Identifier.", "Sepsis Master Error");
                comboBox_PFI.Focus();
                return;
            }
            else
            {

                Reports RR = new Reports(this, comboBox_PFI.Text);
                this.Hide();
                RR.Show();
            }
        }

        private void radioButton_Adult_CheckedChanged(object sender, EventArgs e)
        {

            comboBox_Version.Items.Clear();
            comboBox_Version.Items.Add("7.1");
            comboBox_Version.Items.Add("6.3");
            comboBox_Version.Items.Add("5.1");
            comboBox_Version.Items.Add("4.1");

            comboBox_Version.SelectedIndex = 0;
            dataGridView_DisplayData.DataSource = null;
            dataGridView_DisplayData.Columns.Clear();
            


        }

        private void radioButton_Pediatric_CheckedChanged(object sender, EventArgs e)
        {
            comboBox_Version.Items.Clear();
            comboBox_Version.Items.Add("2.0");
            comboBox_Version.Items.Add("1.1");
            comboBox_Version.Items.Add("5.1");
            comboBox_Version.Items.Add("4.1");

            comboBox_Version.SelectedIndex = 0;

        }

        private void button_Subscribe_Click(object sender, EventArgs e)
        {
            Verify obj = new Verify(this); 
            this.Hide();
            obj.Show();
        }

       private void button_AddDemoGraphics_Click(object sender, EventArgs e)
        {

            if (comboBox_PFI.SelectedValue != null && comboBox_PFI.SelectedValue != "" && comboBox_Version.Text != null && comboBox_Version.Text != "")
            {
                var DemoVersion = comboBox_Version.Text.ToString().Trim();
                //if (comboBox_Version.Text.ToString().Trim() == "6.3")
                //    DemoVersion = "6.2";
                //else
                //    DemoVersion = comboBox_Version.Text.ToString().Trim();
                if (DemoVersion == "7.1" || DemoVersion == "2.0")
                {
                    Demographics dg = new Demographics(this, comboBox_PFI.SelectedValue.ToString(), DemoVersion);
                    this.Hide();
                    dg.Show();
                }
                else
                    MessageBox.Show("Demegraphics Upload is available only for Versions 7.1 (or) 2.0");

                //DemoGraphics dg = new DemoGraphics(this, comboBox_PFI.SelectedValue.ToString(), comboBox_Version.Text.ToString());         
            }
            else
            {
                MessageBox.Show("Please Select Version & Facility Identifier");
            }
        } 
    }
}
