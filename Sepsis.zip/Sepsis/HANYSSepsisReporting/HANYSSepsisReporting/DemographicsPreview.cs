﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1;

namespace HANYSSepsisReporting
{
    public partial class DemographicsPreview : Form
    {
        Demographics dg;
        SepsisMaster sm;

        DataTable prevMappingColumnsDt = new DataTable();
        DataTable prevUploadFileDt = new DataTable();
        DataTable sepsisSaveDt = new DataTable();
        DataTable sepsisValidateCheckDt = new DataTable();
        string saveFileName;

        string format1 = "MM/dd/yyyy HH:mm";
        string format2 = "MM/dd/yyyy";

        OdbcConnection Conn;
        DataBaseConnection Db = new DataBaseConnection();

        string ConnectionString;
        string _facilityidentifier;
        string _version;
        public DemographicsPreview(Demographics _dg, SepsisMaster _sm, DataTable mappingDt, DataTable exceldt, string fileName, string facilityidentifier, string version)
        {
            InitializeComponent();
            dg = _dg;
            sm = _sm;

            dgprevMapping.DataSource = mappingDt;

            dgprevMapping.Columns[0].Width = 400;
            dgprevMapping.Columns[1].Width = 400;

            prevMappingColumnsDt = mappingDt;
            prevUploadFileDt = exceldt;

            DataColumn inValidRecord = new DataColumn("InValidRecord", typeof(string));
            inValidRecord.DefaultValue = 0;
            exceldt.Columns.Add(inValidRecord);

          
            var previewDT = PreviewDataValidationCheck(exceldt);

            DataColumn Sno = new DataColumn("S.No", typeof(string));
            Sno.DefaultValue = 1;
           
            previewDT.Columns.Add(Sno);
            Sno.SetOrdinal(0);

            int rowCount = 1;

            foreach (DataRow row in previewDT.Rows)
            {
                row["S.No"] = rowCount;
                rowCount++;
            }

            dgPreview.DataSource = previewDT;

            //for (int i = 0; i <= dgPreview.RowCount - 1; i++)
            //{


            //    if (dgPreview.Rows[i].Cells["InValidRecord"].Value!=null && dgPreview.Rows[i].Cells["InValidRecord"].Value.ToString() == "1")
            //    {
            //        dgPreview.Rows[i].DefaultCellStyle.BackColor = Color.Red;
            //        dgPreview.Rows[i].DefaultCellStyle.ForeColor = Color.Red;
            //    }

            //   // dgPreview.Columns["InValidRecord"].Visible = false;
            //}




            saveFileName = fileName;
            _facilityidentifier = facilityidentifier;
            _version = version;

            dgprevMapping.Columns[2].Width = 400;
            dgprevMapping.Columns[3].Width = 400;
            dgprevMapping.Columns[0].Visible = false;
            dgprevMapping.Columns[1].Visible = false;

            //Test();
        }

        private void DemoGraphicsPreview_FormClosing(object sender, FormClosingEventArgs e)
        {
            Demographics dg1 = new Demographics(sm, _facilityidentifier, _version);
            this.Hide();
            //dg1.Show();
        }

        private void dgPrievew_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //foreach (DataGridViewRow Myrow in dgPreview.Rows)
            //    if (Myrow.Cells["InValidRecord"].Value != null)
            //    {
            //        if (Myrow.Cells["InValidRecord"].Value.ToString() == "1")
            //        {
            //            Myrow.DefaultCellStyle.BackColor = Color.Red;
            //        }
            //    }

            foreach (DataGridViewRow Myrow in dgPreview.Rows)
            {
                string[] InvalidColumns;

                var values = Convert.ToString(Myrow.Cells["InvalidDataCoumns"].Value);

                if (values.Contains('@'))
                {
                    InvalidColumns = values.Split('@');
                    foreach (string col in InvalidColumns)
                    {
                        if (!string.IsNullOrEmpty(col))
                        {
                            foreach (DataGridViewCell Mycell in Myrow.Cells)
                            {
                                if (Mycell.OwningColumn.Name == col)
                                {
                                    Mycell.Style.BackColor = Color.DarkOrange;
                                }
                            }
                        }
                    }
                }
            }

            dgPreview.Columns["InValidRecord"].Visible = false;
            dgPreview.Columns["InvalidDataCoumns"].Visible = false;
        }

        private void btnSaveMapping_Click(object sender, EventArgs e)
        {
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;

            if (dgprevMapping.Rows.Count > 0)
            {
                OdbcConnection con = new OdbcConnection(ConnectionString);
                var SourceFileName = saveFileName;
                con.Open();
                //for (int i = 0; i < prevMappingColumnsDt.Rows.Count; i++)
                //{
                //    var id = Convert.ToInt32(prevMappingColumnsDt.Rows[i]["MappingId"]);
                //    if (id <= 0)
                //    {
                //        string insertpolquery = "INSERT INTO [dbo].[Demographic_Mapping]([SoureFile_Name],[Demographic_Source_Name],[Target_Column],[Facility_Identifier],[Version])VALUES('" + SourceFileName + "','" + prevMappingColumnsDt.Rows[i]["Source Column"] + "','" + prevMappingColumnsDt.Rows[i]["Target Column"] + "','" + _facilityidentifier + "','" + _version + "')";
                //        OdbcCommand insertpolcmd = new OdbcCommand(insertpolquery, con);
                //        insertpolcmd.CommandType = CommandType.Text;
                //        insertpolcmd.ExecuteNonQuery();
                //    }
                //}
                con.Close();
                if (InsertSepsisCollab())
                {
                    MessageBox.Show("Column Mapping is Saved Successfuly");
                    Demographics dg1 = new Demographics(sm, _facilityidentifier, _version);
                    this.Hide();
                    //dg1.Show();
                }
            }
            else
            {
                MessageBox.Show("Atleast one record required for Mapping Grid");
            }

        }

        private bool InsertSepsisCollab()
        {
            var IsValidRecords = true;

            foreach (DataRow row in sepsisValidateCheckDt.Rows)
            {

                if (sepsisValidateCheckDt.Columns.Contains("InValidRecord"))
                {
                    var IsInvalidRecordExist = Convert.ToString(row["InValidRecord"]);
                    if (IsInvalidRecordExist == "1")
                    {
                        IsValidRecords = false;
                        break;
                    }
                }
            }
            if (IsValidRecords)
            {
              

                if (prevUploadFileDt.Columns.Contains("InValidRecord"))
                {
                    prevUploadFileDt.Columns.Remove("InValidRecord");
                }

                foreach (DataRow sepHeader in prevMappingColumnsDt.Rows)
                {
                    sepsisSaveDt.Columns.Add(sepHeader["SourceCodeColumn"].ToString(), typeof(string));
                }

                foreach (DataRow sepData in prevUploadFileDt.Rows)
                {
                    sepsisSaveDt.Rows.Add(sepData.ItemArray);
                }

                #region  StaticValues 

                DataColumn newColumn = new DataColumn("facility_identifier", typeof(string));
                newColumn.DefaultValue = _facilityidentifier;
                sepsisSaveDt.Columns.Add(newColumn);

                DataColumn newColumn1 = new DataColumn("version", typeof(string));
                newColumn1.DefaultValue = _version;
                sepsisSaveDt.Columns.Add(newColumn1);

                DataColumn dateCreated = new DataColumn("date_Created", typeof(string));
                dateCreated.DefaultValue = DateTime.Now;
                sepsisSaveDt.Columns.Add(dateCreated);

                DataColumn year = new DataColumn("year", typeof(string));
                year.DefaultValue = DateTime.Now.Year;
                sepsisSaveDt.Columns.Add(year);

                DataColumn autoUploadedCase = new DataColumn("auto_uploaded_case", typeof(string));
                autoUploadedCase.DefaultValue = 1;
                sepsisSaveDt.Columns.Add(autoUploadedCase);

                DataColumn recordCompleted = new DataColumn("Record_Completed", typeof(string));
                recordCompleted.DefaultValue = 0;
                sepsisSaveDt.Columns.Add(recordCompleted);

                DataColumn CsVGenerated = new DataColumn("CsVGenerated", typeof(string));
                CsVGenerated.DefaultValue = 0;
                sepsisSaveDt.Columns.Add(CsVGenerated);

                //DataColumn quarter = new DataColumn("quarter", typeof(string));
                //quarter.DefaultValue = "";
                //sepsisSaveDt.Columns.Add(quarter);

                #endregion


                var insertDt = new DataTable();
                var updateDt = new DataTable();


                #region DischargeDateTime

                var IsDischargeDateTime1 = sepsisSaveDt.Columns.Contains("discharge_datetime");
                var IsDischargeTime1 = sepsisSaveDt.Columns.Contains("DischargeTime");

                if (IsDischargeDateTime1 & IsDischargeTime1)
                {
                    foreach (DataRow row in sepsisSaveDt.Rows)
                    {
                        row["discharge_datetime"] = row["discharge_datetime"] + " " + row["DischargeTime"];
                    }
                }
                if (IsDischargeDateTime1)
                {
                    foreach (DataRow row in sepsisSaveDt.Rows)
                    {
                        row["discharge_datetime"] = (row["discharge_datetime"] != null ? GetDateString(row["discharge_datetime"])
                            : "") + " " + (IsDischargeTime1 ? row["DischargeTime"] : "00:00");
                    }
                }
                if (IsDischargeTime1)
                {
                    sepsisSaveDt.Columns.Remove("DischargeTime");
                }

                #endregion


                #region AdmissionDateTime

                var IsAdmissionDateTime = sepsisSaveDt.Columns.Contains("admission_datetime");
                var IsAdmissionTime = sepsisSaveDt.Columns.Contains("AdmissionTime");

                if (IsAdmissionDateTime & IsAdmissionTime)
                {
                    foreach (DataRow row in sepsisSaveDt.Rows)
                    {
                        //row["admission_datetime"] = (row["admission_datetime"] != null ? GetDateString(row["admission_datetime"])
                        //         : "")+ " " + (IsAdmissionTime ? row["AdmissionTime"] : "00:00");
                        row["admission_datetime"] = row["admission_datetime"] + " " + row["AdmissionTime"];
                    }
                }
                if (IsAdmissionDateTime)
                {
                    foreach (DataRow row in sepsisSaveDt.Rows)
                    {
                        row["admission_datetime"] = (row["admission_datetime"] != null ? GetDateString(row["admission_datetime"])
                                 : "") + " " + (IsAdmissionTime ? row["AdmissionTime"] : "00:00");
                    }
                }
                if (IsAdmissionTime)
                {
                    sepsisSaveDt.Columns.Remove("AdmissionTime");
                }
                //sepsisValidateCheckDt.AcceptChanges();

                #endregion


                #region ArrivalDateTime

                var IsArrivalDateTime = sepsisSaveDt.Columns.Contains("earliest_datetime");
                var IsArrivalTime = sepsisSaveDt.Columns.Contains("ArrivalTime");

                if (IsArrivalDateTime & IsArrivalTime)
                {
                    foreach (DataRow row in sepsisSaveDt.Rows)
                    {

                        //row["earliest_datetime"] = (row["earliest_datetime"] != null ? GetDateString(row["earliest_datetime"])
                        //    : "") + " " + (IsArrivalTime ? row["ArrivalTime"] : "00:00");
                        row["earliest_datetime"] = row["earliest_datetime"] + " " + row["ArrivalTime"];
                    }
                }
                if (IsArrivalDateTime)
                {
                    foreach (DataRow row in sepsisSaveDt.Rows)
                    {
                        row["earliest_datetime"] = (row["earliest_datetime"] != null ? GetDateString(row["earliest_datetime"])
                                : "") + " " + (IsArrivalTime ? row["ArrivalTime"] : "00:00");
                    }
                }
                if (IsArrivalTime)
                {
                    sepsisSaveDt.Columns.Remove("ArrivalTime");
                }
                //sepsisValidateCheckDt.AcceptChanges();

                #endregion


                #region TriageDateTime

                var IsTriageDateTime = sepsisSaveDt.Columns.Contains("triage_datetime");
                var IsTriageTime = sepsisSaveDt.Columns.Contains("TriageTime");

                if (IsTriageDateTime & IsTriageTime)
                {
                    foreach (DataRow row in sepsisSaveDt.Rows)
                    {
                        //row["triage_datetime"] = (row["triage_datetime"] != null ? GetDateString(row["triage_datetime"])
                        //        : "") //row["triage_datetime"] 
                        //        + " " + (IsTriageTime ? row["TriageTime"] : "00:00");
                        row["triage_datetime"] = row["triage_datetime"] + " " + row["TriageTime"];
                    }
                }

                if (IsTriageDateTime)
                {
                    foreach (DataRow row in sepsisSaveDt.Rows)
                    {
                        row["triage_datetime"] = (row["triage_datetime"] != null ? GetDateString(row["triage_datetime"])
                                : "") //row["triage_datetime"] 
                                + " " + (IsTriageTime ? row["TriageTime"] : "00:00");
                    }
                }

                if (IsTriageTime)
                {
                    sepsisSaveDt.Columns.Remove("TriageTime");
                }

                #endregion

                foreach (DataColumn col in sepsisSaveDt.Columns)
                {
                    insertDt.Columns.Add(col.ColumnName, col.DataType);
                    updateDt.Columns.Add(col.ColumnName, col.DataType);
                }

                foreach (DataRow validateDt in sepsisSaveDt.Rows)
                {
                    var medicalNumber = validateDt["medical_record_number"].ToString();
                    var IsMedicalExist = MedicalRecordIsExist(medicalNumber);
                    if (IsMedicalExist)
                    {
                        updateDt.ImportRow(validateDt);
                    }
                    else
                    {
                        insertDt.ImportRow(validateDt);
                    }
                }

                if (updateDt.Rows.Count > 0)
                {
                    UpdateSepsisCollab(updateDt);
                }
                if (insertDt.Rows.Count > 0)
                {
                    InsertedSepsisCollab(insertDt);
                }
            }
            else
            {
                MessageBox.Show("Fields highlited in orange color are invalid! Please correct the values and upload file.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return IsValidRecords;
        }

        private void InsertedSepsisCollab(DataTable insertDt)
        {
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;
            string columns = string.Join(",", insertDt.Columns.Cast<DataColumn>().Select(c => c.ColumnName));
            string values = string.Join(",", insertDt.Columns.Cast<DataColumn>().Select(c => string.Format("@{0}", c.ColumnName)));

            string sqlQuery = string.Format("INSERT INTO [dbo].[sepsis_Collab]({0}) ", columns);
            StringBuilder insertScript = new StringBuilder();

            foreach (DataRow row in insertDt.Rows)
            {
                insertScript.Append(sqlQuery + " VALUES(");
                int colCount = 0;
                foreach (DataColumn col in insertDt.Columns)
                {
                    colCount++;
                    insertScript.Append("'" + row[col] + "'");
                    if (insertDt.Columns.Count != colCount)
                        insertScript.Append(",");
                }
                insertScript.Append("); ");
            }

            using (var con = new OdbcConnection(ConnectionString))
            using (var cmd = new OdbcCommand(insertScript.ToString(), con))
            {
                con.Open();
                int inserted = cmd.ExecuteNonQuery();
            }
        }

        private void UpdateSepsisCollab(DataTable updateDt)
        {
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;
            var updateMedicalRecordNumber = string.Empty;
            using (var con = new OdbcConnection(ConnectionString))
            {
                foreach (DataRow row in updateDt.Rows)
                {
                    var equals = new List<string>();
                    updateMedicalRecordNumber = row["medical_record_number"].ToString();
                    foreach (DataColumn column in updateDt.Columns)
                    {
                        var ColumnName = column.ColumnName;
                        var ColumnData = row[column].ToString();
                        equals.Add(string.Format("{0}='{1}'", ColumnName, ColumnData));
                    }
                    string where = "medical_record_number = '" + updateMedicalRecordNumber + "'";
                    string sqlUpdateQuery = string.Format("update [dbo].[sepsis_Collab] set {0} where {1}", string.Join(", ", equals.ToArray()), where);
                    con.Open();
                    OdbcCommand cmd = new OdbcCommand(sqlUpdateQuery, con);
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        
        private string GetDateString(object value)
        {
            string retValue = string.Empty;
            DateTime dt;
            DateTime.TryParse(value.ToString(), out dt);
            if(dt!=DateTime.MinValue && dt != DateTime.MaxValue)
            {
                retValue = dt.ToString("MM/dd/yyyy");
            }
            else
            {
                retValue = value.ToString();
            }
            return retValue;

        }           

        private DataTable PreviewDataValidationCheck(DataTable dt)
        {
            var displayGrdDt = new DataTable();
            var invalidDataCoumns = new StringBuilder();

            foreach (DataRow sepHeader in prevMappingColumnsDt.Rows)
            {
                sepsisValidateCheckDt.Columns.Add(sepHeader["SourceCodeColumn"].ToString(), typeof(string));
                displayGrdDt.Columns.Add(sepHeader["Source Column"].ToString(), typeof(string));
            }

            DataColumn inValidRecord = new DataColumn("InValidRecord", typeof(string));
            sepsisValidateCheckDt.Columns.Add(inValidRecord);

            DataColumn InvalidDataCoumns = new DataColumn("InvalidDataCoumns", typeof(string));
            sepsisValidateCheckDt.Columns.Add(InvalidDataCoumns);


            DataColumn inValidRecord1 = new DataColumn("InValidRecord", typeof(string));
            displayGrdDt.Columns.Add(inValidRecord1);

            DataColumn InvalidDataCoumns1 = new DataColumn("InvalidDataCoumns", typeof(string));
            displayGrdDt.Columns.Add(InvalidDataCoumns1);

            foreach (DataRow sepData in dt.Rows)
            {
                sepsisValidateCheckDt.Rows.Add(sepData.ItemArray);
            }

            #region Data table Format

            //if (sepsisValidateCheckDt.Columns.Contains("race"))
            //{
            //    sepsisValidateCheckDt.AsEnumerable().ToList<DataRow>().ForEach(r => { r["race"] = Convert.ToInt32(r["race"]).ToString("D2"); });
            //}

            #region DischargeDateTime

            var IsDischargeDateTime1 = sepsisValidateCheckDt.Columns.Contains("discharge_datetime");
            var IsDischargeTime1 = sepsisValidateCheckDt.Columns.Contains("DischargeTime");

            if (IsDischargeDateTime1 & IsDischargeTime1)
            {
                foreach (DataRow row in sepsisValidateCheckDt.Rows)
                {
                    //row["discharge_datetime"] = (row["discharge_datetime"] != null ? GetDateString(row["discharge_datetime"])
                    //        : "") + " " + (IsDischargeTime1 ? row["DischargeTime"] : "00:00");  
                    row["discharge_datetime"] = row["discharge_datetime"] + " " + row["DischargeTime"];
                }
            }
            if (IsDischargeDateTime1)
            {
                foreach (DataRow row in sepsisValidateCheckDt.Rows)
                {
                    row["discharge_datetime"] = (row["discharge_datetime"] != null ? GetDateString(row["discharge_datetime"])
                        : "") + " " + (IsDischargeTime1 ? row["DischargeTime"] : "00:00");
                }
            }
            if (IsDischargeTime1)
            {
                sepsisValidateCheckDt.Columns.Remove("DischargeTime");
                displayGrdDt.Columns.Remove("Discharge Time");
            }

            #endregion

            //Preview

            if (sepsisValidateCheckDt.Columns.Contains("discharge_status"))
            {
                sepsisValidateCheckDt.AsEnumerable().ToList<DataRow>().ForEach(r => { r["discharge_status"] = Convert.ToInt32(r["discharge_status"]).ToString("D2"); });
            }

            #region AdmissionDateTime

            var IsAdmissionDateTime = sepsisValidateCheckDt.Columns.Contains("admission_datetime");
            var IsAdmissionTime = sepsisValidateCheckDt.Columns.Contains("AdmissionTime");

            if (IsAdmissionDateTime & IsAdmissionTime)
            {
                foreach (DataRow row in sepsisValidateCheckDt.Rows)
                {
                    //row["admission_datetime"] = (row["admission_datetime"] != null ? GetDateString(row["admission_datetime"])
                    //         : "")+ " " + (IsAdmissionTime ? row["AdmissionTime"] : "00:00");
                    row["admission_datetime"] = row["admission_datetime"] + " " + row["AdmissionTime"];
                }
            }
            if (IsAdmissionDateTime)
            {
                foreach (DataRow row in sepsisValidateCheckDt.Rows)
                {
                    row["admission_datetime"] = (row["admission_datetime"] != null ? GetDateString(row["admission_datetime"])
                             : "") + " " + (IsAdmissionTime ? row["AdmissionTime"] : "00:00");
                }
            }
            if (IsAdmissionTime)
            {
                sepsisValidateCheckDt.Columns.Remove("AdmissionTime");
                displayGrdDt.Columns.Remove("Admission Time");
            }
            //sepsisValidateCheckDt.AcceptChanges();

            #endregion

            #region ArrivalDateTime

            var IsArrivalDateTime = sepsisValidateCheckDt.Columns.Contains("earliest_datetime");
            var IsArrivalTime = sepsisValidateCheckDt.Columns.Contains("ArrivalTime");

            if (IsArrivalDateTime & IsArrivalTime)
            {
                foreach (DataRow row in sepsisValidateCheckDt.Rows)
                {

                    //row["earliest_datetime"] = (row["earliest_datetime"] != null ? GetDateString(row["earliest_datetime"])
                    //    : "") + " " + (IsArrivalTime ? row["ArrivalTime"] : "00:00");
                    row["earliest_datetime"] = row["earliest_datetime"] + " " + row["ArrivalTime"];
                }
            }
            if (IsArrivalDateTime)
            {
                foreach (DataRow row in sepsisValidateCheckDt.Rows)
                {
                    row["earliest_datetime"] = (row["earliest_datetime"] != null ? GetDateString(row["earliest_datetime"])
                            : "") + " " + (IsArrivalTime ? row["ArrivalTime"] : "00:00");
                }
            }
            if (IsArrivalTime)
            {
                sepsisValidateCheckDt.Columns.Remove("ArrivalTime");
                displayGrdDt.Columns.Remove("Arrival Time");
            }
            //sepsisValidateCheckDt.AcceptChanges();

            #endregion

            #region TriageDateTime

            var IsTriageDateTime = sepsisValidateCheckDt.Columns.Contains("triage_datetime");
            var IsTriageTime = sepsisValidateCheckDt.Columns.Contains("TriageTime");

            if (IsTriageDateTime & IsTriageTime)
            {
                foreach (DataRow row in sepsisValidateCheckDt.Rows)
                {
                    //row["triage_datetime"] = (row["triage_datetime"] != null ? GetDateString(row["triage_datetime"])
                    //        : "") //row["triage_datetime"] 
                    //        + " " + (IsTriageTime ? row["TriageTime"] : "00:00");
                    row["triage_datetime"] = row["triage_datetime"] + " " + row["TriageTime"];
                }
            }

            if (IsTriageDateTime)
            {
                foreach (DataRow row in sepsisValidateCheckDt.Rows)
                {
                    row["triage_datetime"] = (row["triage_datetime"] != null ? GetDateString(row["triage_datetime"])
                            : "") //row["triage_datetime"] 
                            + " " + (IsTriageTime ? row["TriageTime"] : "00:00");
                }
            }

            if (IsTriageTime)
            {
                sepsisValidateCheckDt.Columns.Remove("TriageTime");
                displayGrdDt.Columns.Remove("Triage Time");
            }

            #endregion

            #region Insurance Number

            var insuranceNumber = sepsisValidateCheckDt.Columns.Contains("insurance_number");
             

            if (insuranceNumber)
            { 
                foreach (DataRow row in sepsisValidateCheckDt.Rows)
                {
                    var payer = row["payer"].ToString().ToUpper();

                    if (payer == "C" || payer == "D" || payer == "F" || payer == "G")
                        row["insurance_number"] = row["insurance_number"];
                    else
                        row["insurance_number"] = "";


                }
            }

            #endregion

            #region Tranfer Facility Identifier

            var transferIdentifier = sepsisValidateCheckDt.Columns.Contains("transfer_facility_identifier");


            if (transferIdentifier)
            {
                foreach (DataRow row in sepsisValidateCheckDt.Rows)
                {
                    var transferstatus = row["transfer_status"].ToString().ToUpper();

                    if (transferstatus == "3" || transferstatus == "4" || transferstatus == "5")
                        row["transfer_facility_identifier"] = row["transfer_facility_identifier"];
                    else
                        row["transfer_facility_identifier"] = "";


                }
            }

            #endregion

            #region date of birth

            var IsDOBDateTime = sepsisValidateCheckDt.Columns.Contains("date_of_birth");
            
            if (IsDOBDateTime)
            {
                foreach (DataRow row in sepsisValidateCheckDt.Rows)
                {
                    if (IsDOBDateTime)
                        row["date_of_birth"] = row["date_of_birth"] != null ? GetDateString(row["date_of_birth"]) : "";

                }
            }

            #endregion

            sepsisValidateCheckDt.AcceptChanges();

            #endregion

            var PreviewDataDT = sepsisValidateCheckDt;
            

            foreach (DataRow row in PreviewDataDT.Rows)
            {
                invalidDataCoumns = new StringBuilder();

                

                #region Unique Personal Identifier
                if (PreviewDataDT.Columns.Contains("unique_personal_identifier"))
                {
                    var personIdentiferValue = Convert.ToString(row["unique_personal_identifier"]);
                    var IsValidPersonIdenf = IsValidPersonalIdentifer(personIdentiferValue);
                    if (!IsValidPersonIdenf)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Unique Personal Identifier").Append("@");
                    }
                    else
                    {
                        for (int i = 0; i < personIdentiferValue.Length; i++)
                        {
                            if (!char.IsLetterOrDigit(personIdentiferValue[i]))
                            {
                                row["InValidRecord"] = 1;
                                invalidDataCoumns.Append("Unique Personal Identifier").Append("@");
                            }
                        }
                    }                 
                }

                //if (PreviewDataDT.Columns.Contains("unique_personal_identifier"))
                //{
                //    var uniquepersonalidentifier = Convert.ToString(row["unique_personal_identifier"]);

                //    for (int i = 0; i < uniquepersonalidentifier.Length; i++)
                //    {
                //        if (!char.IsLetterOrDigit(uniquepersonalidentifier[i]))
                //        {
                //            row["InValidRecord"] = 1;
                //            invalidDataCoumns.Append("Unique Personal Identifier").Append("@");
                //        }
                //    }
                //}
                #endregion

               /* if (PreviewDataDT.Columns.Contains("insurance_number"))
                {
                    var number = Convert.ToString(row["insurance_number"]);
                    if (number.Length > 19)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Insurance Number").Append("@");
                    }
                    if(PreviewDataDT.Columns.Contains("payer"))
                    {
                        var payer = row["payer"].ToString();
                        if (payer.ToUpper().Contains("C") || payer.ToUpper().Contains("D") 
                            || payer.ToUpper().Contains("F") || payer.ToUpper().Contains("G"))
                        {
                            if (string.IsNullOrWhiteSpace(number))
                            {
                                row["InValidRecord"] = 1;
                                invalidDataCoumns.Append("Insurance Number").Append("@");
                            }
                        }
                       
                    }
                }*/

                if (PreviewDataDT.Columns.Contains("transfer_facility_identifier"))
                {
                    var transfer = Convert.ToString(row["transfer_facility_identifier"]);
                    if (PreviewDataDT.Columns.Contains("transfer_status"))
                    {
                        var status = RemoveSpecialCharacters(row["transfer_status"].ToString());
                        if (status.ToUpper().Contains(RemoveSpecialCharacters("ADMISSION TRANSFER WITH SS")) 
                            || status.ToUpper().Contains(RemoveSpecialCharacters("NO PROTOCOL"))
                            || status.ToUpper().Contains(RemoveSpecialCharacters("INITIATED PROTOCOL") ))
                        {
                            if (string.IsNullOrWhiteSpace(transfer))
                            {
                                row["InValidRecord"] = 1;
                                invalidDataCoumns.Append("Transfer Facility Identifier").Append("@");
                            }
                        }
                    }  
                }
                #region Patient Control Number
                if (PreviewDataDT.Columns.Contains("patient_control_number"))
                {
                    var number = Convert.ToString(row["patient_control_number"]);

                    if (/*string.IsNullOrWhiteSpace(number) ||*/ number.Length > 20)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Patient Control Number").Append("@");
                    }
                    else
                    {
                        for (int i = 0; i < number.Length; i++)
                        {
                            if (!char.IsLetterOrDigit(number[i]))
                            {
                                row["InValidRecord"] = 1;
                                invalidDataCoumns.Append("Patient Control Number").Append("@");
                            }
                        }
                    }                
                }

                //if (PreviewDataDT.Columns.Contains("patient_control_number"))
                //{
                //    var patientcontrolnumber = Convert.ToString(row["patient_control_number"]);

                //    for (int i = 0; i < patientcontrolnumber.Length; i++)
                //    {
                //        if (!char.IsLetterOrDigit(patientcontrolnumber[i]))
                //        {
                //            row["InValidRecord"] = 1;
                //            invalidDataCoumns.Append("Patient Control Number").Append("@");
                //        }
                //    }
                //}
                #endregion

                #region  Medical Record Number
                if (PreviewDataDT.Columns.Contains("medical_record_number"))
                {
                    var patientcontrolnumber = Convert.ToString(row["medical_record_number"]);

                    for (int i = 0; i < patientcontrolnumber.Length; i++)
                    {
                        if (!char.IsLetterOrDigit(patientcontrolnumber[i]))
                        {
                            row["InValidRecord"] = 1;
                            invalidDataCoumns.Append("Medical Record Number").Append("@");
                        }
                    }
                    if (string.IsNullOrWhiteSpace(patientcontrolnumber) || patientcontrolnumber.Length > 17)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Medical Record Number").Append("@");
                    }
                }
                //if (PreviewDataDT.Columns.Contains("medical_record_number"))
                //{
                //    var number = Convert.ToString(row["medical_record_number"]);

                //    if (string.IsNullOrWhiteSpace(number) || number.Length > 17)
                //    {
                //        row["InValidRecord"] = 1;
                //        invalidDataCoumns.Append("Medical Record Number").Append("@");
                //    }
                //}
                #endregion

                #region  RecoredCheckDB

                if (PreviewDataDT.Columns.Contains("race"))
                {
                    var raceValue = Convert.ToString(row["race"]);

                    int n;
                    bool isNumeric = int.TryParse(raceValue, out n);
                    if (isNumeric)
                    {
                        raceValue = Convert.ToInt32(raceValue).ToString("D2");
                        row["race"] = raceValue;
                    }
                    var validRace = ComboBoxLookUpIsExist("race", raceValue);
                    if (!validRace)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Race").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("gender"))
                {
                    var genderValue = Convert.ToString(row["gender"]);
                    var validGender = ComboBoxLookUpIsExist("Gender", genderValue);
                    if (!validGender)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Gender").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("payer"))
                {
                    var payerValue = Convert.ToString(row["payer"]);
                    var validpayer = ComboBoxLookUpIsExist("Payor", payerValue);
                    if (!validpayer)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Payer").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("transfer_status"))
                {
                    var transferValue = Convert.ToString(row["transfer_status"]);
                    var validtransfer = ComboBoxLookUpIsExist("Transfer", transferValue);
                    if (!validtransfer)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Transfer Status").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("pregnancy_status"))
                {
                    var pregnancystatusValue = Convert.ToString(row["pregnancy_status"]);
                    var validpregnancystatus = ComboBoxLookUpIsExist("PregnancyStatus", pregnancystatusValue);
                    if (!validpregnancystatus)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Pregnancy Status").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("source_of_admission"))
                {
                    var SourceOfAdmissionValue = Convert.ToString(row["source_of_admission"]);
                    var validSourceOfAdmission = ComboBoxLookUpIsExist("SourceOfAdmission", SourceOfAdmissionValue);
                    if (!validSourceOfAdmission)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Source of Admission").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("discharge_status"))
                {
                    var dischargedstatusValue = Convert.ToString(row["discharge_status"]);
                    var validdischargedstatus = ComboBoxLookUpIsExist("DischargedStatus", dischargedstatusValue);
                    if (!validdischargedstatus)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Discharged Status").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("sepsis_identification_place"))
                {
                    var sepsisidentificationplaceValue = Convert.ToString(row["sepsis_identification_place"]);
                    var validsepsisidentificationplace = ComboBoxLookUpIsExist("SepsisIdentificationPlace", sepsisidentificationplaceValue);
                    if (!validsepsisidentificationplace)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Sepsis Identification Place").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("excluded_from_protocol"))
                {
                    var excludedreasonValue = Convert.ToString(row["excluded_from_protocol"]);
                    var validexcludedreason = ComboBoxLookUpIsExist("ExcludedFromProtocol", excludedreasonValue);
                    if (!validexcludedreason)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Excluded From Protocol").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("excluded_reason"))
                {
                    var excludedreasonValue = Convert.ToString(row["excluded_reason"]);
                    var validexcludedreason = ComboBoxLookUpIsExist("ExcludedReason", excludedreasonValue);
                    if (!validexcludedreason)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Excluded Reason").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("excluded_explain"))
                {
                    var excludedexplainValue = Convert.ToString(row["excluded_explain"]);
                    var validexcludedexplain = ComboBoxLookUpIsExist("ExcludedExplain", excludedexplainValue);
                    if (!validexcludedexplain)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Excluded Explain").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("discharge_datetime"))
                {
                    var dischargeDateTimeValue = Convert.ToString(row["discharge_datetime"]);

                    if (validateDatetime(dischargeDateTimeValue) == false)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Discharge Date/time").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("admission_datetime"))
                {
                    var admissionDateTimeValue = Convert.ToString(row["admission_datetime"]);

                    if (validateDatetime(admissionDateTimeValue) == false)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Admission Date/Time").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("earliest_datetime"))
                {
                    var arrivalDateTimeValue = Convert.ToString(row["earliest_datetime"]);

                    if (validateDatetime(arrivalDateTimeValue) == false)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Arrival Datetime").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("triage_datetime"))
                {
                    var triageDateTimeValue = Convert.ToString(row["triage_datetime"]);

                    if (validateDatetime(triageDateTimeValue) == false)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Triage Datetime").Append("@");
                    }
                }

                if (PreviewDataDT.Columns.Contains("date_of_birth"))
                {
                    var DOBValue = Convert.ToString(row["date_of_birth"]);

                    if (validateDate(DOBValue) == false)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Date of Birth").Append("@");
                    }
                }
                //Ethnicity
                if (PreviewDataDT.Columns.Contains("ethnicity"))
                {
                    var ethnicityValue = Convert.ToString(row["ethnicity"]);
                    var validethnicityValues = ComboBoxLookUpIsExist("ethnicity", ethnicityValue);
                    if (!validethnicityValues)
                    {
                        row["InValidRecord"] = 1;
                        invalidDataCoumns.Append("Ethnicity").Append("@");
                    }
                }
                row["InvalidDataCoumns"] = invalidDataCoumns;
                #endregion
            }

            foreach (DataRow sepData in PreviewDataDT.Rows)
            {
                displayGrdDt.Rows.Add(sepData.ItemArray);
            }

            return displayGrdDt;

        }

        private bool IsValidPersonalIdentifer(string uniquePersonIdentifer)
        {
            var IsValidPersonalIdef = true;

            if (uniquePersonIdentifer.Length == 10)
            {
                var first6letters = uniquePersonIdentifer.Substring(0, 6);
                var second4numbers = uniquePersonIdentifer.Substring(6);

                for (int i = 0; i < first6letters.Length; i++)
                {

                    if (!char.IsLetter(first6letters[i]))
                    {
                        return false;
                    }
                }

                for (int j = 0; j < second4numbers.Length; j++)
                {

                    if (!char.IsNumber(second4numbers[j]))
                    {
                        return false;
                    }
                }
            }
            else
            {
                return false;
            }
            return IsValidPersonalIdef;
        }

        private bool ComboBoxLookUpIsExist(string columnName, string columnValue)
        {
            ConnectionString = "DSN=" + Db.DSN + ";UID=" + Db.UserName + ";PWD=" + Db.Password;
            bool IsRecordExist = true;
            var con = new OdbcConnection(ConnectionString);
            con.Open();
            string ComboxBoxQuery = "select top 1 UniqueID from [dbo].[ComboBox_LookUp] where ComboBox_Name = '" + columnName + "' and ComboBox_Key = '" + columnValue + "'";
            OdbcCommand clientrefCmd = new OdbcCommand(ComboxBoxQuery, con);
            var value = clientrefCmd.ExecuteScalar();
            con.Close();
            IsRecordExist = value != null ? true : false;
            return IsRecordExist;
        }

        private bool MedicalRecordIsExist(string medicalRecordNumber)
        {
            bool IsRecordExist = true;
            OdbcConnection con = new OdbcConnection(ConnectionString);
            con.Open();
            string ComboxBoxQuery = "select top 1 * from [Sepsis].[dbo].[sepsis_Collab] where medical_record_number = '" + medicalRecordNumber + "'";
            OdbcCommand medicalCmd = new OdbcCommand(ComboxBoxQuery, con);
            var value = medicalCmd.ExecuteScalar();
            con.Close();
            IsRecordExist = value != null ? true : false;
            return IsRecordExist;
        }

        private void Label_ClickHere_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            WindowsFormsApplication1.Help hp = new WindowsFormsApplication1.Help();
            hp.Show();
        }

        //private DataTable ValidateSepsisDt(DataTable dt)
        //{
        //    DataTable validateDt;

        //    if (dt.Columns.Contains("race"))
        //    {
        //        dt.AsEnumerable().ToList<DataRow>().ForEach(r => { r["race"] = Convert.ToInt32(r["race"]).ToString("D2"); });
        //    }
        //    if (dt.Columns.Contains("discharge_status"))
        //    {
        //        dt.AsEnumerable().ToList<DataRow>().ForEach(r => { r["discharge_status"] = Convert.ToInt32(r["discharge_status"]).ToString("D2"); });
        //    }

        //    #region DischargeDateTime

        //    var IsDischargeDateTime = dt.Columns.Contains("discharge_datetime");
        //    var IsDischargeTime = dt.Columns.Contains("DischargeTime");

        //    if (IsDischargeDateTime & IsDischargeTime)
        //    {
        //        foreach (DataRow row in dt.Rows)
        //        {
        //            if (IsDischargeTime)
        //                row["discharge_datetime"] = row["discharge_datetime"] + " " + row["DischargeTime"];
        //        }
        //    }


        //    if (IsDischargeTime)
        //    {
        //        dt.Columns.Remove("DischargeTime");
        //    }
        //    dt.AcceptChanges();

        //    #endregion

        //    validateDt = dt;

        //    return validateDt;

        //}
        //private string Validation(DataTable dt)
        //{
        //    string ValidationMessage = string.Empty;

        //    foreach (DataRow row in dt.Rows)
        //    {


        //        if (dt.Columns.Contains("race"))
        //        {
        //            var raceValue = Convert.ToString(row["race"]);
        //            var validRace = ComboBoxLookUpIsExist("race", raceValue);
        //            if (!validRace)
        //            {
        //                ValidationMessage = "Invalid Race Value";
        //                break;
        //            }
        //        }

        //        if (dt.Columns.Contains("gender"))
        //        {
        //            var genderValue = Convert.ToString(row["gender"]);
        //            var validGender = ComboBoxLookUpIsExist("Gender", genderValue);
        //            if (!validGender)
        //            {
        //                ValidationMessage = "Invalid Gender Value";
        //                break;
        //            }
        //        }

        //        if (dt.Columns.Contains("payer"))
        //        {
        //            var payerValue = Convert.ToString(row["payer"]);
        //            var validpayer = ComboBoxLookUpIsExist("Payor", payerValue);
        //            if (!validpayer)
        //            {
        //                ValidationMessage = "Invalid Payer Value";
        //                break;
        //            }
        //        }

        //        if (dt.Columns.Contains("pregnancy_status"))
        //        {
        //            var pregnancystatusValue = Convert.ToString(row["pregnancy_status"]);
        //            var validpregnancystatus = ComboBoxLookUpIsExist("Pregnancy Status", pregnancystatusValue);
        //            if (!validpregnancystatus)
        //            {
        //                ValidationMessage = "Invalid Pregnancy Status Value";
        //                break;
        //            }
        //        }

        //        if (dt.Columns.Contains("source_of_admission"))
        //        {
        //            var SourceOfAdmissionValue = Convert.ToString(row["source_of_admission"]);
        //            var validSourceOfAdmission = ComboBoxLookUpIsExist("SourceOfAdmission", SourceOfAdmissionValue);
        //            if (!validSourceOfAdmission)
        //            {
        //                ValidationMessage = "Invalid Source Of Admission Value";
        //                break;
        //            }
        //        }

        //        if (dt.Columns.Contains("discharge_status"))
        //        {
        //            var dischargedstatusValue = Convert.ToString(row["discharge_status"]);
        //            var validdischargedstatus = ComboBoxLookUpIsExist("DischargedStatus", dischargedstatusValue);
        //            if (!validdischargedstatus)
        //            {
        //                ValidationMessage = "Invalid Discharged Status Value";
        //                break;
        //            }
        //        }

        //        if (dt.Columns.Contains("sepsis_identification_place"))
        //        {
        //            var sepsisidentificationplaceValue = Convert.ToString(row["sepsis_identification_place"]);
        //            var validsepsisidentificationplace = ComboBoxLookUpIsExist("SepsisIdentificationPlace", sepsisidentificationplaceValue);
        //            if (!validsepsisidentificationplace)
        //            {
        //                ValidationMessage = "Invalid Sepsis Identification Place Value";
        //                break;
        //            }
        //        }
        //    }

        //    return ValidationMessage;

        //}

        //private string ValidationCheck(DataTable dt)
        //{
        //    string ValidationMessage = string.Empty;

        //    foreach (DataRow row in dt.Rows)
        //    {
        //        #region uniqueIdentifer

        //        if (dt.Columns.Contains("unique_personal_identifier"))
        //        {
        //            var uniquePersonIdentifer = Convert.ToString(row["unique_personal_identifier"]);

        //            if (uniquePersonIdentifer.Length == 10)
        //            {
        //                var first6letters = uniquePersonIdentifer.Substring(0, 6);
        //                var second4numbers = uniquePersonIdentifer.Substring(6);

        //                for (int i = 0; i < first6letters.Length; i++)
        //                {

        //                    if (!char.IsLetter(first6letters[i]))
        //                    {
        //                        return ValidationMessage = "Invalid unique personal identifier number(i.e abcdef0001)";
        //                    }
        //                }

        //                for (int j = 0; j < second4numbers.Length; j++)
        //                {

        //                    if (!char.IsNumber(second4numbers[j]))
        //                    {
        //                        return ValidationMessage = "Invalid unique personal identifier number(i.e abcdef0001)";
        //                    }
        //                }

        //            }
        //            else
        //            {
        //                return ValidationMessage = "Invalid unique personal identifier number(i.e abcdef0001)";
        //            }

        //        }

        //        #endregion

        //        if (dt.Columns.Contains("race"))
        //        {
        //            var raceValue = Convert.ToString(row["race"]);
        //            var validRace = ComboBoxLookUpIsExist("race", raceValue);
        //            if (!validRace)
        //            {
        //                ValidationMessage = "Invalid Race Value";
        //                break;
        //            }
        //        }

        //        if (dt.Columns.Contains("gender"))
        //        {
        //            var genderValue = Convert.ToString(row["gender"]);
        //            var validGender = ComboBoxLookUpIsExist("Gender", genderValue);
        //            if (!validGender)
        //            {
        //                ValidationMessage = "Invalid Gender Value";
        //                break;
        //            }
        //        }

        //        if (dt.Columns.Contains("payer"))
        //        {
        //            var payerValue = Convert.ToString(row["payer"]);
        //            var validpayer = ComboBoxLookUpIsExist("Payor", payerValue);
        //            if (!validpayer)
        //            {
        //                ValidationMessage = "Invalid Payer Value";
        //                break;
        //            }
        //        }

        //        if (dt.Columns.Contains("pregnancy_status"))
        //        {
        //            var pregnancystatusValue = Convert.ToString(row["pregnancy_status"]);
        //            var validpregnancystatus = ComboBoxLookUpIsExist("Pregnancy Status", pregnancystatusValue);
        //            if (!validpregnancystatus)
        //            {
        //                ValidationMessage = "Invalid Pregnancy Status Value";
        //                break;
        //            }
        //        }

        //        if (dt.Columns.Contains("source_of_admission"))
        //        {
        //            var SourceOfAdmissionValue = Convert.ToString(row["source_of_admission"]);
        //            var validSourceOfAdmission = ComboBoxLookUpIsExist("SourceOfAdmission", SourceOfAdmissionValue);
        //            if (!validSourceOfAdmission)
        //            {
        //                ValidationMessage = "Invalid Source Of Admission Value";
        //                break;
        //            }
        //        }

        //        if (dt.Columns.Contains("discharge_status"))
        //        {
        //            var dischargedstatusValue = Convert.ToString(row["discharge_status"]);
        //            var validdischargedstatus = ComboBoxLookUpIsExist("DischargedStatus", dischargedstatusValue);
        //            if (!validdischargedstatus)
        //            {
        //                ValidationMessage = "Invalid Discharged Status Value";
        //                break;
        //            }
        //        }

        //        //if (dt.Columns.Contains("transfer_status"))
        //        //{
        //        //    var pregnancystatusValue = Convert.ToString(row[" "]);
        //        //    var validpregnancystatus = ComboBoxLookUpIsExist(" ", pregnancystatusValue);
        //        //    if (!validpregnancystatus)
        //        //    {
        //        //        ValidationMessage = "Invalid Transfer Status Value";
        //        //        break;
        //        //    }
        //        //}

        //        if (dt.Columns.Contains("sepsis_identification_place"))
        //        {
        //            var sepsisidentificationplaceValue = Convert.ToString(row["sepsis_identification_place"]);
        //            var validsepsisidentificationplace = ComboBoxLookUpIsExist("SepsisIdentificationPlace", sepsisidentificationplaceValue);
        //            if (!validsepsisidentificationplace)
        //            {
        //                ValidationMessage = "Invalid Sepsis Identification Place Value";
        //                break;
        //            }
        //        }

        //        //if (dt.Columns.Contains("ExcludedForPayrol "))
        //        //{
        //        //    var pregnancystatusValue = Convert.ToString(row[" "]);
        //        //    var validpregnancystatus = ComboBoxLookUpIsExist(" ", pregnancystatusValue);
        //        //    if (!validpregnancystatus)
        //        //    {
        //        //        ValidationMessage = "Invalid Sepsis Identification Place Value";
        //        //        break;
        //        //    }
        //        //}

        //        if (dt.Columns.Contains("excluded_reason"))
        //        {
        //            var excludedreasonValue = Convert.ToString(row["excluded_reason"]);
        //            var validexcludedreason = ComboBoxLookUpIsExist("ExcludedReason", excludedreasonValue);
        //            if (!validexcludedreason)
        //            {
        //                ValidationMessage = "Invalid Excluded Reason Value";
        //                break;
        //            }
        //        }

        //        if (dt.Columns.Contains("excluded_explain"))
        //        {
        //            var excludedexplainValue = Convert.ToString(row["excluded_explain"]);
        //            var validexcludedexplain = ComboBoxLookUpIsExist("ExcludedExplain", excludedexplainValue);
        //            if (!validexcludedexplain)
        //            {
        //                ValidationMessage = "Invalid Excluded Explain Value";
        //                break;
        //            }
        //        }
        //    }

        //    return ValidationMessage;

        //}

        public bool validateDatetime(string inputString)
        {
            DateTime dDate;
            if (inputString == "/  /       :")
            {
                return true;
            }
            if (DateTime.TryParseExact(inputString, format1, CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out dDate))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool validateDate(string inputString)
        {
            DateTime dDate;

            if (inputString == "/  /")
            {
                return true;
            }
            if (DateTime.TryParseExact(inputString, format2, CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out dDate))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public static string RemoveSpecialCharacters(string str)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in str)
            {
                if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '.' || c == '_')
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

    }
}