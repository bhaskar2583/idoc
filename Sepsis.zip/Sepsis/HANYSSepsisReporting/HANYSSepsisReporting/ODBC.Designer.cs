﻿namespace HANYSSepsisReporting
{
    partial class ODBC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox_DSNType = new System.Windows.Forms.ComboBox();
            this.label_DSNType = new System.Windows.Forms.Label();
            this.button_Submit = new System.Windows.Forms.Button();
            this.textBox_Password = new System.Windows.Forms.TextBox();
            this.textBox_UserName = new System.Windows.Forms.TextBox();
            this.textBox_ServerName = new System.Windows.Forms.TextBox();
            this.label_Password = new System.Windows.Forms.Label();
            this.label_UserName = new System.Windows.Forms.Label();
            this.label_ServerName = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.comboBox_DSNType);
            this.panel1.Controls.Add(this.label_DSNType);
            this.panel1.Controls.Add(this.button_Submit);
            this.panel1.Controls.Add(this.textBox_Password);
            this.panel1.Controls.Add(this.textBox_UserName);
            this.panel1.Controls.Add(this.textBox_ServerName);
            this.panel1.Controls.Add(this.label_Password);
            this.panel1.Controls.Add(this.label_UserName);
            this.panel1.Controls.Add(this.label_ServerName);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Location = new System.Drawing.Point(41, 42);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(685, 360);
            this.panel1.TabIndex = 0;
            // 
            // comboBox_DSNType
            // 
            this.comboBox_DSNType.FormattingEnabled = true;
            this.comboBox_DSNType.Items.AddRange(new object[] {
            "System DSN",
            "User DSN"});
            this.comboBox_DSNType.Location = new System.Drawing.Point(131, 251);
            this.comboBox_DSNType.Name = "comboBox_DSNType";
            this.comboBox_DSNType.Size = new System.Drawing.Size(310, 21);
            this.comboBox_DSNType.TabIndex = 10;
            // 
            // label_DSNType
            // 
            this.label_DSNType.AutoSize = true;
            this.label_DSNType.Location = new System.Drawing.Point(40, 254);
            this.label_DSNType.Name = "label_DSNType";
            this.label_DSNType.Size = new System.Drawing.Size(69, 13);
            this.label_DSNType.TabIndex = 8;
            this.label_DSNType.Text = "DSN Type:";
            // 
            // button_Submit
            // 
            this.button_Submit.Location = new System.Drawing.Point(408, 307);
            this.button_Submit.Name = "button_Submit";
            this.button_Submit.Size = new System.Drawing.Size(75, 23);
            this.button_Submit.TabIndex = 7;
            this.button_Submit.Text = "Submit";
            this.button_Submit.UseVisualStyleBackColor = true;
            this.button_Submit.Click += new System.EventHandler(this.button_Submit_Click);
            // 
            // textBox_Password
            // 
            this.textBox_Password.Location = new System.Drawing.Point(131, 199);
            this.textBox_Password.Name = "textBox_Password";
            this.textBox_Password.PasswordChar = '*';
            this.textBox_Password.Size = new System.Drawing.Size(310, 20);
            this.textBox_Password.TabIndex = 6;
            // 
            // textBox_UserName
            // 
            this.textBox_UserName.Location = new System.Drawing.Point(131, 146);
            this.textBox_UserName.Name = "textBox_UserName";
            this.textBox_UserName.Size = new System.Drawing.Size(310, 20);
            this.textBox_UserName.TabIndex = 5;
            // 
            // textBox_ServerName
            // 
            this.textBox_ServerName.Location = new System.Drawing.Point(131, 92);
            this.textBox_ServerName.Name = "textBox_ServerName";
            this.textBox_ServerName.Size = new System.Drawing.Size(310, 20);
            this.textBox_ServerName.TabIndex = 4;
            // 
            // label_Password
            // 
            this.label_Password.AutoSize = true;
            this.label_Password.Location = new System.Drawing.Point(40, 202);
            this.label_Password.Name = "label_Password";
            this.label_Password.Size = new System.Drawing.Size(65, 13);
            this.label_Password.TabIndex = 3;
            this.label_Password.Text = "Password:";
            // 
            // label_UserName
            // 
            this.label_UserName.AutoSize = true;
            this.label_UserName.Location = new System.Drawing.Point(40, 149);
            this.label_UserName.Name = "label_UserName";
            this.label_UserName.Size = new System.Drawing.Size(76, 13);
            this.label_UserName.TabIndex = 2;
            this.label_UserName.Text = "SQL UserId:";
            // 
            // label_ServerName
            // 
            this.label_ServerName.AutoSize = true;
            this.label_ServerName.Location = new System.Drawing.Point(40, 92);
            this.label_ServerName.Name = "label_ServerName";
            this.label_ServerName.Size = new System.Drawing.Size(84, 13);
            this.label_ServerName.TabIndex = 1;
            this.label_ServerName.Text = "Server Name:";
            // 
            // ODBC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "ODBC";
            this.Text = "ODBC";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ODBC_FormClosing);
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_Submit;
        private System.Windows.Forms.TextBox textBox_Password;
        private System.Windows.Forms.TextBox textBox_UserName;
        private System.Windows.Forms.TextBox textBox_ServerName;
        private System.Windows.Forms.Label label_Password;
        private System.Windows.Forms.Label label_UserName;
        private System.Windows.Forms.Label label_ServerName;
        private System.Windows.Forms.ComboBox comboBox_DSNType;
        private System.Windows.Forms.Label label_DSNType;
    }
}