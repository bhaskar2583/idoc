﻿using HMDL.Core.Models;
using HMDL.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HANYSMasterDatesetList.Controllers
{
    public class MasterController : Controller
    {
        MasterDatasetService MDS = new MasterDatasetService();

        // GET: Master
        public ActionResult Index()
        {
            string user = "kmanam";
            var data = MDS.GetAllMasterDataByUser(user);

            data = data.OrderBy(x => x.DataSetName).ToList();

            return View(data);
        }
        public ActionResult AddRequest()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddRequest(MasterDatasetModel data)
        {
            try
            {
                
            }
            catch
            {

            }            
            return View();
        }
        public ActionResult MasterDatasetForm(string id)
        {
            try
            {
                List<SelectListItem> lstDataSetNames = new List<SelectListItem>();
                lstDataSetNames = MDS.GetAllDatasetNames().Select(x =>
                                  new SelectListItem
                                  {
                                      Value = x.ToString(),
                                      Text = x.ToString()
                                  }).ToList();
                ViewBag.DataSetNames = lstDataSetNames;
                if (!string.IsNullOrWhiteSpace(id))
                {
                    var data = MDS.GetDatasetNameDetails(id);
                    return View(data);
                }
            }
            catch
            {

            }
            return View();
        }


        [HttpPost]
        public ActionResult MasterDatasetForm(MasterDatasetModel data)
        {
            try
            {
                if (data != null)
                {
                    var isExist = MDS.GetDataset(data.DataSetName, data.UserName);
                    if (isExist == null)
                    {
                        MDS.SaveRequest(data);
                    }
                    if (isExist != null)
                    {
                        MDS.UpdateRequest(data);
                    }
                }
            }
            catch
            {

            }
            return View();
        }
    }
}