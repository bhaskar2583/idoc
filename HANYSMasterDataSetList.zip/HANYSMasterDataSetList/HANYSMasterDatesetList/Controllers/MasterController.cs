﻿using HMDL.Core.Models;
using HMDL.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HANYSMasterDatesetList.Controllers
{
    public class MasterController : Controller
    {
        MasterDatasetService MDS = new MasterDatasetService();

        public string GetWindowsUser()
        {
            string windowsUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            var user = Environment.UserName;

            return user;
        }
        public bool IsValidUser(string user)
        {
            var validUser = MDS.GetUser(user);

            if (validUser != null) { return true; }
            return false;
        }
        // GET: Master
        public ActionResult Index()
        {
            string user = GetWindowsUser();

            if (!IsValidUser(user))
            {
                ViewBag.IsValidUser = false;
                ViewBag.User = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                return View();
            }

            ViewBag.User = MDS.GetUser(user).UDS_Name;
            ViewBag.IsValidUser = true;

            var data = MDS.GetAllMasterDataByUser(user);

            data = data.OrderBy(x => x.DataSetName).ToList();

            return View(data);
        }
        public ActionResult AddRequest()
        {
            string user = GetWindowsUser();
            //user = user.Replace("HANYSNT\\", "");
            int id = MDS.GetUser(user).UDS_Id;
            var data = MDS.GetDetails(id);
            return View(data);
        }

        [HttpPost]
        public ActionResult AddRequest(NewDatasetRequestModel data)
        {
            if (ModelState.IsValid)
            {
                if (data != null)
                {
                    var result = MDS.SendEmail(data);
                    if (result)
                    {
                        ViewBag.Message = "Request submitted Successfully";
                        return RedirectToAction("Index");
                    }
                    else
                        ViewBag.Message = "Error occured! Please try again.";
                }
            }
            return View();
        }

        [HttpGet]
        public ActionResult MasterDatasetForm(int id)
        {
            try
            {
                var ownerList = new List<DatasetOwnerModel>();

                ownerList = MDS.GetOwners();
                ViewBag.Owners = ownerList;

                if (id > 0)
                {
                    var d = MDS.GetDatasetNameDetails(id);
                    return View(d);
                }
            }
            catch (Exception ex)
            {

            }
            return View();
        }
        [HttpPost]
        public ActionResult MasterDatasetForm(MasterDatasetModel data)
        {
            try
            {
                string user = GetWindowsUser();
                user = user + "@hanys.org";

                if (data != null)
                {
                    if (data.DataAccessEncryption == null || data.DataPurpose == null || data.DatasetFormat == null || data.DatasetRestrictions == null || data.DatasetRetensionRequired == null
                        || data.DataSource == null || data.Department == null || data.DescribeDestructionAutomated == null || data.DestructionAutomated == null
                        || data.Encryption == null || data.EncryptionFeilds == null || data.ExplainDatasetRestrictions == null || data.ExternalUsers == null
                        || data.IfNocanDatasetBeArchived == null || data.IsDatasetActiveInlast12months == null || data.LastLoadDate == null || data.LawGoverningSesitivity == null
                        || data.LawGoverningSesitivityId == null || data.LoadFormat == null || data.LoadFormatId == null || data.OtherInformationSensitivity == null
                        || data.OtherLawGoverningSensitivity == null || data.OtherLoadFormat == null || data.Owner == null || data.PermissionToPublishDataset == null
                        || data.ReasonForSpecialBackUp == null || data.RententionRequirement == null || data.RetentionStartDate == null || data.SourceLocation == null
                        || data.SpecialAccessRquirements == null || data.SpecialAccessRquirementsForBackups == null || data.Users == null)
                    {
                        data.RecordComplete = false;
                    }
                    else
                        data.RecordComplete = true;

                    if (data.LoadFormatId != null && data.LoadFormatId == 4 && data.OtherLoadFormat == null)
                        data.RecordComplete = false;

                    if (data.LawGoverningSesitivityId != null && data.LawGoverningSesitivityId == 5 && data.OtherLawGoverningSensitivity == null)
                        data.RecordComplete = false;

                    if (data.DatasetRestrictions != null && data.DatasetRestrictions == true && data.ExplainDatasetRestrictions == null)
                        data.RecordComplete = false;

                    if (data.Encryption != null && data.Encryption == 2 && data.EncryptionFeilds == null)
                        data.RecordComplete = false;

                    if (data.DatasetRetensionRequired != null && data.DatasetRetensionRequired == true && data.DatasetRetensionRequired == null)
                        data.RecordComplete = false;

                    if (data.DestructionAutomated != null && data.DestructionAutomated == false && data.DescribeDestructionAutomated == null)
                        data.RecordComplete = false;

                    data.UserName = user;
                    var isExist = MDS.GetDataset(data.DataSetId, data.UserId);
                    if (isExist == null)
                    {
                        MDS.SaveRequest(data);
                    }
                    if (isExist != null)
                    {
                        MDS.UpdateRequest(data);
                    }
                }
            }
            catch
            {

            }
            return RedirectToAction("Index");
        }
    }
}