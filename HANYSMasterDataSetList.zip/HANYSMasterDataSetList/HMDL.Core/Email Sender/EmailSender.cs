﻿using HMDL.Core.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMDL.Core.Email_Sender
{
    public class EmailSender
    {
        public static bool SendEmail(NewDatasetRequestModel data)
        {
            try
            {
                string toMailList = ConfigurationManager.AppSettings["toMailList"];
                string ccMailList = ConfigurationManager.AppSettings["ccMailList"];
                string bccMailList = ConfigurationManager.AppSettings["bccMailList"];

                toMailList = toMailList.Replace(",", ";");
                ccMailList = ccMailList.Replace(",", ";");
                bccMailList = bccMailList.Replace(",", ";");

                string subject = "Request for new Dataset";
                string emailBody = GetEmailBody(data).ToString();


                string connString = ConfigurationManager.ConnectionStrings["emailConString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connString))
                {
                    string emailQuery = "INSERT INTO [dbo].[EmailHistory]([EmailType],[Recipients],[CCRecipients],[BCCRecipients],[EmailSubject],[EmailBody],[SentDate],[SendStatus],[Priority])" +
                        "VALUES('New Request for Dataset', '" + toMailList + "','" + ccMailList + "','" + bccMailList + "','" + subject + "','" + emailBody + "',NULL,NULL,'High')";
                    con.Open();
                    SqlCommand excCommand = new SqlCommand(emailQuery, con);
                    var returnValue = excCommand.ExecuteNonQuery();
                    con.Close();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
                throw ex;                
            }
        }
        public static string GetEmailBody(NewDatasetRequestModel data)
        {
            if (data != null)
            {
                var body = "";

                body=body+ "<html><head></head><body><div style =\"margin:10px 5px 5px 5px;\"><p style =\"margin-left:30px;\"><h4>";

                body = body + "<u>Request For New Dataset</u></h4></p><div><br/><br/><label>Dataset Name:</label><b>" + data.DatasetName;

                body = body + "</b><br/><br/><label>Owner for Dataset:</label> <b>" + data.Owner + "</b><br/><br/>";

                body = body + "</b><br/><br/><label>Description:</label> <p>" + data.DatasetDescription + "</p><br/><br/>";

                body = body + "<label>User Requested:</label> <b>" + data.userName + "</b><br/><br/>";

                body = body + "<label>Department:</label> <b>" + data.Department + "</b><br/><br/></div></div>";

                body = body + "<br/><br/><br/> <span>From, </span><br/><br/><span> HANYS Master Dataset Application </span><br/></body></html>";

                return body;
            }
            return null;
        }
    }
}