﻿using HMDL.Core.DataModel;
using HMDL.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMDL.Core.Services
{
    public class MasterDatasetService
    {
        private HanysMasterDBEntities dbContext = new HanysMasterDBEntities();

        public MasterDataset GetDataset(string datasetName,string Username)
        {
            return dbContext.MasterDatasets.FirstOrDefault(x => x.MDS_DataSetName == datasetName && x.MDS_UserName == Username);
        }

        //To get all DatasetNames
        public List<string> GetAllDatasetNames()
        {
            return dbContext.MasterDatasets.Select(x=>x.MDS_DataSetName).Distinct().ToList();
        }

        //To get single DatasetName details
        public MasterDatasetModel GetDatasetNameDetails(string datasetName)
        {
            var masterModel = new MasterDatasetModel();
            var d = dbContext.MasterDatasets.FirstOrDefault(x => x.MDS_DataSetName == datasetName);
            

            if (d == null)
                return masterModel;

            masterModel = new MasterDatasetModel()
            {
                UserName = d.MDS_UserName,
                Users = d.MDS_Users,
                ExternalUsers = (bool)d.MDS_ExternalUsers,
                DepartmentId = d.MDS_DepartmentId,
                Department = dbContext.Departments.FirstOrDefault(x => x.DPT_Id == d.MDS_DepartmentId).DPT_Department,
                LoadFormatId = (int)d.MDS_LoadFormatId.GetValueOrDefault(),
                LoadFormat = dbContext.LoadFormats.FirstOrDefault(x => x.LAF_Id == d.MDS_LoadFormatId).LAF_LoadFormat,
                LawGoverningSesitivityId = (int)d.MDS_LawsGovervingSensId.GetValueOrDefault(),
                //LawGoverningSesitivity = dbContext.LawsGoverningSensitivities.FirstOrDefault(x => x.LGS_Id == d.MDS_LawsGovervingSensId).LGS_LawsGoverning,
                LastLoadDate = d.MDS_LastLoadDate.GetValueOrDefault(),
                DataAccessEncryption = (bool)d.MDS_DataAccessEncyption.GetValueOrDefault(),
                DataPurpose = d.MDS_DataPurpose ?? null,
                RecordComplete = d.MDS_RecordComplete,
                DataSetName = d.MDS_DataSetName,
                DatasetFormat = (int)d.MDS_DatasetFormat.GetValueOrDefault(),
                DescribeDestructionAutomated = d.MDS_DescribeDestructionAutomated ?? null,
                DatasetRetensionRequired = (bool)d.MDS_DatasetRetentionReq.GetValueOrDefault(),
                DetailsForDatasetRetension = d.MDS_DetailsDatasetRentention ?? null,
                DestructionAutomated = (bool)d.MDS_DestructionAutomated.GetValueOrDefault(),
                Encryption = (int)d.MDS_Encryption.GetValueOrDefault(),
                OtherInformationSensitivity = d.MDS_OtherInformationSensi ?? null,
                OtherLoadFormat = d.MDS_OtherLoadFormat ?? null,
                OtherLawGoverningSensitivity = d.MDS_OtherLawsGoverningSens ?? null,
                EncryptionFeilds = d.MDS_EncryptionFeilds ?? null,
                ReasonForSpecialBackUp = d.MDS_ReasonForSepicalBackUp ?? null,
                RententionRequirement = d.MDS_RetentionRequirement ?? null,
                RetentionStartDate = d.MDS_RetentionStartDate ?? null,
                SpecialAccessRquirements = d.MDS_SpecialAccessRequirements ?? null,
                SpecialAccessRquirementsForBackups = d.MDS_SpecialRequirementsForBackups ?? null,
                SourceLocation = d.MDS_SourceLocation ?? null,
                DataSource = d.MDS_DataSource ?? null,
                Owner = d.MDS_Owner ?? null
            };
            return masterModel;
        }

        public List<MasterDatasetModel> GetAllMasterDataByUser(string Username)
        {
            var masterModel = new List<MasterDatasetModel>();
            var data = dbContext.MasterDatasets.Where(x => x.MDS_UserName.ToLower().Trim() == Username.ToLower()).ToList();

            if (data == null)
            {
                return masterModel;
            }
            data.ForEach(d =>
            {

               masterModel.Add(new MasterDatasetModel()
                {
                    UserName = d.MDS_UserName,
                    Users = d.MDS_Users,
                    ExternalUsers = (bool)d.MDS_ExternalUsers,
                    DepartmentId = d.MDS_DepartmentId,
                    Department = dbContext.Departments.FirstOrDefault(x => x.DPT_Id == d.MDS_DepartmentId).DPT_Department,
                    LoadFormatId = (int)d.MDS_LoadFormatId.GetValueOrDefault(),
                    LoadFormat = dbContext.LoadFormats.FirstOrDefault(x => x.LAF_Id == d.MDS_LoadFormatId).LAF_LoadFormat,
                    LawGoverningSesitivityId = (int)d.MDS_LawsGovervingSensId.GetValueOrDefault(),
                    //LawGoverningSesitivity = dbContext.LawsGoverningSensitivities.FirstOrDefault(x => x.LGS_Id == d.MDS_LawsGovervingSensId).LGS_LawsGoverning,
                    LastLoadDate = d.MDS_LastLoadDate.GetValueOrDefault(),
                    DataAccessEncryption = (bool)d.MDS_DataAccessEncyption.GetValueOrDefault(),
                    DataPurpose = d.MDS_DataPurpose ?? null,
                    RecordComplete = d.MDS_RecordComplete,
                    DataSetName = d.MDS_DataSetName,
                    DatasetFormat = (int)d.MDS_DatasetFormat.GetValueOrDefault(),
                    DescribeDestructionAutomated = d.MDS_DescribeDestructionAutomated ?? null,
                    DatasetRetensionRequired = (bool)d.MDS_DatasetRetentionReq.GetValueOrDefault(),
                    DetailsForDatasetRetension = d.MDS_DetailsDatasetRentention ?? null,
                    DestructionAutomated = (bool)d.MDS_DestructionAutomated.GetValueOrDefault(),
                    Encryption = (int)d.MDS_Encryption.GetValueOrDefault(),
                    OtherInformationSensitivity = d.MDS_OtherInformationSensi ?? null,
                    OtherLoadFormat = d.MDS_OtherLoadFormat ?? null,
                    OtherLawGoverningSensitivity = d.MDS_OtherLawsGoverningSens ?? null,
                    EncryptionFeilds = d.MDS_EncryptionFeilds ?? null,
                    ReasonForSpecialBackUp = d.MDS_ReasonForSepicalBackUp ?? null,
                    RententionRequirement = d.MDS_RetentionRequirement ?? null,
                    RetentionStartDate = d.MDS_RetentionStartDate ?? null,
                    SpecialAccessRquirements = d.MDS_SpecialAccessRequirements ?? null,
                    SpecialAccessRquirementsForBackups = d.MDS_SpecialRequirementsForBackups ?? null,
                    SourceLocation = d.MDS_SourceLocation ?? null,
                    DataSource = d.MDS_DataSource ?? null,
                    Owner = d.MDS_Owner ?? null
               });
            });
            return masterModel;
        }
        public List<string> GetDataSets(string data)
        {
            var user = dbContext.Users.FirstOrDefault(x => x.UDS_User == data);

            var datasets = dbContext.UserDatasets.Where(x => x.UDS_UserId == user.UDS_Id).Select(y => y.UDS_Dataset).ToList();

            return datasets;
        }
        public string GetUserDepartment(string user)
        {
            var departmentId = dbContext.Users.FirstOrDefault(x => x.UDS_User == user).UDS_DepartmentId;

            return dbContext.Departments.FirstOrDefault(x => x.DPT_Id == departmentId).DPT_Department;
        }
        public IEnumerable<LawsGoverningSensitivity> GetLawGovernings()
        {
            return dbContext.LawsGoverningSensitivities.ToList();
        }
        public IEnumerable<LoadFormat> GetLoadFormats()
        {
            return dbContext.LoadFormats.ToList();
        }
        public bool SaveRequest(MasterDatasetModel data)
        {
            if (data != null)
            {
                var masterData = new MasterDataset();

                masterData.MDS_DataSetName = data.DataSetName;
                masterData.MDS_DepartmentId = data.DepartmentId;
                masterData.MDS_DataSource = data.DataSource;
                masterData.MDS_DescribeDestructionAutomated = data.DescribeDestructionAutomated;
                masterData.MDS_DestructionAutomated = data.DestructionAutomated;
                masterData.MDS_DetailsDatasetRentention = data.DetailsForDatasetRetension;
                masterData.MDS_Encryption = data.Encryption;
                masterData.MDS_ExternalUsers = data.ExternalUsers;
                masterData.MDS_LastLoadDate = data.LastLoadDate;
                masterData.MDS_LawsGovervingSensId = data.LawGoverningSesitivityId;
                masterData.MDS_LoadFormatId = data.LoadFormatId;
                masterData.MDS_OtherLoadFormat = data.OtherLoadFormat;
                masterData.MDS_Owner = data.Owner;
                masterData.MDS_ReasonForSepicalBackUp = data.ReasonForSpecialBackUp;
                masterData.MDS_RetentionRequirement = data.RententionRequirement;
                masterData.MDS_RetentionStartDate = data.RetentionStartDate;
                masterData.MDS_SourceLocation = data.SourceLocation;
                masterData.MDS_SpecialAccessRequirements = data.SpecialAccessRquirements;
                masterData.MDS_UserName = data.UserName;
                masterData.MDS_Users = data.Users;
                masterData.MDS_RecordComplete = data.RecordComplete;
                masterData.MDS_OtherLawsGoverningSens = data.OtherLawGoverningSensitivity;
                masterData.MDS_OtherInformationSensi = data.OtherInformationSensitivity;

                dbContext.MasterDatasets.Add(masterData);
                dbContext.SaveChanges();
            }
            return true;
        }
        public bool UpdateRequest(MasterDatasetModel data)
        {
            if (data != null)
            {
                var isExist = GetDataset(data.DataSetName,data.UserName);
                if (isExist != null)
                {
                    isExist.MDS_Owner = data.Owner;
                    isExist.MDS_DataSource = data.DataSource;
                    isExist.MDS_DescribeDestructionAutomated = data.DescribeDestructionAutomated;
                    isExist.MDS_DestructionAutomated = data.DestructionAutomated;
                    isExist.MDS_DetailsDatasetRentention = data.DetailsForDatasetRetension;
                    isExist.MDS_Encryption = data.Encryption;
                    isExist.MDS_ExternalUsers = data.ExternalUsers;
                    isExist.MDS_LastLoadDate = data.LastLoadDate;
                    isExist.MDS_LawsGovervingSensId = data.LawGoverningSesitivityId;
                    isExist.MDS_LoadFormatId = data.LoadFormatId;
                    isExist.MDS_OtherLoadFormat = data.OtherLoadFormat;
                    isExist.MDS_ReasonForSepicalBackUp = data.ReasonForSpecialBackUp;
                    isExist.MDS_RetentionRequirement = data.RententionRequirement;
                    isExist.MDS_RetentionStartDate = data.RetentionStartDate;
                    isExist.MDS_SourceLocation = data.SourceLocation;
                    isExist.MDS_SpecialAccessRequirements = data.SpecialAccessRquirements;
                    isExist.MDS_Users = data.Users;
                    isExist.MDS_RecordComplete = data.RecordComplete;
                    isExist.MDS_OtherLawsGoverningSens = data.OtherLawGoverningSensitivity;
                    isExist.MDS_OtherInformationSensi = data.OtherInformationSensitivity;

                    dbContext.SaveChanges();
                }
                return true;
            }
            return false;
        }
    }
}
