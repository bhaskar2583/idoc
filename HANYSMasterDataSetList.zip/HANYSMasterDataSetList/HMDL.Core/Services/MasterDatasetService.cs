﻿using HMDL.Core.DataModel;
using HMDL.Core.Email_Sender;
using HMDL.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMDL.Core.Services
{
    public class MasterDatasetService
    {
        private HanysMasterDBEntities dbContext = new HanysMasterDBEntities();

        public MasterDataset GetDataset(int datasetId, int userId)
        {
            return dbContext.MasterDatasets.FirstOrDefault(x => x.MDS_DatasetId == datasetId && x.MDS_UserId == userId);
        }
        public User GetUser(string user)
        {
            return dbContext.Users.FirstOrDefault(x => x.UDS_User.ToLower() == user.Trim().ToLower() && x.UDS_IsActive == true);
        }
        public List<DatasetOwnerModel> GetOwners()
        {
            var modelList = new List<DatasetOwnerModel>();
            var data = dbContext.DatasetOwners.Where(x => x.DSO_IsActive == true).OrderBy(x => x.DSO_Owner).ToList();

            data.ForEach(d =>
            {
                modelList.Add(new DatasetOwnerModel()
                {
                    Id = d.DSO_Id,
                    Name = d.DSO_Owner
                });
            });

            return modelList;
        }
        //To get all DatasetNames
        public List<string> GetAllDatasetNames()
        {
            return dbContext.MasterDatasets.Select(x => x.MDS_DataSetName).Distinct().ToList();
        }

        //To get single DatasetName details
        public MasterDatasetModel GetDatasetNameDetails(int datasetId)
        {
            var masterModel = new MasterDatasetModel();
            try
            {
                var d = dbContext.MasterDatasets.FirstOrDefault(x => x.MDS_DatasetId == datasetId);
                var dataset = dbContext.UserDatasets.FirstOrDefault(x => x.UDS_Id == datasetId);

                if (d == null)
                {
                    if (dataset != null)
                    {
                        masterModel = new MasterDatasetModel()
                        {
                            UserId = dataset.UDS_UserId,
                            UserName = dataset.User.UDS_User,
                            OwnerId = dataset.UDS_DatasetOwnerId,
                            Owner = dataset.DatasetOwner.DSO_Owner,
                            DataSetName = dataset.UDS_Dataset,
                            DataSetId = dataset.UDS_Id,
                            Department = dataset.User.Department.DPT_Department
                        };
                        return masterModel;
                    }
                    else
                        return masterModel;
                }

                masterModel = new MasterDatasetModel()
                {
                    UserName = d.User.UDS_User,
                    UserId = d.MDS_UserId,
                    DataSetId = d.MDS_DatasetId,
                    Users = d.MDS_Users ?? null,
                    ExternalUsers = d.MDS_ExternalUsers ?? null,
                    DepartmentId = (int)d.MDS_DepartmentId,
                    Department = d.Department.DPT_Department ?? null,
                    LoadFormatId = (int)d.MDS_LoadFormatId.GetValueOrDefault(),
                    LawGoverningSesitivityId = (int)d.MDS_LawsGovervingSensId.GetValueOrDefault(),
                    LastLoadDate = d.MDS_LastLoadDate.GetValueOrDefault(),
                    DataAccessEncryption = (bool)d.MDS_DataAccessEncyption.GetValueOrDefault(),
                    DataPurpose = d.MDS_DataPurpose ?? null,
                    RecordComplete = d.MDS_RecordComplete,
                    DataSetName = d.UserDataset.UDS_Dataset,
                    DatasetFormat = (int)d.MDS_DatasetFormat.GetValueOrDefault(),
                    DescribeDestructionAutomated = d.MDS_DescribeDestructionAutomated ?? null,
                    DatasetRetensionRequired = (bool)d.MDS_DatasetRetentionReq.GetValueOrDefault(),
                    DetailsForDatasetRetension = d.MDS_DetailsDatasetRentention ?? null,
                    DestructionAutomated = (bool)d.MDS_DestructionAutomated.GetValueOrDefault(),
                    Encryption = (int)d.MDS_Encryption.GetValueOrDefault(),
                    OtherInformationSensitivity = d.MDS_OtherInformationSensi ?? null,
                    OtherLoadFormat = d.MDS_OtherLoadFormat ?? null,
                    OtherLawGoverningSensitivity = d.MDS_OtherLawsGoverningSens ?? null,
                    EncryptionFeilds = d.MDS_EncryptionFeilds ?? null,
                    ReasonForSpecialBackUp = d.MDS_ReasonForSepicalBackUp ?? null,
                    RententionRequirement = d.MDS_RetentionRequirement ?? null,
                    RetentionStartDate = d.MDS_RetentionStartDate ?? null,
                    SpecialAccessRquirements = d.MDS_SpecialAccessRequirements ?? null,
                    SpecialAccessRquirementsForBackups = d.MDS_SpecialRequirementsForBackups ?? null,
                    SourceLocation = d.MDS_SourceLocation ?? null,
                    DataSource = d.MDS_DataSource ?? null,
                    Owner = dataset.DatasetOwner.DSO_Owner,
                    OwnerId = dataset.UDS_DatasetOwnerId,
                    LoadDateAsString = d.MDS_LastLoadDate.HasValue ? d.MDS_LastLoadDate.Value.ToString("MM/dd/yyyy") : string.Empty,
                    ExplainDatasetRestrictions = d.MDS_ExplainDatasetRestrictions ?? null,
                    IsDatasetActiveInlast12months = d.MDS_IsDatasetActiveInPastYear ?? null,
                    IfNocanDatasetBeArchived = d.MDS_IfNoCanDatasetBeArchived ?? null,
                    PermissionToPublishDataset = d.MDS_PermissionToPublishDataset ?? null
                };
                if (masterModel.LoadFormatId != null)
                {
                    masterModel.LoadFormat = d.LoadFormat.LAF_LoadFormat;
                }
                if (masterModel.LawGoverningSesitivityId != null)
                {
                    masterModel.LawGoverningSesitivity = d.LawsGoverningSensitivity.LGS_LawsGoverning;
                }

                return masterModel;
            }
            catch (Exception ex)
            {
                return masterModel;
            }

        }
        public List<MasterDatasetModel> GetAllMasterDataByUser(string Username)
        {
            var masterModel = new List<MasterDatasetModel>();
            var datasets = new List<UserDataset>();
            var user = GetUser(Username);

            var UserIds = dbContext.Users.Where(x => x.UDS_DepartmentId == user.UDS_DepartmentId && x.UDS_IsActive == true).Select(y => y.UDS_Id).ToList();
            if (user.UDS_UserRole != null && user.UDS_UserRole == 1)
            {
                datasets = dbContext.UserDatasets.ToList();
            }
            else
                datasets = dbContext.UserDatasets.Where(x => UserIds.Contains(x.UDS_UserId)).ToList();

            datasets.ForEach(ds =>
            {
                var data = dbContext.MasterDatasets.FirstOrDefault(x => x.MDS_DatasetId == ds.UDS_Id);

                if (data == null)
                {
                    masterModel.Add(new MasterDatasetModel()
                    {
                        UserId = ds.UDS_UserId,
                        UserName = ds.User.UDS_User,
                        OwnerId = ds.UDS_DatasetOwnerId,
                        Owner = ds.DatasetOwner.DSO_Owner,
                        Department = ds.User.Department.DPT_Department,
                        DataSetName = ds.UDS_Dataset,
                        DataSetId = ds.UDS_Id,
                        RecordComplete = false,
                        RecordStatus = "New Dataset"
                    });
                }
                else
                {
                    masterModel.Add(new MasterDatasetModel()
                    {
                        UserId = data.MDS_UserId,
                        UserName = data.MDS_UserName,
                        Department = data.Department.DPT_Department,
                        OwnerId = ds.UDS_DatasetOwnerId,
                        Owner = ds.DatasetOwner.DSO_Owner,
                        //LastLoadDate = data.MDS_LastLoadDate,
                        //LoadDateAsString = data.MDS_LastLoadDate.HasValue ? data.MDS_LastLoadDate.Value.ToString("MM/dd/yyyy") : string.Empty,
                        DataSetName = data.MDS_DataSetName,
                        DataSetId = data.MDS_DatasetId,
                        //Users = data.MDS_Users,
                        DataPurpose = data.MDS_DataPurpose,
                        RecordComplete = data.MDS_RecordComplete
                    });

                    masterModel.ForEach(d =>
                    {
                        if (d.RecordComplete == true && d.RecordStatus == null) { d.RecordStatus = "Completed"; }
                        if (d.RecordComplete == false && d.RecordStatus == null) { d.RecordStatus = "Incomplete"; }
                    });
                }
            });

            return masterModel;
        }
        public List<string> GetDataSets(string data)
        {
            var user = dbContext.Users.FirstOrDefault(x => x.UDS_User == data && x.UDS_IsActive == true);

            var datasets = dbContext.UserDatasets.Where(x => x.UDS_UserId == user.UDS_Id).Select(y => y.UDS_Dataset).ToList();

            return datasets;
        }
        //public string GetUserDepartment(string user)
        //{
        //    var userData = GetUser(user);

        //    return userData.Department.DPT_Department;
        //}
        public IEnumerable<LawsGoverningSensitivity> GetLawGovernings()
        {
            return dbContext.LawsGoverningSensitivities.ToList();
        }
        public IEnumerable<LoadFormat> GetLoadFormats()
        {
            return dbContext.LoadFormats.ToList();
        }
        public bool SaveRequest(MasterDatasetModel data)
        {
            if (data != null)
            {
                var masterData = new MasterDataset();

                masterData.MDS_DatasetId = data.DataSetId;
                masterData.MDS_UserId = data.UserId;
                masterData.MDS_OwnerId = data.OwnerId;
                masterData.MDS_DepartmentId = data.DepartmentId;
                masterData.MDS_DataSource = data.DataSource;
                masterData.MDS_DescribeDestructionAutomated = data.DescribeDestructionAutomated;
                masterData.MDS_DestructionAutomated = data.DestructionAutomated;
                masterData.MDS_DetailsDatasetRentention = data.DetailsForDatasetRetension;
                masterData.MDS_Encryption = data.Encryption;
                masterData.MDS_ExternalUsers = data.ExternalUsers;
                masterData.MDS_LastLoadDate = data.LastLoadDate;
                masterData.MDS_LawsGovervingSensId = data.LawGoverningSesitivityId;
                masterData.MDS_LoadFormatId = data.LoadFormatId;
                masterData.MDS_OtherLoadFormat = data.OtherLoadFormat;
                masterData.MDS_ReasonForSepicalBackUp = data.ReasonForSpecialBackUp;
                masterData.MDS_RetentionRequirement = data.RententionRequirement;
                masterData.MDS_RetentionStartDate = data.RetentionStartDate;
                masterData.MDS_SourceLocation = data.SourceLocation;
                masterData.MDS_SpecialAccessRequirements = data.SpecialAccessRquirements;
                masterData.MDS_Users = data.Users;
                masterData.MDS_RecordComplete = data.RecordComplete;
                masterData.MDS_OtherLawsGoverningSens = data.OtherLawGoverningSensitivity;
                masterData.MDS_OtherInformationSensi = data.OtherInformationSensitivity;
                masterData.MDS_ExplainDatasetRestrictions = data.ExplainDatasetRestrictions;
                masterData.MDS_DataAccessEncyption = data.DataAccessEncryption;
                masterData.MDS_DatasetRetentionReq = data.DatasetRetensionRequired;
                masterData.MDS_IsDatasetActiveInPastYear = data.IsDatasetActiveInlast12months;
                masterData.MDS_DatasetRestrictions = data.DatasetRestrictions;
                masterData.MDS_IfNoCanDatasetBeArchived = data.IfNocanDatasetBeArchived;
                masterData.MDS_PermissionToPublishDataset = data.PermissionToPublishDataset;
                masterData.MDS_SpecialRequirementsForBackups = data.SpecialAccessRquirementsForBackups;
                masterData.MDS_EncryptionFeilds = data.EncryptionFeilds;
                masterData.MDS_DataPurpose = data.DataPurpose;
                masterData.MDS_AddDate = DateTime.Now;
                masterData.MDS_AddUser = data.UserName;


                dbContext.MasterDatasets.Add(masterData);
                dbContext.SaveChanges();

                UpdateUserDatasets(masterData);
            }
            return true;
        }
        public bool UpdateRequest(MasterDatasetModel data)
        {
            if (data != null)
            {
                var isExist = GetDataset(data.DataSetId, data.UserId);

                isExist.MDS_OwnerId = data.OwnerId;
                isExist.MDS_DataSource = data.DataSource;
                isExist.MDS_DescribeDestructionAutomated = data.DescribeDestructionAutomated;
                isExist.MDS_DestructionAutomated = data.DestructionAutomated;
                isExist.MDS_DetailsDatasetRentention = data.DetailsForDatasetRetension;
                isExist.MDS_Encryption = data.Encryption;
                isExist.MDS_ExternalUsers = data.ExternalUsers;
                isExist.MDS_LastLoadDate = data.LastLoadDate;
                isExist.MDS_LawsGovervingSensId = data.LawGoverningSesitivityId;
                isExist.MDS_LoadFormatId = data.LoadFormatId;
                isExist.MDS_DatasetRestrictions = data.DatasetRestrictions;
                isExist.MDS_DatasetFormat = data.DatasetFormat;
                isExist.MDS_OtherLoadFormat = data.OtherLoadFormat;
                isExist.MDS_ExplainDatasetRestrictions = data.ExplainDatasetRestrictions;
                isExist.MDS_ReasonForSepicalBackUp = data.ReasonForSpecialBackUp;
                isExist.MDS_SpecialRequirementsForBackups = data.SpecialAccessRquirementsForBackups;
                isExist.MDS_RetentionRequirement = data.RententionRequirement;
                isExist.MDS_RetentionStartDate = data.RetentionStartDate;
                isExist.MDS_SourceLocation = data.SourceLocation;
                isExist.MDS_SpecialAccessRequirements = data.SpecialAccessRquirements;
                isExist.MDS_Users = data.Users;
                isExist.MDS_RecordComplete = data.RecordComplete;
                isExist.MDS_OtherLawsGoverningSens = data.OtherLawGoverningSensitivity;
                isExist.MDS_OtherInformationSensi = data.OtherInformationSensitivity;
                isExist.MDS_EncryptionFeilds = data.EncryptionFeilds;
                isExist.MDS_PermissionToPublishDataset = data.PermissionToPublishDataset;
                isExist.MDS_IsDatasetActiveInPastYear = data.IsDatasetActiveInlast12months;
                isExist.MDS_IfNoCanDatasetBeArchived = data.IfNocanDatasetBeArchived;
                isExist.MDS_DataPurpose = data.DataPurpose;
                isExist.MDS_DataAccessEncyption = data.DataAccessEncryption;
                isExist.MDS_DatasetRetentionReq = data.DatasetRetensionRequired;
                isExist.MDS_RevUser = data.UserName;
                isExist.MDS_RevDate = DateTime.Now;

                dbContext.SaveChanges();

                UpdateUserDatasets(isExist);

                return true;
            }
            return false;
        }
        public bool UpdateUserDatasets(MasterDataset data)
        {
            var isExist = dbContext.UserDatasets.FirstOrDefault(x => x.UDS_Id == data.MDS_DatasetId && x.UDS_IsActive == true);
            if (isExist != null)
            {
                isExist.UDS_DatasetOwnerId = data.MDS_OwnerId;
                dbContext.SaveChanges();
            }
            return true;
        }
        public NewDatasetRequestModel GetDetails(int id)
        {
            var user = dbContext.Users.FirstOrDefault(x => x.UDS_Id == id);

            var data = new NewDatasetRequestModel()
            {
                userName = user.UDS_User,
                Department = dbContext.Departments.FirstOrDefault(x => x.DPT_Id == user.UDS_DepartmentId).DPT_Department
            };
            return data;
        }
        public bool SendEmail(NewDatasetRequestModel data)
        {
            var value = EmailSender.SendEmail(data);
            if (value)
            {
                return true;
            }
            return false;
        }
    }
}
