﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMDL.Core.Models
{
    public class NewDatasetRequestModel
    {
        [Required]
        [DisplayName("Name of the Dataset")]
        public string DatasetName { get; set; }
        [Required]
        [DisplayName("Owner for the New Dataset")]
        public string Owner { get; set; }
        public string userName { get; set; }
        public string Department { get; set; }
        [Required]
        [DisplayName("Description")]
        public string DatasetDescription { get; set; }
    }
}
