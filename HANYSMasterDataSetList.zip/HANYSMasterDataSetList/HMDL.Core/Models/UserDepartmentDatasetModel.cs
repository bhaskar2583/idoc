﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMDL.Core.Models
{
    public class UserDepartmentDatasetModel
    {
        public int Id { get; set; }
        public int DepartmentId { get; set; }
        public string User { get; set; }
        public List<DatasetModel> Datasets { get; set; }
        public class DatasetModel
        {
            public string Datasets { get; set; }
        }
    }
}
