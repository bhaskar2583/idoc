﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMDL.Core.Models
{
    public class MasterDatasetModel
    {
        public int Id { get; set; }
        public int DepartmentId { get; set; }
        public string Department { get; set; }
        public int? LoadFormatId { get; set; }
        public string LoadFormat { get; set; }
        public int? LawGoverningSesitivityId { get; set; }
        public string LawGoverningSesitivity { get; set; }
        public int? Encryption { get; set; }
        public bool? ExternalUsers { get; set; }
        public int? DatasetFormat { get; set; }
        public bool? DataAccessEncryption { get; set; }
        public string UserName { get; set; }
        public string DataSetName { get; set; }
        public int DataSetId { get; set; }
        public int OwnerId { get; set; }
        public string Owner { get; set; }
        public string OtherLoadFormat { get; set; }
        public string DataSource { get; set; }
        public string Users { get; set; }
        public string SourceLocation { get; set; }
        public string DataPurpose { get; set; }
        public string OtherLawGoverningSensitivity { get; set; }
        public string OtherInformationSensitivity { get; set; }
        public string EncryptionFeilds { get; set; }
        public string SpecialAccessRquirements { get; set; }
        public string RententionRequirement { get; set; }
        public string DescribeDestructionAutomated { get; set; }
        public string SpecialAccessRquirementsForBackups { get; set; }
        public string DetailsForDatasetRetension { get; set; }
        public string ReasonForSpecialBackUp { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public Nullable<System.DateTime> LastLoadDate { get; set; }

        //public DateTime? LastLoadDate { get; set; }
        public string RetentionStartDate { get; set; }
        public bool? DatasetRetensionRequired { get; set; }
        public bool? DestructionAutomated { get; set; }
        public bool RecordComplete { get; set; }
        public bool? DatasetRestrictions { get; set; }
        public string ExplainDatasetRestrictions { get; set; }
        public int UserId { get; set; }
        public string LoadDateAsString { get; set; }
        public string RecordStatus { get; set; }
        public bool? IsDatasetActiveInlast12months { get; set; }
        public bool? IfNocanDatasetBeArchived { get; set; }
        public bool? PermissionToPublishDataset { get; set; }
    }
    public class DatasetOwnerModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
