﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBS.Core.Models
{
    public class ClientModel : BaseModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool Division { get; set; }
        public bool IsActive { get; set; }
    }
}
