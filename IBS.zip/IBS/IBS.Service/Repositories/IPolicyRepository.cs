﻿using IBS.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBS.Service.Repositories
{
    public interface IPolicyRepository
    {
        IQueryable<Policies> GetAll();
        Policies GetById(int id);
        bool Add(Policies policy);
        bool Update(Policies policy);
        bool Delete(int id);
    }
}
