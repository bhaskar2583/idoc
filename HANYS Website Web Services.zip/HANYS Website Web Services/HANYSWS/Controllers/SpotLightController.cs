﻿using HANYSWS.Core.EDM;
using HANYSWS.Core.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace HANYSWS.Controllers
{

    public class SpotLightController : ApiController
    {
        private SpotLightService spotLightService = new SpotLightService();

        // GET: api/SpotLightImage
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        // GET api/GetSpotLight
        //api/SpotLight/GetSpotLightByRecordNumber?RecordNumber=1
        public IHttpActionResult GetSpotLightByRecordNumber(int recordNumber)
        {
            try
            {
                var spotlightList = spotLightService.GetSpotLights();
                if (recordNumber > 0)
                {
                    spotlightList.Where(x => x.RECORDNUMBER == recordNumber);
                }

                List<SPOTLIGHT> list = new List<SPOTLIGHT>();

                list = spotLightService.GetSpotLights().ToList();

                return Ok(JsonConvert.SerializeObject(list));
            }
            catch (Exception ex)
            {
                return null;//new HttpResponseMessage(HttpStatusCode.BadRequest);
            }
        }
        // GET: api/SpotLightImage/5
        //api/SpotLight/GetAttachmentListByRecordNumber?recordNumber=174
        public IHttpActionResult GetAttachmentListByRecordNumber(int recordNumber)

        {
            var slAttachmentList = spotLightService.GetAttachmentListByRecordNumber(recordNumber);
            return Ok(JsonConvert.SerializeObject(slAttachmentList));
        }

        //api/SpotLight/ReplaceSpotImagebyFileID/?id=31
        [HttpPatch]
        public IHttpActionResult ReplaceSpotImagebyFileID(int id)
        {
            var result = spotLightService.ReplaceSpotImagebyFileID(id);
            if (result)
            {
                return Ok(true);
            }
            return Ok(false);
        }

        //api/SpotLight/DeleteImagebyFileId/?id=31
        [HttpDelete]
        public IHttpActionResult DeleteImagebyFileId(int id)
        {
            var result = spotLightService.DeleteImagebyFileId(id);
            if (result)
            {
                return Ok(true);
            }
            return Ok(false);
        }

        [HttpPost]
        public IHttpActionResult AddSpotLightImage(SPOTLIGHT_IMAGES sPOTLIGHT_IMAGES)
        {
            var result = spotLightService.AddSpotLightImage(sPOTLIGHT_IMAGES);
            if (result)
            {
                return Ok(true);
            }
            return Ok(false);
        }

        [HttpPatch]
        public IHttpActionResult UpdateSpotLight(SPOTLIGHT sPOTLIGHT)
        {
            var result = spotLightService.UpdateSpotLight(sPOTLIGHT);
            if (result)
            {
                return Ok(true);
            }
            return Ok(false);
        }

        [HttpPatch]
        public IHttpActionResult UnpublishSpotLightbyRecordNumber(int recordNumber)
        {
            var result = spotLightService.UnpublishSpotLightbyRecordNumber(recordNumber);
            if (result)
            {
                return Ok(true);
            }
            return Ok(false);
        }

        //api/SpotLight/GetListSpotLightbyStartAndEnd?start=2&end=9
        [HttpGet]
        public IHttpActionResult GetListSpotLightbyStartAndEnd(int start, int end)
        {
            var slAttachmentList = spotLightService.GetListSpotLightbyStartAndEnd(start, end);
            return Ok(JsonConvert.SerializeObject(slAttachmentList));
        }

    }
}
