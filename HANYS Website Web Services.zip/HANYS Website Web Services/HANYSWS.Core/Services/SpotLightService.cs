﻿using HANYSWS.Core.EDM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HANYSWS.Core.Services
{
    public class SpotLightService
    {
        private HANYSWebEntities dbContext = new HANYSWebEntities();

        public List<SPOTLIGHT> GetSpotLights()
        {
            return dbContext.SPOTLIGHTs.ToList();
        }
        public SPOTLIGHT GetSpotLightMaxId()
        {
            SPOTLIGHT sp = new SPOTLIGHT();
            return sp;
        }

        /// <summary>
        /// Gets AttachmentLists By RecordNumber
        /// </summary>
        /// <param name="recordNumber"></param>
        /// <returns></returns>
        public IEnumerable<SPOTLIGHT_IMAGES> GetAttachmentListByRecordNumber(int recordNumber)
        {
            try
            {
                var attachementList = dbContext.SPOTLIGHT_IMAGES.Where(s => s.SPOTLIGHTRECORDNUMBER == recordNumber)
                                        .OrderBy(a => a.FILEID).ToList();

                return attachementList;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public bool ReplaceSpotImagebyFileID(int fileId)
        {
            try
            {
                var result = dbContext.SPOTLIGHT_IMAGES.SingleOrDefault(a => a.FILEID == fileId);
                if (result != null)
                {
                    result.FILEDATE = DateTime.Now;
                    result.DATE_STAMP = DateTime.Now;
                    dbContext.SaveChanges();
                    return true;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return false;
        }

        public bool DeleteImagebyFileId(int fileId)
        {
            try
            {
                var deleteRecord = dbContext.SPOTLIGHT_IMAGES.SingleOrDefault(s => s.FILEID == fileId);
                if (deleteRecord != null)
                {
                    dbContext.SPOTLIGHT_IMAGES.Remove(deleteRecord);
                    dbContext.SaveChanges();
                    return true;
                }
            }
            catch (Exception e)
            {
                //throw e;
            }
            return false;

        }

        public bool AddSpotLightImage(SPOTLIGHT_IMAGES sPOTLIGHT_IMAGES)
        {
            try
            {
                dbContext.SPOTLIGHT_IMAGES.Add(sPOTLIGHT_IMAGES);
                dbContext.SaveChanges();
                return true;
            }
            catch (Exception e)
            {

                // throw;
            }
            return false;

        }


        public bool AddSpotLight(SPOTLIGHT spotLight)
        {
            return true;
        }
        public bool UpdateSpotLight(SPOTLIGHT spotLight)
        {

            try
            {
                var result = dbContext.SPOTLIGHTs.SingleOrDefault(r => r.RECORDNUMBER == spotLight.RECORDNUMBER);
                if (result != null)
                {
                    result.TITLE = spotLight.TITLE;
                    result.TYPE = spotLight.TYPE;
                    result.ID = spotLight.ID;
                    result.BACKGROUND = spotLight.BACKGROUND;
                    result.SOCIALIMAGE = spotLight.SOCIALIMAGE; //needs to add other parameters ad per the query in word doc
                    result.STORYDATE = spotLight.STORYDATE;
                    result.RECORDNUMBER = spotLight.RECORDNUMBER;
                    result.FACILITY_NAME = spotLight.FACILITY_NAME;
                    result.FACILITY_ID = spotLight.FACILITY_ID;
                    result.CATEGORY = spotLight.CATEGORY;
                    result.EMBLEM = spotLight.EMBLEM;
                    result.SOCIALDESCRIPTION = spotLight.SOCIALDESCRIPTION;
                    result.INTRO = spotLight.INTRO;
                    result.STORY_TEXT = spotLight.STORY_TEXT;
                    result.PUBLISHED = spotLight.PUBLISHED;

                    dbContext.SaveChanges();
                    return true;
                }
            }
            catch (Exception e)
            {

                //throw;
            }
            return false;
        }

        public bool UnpublishSpotLightbyRecordNumber(int recordNumber)
        {

            try
            {
                var result = dbContext.SPOTLIGHTs.SingleOrDefault(r => r.RECORDNUMBER == recordNumber);
                if (result != null)
                {
                    result.PUBLISHED = "deleted";
                    dbContext.SaveChanges();
                    return true;
                }
            }
            catch (Exception e)
            {

                //throw;
            }
            return false;
        }

        public IEnumerable<SPOTLIGHT> GetListSpotLightbyStartAndEnd(int start, int end)
        {
            IEnumerable<SPOTLIGHT> spotLightList = null;
            try
            {
                var query = dbContext.SPOTLIGHTs.OrderBy(t => t.STORYDATE).Select(a => a).AsEnumerable()
                                            .Select((t, index) => new
                                            {
                                                RowNumber = index + 1,
                                                t.TITLE,
                                                t.ID,
                                                t.BACKGROUND,
                                                t.CATEGORY,
                                                t.TYPE,
                                                t.SOCIALIMAGE,
                                                t.STORYDATE,
                                                t.RECORDNUMBER,
                                                t.FACILITY_NAME,
                                                t.FACILITY_ID,
                                                t.EMBLEM,
                                                t.SOCIALDESCRIPTION,
                                                t.INTRO,
                                                t.STORY_TEXT,
                                                t.PUBLISHED
                                            }).ToList();

                spotLightList = query.Where(r => r.RowNumber >= start && r.RowNumber <= end)
                    .Select(t =>
                       new SPOTLIGHT
                       {
                           TITLE = t.TITLE,
                           ID = t.ID,
                           BACKGROUND = t.BACKGROUND,
                           CATEGORY = t.CATEGORY,
                           TYPE = t.TYPE,
                           SOCIALIMAGE = t.SOCIALIMAGE,
                           STORYDATE = t.STORYDATE,
                           RECORDNUMBER = t.RECORDNUMBER,
                           FACILITY_NAME = t.FACILITY_NAME,
                           FACILITY_ID = t.FACILITY_ID,
                           EMBLEM = t.EMBLEM,
                           SOCIALDESCRIPTION = t.SOCIALDESCRIPTION,
                           INTRO = t.INTRO,
                           STORY_TEXT = t.STORY_TEXT,
                           PUBLISHED = t.PUBLISHED
                       }
                    ).ToList();
                return spotLightList;
            }
            catch (Exception e)
            {
                //throw;
            }
            return spotLightList;
        }
        public bool DeleteSpotLight(int id)
        {
            return true;
        }
        public bool PublishSpotLight(bool value)
        {
            return true;
        }
    }
}
