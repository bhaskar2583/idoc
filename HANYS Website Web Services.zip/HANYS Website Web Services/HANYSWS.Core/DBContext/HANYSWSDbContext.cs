﻿using HANYSWS.Core.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HANYSWS.Core.DBContext
{
    public sealed class SingletonForEF
    {
        SingletonForEF()
        {
        }
        private static readonly object padlock = new object();
        private static HANYSWSDBContext instance = null;
        public static HANYSWSDBContext Instance
        {
            get
            {
                lock (padlock)
                {
                    if (instance == null)
                    {
                        instance = new HANYSWSDBContext();
                    }
                    return instance;
                }
            }
        }
    }
    public class HANYSWSDBContext : DbContext
    {
        public HANYSWSDBContext() : base()
        {
            Database.SetInitializer<HANYSWSDBContext>(null);
        }

        public virtual DbSet<SpotLight> SpotLight { get; set; }
        public virtual DbSet<SpotLightImage> SpotLightImages { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBinder)
        {
            modelBinder.Entity<SpotLight>().Map(entity =>
            {
                entity.Property(p => p.ID).HasColumnName("ID");
                entity.Property(p => p.Facility_Id).HasColumnName("FACILITY_ID");
                entity.Property(p => p.Facility_Name).HasColumnName("FACILITY_NAME");
                entity.Property(p => p.Title).HasColumnName("TITLE");
                entity.Property(p => p.Type).HasColumnName("TYPE");
                entity.Property(p => p.SocialDescription).HasColumnName("SOCIALDESCRIPTION");
                entity.Property(p => p.SocialImage).HasColumnName("SOCIALIMAGE");
                entity.Property(p => p.Story_Text).HasColumnName("STORY_TEXT");
                entity.Property(p => p.StoryDate).HasColumnName("STORYDATE");
                entity.Property(p => p.Published).HasColumnName("PUBLISHED");
                entity.Property(p => p.RecordNumber).HasColumnName("RECORDNUMBER");
                entity.Property(p => p.Intro).HasColumnName("INTRO");
                entity.Property(p => p.BackGround).HasColumnName("BACKGROUND");
                entity.Property(p => p.Emblem).HasColumnName("EMBLEM");
                entity.Property(p => p.Category).HasColumnName("CATEGORY");

                entity.ToTable("SPOTLIGHT");
            });
            modelBinder.Entity<SpotLightImage>().Map(entity =>
            {
                entity.Property(p => p.FileDate).HasColumnName("FILEDATE");
                entity.Property(p => p.FiledId).HasColumnName("FILEID");
                entity.Property(p => p.FileExtension).HasColumnName("FILEEXTENSION");
                entity.Property(p => p.FileName).HasColumnName("FILENAME");
                entity.Property(p => p.SpotLightRecordNumber).HasColumnName("SPOTLIGHTRECORDNUMBER");
                entity.Property(p => p.Title).HasColumnName("TITLE");
                entity.Property(p => p.Date_Stamp).HasColumnName("DATE_STAMP");

                entity.ToTable("SPOTLIGHT_IMAGES");
            });
        }

    }
}
