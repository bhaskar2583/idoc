﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HANYSWS.Core.Models
{
    public class SpotLightModel
    {
        public string ID { get; set; }
        public string Title { get; set; }
        public string Type { get; set; }
        public string BackGround { get; set; }
        public string SocialImage { get; set; }
        public string Facility_Name { get; set; }
        public string Category { get; set; }
        public string Emblem { get; set; }
        public string SocialDescription { get; set; }
        public long? Facility_Id { get; set; }
        public string Intro { get; set; }
        public string Story_Text { get; set; }
        public string Published { get; set; }
        public int? RecordNumber { get; set; }
        public DateTime? StoryDate { get; set; }
    }
}