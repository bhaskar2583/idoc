﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    public static class StartDate
    {
        public static string DateTime { get; set; }
    }
    class Program
    {
        public static string Decrypt(string input, string key)
        {
            byte[] inputArray = Convert.FromBase64String(input);
            TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
            tripleDES.Key = UTF8Encoding.UTF8.GetBytes(key);
            tripleDES.Mode = CipherMode.ECB;
            tripleDES.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = tripleDES.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
            tripleDES.Clear();
            return UTF8Encoding.UTF8.GetString(resultArray);
        }
        public static string Encrypt(string input, string key)
        {
            byte[] inputArray = UTF8Encoding.UTF8.GetBytes(input);
            TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
            tripleDES.Key = UTF8Encoding.UTF8.GetBytes(key);
            tripleDES.Mode = CipherMode.ECB;
            tripleDES.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = tripleDES.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
            tripleDES.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }
        static void Main(string[] args)
        {
            string original = DateTime.Now.AddMinutes(5).ToString();
            byte[] array;
            byte[] iv1;
            byte[] key1;
            using (AesManaged myAes = new AesManaged())
            {
                byte[] encrypted = Encrypt(original, myAes.Key, myAes.IV);

                string bitString = BitConverter.ToString(encrypted);
                Console.WriteLine("Date");
               // Console.WriteLine(bitString);
                var eDate= Encrypt(bitString, "sblw-3hn8-sqoy19");
                var dDate = Decrypt(eDate, "sblw-3hn8-sqoy19");
                Console.WriteLine(eDate);

                String[] arr = bitString.Split('-');
                array = new byte[arr.Length];
                for (int i = 0; i < arr.Length; i++) array[i] = Convert.ToByte(arr[i], 16);
                
                key1 = myAes.Key;
                iv1 = myAes.IV;

                string bitString1 = BitConverter.ToString(myAes.Key);
                Console.WriteLine("Key");
                //Console.WriteLine(bitString1);
                var keDate = Encrypt(bitString1, "sblw-3hn8-sqoy19");
                var kdDate = Decrypt(keDate, "sblw-3hn8-sqoy19");
                Console.WriteLine(keDate);

                string bitString2 = BitConverter.ToString(myAes.IV);
                Console.WriteLine("Iv");
                //Console.WriteLine(bitString2);
                var iveDate = Encrypt(bitString2, "sblw-3hn8-sqoy19");
                var ivdDate = Decrypt(iveDate, "sblw-3hn8-sqoy19");
                Console.WriteLine(iveDate);

                Console.ReadLine();
            }
            
        }

        static byte[] Encrypt(string plainText, byte[] Key, byte[] IV)
        {
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException("plainText");
            if (Key == null || Key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("IV");
            byte[] encrypted;
            using (AesManaged aesAlg = new AesManaged())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }
            return encrypted;

        }

    }
}
