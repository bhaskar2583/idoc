﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    public static class StartDate
    {
        public static string DateTime { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            string original = DateTime.Now.AddMinutes(5).ToString();
            byte[] array;
            byte[] iv1;
            byte[] key1;
            using (AesManaged myAes = new AesManaged())
            {
                byte[] encrypted = Encrypt(original, myAes.Key, myAes.IV);

                string bitString = BitConverter.ToString(encrypted);
                Console.WriteLine("Date");
                Console.WriteLine(bitString);

                String[] arr = bitString.Split('-');
                array = new byte[arr.Length];
                for (int i = 0; i < arr.Length; i++) array[i] = Convert.ToByte(arr[i], 16);
                
                key1 = myAes.Key;
                iv1 = myAes.IV;

                string bitString1 = BitConverter.ToString(myAes.Key);
                Console.WriteLine("Key");
                Console.WriteLine(bitString1);

                string bitString2 = BitConverter.ToString(myAes.IV);
                Console.WriteLine("Iv");
                Console.WriteLine(bitString2);

                Console.ReadLine();
            }
            
        }

        static byte[] Encrypt(string plainText, byte[] Key, byte[] IV)
        {
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException("plainText");
            if (Key == null || Key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("IV");
            byte[] encrypted;
            using (AesManaged aesAlg = new AesManaged())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }
            return encrypted;

        }

    }
}
