﻿CREATE TABLE [dbo].[PFP_Data] (
    [org_cst_key]        UNIQUEIDENTIFIER NULL,
    [org_name]           NVARCHAR (150)   NULL,
    [cst_parent_cst_key] UNIQUEIDENTIFIER NULL
);

