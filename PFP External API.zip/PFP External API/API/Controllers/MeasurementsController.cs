﻿namespace API.Controllers
{
    using API.Models.DAL.Measurements;
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Web.Http;
    using System.Web.Http.Description;

    public class MeasurementsController : ApiController
    {
        private MeasurementsDAL dbM = new MeasurementsDAL();

        public List<HospitalData> GetHospitalsData(string email)
        {
            return dbM.GetHospitalsData(email);
        }

        public List<YearData> GetYears(int Year)
        {
            return dbM.GetYears(Year);
        }

        public List<EventTypeData> GetEventTypes()
        {
            return dbM.GetEventTypes();
        }

        public List<EventTypeMeasuresData> GetEventTypeMeasures(int EVMId)
        {
            return dbM.GetEventTypeMeasures(EVMId);
        }

        public List<TimePeriodData> GetTimePeriods(int EVMId)
        {
            return dbM.GetTimePeriods(EVMId);
        }

        public Models.PeriodEventMeasurements GetMeasuresData(int HOSId, int EMMId, int Year, string TimePeriod)
        {
            return dbM.GetMeasurementsData(HOSId, EMMId, Year, TimePeriod);
        }

        [ResponseType(typeof(HttpStatusCode))]
        public HttpStatusCode PostMeasuresData(List<PFPMeasurementData> pFPMeasurementDatas)
        {
            if (!ModelState.IsValid)
            {
                return HttpStatusCode.BadRequest;
            }

            try
            {
                dbM.SaveMeasuresData(pFPMeasurementDatas);
                return HttpStatusCode.OK;
            }
            catch (Exception)
            {
                return HttpStatusCode.BadRequest;
            }
        }
    }
}
