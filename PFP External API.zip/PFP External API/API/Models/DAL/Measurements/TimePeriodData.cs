﻿namespace API.Models.DAL.Measurements
{
    public class TimePeriodData
    {
        public string TPId { get; set; }
        public string TimePeriod { get; set; }
    }
}