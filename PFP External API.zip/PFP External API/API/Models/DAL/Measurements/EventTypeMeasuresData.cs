﻿namespace API.Models.DAL.Measurements
{
    public class EventTypeMeasuresData
    {
        public int EMMId { get; set; }
        public string MEMMeasure { get; set; }
        public string MEMDisplayName { get; set; }
        public string EMMTimePeriod { get; set; }
        public int MEMMultiplier { get; set; }
    }
}
