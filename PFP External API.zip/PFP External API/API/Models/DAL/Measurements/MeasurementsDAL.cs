﻿namespace API.Models.DAL.Measurements
{
    using API.Models.EDM;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;

    internal class MeasurementsDAL
    {
        private readonly PFPEntities db = new PFPEntities();

        internal List<HospitalData> GetHospitalsData(string email = "")
        {
            var hospitals = new List<Hospital>();
            if (email != null && email.Length > 0)
            {
                var userHosName = db.Users
                    .Where(u => u.USR_Email == email)?.FirstOrDefault()?
                    .USR_OrganizationName?.Replace(" ", "")?.ToLower() ?? string.Empty;
                var Hoss = db.Hospitals.Where(h => h.HOS_Active == true);
                var HosUniqueId = Hoss
                    .Where(h => h.HOS_Active == true && h.HOS_HospitalName.Replace(" ", "").ToLower() == userHosName)?.FirstOrDefault()?
                    .HOS_Unique_Id?.Replace(" ", "")?.ToLower() ?? string.Empty;
                hospitals = Hoss
                    .Where(h => h.HOS_Active == true 
                    && (h.HOS_HospitalName.Replace(" ", "").ToLower() == userHosName 
                    || h.HOS_Unique_Id.Replace(" ", "").ToLower() == HosUniqueId 
                    || h.HOS_Parent_Id.Replace(" ", "").ToLower() == HosUniqueId)).ToList();
                return Komparer(hospitals);
            }
            else
            {
                hospitals = db.Hospitals.Where(h => h.HOS_Active == true).ToList();
                return Komparer(hospitals);
            }
        }

        internal List<HospitalData> Komparer(List<Hospital> hospitals)
        {
            var hoss = hospitals.GroupBy(k => new { k.HOS_HospitalName, k.HOS_Unique_Id }).Select(k => k.FirstOrDefault());
            return hoss.Select(h => new HospitalData() { HOSId = h.HOS_Id, HOSHospitalName = h.HOS_HospitalName }).OrderBy(h => h.HOSHospitalName).ToList();
        }

        internal List<YearData> GetYears(int Year)
        {
            var Years = db.CalendarMasters.Where(c => c.CAL_Active == true).GroupBy(y => new { y.CAL_Year }).Select(c => c.FirstOrDefault());
            if (Year > 0)
                Years = Years.Where(c => c.CAL_Year >= Year);
            return Years.Select(c => new YearData { Year = c.CAL_Year }).OrderByDescending(c => c.Year).ToList();
        }

        internal List<EventTypeData> GetEventTypes()
        {
            var ets = db.EventTypeMasters.Where(e => e.EVM_Active == true);
            return ets.Select(e => new EventTypeData() { EVMId = e.EVM_Id, EVMEventType = e.EVM_EventType }).OrderBy(e => e.EVMEventType).ToList();
        }

        internal List<EventTypeMeasuresData> GetEventTypeMeasures(int EVMId)
        {
            var ets = db.EventMeasureMasters.Where(e => e.EMM_Active == true && e.EMM_Id == EVMId);
            return ets.Select(e => new EventTypeMeasuresData() { EMMId = e.EMM_Id, MEMDisplayName = e.MeasureMaster.MEM_DisplayName, MEMMeasure = e.MeasureMaster.MEM_Measure, EMMTimePeriod = e.EMM_TimePeriod, MEMMultiplier = e.MeasureMaster.MEM_Multiplier }).OrderBy(e => e.MEMDisplayName).ToList();
        }

        internal List<TimePeriodData> GetTimePeriods(int EVMId)
        {
            var tps = GetEventTypeMeasures(EVMId).GroupBy(k => k.EMMTimePeriod).Select(k => k.FirstOrDefault().EMMTimePeriod).ToList();
            List<TimePeriodData> timePeriods = new List<TimePeriodData>();
            foreach (var tp in tps)
            {
                if (tp.ToLower().StartsWith("m"))
                {
                    timePeriods.Add(new TimePeriodData() { TPId = "m1", TimePeriod = "Monthly (Jan - Mar)" });
                    timePeriods.Add(new TimePeriodData() { TPId = "m2", TimePeriod = "Monthly (Apr - Jun" });
                    timePeriods.Add(new TimePeriodData() { TPId = "m3", TimePeriod = "Monthly (Jul - Sep" });
                    timePeriods.Add(new TimePeriodData() { TPId = "m4", TimePeriod = "Monthly (Oct - Dec" });
                }
                else if (tp.ToLower().StartsWith("q"))
                {
                    timePeriods.Add(new TimePeriodData() { TPId = "q", TimePeriod = "Quarterly (Q1, Q2, Q3, Q4)" });
                }
            }

            return timePeriods;
        }

        internal PeriodEventMeasurements GetMeasurementsData(int HOSId, int EMMId, int Year, string TimePeriod)
        {


            return new PeriodEventMeasurements();
        }

        internal void SaveMeasuresData(List<PFPMeasurementData> pFPMeasurementDatas)
        {
            try
            {
                foreach (var m in pFPMeasurementDatas)
                {
                    var MEMMultiplier = db.EventMeasureMasters.Where(k => k.EMM_Id == m.EMMId)?.FirstOrDefault()?.MeasureMaster?.MEM_Multiplier ?? 0;
                    var pfp = db.NYSPFPDatas.Where(k => k.NPD_HOS_Id == m.HOSId && k.NPD_Cal_Id == m.CALId && k.NPD_EMM_Id == m.EMMId).FirstOrDefault();
                    if (pfp != null && pfp.NPD_Id > 0)
                    {
                        pfp.NPD_Numerator = m.Numerator;
                        pfp.NPD_Denominator = m.Denominator;
                        pfp.NPD_Measurement = m.Denominator > 0 ? (m.Numerator / m.Denominator) * MEMMultiplier : 0;
                        pfp.NPD_SourceType = "NYSPFP";
                        pfp.NPD_CreatedBy = "HANYSNT\\Ksuriyak";
                        pfp.NPD_CreatedOn = DateTime.Now;
                        pfp.NPD_UpdatedBy = m.UpdatedBy;
                        pfp.NPD_UpdatedOn = DateTime.Now;

                        db.Entry(pfp).State = EntityState.Modified;
                        db.SaveChanges();
                    }
                    else
                    {
                        pfp = new NYSPFPData
                        {
                            NPD_Id = 0,
                            NPD_HOS_Id = m.HOSId,
                            NPD_Cal_Id = m.CALId,
                            NPD_EMM_Id = m.EMMId,
                            NPD_Numerator = m.Numerator,
                            NPD_Denominator = m.Denominator,
                            NPD_Measurement = m.Denominator > 0 ? (m.Numerator / m.Denominator) * MEMMultiplier : 0,
                            NPD_SourceType = "NYSPFP",
                            NPD_CreatedBy = "HANYSNT\\Ksuriyak",
                            NPD_CreatedOn = DateTime.Now,
                            NPD_UpdatedBy = m.UpdatedBy,
                            NPD_UpdatedOn = DateTime.Now
                        };
                        db.NYSPFPDatas.Add(pfp);
                        db.SaveChanges();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}

