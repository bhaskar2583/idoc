﻿namespace API.Models.DAL.Measurements
{
    public class PFPMeasurementData
    {
        public int HOSId { get; set; }
        public int CALId { get; set; }
        public int EMMId { get; set; }
        public decimal Numerator { get; set; }
        public decimal Denominator { get; set; }
        public string UpdatedBy { get; set; }
    }
}