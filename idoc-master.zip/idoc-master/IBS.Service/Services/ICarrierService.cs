﻿using IBS.Core.Enums;
using IBS.Core.Models;
using System.Collections.Generic;

namespace IBS.Service.Services
{
    public interface ICarrierService
    {
        IList<CarrierModel> GetAllCarriers();
        CarrierModel GetById(int Id);
        bool AddCarrier(CarrierModel carrier);
        bool ModifyCarrier(CarrierModel carrier);
        bool DeleteCarrier(int carrierId);
        IList<CarrierModel> ApplyFilterForIndex(string carrierName, CarrierStatusEnum searchStatus, IList<CarrierModel> source);
    }
}
