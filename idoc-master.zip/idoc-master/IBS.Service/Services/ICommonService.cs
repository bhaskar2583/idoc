﻿using IBS.Core.Entities;
using IBS.Core.Models;
using System.Collections.Generic;

namespace IBS.Service.Services
{
    public interface ICommonService
    {
        IList<Coverage> GetAllCoverages();
        IList<Product> GetAllProducts();
        IList<Product> GetAllProductsByCoverageId(int coverageId);
        Coverage GetCoverageById(int coverageId);
        Product GetProductById(int productId);
        IList<ClientPolicie> GetAllClientPolicies();
        IList<ClientPolicie> GetAllClientPoliciesById(int clientId);
        IList<ClientPolicie> GetClientPolicyByPolicyId(int PolicyId);
        bool AddClientPolicy(ClientPolicie clientPolicy);
        bool UpdateClientPolicy(ClientPolicie clientPolicy);
        bool SoftRemoveClientPolicy(int policyId, int clientId);
        IList<ClientPolicyBudget> GetAllPolicyBudgets(int policyId);
        bool AddClientPolicyBudget(AddPolicyBudget budget);
        bool UpdateClientPolicyBudget(AddPolicyBudget budget);
        IList<ClientPolicyBudget> GetAllPolicyBudgetsForClientPolicyYear(int clientId, int policyId, int year);
        ClientPolicyBudget GetAllPolicyBudgetsForPolicyYearMonth(int policyId, int year, string month);
        ClientPolicie GetClientPoliciesByPolicyId(int policyId);
        IList<CorporateProductsXProduct> GetAllCorporateXProducts();
        CorporateProduct GetCorporateProductById(int productId);
        bool DeleteCommission(int clientPolicyId);
        IList<Client> GetAllClients();
        //Client GetClientById(int clientId);
    }
}