﻿using IBS.Core.Entities;
using IBS.Core.Models;
using IBS.Service.Utils;
using System.Collections.Generic;


namespace IBS.Service.Services
{
    public interface ICommisionService
    {
        List<Commision> GetSavedCommissions();
        ClientPolicie GetAllClientPoliciesByIndexId(int Id);
        List<ClientPolicie> GetAllClientPolicies();
        List<CommisionModel> GetCarrierPoliciesById(int carrierId);
        List<CommisionModel> GetAllSavedCommissionsForCarrier(int carrierId);
        bool SaveCommissions(List<CommisionModel> commissions, bool save);
        bool UpdateCommissions(List<CommisionModel> commissions);
        Policie GetPolicyByNoCarriageCoverage(string policyNo, int carrierId, int coverageId, int product);
        Policie GetPolicyByNoCarriageCoverage(string policyNo, int carrierId, int coverageId);
        ClientPolicie GetClientPoliciesByPolicyId(int policyId);
        List<Product> GetProductsOfPolicy(string client, string policy, string coverage);
        List<SelectListCommon> GetCarrierStatementDates(string carrierId);
        List<SelectListCommon> GetCarrierStatementDatePayments(string carrierId, string statementDate);
        IList<CorporateProduct> GetAllCorporateProducts();
        List<ExceptionCommissionModel> GetAllExceptionCommissionsForCarrier(int? carrierId);
        IList<Carrier> GetExceptionCommissionsCariers();
        List<SelectListCommon> GetExceptionCarrierStatementDates(int? carrierId);
        bool UpdateExceptionCommisions(List<ExceptionCommissionModel> commissions);
        bool UpdateExceptionCommisionsClient(int Id, int clientId, int policyId, string policyNo);
    }
}