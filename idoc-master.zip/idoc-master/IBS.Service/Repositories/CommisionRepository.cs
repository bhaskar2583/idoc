﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using IBS.Core.Entities;
using IBS.Core.Models;
using IBS.Service.DataBaseContext;
using IBS.Service.Utils;

namespace IBS.Service.Repositories
{
    public class CommisionRepository : ICommisionRepository
    {
        private readonly IBSDbContext _hanysContext;
        public CommisionRepository()
        {
            _hanysContext = SingletonForEF.Instance;
        }
        public bool Add(Commision commission)
        {
            _hanysContext.Commissions.Add(commission);
            _hanysContext.SaveChanges();
            return true;
        }

        public List<Commision> GetSavedCommissions()
        {
          return _hanysContext.Commissions.ToList();
        }

        public Commision GetByClientPolicyId(int clientPolicyId)
        {
            return _hanysContext.Commissions.FirstOrDefault(cov => cov.ClientPolicyId == clientPolicyId);
        }
        public List<Commision> GetSavedCommissionsForCarrier(int carrierId)
        {
            return _hanysContext.Commissions.ToList();//.Where(cov => cov.CarrierId == carrierId).ToList();
        }
        public List<Commision> GetByAllClientPolicyId(int clientPolicyId)
        {
            return _hanysContext.Commissions.Where(cov => cov.ClientPolicyId == clientPolicyId).ToList();
        }
        public bool Update(CommisionModel commission)
        {
            //var data = _hanysContext.Commisions.FirstOrDefault(c => c.ClientPolicyId == commission.ClientPolicyId);
            var data = _hanysContext.Commissions.FirstOrDefault(c => c.Id == commission.Id);
            if (data != null)
            {
                data.CommissionValue = commission.CommissionValue;
                data.CommissionString = commission.CommissionString;
                //data.PaymentId = commission.PaymentId;
                //data.StatementDate = commission.StatementDate;
                data.AppliedDate = commission.AppliedDate;
                data.RevDate = commission.RevDate;
                data.RevUser = commission.RevUser;
                //data.Status = commission.Status;
                _hanysContext.SaveChanges();
            }
            return true;
        }

        public bool UpdateCommissionReconciliation(CommisionModel commission)
        {
            try
            {
                var data = _hanysContext.Commissions.Where(c => c.Id == commission.Id).ToList();
                if (data != null)
                {
                    data.ForEach(d =>
                    {
                        d.CommissionValue = commission.CommissionValue;
                        d.ReconciliationDate = commission.AppliedDate;
                        d.ReconciliationStatus = commission.ReconciliationStatus;
                        d.RevDate = commission.RevDate;
                        d.RevUser = commission.RevUser;
                        _hanysContext.SaveChanges();
                    });

                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        public List<InvalidCommission> GetExceptionCommissionsForCarrier(int carrierId)
        {
            if (carrierId == 0)
                return _hanysContext.InvalidCommissions.Where(ec => !ec.IsDumped).ToList();

            return _hanysContext.InvalidCommissions.Where(ec => !ec.IsDumped &&
             ec.CarrierId == carrierId).ToList();
        }
        public List<int> GetExceptionCommissionsCariers()
        {
            try
            {
                var data = _hanysContext.InvalidCommissions.ToList();
                return _hanysContext.InvalidCommissions.Where(ec => !ec.IsDumped).Select(c => c.CarrierId).Distinct().ToList();
            }
            catch (Exception ex)
            {
                return new List<int>();
            }
        }
        private string GetDateFormat(DateTime? date)
        {
            if (date == null)
                return string.Empty;

            DateTime dt = Convert.ToDateTime(date);
            return dt.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        }
        public List<SelectListCommon> GetExceptionCarrierStatementDates(int carrierId)
        {
            try
            {
                var dates = new List<SelectListCommon>();

                var commissions = _hanysContext.InvalidCommissions.Where(ec => !ec.IsDumped &&
                ec.CarrierId == carrierId).ToList().Select(d => new SelectListCommon()
                {
                    Id = 0,
                    Name = GetDateFormat(d.StatementDate)
                }).Distinct().ToList();

                commissions.ForEach(c =>
                {
                    if (dates.FirstOrDefault(d => d.Name == c.Name) == null)
                    {
                        dates.Add(c);
                    }
                });
                return dates;
            }
            catch (Exception ex)
            {
                return new List<SelectListCommon>();
            }
        }

        public bool UpdateExceptionCommisions(InvalidCommission commission)
        {
            var eCommission = _hanysContext.InvalidCommissions.FirstOrDefault(ec => ec.Id == commission.Id);
            if (eCommission != null)
            {
                eCommission.IsDumped = true;
                _hanysContext.SaveChanges();
            }
            return true;
        }

        public InvalidCommission GetExceptionCommissionsById(int Id)
        {
            return _hanysContext.InvalidCommissions.FirstOrDefault(ec => ec.Id == Id);
        }

        public bool UpdateExceptionCommisionsClient(InvalidCommission commission)
        {
            var eCommission = _hanysContext.InvalidCommissions.FirstOrDefault(ec => ec.Id == commission.Id);
            if (eCommission != null)
            {
                eCommission.ClientId = commission.ClientId;
                eCommission.ClientPolicyId = commission.ClientPolicyId;
                eCommission.ExceptionCode = 0;
                _hanysContext.SaveChanges();
            }
            return true;
        }
        public bool IsValidException(string ClientName, string PolicyNumber, string ProductType, string CoverageType)
        {
            var flag = true;

            var IsExistClient = _hanysContext.Clients.Where(x => x.IsActive == true).FirstOrDefault(x => x.Name == ClientName);
            var IsExistPolicy = _hanysContext.Policies.Where(y => y.IsActive == true).FirstOrDefault(y => y.PolicyNumber == PolicyNumber);
            var IsExistProduct = _hanysContext.Products.FirstOrDefault(z => z.Name == ProductType);
            var IsExistCoverage = _hanysContext.Coverages.FirstOrDefault(m => m.Name == CoverageType);

            if (IsExistClient != null & IsExistPolicy != null & IsExistProduct != null & IsExistCoverage != null)
            {
                return flag;
            }
            else
            {
                return false;
            }
        }
        public List<ExceptionCodeLookUp> GetExceptionCodeLookUp(int exceptionCode)
        {
            return _hanysContext.ExceptionCodeLookUps.Where(x => x.ExceptionCode == exceptionCode).ToList();
        }

        public List<InvalidCommission> GetExceptionCommissionsByPolicyNo(string policyNo)
        {
            return _hanysContext.InvalidCommissions.Where(ec => ec.PolicyNumber == policyNo).ToList();
        }
    }
}