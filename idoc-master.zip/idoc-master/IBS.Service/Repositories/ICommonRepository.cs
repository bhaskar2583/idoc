﻿using IBS.Core.Entities;
using System.Collections.Generic;

namespace IBS.Service.Repositories
{
    public interface ICommonRepository
    {

        bool AddCoverages(Coverage coverage);
        bool AddProduct(Product product);
        IList<ClientPolicie> GetAllClientPoliciesByIndexId(int id);
        IList<Coverage> GetAllCoverages();
        IList<Product> GetAllProducts();
        IList<Product> GetAllProductsByCoverageId(int coverageId);
        Coverage GetCoverageById(int coverageId);
        Product GetProductById(int productId);
        Client GetClientById(int clientId);
        IList<ClientPolicie> GetAllClientPolicies();
        IList<ClientPolicie> GetAllClientPoliciesById(int clientId);
        IList<ClientPolicie> GetClientPolicyByPolicyId(int policyId);
        bool AddClientPolicy(ClientPolicie clientPolicy);
        bool UpdateClientPolicy(ClientPolicie clientPolicy);
        bool SoftRemoveClientPolicy(int policyId, int clientId);
        IList<ClientPolicyBudget> GetAllPolicyBudgets(int policyId);
        IList<ClientPolicyBudget> GetClientPolicyBudgetByClientYear(int clientId, int year);
        bool AddClientPolicyBudget(ClientPolicyBudget budget);
        bool UpdateClientPolicyBudget(ClientPolicyBudget budget);
        IList<ClientPolicyBudget> GetAllPolicyBudgetsForClientPolicyYear(int clientId, int policyId, int year);
        ClientPolicyBudget GetAllPolicyBudgetsForPolicyYearMonth(int policyId, int year, string month);
        ClientPolicie GetClientPoliciesByPolicyId(int policyId);
        IList<CorporateProduct> GetAllCorporateProducts();
        IList<CorporateProduct> GetAllCorporateProductsByCoverageId(int coverageId);
        CorporateProduct GetCorporateProductById(int productId);
        IList<CorporateProductsXProduct> GetAllCorporateXProducts();
        bool DeleteCommission(int clientPolicyId);
        IList<Client> GetAllClients();
        bool UpdateCoverages(Coverage coverage);
        bool UpdateProduct(Product product);
    }
}