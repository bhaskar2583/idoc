﻿using IBS.Core.Entities;
using System.Linq;

namespace IBS.Service.Repositories
{
    public interface IClientRepository
    {
        IQueryable<Client> GetAll();
        Client GetById(int id);
        bool Add(Client client);
        bool Update(Client client);
        bool Delete(int id);
    }
}