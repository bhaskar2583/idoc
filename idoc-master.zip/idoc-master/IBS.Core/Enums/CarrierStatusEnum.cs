﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBS.Core.Enums
{
    public enum CarrierStatusEnum
    {
        Active,
        InActive,
        None
    }
}
